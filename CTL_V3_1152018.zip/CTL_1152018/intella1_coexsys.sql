-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 05, 2018 at 10:03 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intella1_coexsys`
--

-- --------------------------------------------------------

--
-- Table structure for table `cxs_aliases`
--

CREATE TABLE `cxs_aliases` (
  `ALIAS_ID` bigint(20) NOT NULL,
  `ALIAS_NAME` varchar(50) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(50) NOT NULL DEFAULT '',
  `PROJECT_NUMBER` varchar(50) NOT NULL DEFAULT '',
  `TASK_NUMBER` varchar(50) NOT NULL DEFAULT '',
  `EXPENDITURE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `EMPLOYEE_NUMBER` varchar(30) NOT NULL DEFAULT '',
  `XXTPAA_COMMENT` varchar(240) NOT NULL DEFAULT '',
  `LAST_UPDATE_LOGIN` bigint(20) NOT NULL DEFAULT '0',
  `ORG_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_STATUS` varchar(50) NOT NULL DEFAULT '',
  `RESOURCE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `CATEGORY` varchar(240) NOT NULL DEFAULT '',
  `SUB_CATEGORY` varchar(240) NOT NULL DEFAULT '',
  `ETRACKER_CCD_NO` varchar(50) NOT NULL DEFAULT '',
  `COPY_ALLOWED` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `AUTOPOPULATE` varchar(1) NOT NULL DEFAULT '',
  `WBS_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALIAS_TYPE` varchar(350) NOT NULL DEFAULT '',
  `ALIAS_CLASS` varchar(50) NOT NULL DEFAULT '',
  `ADDINUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_aliases`
--

INSERT INTO `cxs_aliases` (`ALIAS_ID`, `ALIAS_NAME`, `PERIOD_NAME`, `PROJECT_NUMBER`, `TASK_NUMBER`, `EXPENDITURE_TYPE`, `DESCRIPTION`, `EMPLOYEE_NUMBER`, `XXTPAA_COMMENT`, `LAST_UPDATE_LOGIN`, `ORG_ID`, `ALIAS_STATUS`, `RESOURCE_TYPE`, `CATEGORY`, `SUB_CATEGORY`, `ETRACKER_CCD_NO`, `COPY_ALLOWED`, `ACTIVE_FLAG`, `AUTOPOPULATE`, `WBS_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ALIAS_TYPE`, `ALIAS_CLASS`, `ADDINUSE_FLAG`, `SITE_ID`) VALUES
(1, 'AL', '', '', '', '', 'LEAVE', '', '', 0, 0, '', '', '', '', '', 'N', 'Y', 'N', 1, 1, '2018-10-11 23:31:40', 1, '2018-10-31 17:34:50', 'PTO-Personal Time Off', 'Leave', 'Y', 1),
(2, 'WO-250000', '', '', '', '', 'WO-250000', '', '', 0, 0, '', '', '', '', '', 'N', 'Y', 'Y', 2, 3, '2018-10-31 11:47:45', 3, '2018-10-31 17:47:45', 'RES-Resource Specific Alias', '', '', 1),
(3, 'WO-250001', '', '', '', '', 'WO-250001', '', '', 0, 0, '', '', '', '', '', 'N', 'Y', 'Y', 3, 3, '2018-10-31 11:48:15', 3, '2018-10-31 17:48:24', 'RES-Resource Specific Alias', '', '', 1),
(4, 'PTO', '', '', '', '', 'PERSONAL LEAVE', '', '', 0, 0, '', '', '', '', '', 'N', 'Y', 'Y', 0, 1, '2018-10-31 11:55:21', 1, '2018-10-31 17:55:21', 'PTO-Personal Time Off', 'Leave', '', 1),
(5, 'CTO', '', '', '', '', 'CTO', '', '', 0, 0, '', '', '', '', '', 'N', 'Y', 'N', 0, 1, '2018-10-31 11:55:49', 1, '2018-10-31 17:55:49', 'CTO-Compensatory Time Off', 'Leave', '', 1),
(6, 'AL2', '', '', '', '', 'AL2', '', '', 0, 0, '', '', '', '', '', 'Y', 'Y', 'Y', 0, 1, '2018-11-01 12:50:16', 1, '2018-11-01 18:51:32', 'PTO-Personal Time Off', 'Leave', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_am_approval_mgmt`
--

CREATE TABLE `cxs_am_approval_mgmt` (
  `USER_ID` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `REFERENCE_APPROVER_ID` bigint(20) NOT NULL,
  `APPROVER_TYPE` varchar(40) NOT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_am_app_admin`
--

CREATE TABLE `cxs_am_app_admin` (
  `APP_ADM_ID` bigint(20) NOT NULL,
  `USER_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `APPLICATION_ID` bigint(20) NOT NULL,
  `START_DATE_ACTIVE` date DEFAULT NULL,
  `END_DATE_ACTIVE` date DEFAULT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_am_personal_alias`
--

CREATE TABLE `cxs_am_personal_alias` (
  `USER_ID` bigint(20) DEFAULT NULL,
  `CREATED_BY` bigint(20) DEFAULT NULL,
  `CREATION_DATE` date DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(20) DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_NAME` varchar(40) DEFAULT NULL,
  `DESCRIPTION` varchar(240) DEFAULT NULL,
  `DEPARTMENT` varchar(40) DEFAULT NULL,
  `WBS_COMBINATION_ID` bigint(20) DEFAULT NULL,
  `ACTIVE_FLAG` varchar(1) DEFAULT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_am_roles`
--

CREATE TABLE `cxs_am_roles` (
  `ROLE_ID` int(11) NOT NULL,
  `ROLE_NAME` varchar(40) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `CREATED_BY` int(11) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` int(11) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATE_NEW_USER` varchar(1) NOT NULL,
  `VIEW_ONLY` varchar(1) NOT NULL,
  `UPDATE_ONLY` varchar(1) NOT NULL,
  `VIEW_SUBSCRIBERS` varchar(1) NOT NULL,
  `SUBMIT_CUSTOM` varchar(1) NOT NULL,
  `ALLOW_CHAT` varchar(1) NOT NULL,
  `VIEW_SLA` varchar(1) NOT NULL,
  `EXISTING_USER` varchar(1) NOT NULL,
  `REMOVE_ACCESS` varchar(1) NOT NULL,
  `USAGE_HISTORY` varchar(1) NOT NULL,
  `TEMPORARY_APPROVER_ID` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_SITE_CONTACTS` varchar(1) NOT NULL,
  `OVERRIDE_INUSE` varchar(1) NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_am_roles`
--

INSERT INTO `cxs_am_roles` (`ROLE_ID`, `ROLE_NAME`, `DESCRIPTION`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `CREATE_NEW_USER`, `VIEW_ONLY`, `UPDATE_ONLY`, `VIEW_SUBSCRIBERS`, `SUBMIT_CUSTOM`, `ALLOW_CHAT`, `VIEW_SLA`, `EXISTING_USER`, `REMOVE_ACCESS`, `USAGE_HISTORY`, `TEMPORARY_APPROVER_ID`, `SITE_ID`, `UPDATE_SITE_CONTACTS`, `OVERRIDE_INUSE`) VALUES
(1, 'MOINROLE', 'MOINROLE', 1, '2018-10-16 22:14:42', 1, '2018-10-17 04:14:47', 'N', 'N', 'N', 'N', 'N', '', 'N', 'N', 'N', 'N', 0, 1, 'N', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `cxs_am_ta_rules`
--

CREATE TABLE `cxs_am_ta_rules` (
  `USER_ID` bigint(11) NOT NULL DEFAULT '0',
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `BIZ_MSG_FLAG` varchar(1) NOT NULL,
  `AUDIT_FLAG` varchar(1) NOT NULL,
  `ALLOW_NEGATIVE` varchar(1) NOT NULL,
  `ADVANCE_FOR_OVERTIME` varchar(1) NOT NULL,
  `UPDATE_SUBMITTED` varchar(1) NOT NULL,
  `OVERRIDE_PRIMARY` varchar(1) NOT NULL,
  `RECENT_TIMECARDS` double NOT NULL,
  `RETRO_ADJUST` varchar(1) NOT NULL,
  `MAX_DAILY_LIMIT` double NOT NULL,
  `AFT_ENTRY` varchar(1) NOT NULL,
  `RETRO_PERIOD_NUM` double NOT NULL,
  `ALLOW_COPY` varchar(1) NOT NULL,
  `COPY_ANYONE_TS_FLAG` varchar(1) NOT NULL,
  `APPROVE_ANYONE_TS` varchar(1) NOT NULL,
  `CREATE_ANYONE_TS` varchar(1) NOT NULL,
  `APPROVE_ANYONE_TS_TEAM` varchar(1) NOT NULL,
  `ALLOW_SUP_TS` varchar(1) NOT NULL,
  `ALLOW_PREAPPROVAL` varchar(1) NOT NULL,
  `CREATED_BY` bigint(11) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(11) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALLOW_OVERRIDE_WORKSHIFT` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_am_ta_rules`
--

INSERT INTO `cxs_am_ta_rules` (`USER_ID`, `RESOURCE_GROUP_ID`, `BIZ_MSG_FLAG`, `AUDIT_FLAG`, `ALLOW_NEGATIVE`, `ADVANCE_FOR_OVERTIME`, `UPDATE_SUBMITTED`, `OVERRIDE_PRIMARY`, `RECENT_TIMECARDS`, `RETRO_ADJUST`, `MAX_DAILY_LIMIT`, `AFT_ENTRY`, `RETRO_PERIOD_NUM`, `ALLOW_COPY`, `COPY_ANYONE_TS_FLAG`, `APPROVE_ANYONE_TS`, `CREATE_ANYONE_TS`, `APPROVE_ANYONE_TS_TEAM`, `ALLOW_SUP_TS`, `ALLOW_PREAPPROVAL`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ALLOW_OVERRIDE_WORKSHIFT`, `SITE_ID`) VALUES
(1, 0, '', '', '', '', '', '', 0, 'N', 0, '', 0, '', 'N', 'N', 'N', 'N', 'N', 'N', 1, '2018-10-18 21:21:27', 1, '2018-10-31 17:25:35', 'N', 1),
(3, 0, '', '', '', '', '', '', 0, 'Y', 0, '', 3, '', 'N', 'N', 'N', 'N', 'N', 'N', 1, '2018-11-01 07:23:51', 1, '2018-11-01 13:23:51', 'N', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_application_assignments`
--

CREATE TABLE `cxs_application_assignments` (
  `ASSIGNMENT_ID` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `APPLICATION_ROLE_ID` bigint(20) NOT NULL,
  `ROLE_START_DATE` date DEFAULT NULL,
  `ROLE_END_DATE` date DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_application_roles`
--

CREATE TABLE `cxs_application_roles` (
  `APPLICATION_ROLE_ID` bigint(20) NOT NULL,
  `ROLE_NAME` varchar(40) DEFAULT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_calendars`
--

CREATE TABLE `cxs_calendars` (
  `CALENDAR_ID` bigint(20) NOT NULL,
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `DESCR` varchar(240) NOT NULL DEFAULT '',
  `PERIOD_YEAR` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_TYPE` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FLAG_SYSTEMCREATED` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_common_words`
--

CREATE TABLE `cxs_common_words` (
  `COMMON_WORD_ID` bigint(20) NOT NULL,
  `WORD_NAME` varchar(240) DEFAULT '',
  `ACTIVE_FLAG` varchar(1) DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_daily_audit`
--

CREATE TABLE `cxs_daily_audit` (
  `AUDIT_ID` bigint(20) NOT NULL,
  `EMPLOYEE_NUMBER` varchar(40) NOT NULL DEFAULT '',
  `EMPLOYEE_NAME` varchar(40) NOT NULL DEFAULT '',
  `CREATEDBY_EMPNO` bigint(20) NOT NULL DEFAULT '0',
  `UPDATEDBY_EMPNO` bigint(20) NOT NULL DEFAULT '0',
  `CREATEDBY_ENAME` varchar(40) NOT NULL DEFAULT '',
  `UPDATEDBY_ENAME` varchar(40) NOT NULL DEFAULT '',
  `EI_NORM_ID` bigint(20) NOT NULL,
  `EI_DNORM_ID` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `EXPENDITURE_QTY` double NOT NULL,
  `STATUS_FLAG` varchar(40) NOT NULL DEFAULT '',
  `EXPENDITURE_DATE` date NOT NULL,
  `LAST_UPDATE` datetime DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_flex_schedule`
--

CREATE TABLE `cxs_flex_schedule` (
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `SCHEDULE_TYPE` varchar(40) NOT NULL DEFAULT '',
  `SCHEDULE_START_DATE` date DEFAULT NULL,
  `SCHEDULE_END_DATE` date DEFAULT NULL,
  `DAYS_IN_MONTH1` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH2` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH3` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH4` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH5` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH6` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH7` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH8` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH9` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH10` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH11` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH12` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH13` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH14` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH15` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH16` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH17` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH18` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH19` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH20` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH21` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH22` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH23` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH24` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH25` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH26` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH27` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH28` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH29` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH30` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH31` varchar(1) NOT NULL DEFAULT '',
  `SUNDAY` varchar(1) NOT NULL DEFAULT '',
  `MONDAY` varchar(1) NOT NULL DEFAULT '',
  `TUESDAY` varchar(1) NOT NULL DEFAULT '',
  `WEDNESDAY` varchar(1) NOT NULL DEFAULT '',
  `THURSDAY` varchar(1) NOT NULL DEFAULT '',
  `FRIDAY` varchar(1) NOT NULL DEFAULT '',
  `SATURDAY` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_holidays`
--

CREATE TABLE `cxs_holidays` (
  `HOLIDAY_CALENDAR_ID` bigint(20) NOT NULL,
  `CALENDAR_NAME` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_YEAR` varchar(10) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_holiday_calendar`
--

CREATE TABLE `cxs_holiday_calendar` (
  `CALENDAR_ID` bigint(20) NOT NULL,
  `HOLIDAY_CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `HOLIDAY_TAG_NAME` varchar(40) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `HOLIDAY_START_DATE` date DEFAULT NULL,
  `HOLIDAY_END_DATE` date DEFAULT NULL,
  `INUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ENFORCE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `RECESS_ALLOWED` varchar(1) NOT NULL DEFAULT '',
  `ENABLED_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_hours_deduction`
--

CREATE TABLE `cxs_hours_deduction` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALLOW_PAID_BREAK` varchar(1) NOT NULL DEFAULT '',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `REQUIRED_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `BREAK_HOURS` double NOT NULL DEFAULT '0',
  `BREAK_START_TIME` datetime DEFAULT NULL,
  `BREAK_END_TIME` datetime DEFAULT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_page_list`
--

CREATE TABLE `cxs_page_list` (
  `PAGE_ID` bigint(20) NOT NULL,
  `UI_VALUES` varchar(40) NOT NULL,
  `DB_VALUES` varchar(40) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_page_list`
--

INSERT INTO `cxs_page_list` (`PAGE_ID`, `UI_VALUES`, `DB_VALUES`, `LAST_UPDATE_DATE`) VALUES
(1, 'Contact Support Page', 'CS', '2018-07-31 11:12:48'),
(2, 'Login Issues', 'LI', '2018-07-31 11:12:48'),
(3, 'Performance', 'PF', '2018-07-31 11:12:48'),
(4, 'Access Management', 'AM', '2018-07-31 11:12:48'),
(5, 'Global Alias', 'GA', '2018-07-31 11:12:48'),
(6, 'Work Shift', 'WS', '2018-07-31 11:12:48'),
(7, 'Employee Alias', 'EA', '2018-07-31 11:12:48'),
(8, 'Resource Groups', 'RG', '2018-07-31 11:12:48'),
(9, 'Resources', 'RS', '2018-07-31 11:12:48'),
(10, 'Time Entry Page', 'TE', '2018-07-31 11:12:48'),
(11, 'Dashboard', 'DB', '2018-07-31 11:12:48'),
(12, 'Accounting Periods', 'AP', '2018-07-31 11:12:48'),
(13, 'Holiday Calendar', 'HC', '2018-07-31 11:12:48'),
(14, 'Time Policy', 'TP', '2018-07-31 11:12:48'),
(15, 'Submit Customization Request', 'SC', '2018-08-06 10:19:11');

-- --------------------------------------------------------

--
-- Table structure for table `cxs_password_reuse`
--

CREATE TABLE `cxs_password_reuse` (
  `USER_ID` int(11) NOT NULL,
  `LAST_UPDATE_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(15) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `CREATED_BY` bigint(15) NOT NULL,
  `XXT_PASSWORD` varchar(100) NOT NULL,
  `KOUNTER` int(11) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_periods`
--

CREATE TABLE `cxs_periods` (
  `PERIOD_ID` bigint(20) NOT NULL,
  `FROM_PERIOD_DATE` date NOT NULL,
  `TO_PERIOD_DATE` date NOT NULL,
  `PERIOD_YEAR` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(50) NOT NULL DEFAULT '',
  `STATUS` varchar(50) NOT NULL DEFAULT 'N',
  `ENTITY_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FLAG_INUSE` varchar(1) NOT NULL DEFAULT '',
  `CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_period_audit`
--

CREATE TABLE `cxs_period_audit` (
  `SORT_DATE` datetime DEFAULT NULL,
  `EI_NORM_ID` bigint(20) NOT NULL DEFAULT '0',
  `EXP_STATUS` varchar(12) NOT NULL DEFAULT '',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `FULL_NAME` varchar(240) NOT NULL DEFAULT '',
  `EMPLOYEE_NUMBER` varchar(30) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(35) NOT NULL DEFAULT '',
  `USER_NAME` varchar(40) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_policy_general`
--

CREATE TABLE `cxs_policy_general` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `EXCESS_HOURS_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `HOLIDAY_EARN_CREDIT` varchar(1) NOT NULL DEFAULT 'N',
  `CTO_OVERTIME` varchar(1) NOT NULL DEFAULT 'N',
  `OVERTIME_ALLOWED` varchar(1) NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_policy_header`
--

CREATE TABLE `cxs_policy_header` (
  `POLICY_ID` bigint(20) NOT NULL,
  `NAME` varchar(240) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ADDINUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_policy_time_earned1`
--

CREATE TABLE `cxs_policy_time_earned1` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `EXCESS_HOURS_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `HOLIDAY_EARN_CREDIT` varchar(1) NOT NULL DEFAULT 'N',
  `SHIFT_DIFFERENTIAL` varchar(1) NOT NULL DEFAULT 'N',
  `OVERTIME_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `REQUIRED_HOURS` double NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `EARN_TYPE` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `CTO_OVERTIME` varchar(1) NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_policy_time_off`
--

CREATE TABLE `cxs_policy_time_off` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `MAXIMUM_HOURS_ALLOWED` double DEFAULT NULL,
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_preapp_alias`
--

CREATE TABLE `cxs_preapp_alias` (
  `PREAPP_RULE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROW_NO` int(11) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_preapp_rules`
--

CREATE TABLE `cxs_preapp_rules` (
  `PREAPP_RULE_ID` bigint(20) NOT NULL,
  `PREAPPROVAL_TYPE` varchar(100) NOT NULL DEFAULT '',
  `QUOTA_HOURS` double NOT NULL DEFAULT '0',
  `CHARGE_TYPE` varchar(10) NOT NULL DEFAULT '',
  `BUDGET_HOURS` double NOT NULL DEFAULT '0',
  `TOLERANCE` double NOT NULL DEFAULT '0',
  `RECURRING_FLAG` varchar(1) NOT NULL DEFAULT '',
  `WEEKEND_HOURS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RULE_NAME` varchar(40) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT 'N',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT 'Y',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_resources`
--

CREATE TABLE `cxs_resources` (
  `RESOURCE_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(240) NOT NULL DEFAULT '',
  `MIDDLE_NAME` varchar(240) DEFAULT NULL,
  `LAST_NAME` varchar(240) NOT NULL DEFAULT '',
  `RESOURCE_TYPE` varchar(100) NOT NULL,
  `CONTRACTOR_TYPE_FLAG` varchar(100) NOT NULL DEFAULT '',
  `START_DATE_ACTIVE` date DEFAULT NULL,
  `END_DATE_ACTIVE` date DEFAULT NULL,
  `TIMEMANAGEMENTPOLICY_ID` bigint(20) NOT NULL,
  `PREAPPROVALRULES_ID` bigint(20) NOT NULL,
  `SUPREVISOR_ID` bigint(20) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `ENTITY_ID` bigint(20) NOT NULL,
  `RBAC_ID` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_SESSION_ID` bigint(20) NOT NULL DEFAULT '0',
  `AVAILABILTY_TYPE` varchar(40) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_resource_address`
--

CREATE TABLE `cxs_resource_address` (
  `ADDRESS_RESOURCE_ID` bigint(20) NOT NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `ADDRESS1` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS2` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS3` varchar(100) NOT NULL DEFAULT '',
  `CITY` varchar(100) NOT NULL DEFAULT '',
  `STATE` varchar(100) NOT NULL DEFAULT '',
  `COUNTRY` varchar(100) NOT NULL DEFAULT '',
  `POSTAL_CODE` varchar(50) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_resource_contact`
--

CREATE TABLE `cxs_resource_contact` (
  `CONTACT_RESOURCE_ID` bigint(20) NOT NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `PHONE_NUMBER` varchar(100) NOT NULL DEFAULT '',
  `EMAIL_ADDRESS` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACCEPTS_TEXTS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `SOCIAL_URL` varchar(100) NOT NULL DEFAULT '',
  `SOCIAL_URL_LABEL` varchar(240) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_resource_groups`
--

CREATE TABLE `cxs_resource_groups` (
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL,
  `RESOURCE_GROUP_NAME` varchar(40) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT 'Y',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TIME_POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROLE_ID` bigint(50) NOT NULL DEFAULT '0',
  `PREAPPROVAL_RULE_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_sites`
--

CREATE TABLE `cxs_sites` (
  `SITE_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(240) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(240) NOT NULL DEFAULT '',
  `JOB_TITLE` varchar(240) NOT NULL DEFAULT '',
  `EMAIL` varchar(240) NOT NULL DEFAULT '',
  `PHONE` varchar(40) NOT NULL DEFAULT '',
  `SITE_NAME` varchar(240) NOT NULL DEFAULT '',
  `SITE_CODE` varchar(100) NOT NULL DEFAULT '',
  `EMPLOYEE_BREAK` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL DEFAULT '0',
  `CREATION_DATE` date DEFAULT NULL,
  `UPDATED_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IS_APPROVAL` varchar(1) NOT NULL DEFAULT 'N',
  `SYSTEM_PASSWORD` varchar(240) NOT NULL DEFAULT '',
  `DATE_ACTIVATED` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_site_address`
--

CREATE TABLE `cxs_site_address` (
  `ADDRESS_ID` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL,
  `ADDRESS1` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS2` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS3` varchar(100) NOT NULL DEFAULT '',
  `CITY` varchar(100) NOT NULL DEFAULT '',
  `POSTAL_CODE` varchar(50) NOT NULL DEFAULT '',
  `STATE` varchar(100) NOT NULL DEFAULT '',
  `COUNTRY` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_site_contacts`
--

CREATE TABLE `cxs_site_contacts` (
  `CONTACT_ID` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(100) NOT NULL DEFAULT '',
  `PHONE` varchar(100) NOT NULL DEFAULT '',
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `PHONE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `TITLE` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_site_settings`
--

CREATE TABLE `cxs_site_settings` (
  `SITE_SETTINGS_ID` bigint(20) NOT NULL,
  `MANDATORY_PWD` bigint(20) NOT NULL,
  `INCORRECT_ATTEMPT` bigint(20) NOT NULL,
  `IDLE_SESSION` bigint(20) NOT NULL,
  `MINIMUM_ALLOWED` bigint(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `MAXIMUM_ALLOWED` bigint(20) NOT NULL,
  `DEFAULT_DATE_FORMAT` varchar(20) DEFAULT '',
  `DEFAULT_NUMBER_FORMAT` varchar(1) DEFAULT '',
  `DEFAULT_TIMEZONE` varchar(20) DEFAULT '',
  `ENFORCE_RECENT` varchar(1) DEFAULT '',
  `NUMBER_OF_RECENT` int(1) DEFAULT NULL,
  `ALLOW_SPECIALS` varchar(1) DEFAULT '',
  `ALLOW_UPPERCASE` varchar(1) DEFAULT '',
  `ALLOW_TIME_ENTRY` varchar(1) DEFAULT NULL,
  `ALLOW_LOWERCASE` varchar(1) DEFAULT '',
  `ALLOW_NUMERIC` varchar(1) DEFAULT '',
  `ENABLE_COMMON` varchar(1) DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ENABLE_AUDIT` varchar(1) NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_site_settings`
--

INSERT INTO `cxs_site_settings` (`SITE_SETTINGS_ID`, `MANDATORY_PWD`, `INCORRECT_ATTEMPT`, `IDLE_SESSION`, `MINIMUM_ALLOWED`, `image`, `MAXIMUM_ALLOWED`, `DEFAULT_DATE_FORMAT`, `DEFAULT_NUMBER_FORMAT`, `DEFAULT_TIMEZONE`, `ENFORCE_RECENT`, `NUMBER_OF_RECENT`, `ALLOW_SPECIALS`, `ALLOW_UPPERCASE`, `ALLOW_TIME_ENTRY`, `ALLOW_LOWERCASE`, `ALLOW_NUMERIC`, `ENABLE_COMMON`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`, `ENABLE_AUDIT`) VALUES
(1, 30, 25, 1243, 9, 'main_hires.jpg', 0, '', '', '', 'Y', 5, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 1, '2018-10-11', 1, '2018-10-30 17:57:57', 1, 'Y'),
(2, 30, 25, 1243, 9, '', 0, '', '', '', 'Y', 5, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 2, '2018-10-31', 2, '2018-10-31 16:08:24', 2, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `cxs_subscribers`
--

CREATE TABLE `cxs_subscribers` (
  `SUBSCRIBER_ID` bigint(20) NOT NULL,
  `USER_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(240) NOT NULL,
  `MIDDLE_INITIAL` varchar(40) NOT NULL,
  `LAST_NAME` varchar(240) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_support_history`
--

CREATE TABLE `cxs_support_history` (
  `SUPPORT_HISTORY_ID` bigint(20) NOT NULL,
  `SUPPORT_REQUEST_ID` bigint(20) NOT NULL,
  `UPDATE_COUNTER` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_STMT` varchar(2000) NOT NULL DEFAULT '',
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `PAGE_TYPE_ID` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_support_request`
--

CREATE TABLE `cxs_support_request` (
  `SUPPORT_REQUEST_ID` bigint(20) NOT NULL,
  `SR_NUMBER` varchar(40) NOT NULL DEFAULT '',
  `ISSUE_STMT` varchar(40) NOT NULL DEFAULT '',
  `PAGE_TYPE_ID` int(11) NOT NULL DEFAULT '0',
  `ISSUE_DESCRIPTION` varchar(2000) NOT NULL DEFAULT '',
  `MULTI_USER_FLAG` varchar(1) NOT NULL DEFAULT '',
  `WORKAROUND_FLAG` varchar(1) NOT NULL DEFAULT '',
  `IMPACT_STMT` varchar(100) NOT NULL DEFAULT '',
  `SR_STATUS` varchar(20) NOT NULL DEFAULT '',
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `CUSTOMIZATION_REQUEST` varchar(500) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_ta_modules`
--

CREATE TABLE `cxs_ta_modules` (
  `RESOURCE_GROUP_ID` bigint(20) DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `MODULE_NAME` varchar(40) DEFAULT NULL,
  `TYPE` varchar(50) NOT NULL,
  `CREATE_PRIV` varchar(1) DEFAULT NULL,
  `UPDATE_PRIV` varchar(1) DEFAULT NULL,
  `VIEW_PRIV` varchar(1) DEFAULT NULL,
  `ENABLE_AUDIT` varchar(1) DEFAULT NULL,
  `CREATED_BY` bigint(20) DEFAULT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROWNO` bigint(20) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_ta_modules`
--

INSERT INTO `cxs_ta_modules` (`RESOURCE_GROUP_ID`, `USER_ID`, `MODULE_NAME`, `TYPE`, `CREATE_PRIV`, `UPDATE_PRIV`, `VIEW_PRIV`, `ENABLE_AUDIT`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROWNO`, `SITE_ID`) VALUES
(0, 1, 'Time Management Policy', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:35', 1, 1),
(0, 1, 'Holiday Calendar', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 2, 1),
(0, 1, 'Time Entry', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 3, 1),
(0, 1, 'Global Aliases', 'Rbam-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 4, 1),
(0, 1, 'Resource Aliases', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 6, 1),
(0, 1, 'Create WBS', 'Rbam-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 10, 1),
(0, 1, 'Billing & Payment', 'Rbam-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 13, 1),
(0, 1, 'Manage Payment Methods', 'Rbam-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 15, 1),
(0, 1, 'Resource Management', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 16, 1),
(0, 1, 'Workshifts', 'TE-admin', 'N', 'N', 'N', 'N', 15, '2018-07-23 15:18:08', 1, '2018-10-31 17:25:36', 18, 1),
(0, 15, 'Time Management Policy', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:32:18', 1, 14),
(0, 15, 'Holiday Calendar', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 18:40:30', 2, 14),
(0, 15, 'Time Entry', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:34:47', 3, 14),
(0, 15, 'Global Aliases', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:35:29', 4, 14),
(0, 15, 'Resource Aliases', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-11 12:25:02', 6, 14),
(0, 15, 'PreApproval Rules', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:41:32', 7, 14),
(0, 15, 'Accounting Period', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:42:08', 8, 14),
(0, 15, 'Site Settings', 'Rbam-admin', 'N', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:42:32', 9, 14),
(0, 15, 'Create WBS', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:38:57', 10, 14),
(0, 15, 'Access Management', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:42:58', 11, 14),
(0, 15, 'Subscriber Admin', '', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-08-01 02:14:21', 12, 14),
(0, 15, 'Billing & Payment', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-10 16:51:04', 13, 14),
(0, 15, 'View Bill Payment', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:43:41', 14, 14),
(0, 15, 'Manage Payment Methods', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:39:17', 15, 14),
(0, 15, 'Resources', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:40:25', 16, 14),
(0, 15, 'Resource Group', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-09 17:44:52', 17, 14),
(0, 15, 'Workshifts', 'TE-admin', 'Y', 'Y', 'Y', 'N', 15, '2018-07-31 14:14:21', 15, '2018-10-11 12:35:29', 18, 14),
(0, 35, 'Time Management Policy', 'TE-admin', 'Y', 'Y', 'Y', 'N', 35, '2018-08-05 13:08:15', 35, '2018-10-11 10:07:29', 1, 18),
(0, 35, 'Holiday Calendar', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-08-05 13:08:15', 35, '2018-10-11 12:44:59', 2, 18),
(0, 35, 'Time Entry', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-08-05 13:08:15', 35, '2018-10-10 16:12:22', 3, 18),
(0, 36, 'Time Management Policy', 'TE-admin', 'Y', 'Y', 'Y', 'N', 35, '2018-08-05 15:25:54', 35, '2018-10-09 17:32:18', 1, 18),
(0, 36, 'Holiday Calendar', 'TE-admin', 'Y', 'Y', 'Y', 'N', 35, '2018-08-05 15:25:54', 35, '2018-10-09 18:40:30', 2, 18),
(0, 36, 'Time Entry', 'TE-admin', 'Y', 'Y', 'Y', 'N', 35, '2018-08-05 15:25:54', 35, '2018-10-09 17:34:47', 3, 18),
(0, 36, 'Global Aliases', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 35, '2018-08-05 15:25:54', 35, '2018-10-09 17:35:29', 4, 18),
(0, 42, 'Time Management Policy', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-16 15:12:05', 39, '2018-10-09 17:32:18', 1, 21),
(0, 42, 'Access Management', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-08-16 15:57:04', 39, '2018-10-09 17:42:58', 11, 21),
(0, 42, 'Create WBS', 'Rbam-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-08-16 16:22:43', 39, '2018-10-09 17:38:57', 10, 21),
(0, 42, 'Site Settings', 'Rbam-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-16 17:02:56', 39, '2018-10-09 17:42:32', 9, 21),
(0, 44, 'Time Management Policy', 'TE-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-08-17 10:39:40', 39, '2018-10-09 17:32:18', 1, 21),
(0, 44, 'Holiday Calendar', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:01', 39, '2018-10-09 18:40:30', 2, 21),
(0, 44, 'Time Entry', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-09 17:34:47', 3, 21),
(0, 44, 'Global Aliases', 'Rbam-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-09 17:35:29', 4, 21),
(0, 44, 'Search TimeSheets', '', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-08-18 00:36:32', 5, 21),
(0, 44, 'Resource Aliases', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-11 12:25:02', 6, 21),
(0, 44, 'PreApproval Rules', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-09 17:41:32', 7, 21),
(0, 44, 'Accounting Period', 'TE-admin', 'N', 'Y', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-09 17:42:08', 8, 21),
(0, 44, 'Site Settings', 'Rbam-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 12:36:32', 39, '2018-10-09 17:42:32', 9, 21),
(0, 44, 'Resources', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 14:13:14', 39, '2018-10-09 17:40:25', 16, 21),
(0, 44, 'Resource Group', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 14:13:14', 39, '2018-10-09 17:44:52', 17, 21),
(0, 44, 'Workshifts', 'TE-admin', 'N', 'N', 'Y', 'N', 39, '2018-08-17 14:13:14', 39, '2018-10-11 12:35:29', 18, 21),
(0, 54, 'Time Entry', 'TE-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-09-17 23:13:36', 39, '2018-10-09 17:34:47', 3, 21),
(0, 55, 'Time Entry', 'TE-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-09-17 23:14:13', 39, '2018-10-09 17:34:47', 3, 21),
(0, 53, 'Resources', 'TE-admin', 'Y', 'Y', 'Y', 'N', 39, '2018-10-07 11:50:38', 39, '2018-10-09 17:40:25', 16, 21),
(0, 35, 'Global Aliases', 'Rbam-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 01:30:54', 35, '2018-10-10 16:42:19', 4, 18),
(0, 35, 'Resource Aliases', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 13:22:21', 35, '2018-10-11 12:30:05', 6, 18),
(0, 35, 'Pre Approval Rules', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 13:22:21', 35, '2018-10-11 12:44:59', 7, 18),
(0, 35, 'Resource Management', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 13:22:21', 35, '2018-10-11 12:04:07', 16, 18),
(0, 35, 'Resource Groups', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 13:22:21', 35, '2018-10-11 12:04:07', 17, 18),
(0, 35, 'Workshifts', 'TE-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-09 13:22:21', 35, '2018-10-11 12:35:29', 18, 18),
(0, 35, 'Site Settings', 'Rbam-admin', 'N', 'Y', 'Y', 'N', 35, '2018-10-10 03:48:52', 35, '2018-10-10 16:06:08', 9, 18),
(0, 35, 'Access Management', 'Rbam-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-10 03:48:52', 35, '2018-10-10 16:06:24', 11, 18),
(0, 35, 'Create WBS', '', 'Y', 'N', 'Y', 'N', 35, '2018-10-10 04:42:19', 35, '2018-10-10 16:42:19', 10, 18),
(0, 35, 'Billing & Payment', 'Rbam-admin', 'Y', 'N', 'Y', 'N', 35, '2018-10-10 04:42:19', 35, '2018-10-10 16:51:04', 13, 18),
(0, 35, 'View Bill Payment', '', 'Y', 'N', 'Y', 'N', 35, '2018-10-10 04:42:19', 35, '2018-10-10 16:42:19', 14, 18),
(0, 35, 'Search TimeSheets', '', 'N', 'N', 'Y', 'N', 35, '2018-10-11 16:48:42', 35, '2018-10-20 02:48:11', 5, 18),
(0, 57, 'Search TimeSheets', '', 'N', 'N', 'Y', 'N', 57, '2018-10-19 22:22:16', 57, '2018-10-20 10:22:16', 5, 33),
(0, 57, 'Resource Management', '', 'Y', 'Y', 'Y', 'N', 57, '2018-10-22 21:44:35', 57, '2018-10-23 09:44:35', 16, 33),
(0, 60, 'Time Management Policy', '', 'Y', 'Y', 'Y', 'N', 57, '2018-10-22 21:51:14', 57, '2018-10-23 09:51:14', 1, 33),
(0, 60, 'Time Entry', '', 'Y', 'Y', 'Y', 'N', 57, '2018-10-22 21:51:14', 57, '2018-10-23 09:51:14', 3, 33),
(0, 61, 'Time Management Policy', '', 'Y', 'N', 'Y', 'N', 57, '2018-10-22 21:51:35', 57, '2018-10-23 09:51:35', 1, 33),
(0, 61, 'Time Entry', '', 'Y', 'N', 'Y', 'N', 57, '2018-10-22 21:51:35', 57, '2018-10-23 09:51:35', 3, 33),
(0, 61, 'Search TimeSheets', '', 'N', 'N', 'Y', 'N', 57, '2018-10-22 21:54:29', 57, '2018-10-23 09:54:29', 5, 33),
(0, 60, 'Search TimeSheets', '', 'N', 'N', 'Y', 'N', 57, '2018-10-22 23:45:07', 57, '2018-10-23 12:06:58', 5, 33),
(0, 3, 'Time Management Policy', '', 'Y', 'Y', 'Y', 'N', 1, '2018-11-01 12:41:11', 1, '2018-11-01 18:41:11', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_temp_approver`
--

CREATE TABLE `cxs_temp_approver` (
  `USER_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PERIOD_ID` bigint(20) NOT NULL,
  `ALIAS_ID` bigint(20) NOT NULL,
  `ACTIVE_FLAG` varchar(1) NOT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_te_approved`
--

CREATE TABLE `cxs_te_approved` (
  `EI_APPROVAL_ID` bigint(20) NOT NULL,
  `TE_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ADJUSTED_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `TIME_STATUS` varchar(1) NOT NULL DEFAULT '',
  `INTERFACE_STATUS` varchar(1) NOT NULL DEFAULT '',
  `ACTUAL_HOURS` float NOT NULL DEFAULT '0',
  `BUDGETED_HOURS` float NOT NULL DEFAULT '0',
  `COMMENT` varchar(250) NOT NULL DEFAULT '',
  `ENTRY_DATE` date NOT NULL,
  `APPROVAL_DATE` date NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_te_approved`
--

INSERT INTO `cxs_te_approved` (`EI_APPROVAL_ID`, `TE_ID`, `RESOURCE_ID`, `ALIAS_ID`, `ADJUSTED_HOURS`, `TIME_STATUS`, `INTERFACE_STATUS`, `ACTUAL_HOURS`, `BUDGETED_HOURS`, `COMMENT`, `ENTRY_DATE`, `APPROVAL_DATE`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES
(1, 2, 5, 3, 0, '', '', 8, 0, 'DONE', '2018-10-30', '2018-10-31', 1, '2018-10-31 12:02:51', 1, '2018-10-31 18:02:51', 0),
(2, 2, 5, 2, 0, '', '', 8, 0, 'DONE', '2018-10-29', '2018-10-31', 1, '2018-10-31 12:02:54', 1, '2018-10-31 18:02:54', 0),
(3, 2, 5, 2, 0, '', '', 1, 0, '', '2018-10-31', '2018-10-31', 1, '2018-10-31 12:13:34', 1, '2018-10-31 18:13:34', 0),
(4, 2, 5, 3, 0, '', '', 1, 0, '', '2018-10-31', '2018-10-31', 1, '2018-10-31 12:13:37', 1, '2018-10-31 18:13:37', 0),
(5, 2, 5, 2, 0, '', '', 1, 0, '', '2018-10-30', '2018-10-31', 1, '2018-10-31 12:13:40', 1, '2018-10-31 18:13:40', 0),
(6, 2, 5, 3, 0, '', '', 8, 0, '', '2018-10-30', '2018-10-31', 1, '2018-10-31 12:13:42', 1, '2018-10-31 18:13:42', 0),
(7, 2, 5, 3, 0, '', '', 1, 0, '', '2018-10-30', '2018-10-31', 1, '2018-10-31 12:13:42', 1, '2018-10-31 18:13:42', 0),
(8, 2, 5, 2, 0, '', '', 8, 0, '', '2018-10-29', '2018-10-31', 1, '2018-10-31 12:13:45', 1, '2018-10-31 18:13:45', 0),
(9, 2, 5, 2, 0, '', '', 1, 0, '', '2018-10-29', '2018-10-31', 1, '2018-10-31 12:13:45', 1, '2018-10-31 18:13:45', 0),
(10, 2, 5, 3, 0, '', '', 2, 0, 'DONE', '2018-10-29', '2018-10-31', 1, '2018-10-31 12:13:47', 1, '2018-10-31 18:13:47', 0),
(11, 2, 5, 3, 0, '', '', 1, 0, 'DONE', '2018-10-29', '2018-10-31', 1, '2018-10-31 12:13:47', 1, '2018-10-31 18:13:47', 0),
(12, 3, 5, 2, 0, '', '', 1, 0, '', '2018-11-01', '2018-11-01', 1, '2018-11-01 08:54:45', 1, '2018-11-01 14:54:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_te_file`
--

CREATE TABLE `cxs_te_file` (
  `DETAIL_ID` bigint(20) NOT NULL,
  `TE_ID` bigint(20) NOT NULL DEFAULT '0',
  `APPROVAL_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `WBS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `SEED_ALIAS` varchar(240) NOT NULL,
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `ENTRY_DATE` date DEFAULT NULL,
  `HOURS` float DEFAULT NULL,
  `STATUS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `COMMENT` varchar(250) NOT NULL DEFAULT '',
  `ENTRY_TYPE` varchar(1) NOT NULL DEFAULT '',
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED_LOGIN` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SHIFT` varchar(100) NOT NULL DEFAULT '',
  `APPROVER_COMMENT` varchar(100) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_te_file`
--

INSERT INTO `cxs_te_file` (`DETAIL_ID`, `TE_ID`, `APPROVAL_ID`, `RESOURCE_ID`, `WBS_ID`, `ALIAS_ID`, `SEED_ALIAS`, `PERIOD_ID`, `ENTRY_DATE`, `HOURS`, `STATUS_FLAG`, `COMMENT`, `ENTRY_TYPE`, `ROW_NO`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATED_LOGIN`, `LAST_UPDATE_DATE`, `SHIFT`, `APPROVER_COMMENT`, `SITE_ID`) VALUES
(1, 1, 3, 1, 1, 1, '', 4, '2018-10-22', 8, 'S', '', 'A', 1, 1, '2018-10-23 22:52:50', 1, 0, '2018-10-24 04:52:54', 'STD - Straight Time /Day', '', 1),
(2, 1, 3, 1, 1, 1, '', 4, '2018-10-23', 8, 'S', '', 'A', 2, 1, '2018-10-23 22:54:40', 1, 0, '2018-10-24 04:54:40', 'STD - Straight Time /Day', '', 1),
(3, 1, 3, 1, 1, 1, '', 4, '2018-10-23', 2, 'A', '', 'A', 3, 1, '2018-10-23 23:21:40', 1, 0, '2018-10-24 05:21:43', 'STD - Straight Time /Day', '', 1),
(4, 1, 3, 1, 1, 1, '', 4, '2018-10-22', 1, 'A', '', 'A', 4, 1, '2018-10-25 07:15:02', 1, 0, '2018-10-25 13:16:20', 'STD - Straight Time /Day', '', 1),
(5, 1, 3, 1, 1, 1, '', 4, '2018-10-23', 1, 'A', '', 'A', 5, 1, '2018-10-25 07:18:22', 1, 0, '2018-10-25 13:18:22', 'STD - Straight Time /Day', '', 1),
(6, 1, 3, 1, 1, 1, '', 4, '2018-10-29', 8, 'A', '', 'A', 1, 1, '2018-10-30 11:58:57', 1, 0, '2018-10-30 17:59:01', 'STD - Straight Time /Day', '', 1),
(7, 1, 3, 1, 1, 1, '', 4, '2018-10-29', 2, 'A', '', 'A', 2, 1, '2018-10-31 07:06:49', 1, 0, '2018-10-31 13:06:49', 'STD - Straight Time /Day', '', 1),
(8, 2, 2, 5, 2, 2, '', 4, '2018-10-29', 8, 'A', '', 'A', 1, 3, '2018-10-31 11:58:25', 1, 0, '2018-10-31 18:13:45', 'STD - Straight Time /Day', '', 1),
(9, 2, 2, 5, 3, 3, '', 4, '2018-10-30', 8, 'A', '', 'A', 2, 3, '2018-10-31 11:58:25', 1, 0, '2018-10-31 18:13:42', 'STD - Straight Time /Day', '', 1),
(10, 2, 2, 5, 3, 3, '', 4, '2018-10-29', 2, 'S', '', 'A', 2, 3, '2018-10-31 11:59:10', 3, 0, '2018-11-01 14:51:46', 'STD - Straight Time /Day', '', 1),
(17, 2, 2, 5, 3, 3, '', 4, '2018-10-29', 2, 'W', '', 'A', 5, 3, '2018-10-31 16:54:55', 3, 0, '2018-10-31 22:57:06', 'STD - Straight Time /Day', '', 1),
(11, 2, 2, 5, 2, 2, '', 4, '2018-10-29', 1, 'A', '', 'A', 3, 3, '2018-10-31 12:11:19', 1, 0, '2018-10-31 18:13:45', 'STD - Straight Time /Day', '', 1),
(12, 2, 2, 5, 3, 3, '', 4, '2018-10-29', 1, 'S', '', 'A', 4, 3, '2018-10-31 12:11:19', 3, 0, '2018-11-01 14:51:46', 'STD - Straight Time /Day', '', 1),
(13, 2, 2, 5, 2, 2, '', 4, '2018-10-30', 1, 'A', '', 'A', 3, 3, '2018-10-31 12:11:19', 1, 0, '2018-10-31 18:13:40', 'STD - Straight Time /Day', '', 1),
(14, 2, 2, 5, 3, 3, '', 4, '2018-10-30', 1, 'A', '', 'A', 4, 3, '2018-10-31 12:11:19', 1, 0, '2018-10-31 18:13:42', 'STD - Straight Time /Day', '', 1),
(15, 2, 2, 5, 2, 2, '', 4, '2018-10-31', 1, 'A', '', 'A', 3, 3, '2018-10-31 12:11:19', 1, 0, '2018-10-31 18:13:34', 'STD - Straight Time /Day', '', 1),
(16, 2, 2, 5, 3, 3, '', 4, '2018-10-31', 1, 'A', '', 'A', 4, 3, '2018-10-31 12:11:19', 1, 0, '2018-10-31 18:13:37', 'STD - Straight Time /Day', '', 1),
(18, 3, 2, 5, 2, 2, '', 5, '2018-11-01', 1, 'A', '', 'A', 1, 3, '2018-11-01 08:54:06', 1, 0, '2018-11-01 14:54:45', 'STD - Straight Time /Day', '', 1),
(19, 4, 1, 2, 0, 6, '', 5, '2018-11-01', 8, 'S', 'SOME NOTE', 'A', 1, 1, '2018-11-01 12:58:50', 1, 0, '2018-11-01 18:58:52', 'STD - Straight Time /Day', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_te_header`
--

CREATE TABLE `cxs_te_header` (
  `TE_ID` bigint(20) NOT NULL,
  `TE_NAME` varchar(40) NOT NULL,
  `TE_PREFIX` varchar(20) NOT NULL,
  `TE_DESCR` varchar(240) NOT NULL DEFAULT 'Y',
  `PAY_PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID2` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID3` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID4` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID5` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID6` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID7` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID8` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID9` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID10` bigint(20) NOT NULL DEFAULT '0',
  `TEMPORARY_SUPERVISOR` bigint(20) NOT NULL DEFAULT '0',
  `STATUS` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_LOGIN` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cxs_te_header`
--

INSERT INTO `cxs_te_header` (`TE_ID`, `TE_NAME`, `TE_PREFIX`, `TE_DESCR`, `PAY_PERIOD_ID`, `RESOURCE_ID`, `SUPERVISOR_ID`, `SUPERVISOR_ID2`, `SUPERVISOR_ID3`, `SUPERVISOR_ID4`, `SUPERVISOR_ID5`, `SUPERVISOR_ID6`, `SUPERVISOR_ID7`, `SUPERVISOR_ID8`, `SUPERVISOR_ID9`, `SUPERVISOR_ID10`, `TEMPORARY_SUPERVISOR`, `STATUS`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_LOGIN`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES
(1, 'RVAISHNAV- OCT-2018 ', 'SEP', '', 4, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Open', 1, '2018-10-18 23:48:28', 1, 0, '2018-10-19 05:48:28', 1),
(2, 'JSMITH- OCT-2018 ', 'OCT', '', 4, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Open', 3, '2018-10-31 11:49:51', 3, 0, '2018-10-31 17:49:51', 1),
(3, 'JSMITH- NOV-2018 ', 'SEMI-', '', 5, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Open', 3, '2018-11-01 08:53:42', 3, 0, '2018-11-01 14:53:42', 1),
(4, 'PPAUL- NOV-2018 ', 'PP', '', 5, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Open', 1, '2018-11-01 09:03:07', 1, 0, '2018-11-01 15:03:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cxs_users`
--

CREATE TABLE `cxs_users` (
  `USER_ID` bigint(20) NOT NULL,
  `USER_NAME` varchar(40) DEFAULT NULL,
  `ENC_KEY` varchar(240) DEFAULT NULL,
  `TEMP_PASSWORD` varchar(1) DEFAULT NULL,
  `RESET_DAYS` bigint(20) DEFAULT NULL,
  `PSW_RESET_DATE` date NOT NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `ROLE_ID` bigint(20) NOT NULL,
  `ROLE_START_DATE` date NOT NULL,
  `ROLE_END_DATE` date NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date NOT NULL,
  `PWD_RULE_CODE` varchar(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_LOGIN_TIME` datetime NOT NULL,
  `LAST_LOGOUT_TIME` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_users_favorites`
--

CREATE TABLE `cxs_users_favorites` (
  `USER_ID` bigint(20) NOT NULL,
  `FEATURE_NAME` varchar(40) NOT NULL,
  `PAGE_NAME` varchar(40) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_NAME` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_wbs`
--

CREATE TABLE `cxs_wbs` (
  `WBS_ID` bigint(20) NOT NULL,
  `SEQUENCE` bigint(20) NOT NULL DEFAULT '0',
  `SEGMENT1` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT2` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT3` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT4` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT5` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT6` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT7` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT8` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT9` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT10` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT11` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT12` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT13` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT14` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT15` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION1` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION2` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION3` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION4` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION5` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION6` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION7` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION8` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION9` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION10` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION11` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION12` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION13` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION14` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION15` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG1` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG2` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG3` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG4` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG5` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG6` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG7` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG8` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG9` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG10` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG11` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG12` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG13` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG14` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG15` varchar(100) NOT NULL DEFAULT '',
  `IN_USE1` varchar(100) NOT NULL DEFAULT '',
  `IN_USE2` varchar(100) NOT NULL DEFAULT '',
  `IN_USE3` varchar(100) NOT NULL DEFAULT '',
  `IN_USE4` varchar(100) NOT NULL DEFAULT '',
  `IN_USE5` varchar(100) NOT NULL DEFAULT '',
  `IN_USE6` varchar(100) NOT NULL DEFAULT '',
  `IN_USE7` varchar(100) NOT NULL DEFAULT '',
  `IN_USE8` varchar(100) NOT NULL DEFAULT '',
  `IN_USE9` varchar(100) NOT NULL DEFAULT '',
  `IN_USE10` varchar(100) NOT NULL DEFAULT '',
  `IN_USE11` varchar(100) NOT NULL DEFAULT '',
  `IN_USE12` varchar(100) NOT NULL DEFAULT '',
  `IN_USE13` varchar(100) NOT NULL DEFAULT '',
  `IN_USE14` varchar(100) NOT NULL DEFAULT '',
  `IN_USE15` varchar(100) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_wbs123`
--

CREATE TABLE `cxs_wbs123` (
  `WBS_ID` bigint(20) NOT NULL,
  `SEQUENCE` bigint(20) NOT NULL DEFAULT '0',
  `SEGMENT1` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT2` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT3` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT4` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT5` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT6` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT7` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT8` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT9` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT10` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT11` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT12` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT13` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT14` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT15` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE1` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE2` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE3` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE4` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE5` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE6` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE7` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE8` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE9` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE10` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE11` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE12` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE13` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE14` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE15` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION1` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION2` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION3` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION4` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION5` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION6` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION7` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION8` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION9` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION10` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION11` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION12` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION13` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION14` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION15` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP1` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP2` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP3` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP4` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP5` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP6` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP7` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP8` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP9` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP10` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP11` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP12` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP13` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP14` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP15` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG1` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG2` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG3` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG4` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG5` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG6` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG7` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG8` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG9` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG10` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG11` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG12` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG13` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG14` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG15` varchar(100) NOT NULL DEFAULT '',
  `IN_USE1` varchar(100) NOT NULL DEFAULT '',
  `IN_USE2` varchar(100) NOT NULL DEFAULT '',
  `IN_USE3` varchar(100) NOT NULL DEFAULT '',
  `IN_USE4` varchar(100) NOT NULL DEFAULT '',
  `IN_USE5` varchar(100) NOT NULL DEFAULT '',
  `IN_USE6` varchar(100) NOT NULL DEFAULT '',
  `IN_USE7` varchar(100) NOT NULL DEFAULT '',
  `IN_USE8` varchar(100) NOT NULL DEFAULT '',
  `IN_USE9` varchar(100) NOT NULL DEFAULT '',
  `IN_USE10` varchar(100) NOT NULL DEFAULT '',
  `IN_USE11` varchar(100) NOT NULL DEFAULT '',
  `IN_USE12` varchar(100) NOT NULL DEFAULT '',
  `IN_USE13` varchar(100) NOT NULL DEFAULT '',
  `IN_USE14` varchar(100) NOT NULL DEFAULT '',
  `IN_USE15` varchar(100) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_workshifts`
--

CREATE TABLE `cxs_workshifts` (
  `WORKSHIFT_ID` bigint(20) NOT NULL,
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `TIMEZONE` varchar(240) NOT NULL DEFAULT '',
  `WORKSHIFT_TYPE` varchar(40) NOT NULL DEFAULT '',
  `PART_TIME` varchar(100) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cxs_workshifts_detail`
--

CREATE TABLE `cxs_workshifts_detail` (
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `BEGIN_WORKDAY` varchar(40) NOT NULL DEFAULT '',
  `DAILY_WORK_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(11) NOT NULL DEFAULT '0',
  `SHIFT_HOURS` float NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_applications`
--

CREATE TABLE `sys_applications` (
  `APPLICATION_ID` bigint(20) NOT NULL,
  `NAME` varchar(240) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `DATE_ENABLED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_applications`
--

INSERT INTO `sys_applications` (`APPLICATION_ID`, `NAME`, `DESCRIPTION`, `DATE_ENABLED`) VALUES
(1, 'RBAM', '', '2018-08-01 07:35:27'),
(2, 'Time Accounting', '', '2018-08-08 10:38:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cxs_aliases`
--
ALTER TABLE `cxs_aliases`
  ADD PRIMARY KEY (`ALIAS_ID`),
  ADD UNIQUE KEY `ALIAS_NAME_2` (`ALIAS_NAME`),
  ADD UNIQUE KEY `ALIAS_NAME_3` (`ALIAS_NAME`,`SITE_ID`),
  ADD KEY `WBS_ID` (`WBS_ID`),
  ADD KEY `ALIAS_NAME` (`ALIAS_NAME`),
  ADD KEY `PERIOD_NAME` (`PERIOD_NAME`),
  ADD KEY `PROJECT_NUMBER` (`PROJECT_NUMBER`),
  ADD KEY `TASK_NUMBER` (`TASK_NUMBER`),
  ADD KEY `EXPENDITURE_TYPE` (`EXPENDITURE_TYPE`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `EMPLOYEE_NUMBER` (`EMPLOYEE_NUMBER`),
  ADD KEY `XXTPAA_COMMENT` (`XXTPAA_COMMENT`),
  ADD KEY `LAST_UPDATE_LOGIN` (`LAST_UPDATE_LOGIN`),
  ADD KEY `ORG_ID` (`ORG_ID`),
  ADD KEY `ALIAS_STATUS` (`ALIAS_STATUS`),
  ADD KEY `RESOURCE_TYPE` (`RESOURCE_TYPE`),
  ADD KEY `CATEGORY` (`CATEGORY`),
  ADD KEY `SUB_CATEGORY` (`SUB_CATEGORY`),
  ADD KEY `ETRACKER_CCD_NO` (`ETRACKER_CCD_NO`),
  ADD KEY `COPY_ALLOWED` (`COPY_ALLOWED`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `AUTOPOPULATE` (`AUTOPOPULATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `ALIAS_TYPE` (`ALIAS_TYPE`),
  ADD KEY `ALIAS_CLASS` (`ALIAS_CLASS`),
  ADD KEY `ADDINUSE_FLAG` (`ADDINUSE_FLAG`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_am_approval_mgmt`
--
ALTER TABLE `cxs_am_approval_mgmt`
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `REFERENCE_APPROVER_ID` (`REFERENCE_APPROVER_ID`),
  ADD KEY `APPROVER_TYPE` (`APPROVER_TYPE`),
  ADD KEY `ROWNO` (`ROWNO`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_am_app_admin`
--
ALTER TABLE `cxs_am_app_admin`
  ADD PRIMARY KEY (`APP_ADM_ID`),
  ADD UNIQUE KEY `USER_ID_2` (`USER_ID`,`APPLICATION_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `APPLICATION_ID` (`APPLICATION_ID`),
  ADD KEY `START_DATE_ACTIVE` (`START_DATE_ACTIVE`),
  ADD KEY `END_DATE_ACTIVE` (`END_DATE_ACTIVE`),
  ADD KEY `ROWNO` (`ROWNO`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_am_personal_alias`
--
ALTER TABLE `cxs_am_personal_alias`
  ADD PRIMARY KEY (`ALIAS_ID`),
  ADD UNIQUE KEY `ALIAS_NAME_2` (`ALIAS_NAME`,`WBS_COMBINATION_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `ALIAS_NAME` (`ALIAS_NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `DEPARTMENT` (`DEPARTMENT`),
  ADD KEY `WBS_COMBINATION_ID` (`WBS_COMBINATION_ID`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_am_roles`
--
ALTER TABLE `cxs_am_roles`
  ADD PRIMARY KEY (`ROLE_ID`),
  ADD UNIQUE KEY `ROLE_NAME_2` (`ROLE_NAME`),
  ADD UNIQUE KEY `ROLE_NAME_3` (`ROLE_NAME`,`SITE_ID`),
  ADD KEY `ROLE_NAME` (`ROLE_NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `CREATE_NEW_USER` (`CREATE_NEW_USER`),
  ADD KEY `VIEW_ONLY` (`VIEW_ONLY`),
  ADD KEY `UPDATE_ONLY` (`UPDATE_ONLY`),
  ADD KEY `VIEW_SUBSCRIBERS` (`VIEW_SUBSCRIBERS`),
  ADD KEY `SUBMIT_CUSTOM` (`SUBMIT_CUSTOM`),
  ADD KEY `ALLOW_CHAT` (`ALLOW_CHAT`),
  ADD KEY `OVERRIDE_INUSE` (`OVERRIDE_INUSE`);

--
-- Indexes for table `cxs_am_ta_rules`
--
ALTER TABLE `cxs_am_ta_rules`
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `BIZ_MSG_FLAG` (`BIZ_MSG_FLAG`),
  ADD KEY `AUDIT_FLAG` (`AUDIT_FLAG`),
  ADD KEY `ALLOW_NEGATIVE` (`ALLOW_NEGATIVE`),
  ADD KEY `ADVANCE_FOR_OVERTIME` (`ADVANCE_FOR_OVERTIME`),
  ADD KEY `UPDATE_SUBMITTED` (`UPDATE_SUBMITTED`),
  ADD KEY `OVERRIDE_PRIMARY` (`OVERRIDE_PRIMARY`),
  ADD KEY `RECENT_TIMECARDS` (`RECENT_TIMECARDS`),
  ADD KEY `RETRO_ADJUST` (`RETRO_ADJUST`),
  ADD KEY `MAX_DAILY_LIMIT` (`MAX_DAILY_LIMIT`),
  ADD KEY `AFT_ENTRY` (`AFT_ENTRY`),
  ADD KEY `RETRO_PERIOD_NUM` (`RETRO_PERIOD_NUM`),
  ADD KEY `ALLOW_COPY` (`ALLOW_COPY`),
  ADD KEY `COPY_ANYONE_TS_FLAG` (`COPY_ANYONE_TS_FLAG`),
  ADD KEY `APPROVE_ANYONE_TS` (`APPROVE_ANYONE_TS`),
  ADD KEY `CREATE_ANYONE_TS` (`CREATE_ANYONE_TS`),
  ADD KEY `APPROVE_ANYONE_TS_TEAM` (`APPROVE_ANYONE_TS_TEAM`),
  ADD KEY `ALLOW_SUP_TS` (`ALLOW_SUP_TS`);

--
-- Indexes for table `cxs_application_assignments`
--
ALTER TABLE `cxs_application_assignments`
  ADD PRIMARY KEY (`ASSIGNMENT_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CXS_APPLICATION_ASSIGNMENTS_U1` (`ASSIGNMENT_ID`),
  ADD KEY `APPLICATION_ROLE_ID` (`APPLICATION_ROLE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `ROLE_START_DATE` (`ROLE_START_DATE`),
  ADD KEY `ROLE_END_DATE` (`ROLE_END_DATE`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_application_roles`
--
ALTER TABLE `cxs_application_roles`
  ADD PRIMARY KEY (`APPLICATION_ROLE_ID`),
  ADD UNIQUE KEY `ROLE_NAME_2` (`ROLE_NAME`,`SITE_ID`),
  ADD KEY `ROLE_NAME` (`ROLE_NAME`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_calendars`
--
ALTER TABLE `cxs_calendars`
  ADD PRIMARY KEY (`CALENDAR_ID`),
  ADD UNIQUE KEY `NAME_2` (`NAME`),
  ADD UNIQUE KEY `NAME_3` (`NAME`,`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `NAME` (`NAME`),
  ADD KEY `DESCR` (`DESCR`),
  ADD KEY `PERIOD_YEAR` (`PERIOD_YEAR`),
  ADD KEY `PERIOD_TYPE` (`PERIOD_TYPE`);

--
-- Indexes for table `cxs_common_words`
--
ALTER TABLE `cxs_common_words`
  ADD PRIMARY KEY (`COMMON_WORD_ID`),
  ADD UNIQUE KEY `WORD_NAME_2` (`WORD_NAME`),
  ADD UNIQUE KEY `WORD_NAME_3` (`WORD_NAME`,`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `WORD_NAME` (`WORD_NAME`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`);

--
-- Indexes for table `cxs_daily_audit`
--
ALTER TABLE `cxs_daily_audit`
  ADD PRIMARY KEY (`AUDIT_ID`),
  ADD UNIQUE KEY `EMPLOYEE_NAME` (`EMPLOYEE_NAME`,`SITE_ID`),
  ADD KEY `EMPLOYEE_NUMBER` (`EMPLOYEE_NUMBER`);

--
-- Indexes for table `cxs_flex_schedule`
--
ALTER TABLE `cxs_flex_schedule`
  ADD PRIMARY KEY (`WORKSHIFT_ID`),
  ADD KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATED` (`LAST_UPDATED`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `SCHEDULE_TYPE` (`SCHEDULE_TYPE`),
  ADD KEY `SCHEDULE_START_DATE` (`SCHEDULE_START_DATE`),
  ADD KEY `SCHEDULE_END_DATE` (`SCHEDULE_END_DATE`),
  ADD KEY `DAYS_IN_MONTH1` (`DAYS_IN_MONTH1`),
  ADD KEY `DAYS_IN_MONTH2` (`DAYS_IN_MONTH2`),
  ADD KEY `DAYS_IN_MONTH3` (`DAYS_IN_MONTH3`),
  ADD KEY `DAYS_IN_MONTH4` (`DAYS_IN_MONTH4`),
  ADD KEY `DAYS_IN_MONTH5` (`DAYS_IN_MONTH5`),
  ADD KEY `DAYS_IN_MONTH6` (`DAYS_IN_MONTH6`),
  ADD KEY `DAYS_IN_MONTH7` (`DAYS_IN_MONTH7`),
  ADD KEY `DAYS_IN_MONTH8` (`DAYS_IN_MONTH8`),
  ADD KEY `DAYS_IN_MONTH9` (`DAYS_IN_MONTH9`),
  ADD KEY `DAYS_IN_MONTH10` (`DAYS_IN_MONTH10`),
  ADD KEY `DAYS_IN_MONTH11` (`DAYS_IN_MONTH11`),
  ADD KEY `DAYS_IN_MONTH12` (`DAYS_IN_MONTH12`),
  ADD KEY `DAYS_IN_MONTH13` (`DAYS_IN_MONTH13`),
  ADD KEY `DAYS_IN_MONTH14` (`DAYS_IN_MONTH14`),
  ADD KEY `DAYS_IN_MONTH15` (`DAYS_IN_MONTH15`),
  ADD KEY `DAYS_IN_MONTH16` (`DAYS_IN_MONTH16`),
  ADD KEY `DAYS_IN_MONTH17` (`DAYS_IN_MONTH17`),
  ADD KEY `DAYS_IN_MONTH18` (`DAYS_IN_MONTH18`),
  ADD KEY `DAYS_IN_MONTH19` (`DAYS_IN_MONTH19`),
  ADD KEY `DAYS_IN_MONTH20` (`DAYS_IN_MONTH20`),
  ADD KEY `DAYS_IN_MONTH21` (`DAYS_IN_MONTH21`),
  ADD KEY `DAYS_IN_MONTH22` (`DAYS_IN_MONTH22`),
  ADD KEY `DAYS_IN_MONTH23` (`DAYS_IN_MONTH23`),
  ADD KEY `DAYS_IN_MONTH24` (`DAYS_IN_MONTH24`),
  ADD KEY `DAYS_IN_MONTH25` (`DAYS_IN_MONTH25`),
  ADD KEY `DAYS_IN_MONTH26` (`DAYS_IN_MONTH26`),
  ADD KEY `DAYS_IN_MONTH27` (`DAYS_IN_MONTH27`),
  ADD KEY `DAYS_IN_MONTH28` (`DAYS_IN_MONTH28`),
  ADD KEY `DAYS_IN_MONTH29` (`DAYS_IN_MONTH29`),
  ADD KEY `DAYS_IN_MONTH30` (`DAYS_IN_MONTH30`),
  ADD KEY `DAYS_IN_MONTH31` (`DAYS_IN_MONTH31`),
  ADD KEY `SUNDAY` (`SUNDAY`),
  ADD KEY `MONDAY` (`MONDAY`),
  ADD KEY `TUESDAY` (`TUESDAY`),
  ADD KEY `WEDNESDAY` (`WEDNESDAY`),
  ADD KEY `THURSDAY` (`THURSDAY`),
  ADD KEY `FRIDAY` (`FRIDAY`),
  ADD KEY `SATURDAY` (`SATURDAY`);

--
-- Indexes for table `cxs_holidays`
--
ALTER TABLE `cxs_holidays`
  ADD PRIMARY KEY (`HOLIDAY_CALENDAR_ID`),
  ADD UNIQUE KEY `CALENDAR_NAME_2` (`CALENDAR_NAME`),
  ADD UNIQUE KEY `CALENDAR_NAME_3` (`CALENDAR_NAME`,`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `CALENDAR_NAME` (`CALENDAR_NAME`),
  ADD KEY `PERIOD_YEAR` (`PERIOD_YEAR`);

--
-- Indexes for table `cxs_holiday_calendar`
--
ALTER TABLE `cxs_holiday_calendar`
  ADD PRIMARY KEY (`CALENDAR_ID`),
  ADD UNIQUE KEY `HOLIDAY_CALENDAR_ID_2` (`HOLIDAY_CALENDAR_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `HOLIDAY_CALENDAR_ID` (`HOLIDAY_CALENDAR_ID`),
  ADD KEY `HOLIDAY_TAG_NAME` (`HOLIDAY_TAG_NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `HOLIDAY_START_DATE` (`HOLIDAY_START_DATE`),
  ADD KEY `HOLIDAY_END_DATE` (`HOLIDAY_END_DATE`),
  ADD KEY `INUSE_FLAG` (`INUSE_FLAG`),
  ADD KEY `ENFORCE_FLAG` (`ENFORCE_FLAG`),
  ADD KEY `RECESS_ALLOWED` (`RECESS_ALLOWED`),
  ADD KEY `ENABLED_FLAG` (`ENABLED_FLAG`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`);

--
-- Indexes for table `cxs_hours_deduction`
--
ALTER TABLE `cxs_hours_deduction`
  ADD KEY `POLICY_ID` (`POLICY_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `ALLOW_PAID_BREAK` (`ALLOW_PAID_BREAK`),
  ADD KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  ADD KEY `REQUIRED_HOURS` (`REQUIRED_HOURS`),
  ADD KEY `BREAK_HOURS` (`BREAK_HOURS`),
  ADD KEY `BREAK_START_TIME` (`BREAK_START_TIME`),
  ADD KEY `BREAK_END_TIME` (`BREAK_END_TIME`);

--
-- Indexes for table `cxs_page_list`
--
ALTER TABLE `cxs_page_list`
  ADD PRIMARY KEY (`PAGE_ID`),
  ADD KEY `UI_VALUES` (`UI_VALUES`),
  ADD KEY `DB_VALUES` (`DB_VALUES`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`);

--
-- Indexes for table `cxs_password_reuse`
--
ALTER TABLE `cxs_password_reuse`
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `XXT_PASSWORD` (`XXT_PASSWORD`),
  ADD KEY `KOUNTER` (`KOUNTER`);

--
-- Indexes for table `cxs_periods`
--
ALTER TABLE `cxs_periods`
  ADD PRIMARY KEY (`PERIOD_ID`),
  ADD UNIQUE KEY `PERIOD_NAME_2` (`PERIOD_NAME`,`SITE_ID`),
  ADD KEY `ENTITY_ID` (`ENTITY_ID`),
  ADD KEY `CALENDAR_ID` (`CALENDAR_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `FROM_PERIOD_DATE` (`FROM_PERIOD_DATE`),
  ADD KEY `TO_PERIOD_DATE` (`TO_PERIOD_DATE`),
  ADD KEY `PERIOD_YEAR` (`PERIOD_YEAR`),
  ADD KEY `PERIOD_NAME` (`PERIOD_NAME`),
  ADD KEY `STATUS` (`STATUS`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `FLAG_INUSE` (`FLAG_INUSE`);

--
-- Indexes for table `cxs_policy_general`
--
ALTER TABLE `cxs_policy_general`
  ADD UNIQUE KEY `ALIAS_ID_2` (`ALIAS_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `POLICY_ID` (`POLICY_ID`),
  ADD KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `ROW_NO` (`ROW_NO`),
  ADD KEY `EXCESS_HOURS_ALLOWED` (`EXCESS_HOURS_ALLOWED`),
  ADD KEY `HOLIDAY_EARN_CREDIT` (`HOLIDAY_EARN_CREDIT`),
  ADD KEY `CTO_OVERTIME` (`CTO_OVERTIME`),
  ADD KEY `OVERTIME_ALLOWED` (`OVERTIME_ALLOWED`);

--
-- Indexes for table `cxs_policy_header`
--
ALTER TABLE `cxs_policy_header`
  ADD PRIMARY KEY (`POLICY_ID`),
  ADD UNIQUE KEY `NAME_2` (`NAME`),
  ADD UNIQUE KEY `NAME_3` (`NAME`,`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `NAME` (`NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ADDINUSE_FLAG` (`ADDINUSE_FLAG`);

--
-- Indexes for table `cxs_policy_time_earned1`
--
ALTER TABLE `cxs_policy_time_earned1`
  ADD KEY `POLICY_ID` (`POLICY_ID`);

--
-- Indexes for table `cxs_policy_time_off`
--
ALTER TABLE `cxs_policy_time_off`
  ADD UNIQUE KEY `ALIAS_ID_2` (`ALIAS_ID`),
  ADD KEY `POLICY_ID` (`POLICY_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  ADD KEY `MAXIMUM_HOURS_ALLOWED` (`MAXIMUM_HOURS_ALLOWED`),
  ADD KEY `PERIOD_ID` (`PERIOD_ID`);

--
-- Indexes for table `cxs_preapp_alias`
--
ALTER TABLE `cxs_preapp_alias`
  ADD UNIQUE KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `WBS_ID` (`ALIAS_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `PREAPP_RULE_ID` (`PREAPP_RULE_ID`),
  ADD KEY `ROW_NO` (`ROW_NO`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`);

--
-- Indexes for table `cxs_preapp_rules`
--
ALTER TABLE `cxs_preapp_rules`
  ADD PRIMARY KEY (`PREAPP_RULE_ID`),
  ADD UNIQUE KEY `RULE_NAME_2` (`RULE_NAME`),
  ADD UNIQUE KEY `RULE_NAME_3` (`RULE_NAME`,`SITE_ID`),
  ADD KEY `CALENDAR_ID` (`CALENDAR_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `PREAPPROVAL_TYPE` (`PREAPPROVAL_TYPE`),
  ADD KEY `QUOTA_HOURS` (`QUOTA_HOURS`),
  ADD KEY `CHARGE_TYPE` (`CHARGE_TYPE`),
  ADD KEY `BUDGET_HOURS` (`BUDGET_HOURS`),
  ADD KEY `RECURRING_FLAG` (`RECURRING_FLAG`),
  ADD KEY `TOLERANCE` (`TOLERANCE`),
  ADD KEY `WEEKEND_HOURS_FLAG` (`WEEKEND_HOURS_FLAG`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `RULE_NAME` (`RULE_NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `IN_USE_FLAG` (`IN_USE_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`);

--
-- Indexes for table `cxs_resources`
--
ALTER TABLE `cxs_resources`
  ADD PRIMARY KEY (`RESOURCE_ID`),
  ADD UNIQUE KEY `FIRST_NAME_2` (`FIRST_NAME`,`LAST_NAME`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `FIRST_NAME` (`FIRST_NAME`),
  ADD KEY `MIDDLE_NAME` (`MIDDLE_NAME`),
  ADD KEY `LAST_NAME` (`LAST_NAME`),
  ADD KEY `RESOURCE_TYPE` (`RESOURCE_TYPE`),
  ADD KEY `CONTRACTOR_TYPE_FLAG` (`CONTRACTOR_TYPE_FLAG`),
  ADD KEY `START_DATE_ACTIVE` (`START_DATE_ACTIVE`),
  ADD KEY `END_DATE_ACTIVE` (`END_DATE_ACTIVE`),
  ADD KEY `TIMEMANAGEMENTPOLICY_ID` (`TIMEMANAGEMENTPOLICY_ID`),
  ADD KEY `PREAPPROVALRULES_ID` (`PREAPPROVALRULES_ID`),
  ADD KEY `SUPREVISOR_ID` (`SUPREVISOR_ID`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `ENTITY_ID` (`ENTITY_ID`),
  ADD KEY `RBAC_ID` (`RBAC_ID`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `AVAILABILTY_TYPE` (`AVAILABILTY_TYPE`),
  ADD KEY `IN_USE_FLAG` (`IN_USE_FLAG`);

--
-- Indexes for table `cxs_resource_address`
--
ALTER TABLE `cxs_resource_address`
  ADD PRIMARY KEY (`ADDRESS_RESOURCE_ID`),
  ADD KEY `RESOURCE_ID` (`RESOURCE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `ADDRESS1` (`ADDRESS1`),
  ADD KEY `ADDRESS2` (`ADDRESS2`),
  ADD KEY `ADDRESS3` (`ADDRESS3`),
  ADD KEY `CITY` (`CITY`),
  ADD KEY `STATE` (`STATE`),
  ADD KEY `COUNTRY` (`COUNTRY`),
  ADD KEY `POSTAL_CODE` (`POSTAL_CODE`),
  ADD KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `ROW_NO` (`ROW_NO`);

--
-- Indexes for table `cxs_resource_contact`
--
ALTER TABLE `cxs_resource_contact`
  ADD PRIMARY KEY (`CONTACT_RESOURCE_ID`),
  ADD KEY `RESOURCE_ID` (`RESOURCE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  ADD KEY `EMAIL_ADDRESS` (`EMAIL_ADDRESS`),
  ADD KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ACCEPTS_TEXTS_FLAG` (`ACCEPTS_TEXTS_FLAG`),
  ADD KEY `SOCIAL_URL` (`SOCIAL_URL`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `SOCIAL_URL_LABEL` (`SOCIAL_URL_LABEL`);

--
-- Indexes for table `cxs_resource_groups`
--
ALTER TABLE `cxs_resource_groups`
  ADD PRIMARY KEY (`RESOURCE_GROUP_ID`),
  ADD UNIQUE KEY `RESOURCE_GROUP_NAME_2` (`RESOURCE_GROUP_NAME`),
  ADD KEY `TIME_POLICY_ID` (`TIME_POLICY_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `RESOURCE_GROUP_NAME` (`RESOURCE_GROUP_NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ROLE` (`ROLE_ID`),
  ADD KEY `PREAPPROVAL_RULE_ID` (`PREAPPROVAL_RULE_ID`);

--
-- Indexes for table `cxs_sites`
--
ALTER TABLE `cxs_sites`
  ADD PRIMARY KEY (`SITE_ID`),
  ADD UNIQUE KEY `SITE_NAME_2` (`SITE_NAME`),
  ADD UNIQUE KEY `SITE_CODE_2` (`SITE_CODE`),
  ADD KEY `FIRST_NAME` (`FIRST_NAME`),
  ADD KEY `LAST_NAME` (`LAST_NAME`),
  ADD KEY `JOB_TITLE` (`JOB_TITLE`),
  ADD KEY `EMAIL` (`EMAIL`),
  ADD KEY `PHONE` (`PHONE`),
  ADD KEY `SITE_NAME` (`SITE_NAME`),
  ADD KEY `SITE_CODE` (`SITE_CODE`),
  ADD KEY `EMPLOYEE_BREAK` (`EMPLOYEE_BREAK`),
  ADD KEY `IS_APPROVAL` (`IS_APPROVAL`),
  ADD KEY `SYSTEM_PASSWORD` (`SYSTEM_PASSWORD`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `UPDATED_DATE` (`UPDATED_DATE`),
  ADD KEY `DATE_ACTIVATED` (`DATE_ACTIVATED`);

--
-- Indexes for table `cxs_site_address`
--
ALTER TABLE `cxs_site_address`
  ADD PRIMARY KEY (`ADDRESS_ID`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `ADDRESS1` (`ADDRESS1`),
  ADD KEY `ADDRESS2` (`ADDRESS2`),
  ADD KEY `ADDRESS3` (`ADDRESS3`),
  ADD KEY `CITY` (`CITY`),
  ADD KEY `STATE` (`STATE`),
  ADD KEY `COUNTRY` (`COUNTRY`),
  ADD KEY `ZIP_CODE` (`POSTAL_CODE`),
  ADD KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ROW_NO` (`ROW_NO`);

--
-- Indexes for table `cxs_site_contacts`
--
ALTER TABLE `cxs_site_contacts`
  ADD PRIMARY KEY (`CONTACT_ID`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `FIRST_NAME` (`FIRST_NAME`),
  ADD KEY `LAST_NAME` (`LAST_NAME`),
  ADD KEY `PHONE` (`PHONE`),
  ADD KEY `EMAIL` (`EMAIL`),
  ADD KEY `PHONE_TYPE` (`PHONE_TYPE`),
  ADD KEY `TITLE` (`TITLE`),
  ADD KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ROW_NO` (`ROW_NO`);

--
-- Indexes for table `cxs_site_settings`
--
ALTER TABLE `cxs_site_settings`
  ADD PRIMARY KEY (`SITE_SETTINGS_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `MANDATORY_PWD` (`MANDATORY_PWD`),
  ADD KEY `INCORRECT_ATTEMPT` (`INCORRECT_ATTEMPT`),
  ADD KEY `IDLE_SESSION` (`IDLE_SESSION`),
  ADD KEY `MINIMUM_ALLOWED` (`MINIMUM_ALLOWED`),
  ADD KEY `MAXIMUM_ALLOWED` (`MAXIMUM_ALLOWED`),
  ADD KEY `DEFAULT_DATE_FORMAT` (`DEFAULT_DATE_FORMAT`),
  ADD KEY `DEFAULT_NUMBER_FORMAT` (`DEFAULT_NUMBER_FORMAT`),
  ADD KEY `DEFAULT_TIMEZONE` (`DEFAULT_TIMEZONE`),
  ADD KEY `ENFORCE_RECENT` (`ENFORCE_RECENT`),
  ADD KEY `NUMBER_OF_RECENT` (`NUMBER_OF_RECENT`),
  ADD KEY `ALLOW_SPECIALS` (`ALLOW_SPECIALS`),
  ADD KEY `ALLOW_UPPERCASE` (`ALLOW_UPPERCASE`),
  ADD KEY `ALLOW_TIME_ENTRY` (`ALLOW_TIME_ENTRY`),
  ADD KEY `ALLOW_LOWERCASE` (`ALLOW_LOWERCASE`),
  ADD KEY `ALLOW_NUMERIC` (`ALLOW_NUMERIC`),
  ADD KEY `ENABLE_COMMON` (`ENABLE_COMMON`),
  ADD KEY `ENABLE_AUDIT` (`ENABLE_AUDIT`);

--
-- Indexes for table `cxs_subscribers`
--
ALTER TABLE `cxs_subscribers`
  ADD PRIMARY KEY (`SUBSCRIBER_ID`),
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `FIRST_NAME` (`FIRST_NAME`),
  ADD KEY `MIDDLE_INITIAL` (`MIDDLE_INITIAL`),
  ADD KEY `LAST_NAME` (`LAST_NAME`),
  ADD KEY `START_DATE` (`START_DATE`),
  ADD KEY `END_DATE` (`END_DATE`);

--
-- Indexes for table `cxs_support_history`
--
ALTER TABLE `cxs_support_history`
  ADD PRIMARY KEY (`SUPPORT_HISTORY_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `SUPPORT_REQUEST_ID` (`SUPPORT_REQUEST_ID`),
  ADD KEY `UPDATE_COUNTER` (`UPDATE_COUNTER`),
  ADD KEY `UPDATE_STMT` (`UPDATE_STMT`(1000)),
  ADD KEY `PAGE_TYPE_ID` (`PAGE_TYPE_ID`);

--
-- Indexes for table `cxs_support_request`
--
ALTER TABLE `cxs_support_request`
  ADD PRIMARY KEY (`SUPPORT_REQUEST_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `SR_NUMBER` (`SR_NUMBER`),
  ADD KEY `ISSUE_STMT` (`ISSUE_STMT`),
  ADD KEY `PAGE_TYPE_ID` (`PAGE_TYPE_ID`),
  ADD KEY `ISSUE_DESCRIPTION` (`ISSUE_DESCRIPTION`(1000)),
  ADD KEY `MULTI_USER_FLAG` (`MULTI_USER_FLAG`),
  ADD KEY `WORKAROUND_FLAG` (`WORKAROUND_FLAG`),
  ADD KEY `IMPACT_STMT` (`IMPACT_STMT`),
  ADD KEY `SR_STATUS` (`SR_STATUS`);

--
-- Indexes for table `cxs_ta_modules`
--
ALTER TABLE `cxs_ta_modules`
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  ADD KEY `MODULE_NAME` (`MODULE_NAME`),
  ADD KEY `CREATE_PRIV` (`CREATE_PRIV`),
  ADD KEY `UPDATE_PRIV` (`UPDATE_PRIV`),
  ADD KEY `VIEW_PRIV` (`VIEW_PRIV`),
  ADD KEY `ENABLE_AUDIT` (`ENABLE_AUDIT`),
  ADD KEY `ROWNO` (`ROWNO`);

--
-- Indexes for table `cxs_temp_approver`
--
ALTER TABLE `cxs_temp_approver`
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `PERIOD_ID` (`PERIOD_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `ROWNO` (`ROWNO`),
  ADD KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`);

--
-- Indexes for table `cxs_te_approved`
--
ALTER TABLE `cxs_te_approved`
  ADD PRIMARY KEY (`EI_APPROVAL_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `TE_ID` (`TE_ID`),
  ADD KEY `RESOURCE_ID` (`RESOURCE_ID`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `ADJUSTED_HOURS` (`ADJUSTED_HOURS`),
  ADD KEY `TIME_STATUS` (`TIME_STATUS`),
  ADD KEY `INTERFACE_STATUS` (`INTERFACE_STATUS`),
  ADD KEY `ACTUAL_HOURS` (`ACTUAL_HOURS`),
  ADD KEY `BUDGETED_HOURS` (`BUDGETED_HOURS`),
  ADD KEY `COMMENT` (`COMMENT`),
  ADD KEY `ENTRY_DATE` (`ENTRY_DATE`),
  ADD KEY `APPROVAL_DATE` (`APPROVAL_DATE`);

--
-- Indexes for table `cxs_te_file`
--
ALTER TABLE `cxs_te_file`
  ADD PRIMARY KEY (`DETAIL_ID`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `TE_ID` (`TE_ID`),
  ADD KEY `APPROVAL_ID` (`APPROVAL_ID`),
  ADD KEY `RESOURCE_ID` (`RESOURCE_ID`),
  ADD KEY `WBS_ID` (`WBS_ID`),
  ADD KEY `ALIAS_ID` (`ALIAS_ID`),
  ADD KEY `SEED_ALIAS` (`SEED_ALIAS`),
  ADD KEY `PERIOD_ID` (`PERIOD_ID`),
  ADD KEY `ENTRY_DATE` (`ENTRY_DATE`),
  ADD KEY `HOURS` (`HOURS`),
  ADD KEY `STATUS_FLAG` (`STATUS_FLAG`),
  ADD KEY `COMMENT` (`COMMENT`),
  ADD KEY `ENTRY_TYPE` (`ENTRY_TYPE`),
  ADD KEY `ROW_NO` (`ROW_NO`),
  ADD KEY `LAST_UPDATED_LOGIN` (`LAST_UPDATED_LOGIN`),
  ADD KEY `SHIFT` (`SHIFT`),
  ADD KEY `APPROVER_COMMENT` (`APPROVER_COMMENT`);

--
-- Indexes for table `cxs_te_header`
--
ALTER TABLE `cxs_te_header`
  ADD PRIMARY KEY (`TE_ID`),
  ADD UNIQUE KEY `TE_NAME_2` (`TE_NAME`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `TE_NAME` (`TE_NAME`),
  ADD KEY `TE_PREFIX` (`TE_PREFIX`),
  ADD KEY `TE_DESCR` (`TE_DESCR`),
  ADD KEY `PAY_PERIOD_ID` (`PAY_PERIOD_ID`),
  ADD KEY `RESOURCE_ID` (`RESOURCE_ID`),
  ADD KEY `SUPERVISOR_ID` (`SUPERVISOR_ID`),
  ADD KEY `SUPERVISOR_ID2` (`SUPERVISOR_ID2`),
  ADD KEY `SUPERVISOR_ID3` (`SUPERVISOR_ID3`),
  ADD KEY `SUPERVISOR_ID4` (`SUPERVISOR_ID4`),
  ADD KEY `STATUS` (`STATUS`),
  ADD KEY `LAST_UPDATE_LOGIN` (`LAST_UPDATE_LOGIN`);

--
-- Indexes for table `cxs_users`
--
ALTER TABLE `cxs_users`
  ADD PRIMARY KEY (`USER_ID`,`RESOURCE_ID`),
  ADD UNIQUE KEY `USER_NAME_2` (`USER_NAME`),
  ADD UNIQUE KEY `USER_NAME_3` (`USER_NAME`,`SITE_ID`),
  ADD UNIQUE KEY `USER_NAME_4` (`USER_NAME`,`SITE_ID`),
  ADD KEY `CXS_USERS_U1` (`USER_ID`),
  ADD KEY `USER_NAME` (`USER_NAME`),
  ADD KEY `ENC_KEY` (`ENC_KEY`),
  ADD KEY `TEMP_PASSWORD` (`TEMP_PASSWORD`),
  ADD KEY `RESET_DAYS` (`RESET_DAYS`),
  ADD KEY `PSW_RESET_DATE` (`PSW_RESET_DATE`),
  ADD KEY `ROLE_ID` (`ROLE_ID`),
  ADD KEY `ROLE_START_DATE` (`ROLE_START_DATE`),
  ADD KEY `ROLE_END_DATE` (`ROLE_END_DATE`),
  ADD KEY `PHOTO` (`PHOTO`),
  ADD KEY `START_DATE` (`START_DATE`),
  ADD KEY `END_DATE` (`END_DATE`),
  ADD KEY `PWD_RULE_CODE` (`PWD_RULE_CODE`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `LAST_LOGIN_TIME` (`LAST_LOGIN_TIME`),
  ADD KEY `LAST_LOGOUT_TIME` (`LAST_LOGOUT_TIME`);

--
-- Indexes for table `cxs_users_favorites`
--
ALTER TABLE `cxs_users_favorites`
  ADD KEY `USER_ID` (`USER_ID`),
  ADD KEY `FEATURE_NAME` (`FEATURE_NAME`),
  ADD KEY `PAGE_NAME` (`PAGE_NAME`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `MODULE_NAME` (`MODULE_NAME`);

--
-- Indexes for table `cxs_wbs`
--
ALTER TABLE `cxs_wbs`
  ADD PRIMARY KEY (`WBS_ID`),
  ADD UNIQUE KEY `SEGMENT1_2` (`SEGMENT1`,`SEGMENT2`,`SEGMENT3`,`SEGMENT4`,`SITE_ID`),
  ADD KEY `SEQUENCE` (`SEQUENCE`),
  ADD KEY `SEGMENT1` (`SEGMENT1`),
  ADD KEY `SEGMENT2` (`SEGMENT2`),
  ADD KEY `SEGMENT3` (`SEGMENT3`),
  ADD KEY `SEGMENT4` (`SEGMENT4`),
  ADD KEY `SEGMENT5` (`SEGMENT5`),
  ADD KEY `SEGMENT7` (`SEGMENT7`),
  ADD KEY `SEGMENT6` (`SEGMENT6`),
  ADD KEY `SEGMENT8` (`SEGMENT8`),
  ADD KEY `SEGMENT9` (`SEGMENT9`),
  ADD KEY `SEGMENT10` (`SEGMENT10`),
  ADD KEY `SEGMENT11` (`SEGMENT11`),
  ADD KEY `SEGMENT12` (`SEGMENT12`),
  ADD KEY `SEGMENT13` (`SEGMENT13`),
  ADD KEY `SEGMENT14` (`SEGMENT14`),
  ADD KEY `SEGMENT15` (`SEGMENT15`),
  ADD KEY `DESCRIPTION1` (`DESCRIPTION1`),
  ADD KEY `DESCRIPTION2` (`DESCRIPTION2`),
  ADD KEY `DESCRIPTION3` (`DESCRIPTION3`),
  ADD KEY `DESCRIPTION4` (`DESCRIPTION4`),
  ADD KEY `DESCRIPTION5` (`DESCRIPTION5`),
  ADD KEY `DESCRIPTION6` (`DESCRIPTION6`),
  ADD KEY `DESCRIPTION7` (`DESCRIPTION7`),
  ADD KEY `DESCRIPTION8` (`DESCRIPTION8`),
  ADD KEY `DESCRIPTION9` (`DESCRIPTION9`),
  ADD KEY `DESCRIPTION10` (`DESCRIPTION10`),
  ADD KEY `DESCRIPTION11` (`DESCRIPTION11`),
  ADD KEY `DESCRIPTION12` (`DESCRIPTION12`),
  ADD KEY `DESCRIPTION13` (`DESCRIPTION13`),
  ADD KEY `DESCRIPTION14` (`DESCRIPTION14`),
  ADD KEY `DESCRIPTION15` (`DESCRIPTION15`),
  ADD KEY `ACTIVE_FLAG1` (`ACTIVE_FLAG1`),
  ADD KEY `ACTIVE_FLAG2` (`ACTIVE_FLAG2`),
  ADD KEY `ACTIVE_FLAG5` (`ACTIVE_FLAG5`),
  ADD KEY `ACTIVE_FLAG6` (`ACTIVE_FLAG6`),
  ADD KEY `ACTIVE_FLAG9` (`ACTIVE_FLAG9`),
  ADD KEY `ACTIVE_FLAG10` (`ACTIVE_FLAG10`),
  ADD KEY `ACTIVE_FLAG11` (`ACTIVE_FLAG11`),
  ADD KEY `ACTIVE_FLAG12` (`ACTIVE_FLAG12`),
  ADD KEY `ACTIVE_FLAG13` (`ACTIVE_FLAG13`),
  ADD KEY `ACTIVE_FLAG14` (`ACTIVE_FLAG14`),
  ADD KEY `ACTIVE_FLAG15` (`ACTIVE_FLAG15`),
  ADD KEY `IN_USE1` (`IN_USE1`),
  ADD KEY `IN_USE2` (`IN_USE2`),
  ADD KEY `IN_USE3` (`IN_USE3`),
  ADD KEY `SITE_ID` (`SITE_ID`),
  ADD KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `IN_USE15` (`IN_USE15`),
  ADD KEY `IN_USE14` (`IN_USE14`),
  ADD KEY `IN_USE13` (`IN_USE13`),
  ADD KEY `IN_USE12` (`IN_USE12`),
  ADD KEY `IN_USE11` (`IN_USE11`),
  ADD KEY `IN_USE10` (`IN_USE10`),
  ADD KEY `IN_USE9` (`IN_USE9`),
  ADD KEY `IN_USE8` (`IN_USE8`),
  ADD KEY `IN_USE7` (`IN_USE7`),
  ADD KEY `IN_USE6` (`IN_USE6`),
  ADD KEY `IN_USE5` (`IN_USE5`),
  ADD KEY `IN_USE4` (`IN_USE4`);

--
-- Indexes for table `cxs_wbs123`
--
ALTER TABLE `cxs_wbs123`
  ADD PRIMARY KEY (`WBS_ID`);

--
-- Indexes for table `cxs_workshifts`
--
ALTER TABLE `cxs_workshifts`
  ADD PRIMARY KEY (`WORKSHIFT_ID`),
  ADD UNIQUE KEY `NAME_2` (`NAME`,`SITE_ID`),
  ADD KEY `NAME` (`NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `TIMEZONE` (`TIMEZONE`),
  ADD KEY `WORKSHIFT_TYPE` (`WORKSHIFT_TYPE`),
  ADD KEY `PART_TIME` (`PART_TIME`),
  ADD KEY `IN_USE_FLAG` (`IN_USE_FLAG`),
  ADD KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATED` (`LAST_UPDATED`),
  ADD KEY `SITE_ID` (`SITE_ID`);

--
-- Indexes for table `cxs_workshifts_detail`
--
ALTER TABLE `cxs_workshifts_detail`
  ADD KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  ADD KEY `BEGIN_WORKDAY` (`BEGIN_WORKDAY`),
  ADD KEY `DAILY_WORK_HOURS` (`DAILY_WORK_HOURS`),
  ADD KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  ADD KEY `CREATED_BY` (`CREATED_BY`),
  ADD KEY `CREATION_DATE` (`CREATION_DATE`),
  ADD KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  ADD KEY `LAST_UPDATED` (`LAST_UPDATED`),
  ADD KEY `ROW_NO` (`ROW_NO`),
  ADD KEY `SHIFT_HOURS` (`SHIFT_HOURS`);

--
-- Indexes for table `sys_applications`
--
ALTER TABLE `sys_applications`
  ADD PRIMARY KEY (`APPLICATION_ID`),
  ADD KEY `NAME` (`NAME`),
  ADD KEY `DESCRIPTION` (`DESCRIPTION`),
  ADD KEY `DATE_ENABLED` (`DATE_ENABLED`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cxs_aliases`
--
ALTER TABLE `cxs_aliases`
  MODIFY `ALIAS_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cxs_am_app_admin`
--
ALTER TABLE `cxs_am_app_admin`
  MODIFY `APP_ADM_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cxs_am_roles`
--
ALTER TABLE `cxs_am_roles`
  MODIFY `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_application_assignments`
--
ALTER TABLE `cxs_application_assignments`
  MODIFY `ASSIGNMENT_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_application_roles`
--
ALTER TABLE `cxs_application_roles`
  MODIFY `APPLICATION_ROLE_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_calendars`
--
ALTER TABLE `cxs_calendars`
  MODIFY `CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_common_words`
--
ALTER TABLE `cxs_common_words`
  MODIFY `COMMON_WORD_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_daily_audit`
--
ALTER TABLE `cxs_daily_audit`
  MODIFY `AUDIT_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cxs_holidays`
--
ALTER TABLE `cxs_holidays`
  MODIFY `HOLIDAY_CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_holiday_calendar`
--
ALTER TABLE `cxs_holiday_calendar`
  MODIFY `CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_page_list`
--
ALTER TABLE `cxs_page_list`
  MODIFY `PAGE_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cxs_periods`
--
ALTER TABLE `cxs_periods`
  MODIFY `PERIOD_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cxs_policy_header`
--
ALTER TABLE `cxs_policy_header`
  MODIFY `POLICY_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_preapp_rules`
--
ALTER TABLE `cxs_preapp_rules`
  MODIFY `PREAPP_RULE_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cxs_resources`
--
ALTER TABLE `cxs_resources`
  MODIFY `RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cxs_resource_address`
--
ALTER TABLE `cxs_resource_address`
  MODIFY `ADDRESS_RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_resource_contact`
--
ALTER TABLE `cxs_resource_contact`
  MODIFY `CONTACT_RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_resource_groups`
--
ALTER TABLE `cxs_resource_groups`
  MODIFY `RESOURCE_GROUP_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_sites`
--
ALTER TABLE `cxs_sites`
  MODIFY `SITE_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cxs_site_address`
--
ALTER TABLE `cxs_site_address`
  MODIFY `ADDRESS_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_site_contacts`
--
ALTER TABLE `cxs_site_contacts`
  MODIFY `CONTACT_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_site_settings`
--
ALTER TABLE `cxs_site_settings`
  MODIFY `SITE_SETTINGS_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cxs_subscribers`
--
ALTER TABLE `cxs_subscribers`
  MODIFY `SUBSCRIBER_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_support_history`
--
ALTER TABLE `cxs_support_history`
  MODIFY `SUPPORT_HISTORY_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_support_request`
--
ALTER TABLE `cxs_support_request`
  MODIFY `SUPPORT_REQUEST_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_te_approved`
--
ALTER TABLE `cxs_te_approved`
  MODIFY `EI_APPROVAL_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cxs_te_file`
--
ALTER TABLE `cxs_te_file`
  MODIFY `DETAIL_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `cxs_te_header`
--
ALTER TABLE `cxs_te_header`
  MODIFY `TE_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cxs_users`
--
ALTER TABLE `cxs_users`
  MODIFY `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cxs_wbs`
--
ALTER TABLE `cxs_wbs`
  MODIFY `WBS_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cxs_wbs123`
--
ALTER TABLE `cxs_wbs123`
  MODIFY `WBS_ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cxs_workshifts`
--
ALTER TABLE `cxs_workshifts`
  MODIFY `WORKSHIFT_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sys_applications`
--
ALTER TABLE `sys_applications`
  MODIFY `APPLICATION_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
