<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- editor css -->
    <link href="css/editor.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">  Customer Activity Zone  </a></li>
                        <li> <a href="#"> Customer Communication  </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Customer Communication Center </h2>
                    </div>

                    <!-- find bx-->
                    <div class="form-bx2">
                        <div class="cus-form-cont row ">
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Number </label>
                                <input type="text" class="form-control" placeholder="" maxlength="15">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="50">
                            </div>
                            <div class="col-sm-3 text-center">
                                <label>  </label>
                                <div class="checkbox">
                                    <label>
                                    <input type="checkbox">
                                    All Customers </label>
                                </div>
                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label>  </label>
                                <select class="form-control" maxlength="40">
                                    <option value="">  Maintenance </option>
                                    <option value=""> Product Upgrade</option>
                                    <option value=""> Bug Status</option>
                                    <option value=""> Other </option>
                                    </select>
                            </div>


                        </div>
                    </div>



                    <div class="clearfix"> </div>
                    <div class="text-area-bx mar-botn20">
                        <div class="col-lg-12 nopadding">
                            <textarea id="txtEditor"></textarea>
                        </div>
                    </div>
                    <div class="fright cr-user mar-top-20pxs">
                        <button type="button" class="btn btn-primary btn-style"> Announce </button>
                    </div>


                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/editor.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $("#txtEditor").Editor();
        });
    </script>

</body>

</html>

</html>