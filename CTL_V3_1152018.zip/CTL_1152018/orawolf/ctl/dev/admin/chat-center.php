<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">  Customer Activity Zone  </a></li>
                        <li> <a href="#"> Chat Center </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Chat Center </h2>

                    </div>
                    <h3 class="sec-subtitle"> Chat Notifications </h3>
                    <!-- find bx-->
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Inbound Text Number   </label>
                                <input type="text" class="form-control" placeholder="" maxlength="11">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Inbound Email </label>
                                <input type="email" class="form-control" placeholder="" maxlength="100">

                            </div>
                            <div class="col-sm-3 form-group">
                                <button type="button" class="btn btn-primary btn-style2 mar-tp22"> Find </button>
                            </div>
                        </div>
                    </div>



                    <div>
                        <h2 class="sec-subtitle"> New Notifications </h2>
                    </div>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="check-bx"> <input type="checkbox" id="" value="option1"> </th>
                                        <th> From <i class="fa fa-sort"></i> </th>
                                        <th> Name <i class="fa fa-sort"></i> </th>
                                        <th> Time Sent <i class="fa fa-sort"></i> </th>
                                        <th> Ticket Type <i class="fa fa-sort"></i> </th>
                                        <th> Ticket Severity <i class="fa fa-sort"></i> </th>
                                        <th> Status <i class="fa fa-sort"></i> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>


                    <!-- pagination -->
                    <div class="pagination-bx">
                        <div class="bs-example">
                            <ul class="pagination">
                                <li><a href="#">«</a></li>
                                <li><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#">»</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- chat window start-->
                    <div class="clearfix"></div>
                    <div class="col-md-6 col-md-offset-3">
                        <div class="chat-win-bx">
                            <div class="chat-hd-bx">
                                <h2 class="sec-hd"> Chat with Agent </h2>
                            </div>
                            <div class="chat-mid-bx">
                                <div class="per-block ag-chat">
                                    <p class="chat-hd"> Name <span> 9:25 </span></p>
                                    <p class="chat-t-cont">kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b</p>
                                </div>
                                <div class="per-block">
                                    <p class="chat-hd"> Name <span> 9:25 </span></p>
                                    <p class="chat-t-cont">kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b</p>
                                </div>
                                <div class="per-block">
                                    <p class="chat-hd"> Name <span> 9:25 </span></p>
                                    <p class="chat-t-cont">kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b</p>
                                </div>
                            </div>
                            <div class="type-bx">
                                <div class="type-txt-bx"> <input type="text"> </div>
                                <div class="send-btn-bx">
                                    <a href="#" class="send"> send </a>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>

</html>