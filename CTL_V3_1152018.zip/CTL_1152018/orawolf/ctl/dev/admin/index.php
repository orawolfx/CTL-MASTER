<?php 
ob_start ();
include("conn.php"); 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
	<link href="css/dataTables.bootstrap.min.css" rel="stylesheet">	
	
	<script src="js/jquery.min.js"></script> 
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>	
	<script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
	
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li>
                            <a href="#"> </a>
                        </li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <!-- mid part start -->
                <div class="cont-box cont-sep">

                    <h3 class="sec-subtitle"> New Sites Subscription </h3>
                    <div class="data-bx ">
						<form id = "frmNewSites">
							<div class="table-responsive ">
								<table class="table table-bordered" id = 'Table_SiteSubscription'>
									<thead>
										<tr>
											<th width="5%" class="check-bx "> 
											<input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()">
											</th>
											<th width="5%"> Site Code </th>
											<th width="15%"> Site Name </th>
											<th width="10%"> Address 1 </th>
											<th width="7%"> Country </th>
											<th width="7%"> State </th>
											<th width="7%"> Email </th>
											<th width="5%"> Phone </th>
											<th width="10%"> First Name </th>
											<th width="10%"> Last Name </th>
											<th width="5%"> Buy/Try </th>
											<th width="7%"> Date Created </th>                                        
											<th width="7%">Initial Subscriber</th>
											<th width="5%">Status</th>
										</tr>
									</thead>
									<tbody>
										<?php
											$i=1;
											$qry = "select * from cxs_sites   order by SITE_NAME"; //where IS_APPROVAL = 'N'
											$result = mysql_query($qry);
											while($row = mysql_fetch_array($result))
											{
												$TotalSubscribers =0;
												$CurrentSiteId = $row['SITE_ID'];
												$qry1 = "Select count(SUBSCRIBER_ID) as expr1 from cxs_subscribers where SITE_ID = $CurrentSiteId";
												$result1 = mysql_query($qry1);
												while($row1 = mysql_fetch_array($result1))
												{
													$TotalSubscribers = $row1['expr1'];
												}
												?>
												<tr>												
													<td class="check-bx ">
													<?php if ($row['IS_APPROVAL']=="N") { ?>
														<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()" class="record_chk">
														<input type="hidden" id = <?php echo "h_siteid".$i; ?> name = <?php echo "h_siteid".$i; ?> value = "<?php echo $CurrentSiteId; ?>">
													<?php } ?>	
													</td>
													<td><?php echo $row['SITE_CODE']; ?> </td>
													<td><?php echo $row['SITE_NAME']; ?> </td>
													<td><?php echo ''; ?> </td>
													<td><?php echo ''; ?> </td>
													<td><?php echo ''; ?> </td>
													<td><?php echo $row['EMAIL']; ?> </td>
													<td><?php echo $row['PHONE']; ?> </td>
													<td><?php echo $row['FIRST_NAME']; ?> </td>
													<td><?php echo $row['LAST_NAME']; ?> </td>
													<td><?php echo 'Try'; ?> </td>
													<td><?php echo date('m/d/Y',strtotime($row['CREATION_DATE'])); ?> </td>
													<td><?php echo $TotalSubscribers; ?> </td>
													<td><?php echo ($row['IS_APPROVAL']=="Y")?"Activate":"Inactivate"; ?> </td>
												</tr>	
										<?php	
												$i++;
											}
										?>
									</tbody>
								</table>
							</div>
						</form>	
						<div class="fright cr-user mar-top-20pxs">
                            <button type="button" class="btn btn-primary btn-style" id = "cmdActivateSite" > Activate Selected </button>
                        </div>		
                       
                    </div>
                    <h3 class="sec-subtitle"> New Subscribers </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered" id = 'Table_SubscriberList'>
                                <thead>
                                    <tr>                                        
                                        <th width="8%"> Site Code </th>
                                        <th width="12%"> Site Name </th>
                                        <th width="15%"> First Name </th>
                                        <th width="15%"> Last Name </th>                                        
                                        <th width="10%"> Email </th>                                        
                                        <th width="10%"> Date Created </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
										$i=1;
										$qry = "select cxs_subscribers.*,cxs_sites.SITE_CODE,cxs_sites.SITE_NAME,cxs_users.USER_NAME from cxs_subscribers inner join cxs_sites on cxs_sites.SITE_ID = cxs_subscribers.SITE_ID left join cxs_users on cxs_users.USER_ID = cxs_subscribers.USER_ID order by cxs_sites.SITE_NAME,cxs_subscribers.FIRST_NAME,cxs_subscribers.MIDDLE_INITIAL,cxs_subscribers.LAST_NAME";
										$result = mysql_query($qry);
										while($row = mysql_fetch_array($result))
										{ ?>
											<tr>
												<td><?php echo $row['SITE_CODE']; ?> </td>
												<td><?php echo $row['SITE_NAME']; ?> </td>
												<td><?php echo $row['FIRST_NAME']; ?> </td>
												<td><?php echo $row['LAST_NAME']; ?> </td>												
												<td><?php echo $row['USER_NAME']; ?> </td>												
												<td><?php echo date("m/d/Y",strtotime($row['CREATION_DATE'])); ?> </td>
											</tr>
									<?php
										}
									?>

                                </tbody>
                            </table>
                        </div>
                        <!-- btn -->                      
                    </div>
					<!--
                    <h3 class="sec-subtitle"> Bill and Payment </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </th>
                                        <th width="12%"> Customer Number </th>
                                        <th width="12%"> Customer Name </th>
                                        <th width="6%"> Bill Id </th>
                                        <th width="10%"> Billing Period </th>
                                        <th width="12%"> Bill Sent Date </th>
                                        <th width="15%"> Payment Due Date </th>
                                        <th width="10%"> Days Late </th>
                                        <th width="20%"> Payment Reminder Count </th>
                                        <th width="12%"> Last Reminder Date </th>
                                        <th width="12%"> Payment Status </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>


                                </tbody>
                            </table>
                        </div>

                        <!-- pagination --
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
					-->




                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
	<script>
		$("document").ready(function()
		{
			$("#Table_SiteSubscription").DataTable({"searching": false,"ordering": false});
			$("#Table_SubscriberList").DataTable({"searching": false});
			
		});
		function checkAll()
		{	
			var checkboxValue = $('#Checkbox_SelectAll').prop("checked"); 
			var TABLE_ROW = $("#Table_SiteSubscription tr").length;
			var i=1;
			for(i=1;i<=TABLE_ROW;i++)
			{
				$("#CheckboxInline"+i).prop("checked",checkboxValue);					
			}
			
		}
		function checkInline()
		{
			var TABLE_ROW = $("#Table_SiteSubscription tr").length;
			for(i=1;i<=TABLE_ROW;i++)
			{
				if($("#CheckboxInline"+i).prop("checked")==false)				
				{
					$("#Checkbox_SelectAll").prop("checked",false);	
				}
			}
		}
		
		
		var UpdateRows=new Array();
		$(document).on('click', '.record_chk', function () 
		{
			if($(this).is(":checked")) 
				{
					current_id = $(this).attr("id");
					current_id = FindNumFromString(current_id);
					UpdateRows.push($('#h_siteid'+current_id).val());
					flag_updaterecord="Y";
				}
		});


		function FindNumFromString(thestring)
		{
			var thenum = thestring.match(/\d+$/);		
			return thenum;
		}
		$("#cmdActivateSite").click(function()	
		{
			//var TABLE_ROW = $("#Table_SiteSubscription tr").length;			
			if(UpdateRows.length>0)//if (flag_updaterecord == "Y")
			{	
				$.ajax({
					url : "ajax-admin.php",
					method:"POST",
					data:{Request:"Site Activate",Ids:UpdateRows},
					success:function(response)
					{
						frmNewSites.submit();						
					}
				});
			}
			else
			{
				alert("Please Select Any Record For Update");				
			}
		});
	</script>	
</body>

</html>