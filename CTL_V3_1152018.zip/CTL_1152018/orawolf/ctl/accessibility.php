<?php 
ob_start ();
include("conn.php");
check_login1();
?>

<?php

$siteId = $_SESSION['user-siteid'];
//echo $siteId;
 $query = 'SELECT `APPLICATION_ID` FROM `cxs_am_app_admin` WHERE `SITE_ID` = '.$siteId.'';
$result = mysql_query($query);
$rows = mysql_num_rows($result);
if($rows > 0){
	$array = array();
	while($data = mysql_fetch_assoc($result))
	{
		$array['data'][] = $data;
	}
	
	 $rbam = $array['data'][0]['APPLICATION_ID'];
	 
	
	

	if($rbam != 1)
	{
		header("Location:te/te.php");
	}


	
}



if( isset($_POST['cmdAccessibility']) && $_POST['cmdAccessibility']=='cmdAccessibility' )
{

	if($_POST['Combo_Accessibility']=="RBAM")
	{
		header("location:rbam/rbam.php");
	}
	else if($_POST['Combo_Accessibility']=="TE")
	{
		header("Location:te/te.php");
		
	}
}

?>   

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Coexsys | Accessibility Form</title>  
	<link rel="stylesheet" href="css/bootstrap1.min.css">
	<link rel="stylesheet"href="css/login_style.css">
	<link rel="icon" href="img/logo.jpg" width="20" type="image/x-icon"/>
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
</head>

<body>

    <div class="wrapper">
 <!--   <form class="form-signin" method='post' action=''> 
      <div class='row' > <img style='margin-right:-20px;' class='pull-right' src="img/main_logo.png" /> </div>         
		<div id = "div_accessibility" >
			<h4>Accessibility</h4>
			<select id = "Combo_Accessibility" name = "Combo_Accessibility" class="form-control ">
				<option value="RBAM">Access Management</option>
				<option value="TE">Time & Labor</option>
			</select>
		</div>
		<div class="clear-both" style = "padding-top:15px;"></div>
		<button class="btn btn-lg btn-primary btn-block" name='cmdAccessibility' value='cmdAccessibility' type="submit">Select</button> 
    </form>-->
    
    <div class="wrapper-row">
    <div class="signin-btn-login">    <div class="sigtn-login"><div class="sigtn-logi-outr">
       <div class="mai_log"> <img src="img/log.png" /></div>
    <a href="rbam/rbam.php">CTL ADMINISTRATOR </a>
       <a href="te/te.php">TIME KEEPING</a>
	   <a href="../SRM7/SRM/wizard/?id=0">REPORTS</a>
    </div>    </div> </div>
    
      </div>
  </div>
 
  
<script src="js/bootstrap.min.js"></script>
</body>

</html>

