
<!--<script src="../js/jquery.min.js"></script> 
<script src="../js/jquery-ui.js"></script>	
<!--<script src="../js/bootstrap.min.js"></script>-->
<!--<script src="../js/custom.js" type="text/javascript"></script>-->


<style type="text/css">
.requirefieldcls{	background-color: #fff99c;	}
</style>
<?php

	$OrderBY = "asc";
	$FieldName = "SR_NUMBER";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
   	 $OrderBY = " desc";
   	 $FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}
	if($FieldName =='SR_NUMBER')
	{
		$FieldName = "CAST(SR_NUMBER as SIGNED INTEGER)";
	}
	$SQueryOrderBy = " order by $FieldName $OrderBY";	
	$record_per_page=$RecordsPerPage;
	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	$start_from = ($page-1) *  $record_per_page;
	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$insArr = array();
	
	if (isset($_POST['cmdSubmit'] ))
	{	
		$Text_IssueStatment = isset($_POST["Text_IssueStatment"] )? $_POST["Text_IssueStatment"]: false;
		$Text_IssueDesc = isset($_POST["Text_IssueDesc"] )? $_POST["Text_IssueDesc"]: false;
		$Combo_Page = isset($_POST["Combo_Page"] )? $_POST["Combo_Page"]: false;
		$Combo_MultiUser = isset($_POST["Combo_MultiUser"] )? $_POST["Combo_MultiUser"]: false;
		$Combo_WorkAround = isset($_POST["Combo_WorkAround"] )? $_POST["Combo_WorkAround"]: false;
		$Combo_ImpactStatment = isset($_POST["Combo_ImpactStatment"] )? $_POST["Combo_ImpactStatment"]: false;
		$Text_CustomizationRequest = isset($_POST["Text_CustomizationRequest"] )? $_POST["Text_CustomizationRequest"]: false;
		
		$result = mysql_query("SELECT * FROM cxs_support_request");
		$num_rows = mysql_num_rows($result);
		$SrNo = $num_rows+1;
		
		unset($inArr);	
		$insArr['SR_NUMBER']	 = 		$SrNo;
		$insArr['ISSUE_STMT'] 			= $Text_IssueStatment;
		$insArr['ISSUE_DESCRIPTION'] 	= $Text_IssueDesc;
		$insArr['PAGE_TYPE_ID'] 		= $Combo_Page;
		$insArr['MULTI_USER_FLAG'] 		= $Combo_MultiUser;
		$insArr['WORKAROUND_FLAG'] 		= $Combo_WorkAround;
		$insArr['IMPACT_STMT'] 			= $Combo_ImpactStatment;
		$insArr['SR_STATUS'] 			= "Open";
		$insArr['CREATED_BY'] 			= $LoginUserId ;
		$insArr['CREATION_DATE'] 		= date('Y-m-d H:i:s');
		$insArr['LAST_UPDATED_BY'] 		= $LoginUserId;	
		$insArr['CUSTOMIZATION_REQUEST'] = $Text_CustomizationRequest;	
		insertdata("cxs_support_request",$insArr);	
		
		$LastInsertedId = mysql_insert_id();	
		//$LastInsertedId =1;
		unset($inArr1);	
		$insArr1['SUPPORT_REQUEST_ID']	 = 	$LastInsertedId;
		$insArr1['UPDATE_COUNTER'] 		 =  1;
		$insArr1['UPDATE_STMT'] 		 =  $Text_IssueDesc;
		$insArr1['CREATED_BY'] 			= $LoginUserId ;
		$insArr1['CREATION_DATE'] 		= date('Y-m-d H:i:s');
		$insArr1['LAST_UPDATED_BY'] 		= $LoginUserId;	
		insertdata("cxs_support_history",$insArr1);	
		
		$qry = "SELECT UserName,ResourceEmail,SupervisorId,(SELECT cxs_users.USER_NAME FROM cxs_resources INNER JOIN cxs_users ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_resources.resource_id = a.SupervisorId) AS SupervisorEmail 
					FROM ( SELECT cxs_users.USER_NAME AS ResourceEmail, cxs_resources.SUPREVISOR_ID AS SupervisorId,concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as UserName FROM cxs_users INNER JOIN cxs_resources ON cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID WHERE cxs_users.USER_ID = $LoginUserId ) AS a"; 
			$result = mysql_query($qry)		;
			while($row = mysql_fetch_array($result))
			{
				$UserName = $row['UserName'];
				$ResourceEmail = $row['ResourceEmail'];
				$SupervisorEmail = $row['SupervisorEmail'];
			}
			
			/**************** Code for sending email *****************/		
		$SystemDate = date('Y-m-d H:i:s');
		$s_html = "";
		$s_html = "	<html>
					<head></head>
					<body>
					<table align='left' width='600' border=0 cellspacing='1' cellpadding='2'>					
						<tr height='25px'>
							<td style='font-family:Verdana;font-size:10pt;'> Service Request $SrNo has been submitted by user $UserName on $SystemDate. </td>
						</tr>
					</table>
					</body>
					</html>";
		$from_name='Coexsys Time Accounting'; //Website Name
		$from_email='admin@testrbam.com'; //Admin Email		
		$to=$ResourceEmail." ,".$SupervisorEmail;		
		$subject = "Approval for Submit Task";		
		//include "email/newUser.php"; //email design with content included		
		$message = $s_html;		
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: $from_name < $from_email >\r\n";		
	    mail($to, $subject, $message, $headers);				
		/*********************************************************/		
	}
?>
<!-- modals start -->
	<form id = "SupportRequestForm" name = "SupportRequestForm" method="post" action="" >
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalSupportRequest" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Add New Support Request </h4>
					</div>
					<div class="modal-body"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-6 form-group">
								  <label> Issue Statment </label>
								  <input type="text" id = "Text_IssueStatment" name = "Text_IssueStatment" class="form-control requirefieldcls" required maxlength="100">
								</div>
								
								<div class="col-sm-6 form-group">
								  <label> Issue Description </label> 								  
								  <textarea class="form-control" rows="2" id="Text_IssueDesc" name="Text_IssueDesc" maxlength="2000"></textarea>
								</div>
								
								<div class="col-sm-6 form-group">
								  <label> Page or Issue Type </label>								  
								  <?php
										$ComboPageValues = "<option value=''>- Page or Issue Type -</option>";
										$qry = "select * from cxs_page_list order by UI_VALUES";
										$result = mysql_query($qry);
										while($row=mysql_fetch_array($result))
										{
											$PageId= $row['PAGE_ID'];
											$UIValue = $row['UI_VALUES'];
											$ComboPageValues .= "<option value='$PageId'> $UIValue  </option>";
										}
								  ?>
								  <select id = "Combo_Page" name = "Combo_Page" class="form-control requirefieldcls" required >
										<?php echo $ComboPageValues;  ?>
								  </select>								  
								</div>
								<div class="col-sm-6 form-group">
									<label> Is this happening for more than one user </label>								  
									<select id = "Combo_MultiUser" name = "Combo_MultiUser" class="form-control requirefieldcls" required >
										<option value='Y'>Yes</option>
										<option value='N'>No</option>
										<option value='U'>Not Sure</option>
									</select>
								</div>
								<div class="col-sm-6 form-group">
									<label> Is there a work around? </label>								  
									<select id = "Combo_WorkAround" name = "Combo_WorkAround" class="form-control requirefieldcls" required >
										<option value='Y'>Yes</option>
										<option value='N'>No</option>
										<option value='U'>Not Sure</option>
									</select>
								</div>
								<div class="col-sm-6 form-group">
									<label> What is the impact if not resolved? </label>								  
									<select id = "Combo_ImpactStatment" name = "Combo_ImpactStatment" class="form-control  requirefieldcls" required >
										<option value='Cannot Enter Time'>Cannot Enter Time</option>
										<option value='Cannot Submit Time'>Cannot Submit Time</option>
										<option value='Cannot Approve Time'>Cannot Approve Time</option>
									</select>
								</div>
							<!--	
								<div class="col-sm-6 form-group">
								  <label> Submit Customization Request </label>
								  <input type="text" id = "Text_CustomizationRequest" name = "Text_CustomizationRequest" class="form-control requirefieldcls" required maxlength="100">
								</div> -->
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<button type="submit" id = "cmdSubmit"  name = "cmdSubmit" class="btn btn-primary btn-style"> Submit </button>						
					</div>
				</div>
			</div>
		</div>		
	</form>
	<!-- modals end -->

	<div class="fright cr-user">  
		<button type="button" class="btn btn-primary btn-style" id = "cmdCreate" name = "cmdCreate"  data-toggle="modal" data-target="#ModalSupportRequest"  > Create Support Request</button> 	<!-- onclick= 'ReadonlyInputElements(false)' -->				
	</div>	
	<div class="row tab-edit">
		<?php
			$selectQuery = "SELECT * from cxs_support_request $SQueryOrderBy"; //and cxs_te_header.STATUS = 'OPEN'
			$selectQueryForPages  = $selectQuery;
			$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
			
			$RunUserQuery=mysql_query($selectQuery);
			$StdNumRows = mysql_num_rows($RunUserQuery);
			$msg = "";
			if($StdNumRows == 0 )
			{
				$msg = "No Record Found";
			}
			
		?>
		<form action="" method="post"id="Form1" name="Form1">
			<div class="data-bx">
				<div class="table-responsive">						
					<table class="table table-bordered " width="100%" id='TableTimesheetHistory'>
					  <thead>
						<tr>
							<th width="12%">
							<?php if($Sorts == 'desc' && $FileName == 'SR_NUMBER') { ?>
								  <span style="">
									Request Number
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('SR_NUMBER','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Request Number
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('SR_NUMBER','desc');"></i>
								  </span>
							<?php } ?>
							</th>
							<th width="35%">
							<?php if($Sorts == 'desc' && $FileName == 'ISSUE_STMT') { ?>
								  <span style="">
									Issue Statment
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ISSUE_STMT','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Issue Statment
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ISSUE_STMT','desc');"></i>
								  </span>
							<?php } ?>
							</th>
							
							<th width="10%">
							<?php if($Sorts == 'desc' && $FileName == 'CREATION_DATE') { ?>
								  <span style="">
									Date Created
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CREATION_DATE','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Date Created
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CREATION_DATE','desc');"></i>
								  </span>
							<?php } ?>
							</th>							
							
							<th width="15%">
							<?php if($Sorts == 'desc' && $FileName == 'LAST_UPDATE_DATE') { ?>
								  <span style="">
									Date Last Updated
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('LAST_UPDATE_DATE','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Date Last Updated
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('LAST_UPDATE_DATE','desc');"></i>
								  </span>
							<?php } ?>
							</th>							
							<th width="10%">
							<?php if($Sorts == 'desc' && $FileName == 'SR_STATUS') { ?>
								  <span style="">
									Status<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('SR_STATUS','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Status<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('SR_STATUS','desc');"></i>
								  </span>
							<?php } ?>
							</th>							
							<th width="10%"> <span style="">Action</span> </th>							
						</tr>
					  </thead>							  
					  <tbody>
						<?php
							$i=1;								
							$CurrentPage = Explode('/', $_SERVER['PHP_SELF']);
							$CurrentPage = $CurrentPage[count($CurrentPage) - 1];					
							$LinkPage1 = "te-support-update.php";						
							if($CurrentPage=='rbam-support.php')
							{
								$LinkPage1 = "../te/te-support-update.php";							
							}									
							while($row= mysql_fetch_array($RunUserQuery))
							{
								$id = $row['SUPPORT_REQUEST_ID'];
								//$LinkPage = "te-support-update.php?hid=$id";
								$LinkPage = $LinkPage1."?hid=$id"; //"te-support-update.php?hid=$id";
						?>
								<tr class = "SupportCls" id = "<?php echo$i; ?>">
								<td><?php echo$row['SR_NUMBER']; ?></td>	
								<td><?php echo$row['ISSUE_STMT']; ?></td>	
								<td><?php echo date('m/d/Y ', strtotime($row['CREATION_DATE']));?></td>
								<td><?php echo date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));?></td>
								<td><?php echo$row['SR_STATUS']; ?></td>
								<td>
									<ul class="action-bx">
										<li class="dropdown">
										  <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
										  <ul class="dropdown-menu ac-custom" id = "CurrentUserAction">
											<?php if($row['SR_STATUS']!='Close'){?>
											<li><a href="<?php echo $LinkPage;?>"> Update </a></li>
											<li><a href="javascript:ConfirmFunction('<?php echo $id; ?>','<?php echo $row['SR_NUMBER'];?>')"> Close </a></li>
											<?php } else {?>											
											<li class="disabled"><a href="javascript:void(0);"> Update</a> </li>
											<li class="disabled"><a href="javascript:void(0);">Close</a> </li>
											<?php } ?>
										  </ul>
										</li>
									</ul>
								</td>
								</tr>
					<?php 		$i=$i+1;
							}
						?>	
					  </tbody>
					</table>
				</div>
			</div>	
			<div class="clearfix"></div>
			<!-- pagination start-->
			<div class="pagination-bx">
				<div class="bs-example">
				  <ul class="pagination">
					<?php

							//echo $selectQueryForPages;
							$RunDepQuery=mysql_query($selectQueryForPages);
							$num_records = mysql_num_rows($RunDepQuery);
							$total_pages= ceil($num_records/$RecordsPerPage);
							if (($page-1)==0){ ?>
								<li class="disabled">
									<!--<a rel="0" href="#"> «</a>-->
									<a rel="0" href="#">&laquo;</a>
								</li>
					  <?php  } else{  ?>
						<li class="">
						<a rel="0" href="?page=<?php echo ($page-1); ?>">&laquo;</a>
						</li>
						<?php }
					   for($i=1;$i<=$total_pages;$i++){ ?>
							<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>"><?php echo $i; ?></a></li>
							<?php }
							 if (($page+1)>$total_pages){   ?>
							<li class="disabled"><a href="#">&raquo;</a></li>
								<?php  }else{    ?>
						   <li class=""><a href="?page=<?php echo ($page+1); ?>">&raquo;</a></li>
									  <?php } ?>

				  </ul>

				</div>
			</div>
			<!-- pagination end -->
			<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
			<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">
		</form>	
	</div>	
   
    <script type = "text/javascript">
		function DataSort(str1,str2)
		{
			var str3;
			document.getElementById('h_field_name').value = str1;
			document.getElementById('h_field_order').value = str2;			
			Form1.submit();
		}
		function ConfirmFunction(id,SrNo)
		{
			if(confirm("Are you sure you want to close this Request No "+ SrNo+" ?"))
			{
				$.ajax({
					url:"../ajax-supervisor.php",
					method:"POST",
					data:{Request:"SupportDBClose",Id:id},
					success:function(response)
					{
						SupportRequestForm.submit();
					}
				});
			}
		}
		$(".SupportCls").dblclick(function()
		{
			var Id = $(this).attr('id');
			window.open('te-support-update.php?hid='+Id+"&mode=r"); //'_blank'
		});
	</script>
	