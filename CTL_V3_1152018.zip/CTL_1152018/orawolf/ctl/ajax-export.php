<?php
require_once("conn.php");

$HeadingList = $_POST['ExportHeadings'];
$ExportQry = $_POST['ExportQry'];
$QryFieldName = $_POST['ExportQryFieldName'];
$IdList = $_POST['ExportIdList'];
$ExportFileName = $_POST['ExportFileName'];
$ExportSheetTitle = $_POST['ExportSheetTitle'];
	
if(sizeof($IdList)>0)
{
	foreach($IdList as $id)
	{
		$query_1 .= $QryFieldName.' = '.$id.' or ';
	}
	$query_1 = "and ( ".substr($query_1,0,-3).") ";	
	$position =  stripos($ExportQry,"ORDER BY");
	$ExportQry = putinplace($ExportQry, $query_1, $position);	
}

$_SESSION['ExportHeadings']=$HeadingList;
$_SESSION['ExportQry']=$ExportQry;
$_SESSION['ExportFileName'] = $ExportFileName ;
$_SESSION['ExportSheetTitle'] = $ExportSheetTitle;	
//$_SESSION['ExportQryFieldName']=$QryFieldName;
//$_SESSION['ExportIdList']=$IdList;

function putinplace($string=NULL, $put=NULL, $position=false)
{
    $d1=$d2=$i=false;
    $d=array(strlen($string), strlen($put));
    if($position > $d[0]) $position=$d[0];
    for($i=$d[0]; $i >= $position; $i--) $string[$i+$d[1]]=$string[$i];
    for($i=0; $i<$d[1]; $i++) $string[$position+$i]=$put[$i];
    return $string;
}
?>