<?php

	include('conn.php');

	if($_POST['REQUEST'] == 'FindApprovalList')

	{

		$ResourceId = isset($_POST['ResourceId'])?$_POST['ResourceId']:"";

		$TimeSheetId = isset($_POST['TimeSheetId'])?$_POST['TimeSheetId']:"";

		$SupervisorId = isset($_POST['SupervisorId'])?$_POST['SupervisorId']:"";

		//$query="where  ( cxs_te_header.SUPERVISOR_ID =  $SupervisorId and STATUS_FLAG = 'S'";

		//$query=" where 1=1 ";

		//if($ResourceId!=$SupervisorId)

		{

			$query="where STATUS_FLAG = 'S'";

		}

		if($ResourceId!= '')

		{

			$query .= " and cxs_te_file.RESOURCE_ID = $ResourceId";

		}	

		if($TimeSheetId!= '')

		{

			$query .= " and cxs_te_file.TE_ID = $TimeSheetId";

		}	

		// or  (cxs_te_file.RESOURCE_ID = $SupervisorId)";

?>	

	<table class="table table-bordered " width="100%" id = "TableApprovalList" >

		<thead>

			<tr>

				<th width="5%"><span> TE Date </span></th>

				<th width="20%"><span> Shift </span></th>

				<th width="20%"><span> Alias </span></th>

				<th width="5%"><span> Hours </span></th>

				<th width="5%"><span> Status </span></th>

				<th width="30%"><span> Comment </span></th>

				<th width="5%"><span> Approver Comment </span></th>

		<?php	if($ResourceId!=$SupervisorId)

				{ ?>

				<th width="5%"><span> Approve </span></th>

				<th width="5%"><span> Reject </span></th>					

		<?php 	} ?>		

			</tr>

		</thead>

		<tbody>

<?php

		$CREATE_PRIV_TimeEntry_PERMISSION='Y';

		$qry = "select ENTRY_DATE,SHIFT,cxs_aliases.ALIAS_NAME,cxs_te_file.SEED_ALIAS,sum(cxs_te_file.HOURS) as Hours,cxs_te_file.STATUS_FLAG,cxs_te_file.TE_ID,cxs_te_file.RESOURCE_ID,cxs_te_file.ALIAS_ID,cxs_te_file.COMMENT as CommentPopup,cxs_te_file.APPROVER_COMMENT from cxs_te_file 

					inner join cxs_te_header on cxs_te_header.TE_ID = cxs_te_file.TE_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID $query

					group by cxs_te_file.RESOURCE_ID,cxs_te_file.ENTRY_DATE,cxs_aliases.ALIAS_NAME,cxs_te_file.SEED_ALIAS,STATUS_FLAG

					order by cxs_te_file.ENTRY_DATE desc,cxs_aliases.ALIAS_NAME";

		$result = mysql_query($qry);

		//$noofrecords = mysql_num_rows($result);	

		$i=1;

		while($row = mysql_fetch_array($result))

		{

			$EntryDate = date('m/d/Y', strtotime($row['ENTRY_DATE']));

			$AliasName = isset($row['ALIAS_NAME'])?$row['ALIAS_NAME']:$row['SEED_ALIAS'];	

			if($row['STATUS_FLAG']=="S")

			{

				$Status = "Submitted";

			}

			else if($row['STATUS_FLAG']=="W")

			{

				$Status = "Working";

			}

			else if($row['STATUS_FLAG']=="A")

			{

				$Status = "Approved";

			}

			else if($row['STATUS_FLAG']=="R")

			{

				$Status = "Rejected";

			}

			else 

			{

				$Status = $row['STATUS_FLAG'];

			}

			$TimeSheetId = $row['TE_ID'];

			$ResourceId = $row['RESOURCE_ID'];			

?>			<tr>

				<td> <span id = "<?php echo 'Span_EntryDate'.$i;?>" ><?php echo $EntryDate; ?></span>	</td>

				<td> <span id = "<?php echo 'Span_Shift'.$i;?>"><?php echo $row['SHIFT']; ?></span> </td>

				<td> <span id = "<?php echo 'Span_Alias'.$i;?>"><?php echo $AliasName; ?></span>	</td>

				<td align="right"> <span id = "<?php echo 'Span_Hours'.$i;?>"><?php echo number_format((float)$row['Hours'], 2, '.', ''); ; ?></span> </td>

				<td> <span id = "<?php echo 'Span_Status'.$i;?>"><?php echo $Status; ?></span> </td>

				<td> <span id = "<?php echo 'Span_Comment'.$i;?>"><?php echo $row['CommentPopup']; ?></span> </td>

				<td class = 'check-bx'>

					

					<input type="button" id = "<?php echo "cmdNotes$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" onclick = "ShowPopup('<?php echo$i; ?>')" value = "..."  >

					<input type="hidden" id = "<?php echo "h_comment$i"; ?>"  value = "<?php echo $row['APPROVER_COMMENT']; ?>">	

					

				</td>

				<?php if($ResourceId!=$SupervisorId) { ?> 

					<td class = 'check-bx'> <input type="button" id = "<?php echo 'cmdApprove'.$i;?>" class="btn btn-primary ClsAction"  value = "Approve" onclick = "ActionFun('<?php echo$i; ?>','A');"></td>

					<td class = 'check-bx'> <input  type="button" id = "<?php echo 'cmdReject'.$i;?>" class="btn btn-primary ClsAction" value = "Reject"  onclick = "ActionFun('<?php echo$i; ?>','R');"></td>

				<?php } ?>

				<input type = "hidden" id = "<?php echo 'hAliasId'.$i;?>" value = "<?php echo $row['ALIAS_ID']; ?>" >

				<input type = "hidden" id = "<?php echo 'hSeedAlias'.$i;?>" value = "<?php echo $row['SEED_ALIAS']; ?>" >

			</tr>

<?php 		$i++;

		} ?>	

		</tbody>

		<input type = "hidden" id = "hTimeSheetId" value = "<?php echo $TimeSheetId; ?>">

		<input type = "hidden" id = "hResourceId" value = "<?php echo $ResourceId; ?>">

	</table>	

<?php }





if($_POST['REQUEST'] == 'FindApprovalHistory')

	{

		$ResourceId = isset($_POST['ResourceId'])?$_POST['ResourceId']:"";

		$TimeSheetId = isset($_POST['TimeSheetId'])?$_POST['TimeSheetId']:"";

		$SupervisorId = isset($_POST['SupervisorId'])?$_POST['SupervisorId']:"";

		//$query="where  ( cxs_te_header.SUPERVISOR_ID =  $SupervisorId and STATUS_FLAG = 'S'";

		//$query=" where 1=1 ";

		//if($ResourceId!=$SupervisorId)

		{

			$query="where STATUS_FLAG = 'S'";

		}

		if($ResourceId!= '')

		{

			$query .= " and cxs_te_file.RESOURCE_ID = $ResourceId";

		}	

		if($TimeSheetId!= '')

		{

			$query .= " and cxs_te_file.TE_ID = $TimeSheetId";

		}	

		// or  (cxs_te_file.RESOURCE_ID = $SupervisorId)";

?>	

	<table class="table table-bordered " width="100%" id = "TableApprovalHistory" >

		<thead>

			<tr>

				<th width="5%"><span> TE Date </span></th>

				<th width="20%"><span> Shift </span></th>

				<th width="20%"><span> Alias </span></th>

				<th width="5%"><span> Hours </span></th>

				<th width="5%"><span> Status </span></th>

				<th width="30%"><span> Comment </span></th>

				<th width="5%"><span> Approver Comment </span></th>		

				<th width="5%"><span>  </span></th>				

			</tr>

		</thead>

		<tbody>

<?php

		$CREATE_PRIV_TimeEntry_PERMISSION='Y';

		$qry = "select ENTRY_DATE,SHIFT,cxs_aliases.ALIAS_NAME,cxs_te_file.SEED_ALIAS,sum(cxs_te_file.HOURS) as Hours,cxs_te_file.STATUS_FLAG,cxs_te_file.TE_ID,cxs_te_file.RESOURCE_ID,cxs_te_file.ALIAS_ID,cxs_te_file.COMMENT as CommentPopup,cxs_te_file.APPROVER_COMMENT,cxs_te_file.CREATED_BY,cxs_te_file.CREATION_DATE,cxs_te_file.LAST_UPDATED_BY,cxs_te_file.LAST_UPDATED_BY,cxs_te_file.LAST_UPDATE_DATE from cxs_te_file 

					inner join cxs_te_header on cxs_te_header.TE_ID = cxs_te_file.TE_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID $query

					group by cxs_te_file.RESOURCE_ID,cxs_te_file.ENTRY_DATE,cxs_aliases.ALIAS_NAME,cxs_te_file.SEED_ALIAS,STATUS_FLAG

					order by cxs_te_file.ENTRY_DATE desc,cxs_aliases.ALIAS_NAME";

		$result = mysql_query($qry);

		//$noofrecords = mysql_num_rows($result);	

		$i=1;

		while($row = mysql_fetch_array($result))

		{

			$EntryDate = date('m/d/Y', strtotime($row['ENTRY_DATE']));

			$AliasName = isset($row['ALIAS_NAME'])?$row['ALIAS_NAME']:$row['SEED_ALIAS'];	

			if($row['STATUS_FLAG']=="S")

			{

				$Status = "Submitted";

			}

			else if($row['STATUS_FLAG']=="W")

			{

				$Status = "Working";

			}

			else if($row['STATUS_FLAG']=="A")

			{

				$Status = "Approved";

			}

			else if($row['STATUS_FLAG']=="R")

			{

				$Status = "Rejected";

			}

			else 

			{

				$Status = $row['STATUS_FLAG'];

			}

			$TimeSheetId = $row['TE_ID'];

			$ResourceId = $row['RESOURCE_ID'];	



			$Display_CreatedBy	= $row['CREATED_BY'];

			$Display_CreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $Display_CreatedBy");			

			$Display_CreationDate = date('m/d/Y ', strtotime($row['CREATION_DATE']));							

			$UpdatedBy		= $row['LAST_UPDATED_BY'];

			$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							

			$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));

			

?>			<tr>

				<td> <span id = "<?php echo 'SpanH_EntryDate'.$i;?>" ><?php echo $EntryDate; ?></span>	</td>

				<td> <span id = "<?php echo 'SpanH_Shift'.$i;?>"><?php echo $row['SHIFT']; ?></span> </td>

				<td> <span id = "<?php echo 'SpanH_Alias'.$i;?>"><?php echo $AliasName; ?></span>	</td>

				<td align="right"> <span id = "<?php echo 'SpanH_Hours'.$i;?>"><?php echo number_format((float)$row['Hours'], 2, '.', ''); ; ?></span> </td>

				<td> <span id = "<?php echo 'SpanH_Status'.$i;?>"><?php echo $Status; ?></span> </td>

				<td> <span id = "<?php echo 'SpanH_Comment'.$i;?>"><?php echo $row['CommentPopup']; ?></span> </td>

				<td class = 'check-bx'>

					<input type="button" id = "<?php echo "cmdNotesH$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" onclick = "ShowPopup('<?php echo$i; ?>')" value = "..."  >

					<input type="hidden" id = "<?php echo "h_commentH$i"; ?>"  value = "<?php echo $row['APPROVER_COMMENT']; ?>">						

				</td>

				<td class = 'check-bx'>					

					<button type="button" class="btn btn-default1" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="

					Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 

					<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>					

				</td>

			<!--	<td class = 'check-bx'>										

					<button type="button" class="btn btn-default"  data-toggle="tooltip" data-placement="left" 

						title="Created By: <?php echo $Display_CreatedByName; ?>&#013;Updated By: <?php echo $Display_UpdatedByName; ?>

						&#013;Creation Date: <?php echo $Display_CreationDate; ?> &#013;Last Update Date: <?php echo $Display_LastUpdate; ?>">

						<i class="fa fa-eye"></i>

					</button>					

				</td>				 -->

			</tr>

<?php 		$i++;

		} ?>	

		</tbody>

		<input type = "hidden" id = "hTimeSheetId" value = "<?php echo $TimeSheetId; ?>">

		<input type = "hidden" id = "hResourceId" value = "<?php echo $ResourceId; ?>">

	</table>	

<?php }

if($_POST['REQUEST'] == 'SetAction')

{

	$Action = isset($_POST['Action'])?$_POST['Action']:"";

	$TimeSheetId = isset($_POST['TimeSheetId'])?$_POST['TimeSheetId']:"";

	$ResourceId = isset($_POST['ResourceId'])?$_POST['ResourceId']:"";

	$AliasId = isset($_POST['AliasId'])?$_POST['AliasId']:"";

	$SeedAlias = isset($_POST['SeedAlias'])?$_POST['SeedAlias']:"";

	$EntryDate = isset($_POST['EntryDate'])?$_POST['EntryDate']:"";

	$EntryDate = strtotime($EntryDate);

	$EntryDate = date("Y-m-d",$EntryDate);

	$LoginUserId = $_SESSION['user_id']; 

	$Comment = isset($_POST['Comment'])?$_POST['Comment']:"";									

	

	$qry = "select * from cxs_te_file where ENTRY_DATE = '$EntryDate' and TE_ID = $TimeSheetId and RESOURCE_ID = $ResourceId and ALIAS_ID = $AliasId and SEED_ALIAS = '$SeedAlias'";

	$result = mysql_query($qry);

	while($row = mysql_fetch_array($result))

	{

		$DetailId = $row['DETAIL_ID'];

		//echo "update table cxs_te_file set STATUS_FLAG = '$Action',LAST_UPDATED_BY =  $LoginUserId where DETAIL_ID = $DetailId";

		

		//if($Action=='Comment')

		//{

			mysql_query("update cxs_te_file set APPROVER_COMMENT = '$Comment',LAST_UPDATED_BY =  $LoginUserId where DETAIL_ID = $DetailId" );

		//}

	//	else

	//	{

			mysql_query("update cxs_te_file set APPROVER_COMMENT = '$Comment',STATUS_FLAG = '$Action',LAST_UPDATED_BY =  $LoginUserId where DETAIL_ID = $DetailId" );

			if($Action=='A')

			{

				$insarr = array();

				$insArr['TE_ID'] = $row['TE_ID'];

				$insArr['RESOURCE_ID'] =  $row['RESOURCE_ID'];

				$insArr['ALIAS_ID'] =  $row['ALIAS_ID'];

				$insArr['ACTUAL_HOURS'] =  $row['HOURS'];

				$insArr['COMMENT'] =  $Comment;

				$insArr['ENTRY_DATE'] =  $row['ENTRY_DATE'];

				$insArr['APPROVAL_DATE'] =  'now()';

				$insArr['CREATED_BY'] =  $LoginUserId;		

				$insArr['LAST_UPDATED_BY'] = $LoginUserId;				

				$insArr['CREATION_DATE']='now()';				

				insertdata("cxs_te_approved",$insArr);	

			}	

			echo "done";

	//	}

	}

}

if ($_POST['Request'] == "SupportDBClose")

{

	$Id = isset($_POST['Id'])?$_POST['Id']:0;

	mysql_query("update cxs_support_request set SR_STATUS = 'Close' where SUPPORT_REQUEST_ID = $Id");

}

if($_POST['Request']=="FreeTrialRecord")

{

	function random_password( $length = 8 ) 

	{

    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";

    $password = substr( str_shuffle( $chars ), 0, $length );

    return $password;

	}

	$EnteredEmail = strtoupper($_POST["Text_EmailFreeTrial"]);

	$qry = "select *  from cxs_sites where EMAIL = '$EnteredEmail'";

	$result= mysql_query($qry);

	$noofrecords = mysql_num_rows($result);

	if($noofrecords==0)

	{

		$Expr1 = 0;

		$qry = "select count(*) as expr1 from cxs_sites";

		$result= mysql_query($qry);

		while($row=mysql_fetch_array($result))

		{

			$Expr1 = $row['expr1'];

		}

		$Expr1=$Expr1+1; 

	

	//parse_str($_POST['FormData'],$formArr);	

//	$Text_FirstName = isset($formArr["Text_FirstName"] )? $formArr["Text_FirstName"]: false;

		$new_psw = random_password(8);

		$TempPassword = GetPassword($new_psw);

		$insArr['FIRST_NAME'] = $_POST["Text_FirstName"];

		$insArr['LAST_NAME'] = $_POST["Text_LastName"];

		$insArr['JOB_TITLE'] = $_POST["Text_JobTitle"];

		$insArr['EMAIL'] = $EnteredEmail;

		$insArr['PHONE'] = $_POST["Text_Phone"];

		$insArr['SITE_NAME'] = $_POST["Text_Company"];

		$insArr['SITE_CODE'] = substr($_POST["Text_Company"], 0, 5).$Expr1;

		$insArr['EMPLOYEE_BREAK'] = $_POST["Combo_Employees"];	

		$insArr['CREATION_DATE']='now()' ;

		$insArr['SYSTEM_PASSWORD'] = $TempPassword;

		insertdata("cxs_sites",$insArr);	

		

		$LastInsertedSite = mysql_insert_id();
		echo $LastInsertedSite;
		

		//CreateSystemGenerateUser($LastInsertedSite);

		

		if($LastInsertedSite>0) 

		{

			/************* Email sending code *************/

		   $from_name='Coexsys Time Accounting'; //Website Name

		   $from_email='admin@testrbam.com'; //Admin Email		  

		   $to=$_POST["Text_EmailFreeTrial"];

		   $subject = "Temporary password generate";

		   $cc="";

		   include "rbam/email/tempPasswordGenerate.php"; //email design with content included				   

		   $headers  = "MIME-Version: 1.0\r\n";

		   $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";

		   $headers .= "From: $from_name < $from_email >\r\n";

			

		   mail($to, $subject, $message, $headers);		   

		   /************************************************/

		   

		   //echo "Your free trial up to 30 days has been activated and a temporary password sent to you via email. at $to.";

		   

			echo "true";

		}

	}

	else

	{

		//echo "Email $EnteredEmail is already registered. Please enter another email.";

			echo "false";

	}

}

?>