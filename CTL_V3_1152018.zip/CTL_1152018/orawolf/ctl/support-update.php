<?php
	$HeaderId =  isset( $_GET['hid'] )? $_GET['hid']:0;
	$mode = isset($_GET['mode'])?$_GET['mode']:'';
	
	$qry = "select * from cxs_support_request where SUPPORT_REQUEST_ID = $HeaderId";
	$result = mysql_query($qry);
	while($row = mysql_fetch_array($result))
	{
		$IssueStatment = $row['ISSUE_STMT'];
		$RequestNumber = $row['SR_NUMBER'];
		$SupportStatus = $row['SR_STATUS'];
	}
	if (isset($_POST['cmdSubmit'] ))
	{
		$Text_IssueDesc = isset($_POST["Text_IssueDesc"] )? $_POST["Text_IssueDesc"]: false;
		
		$result = mysql_query("SELECT * FROM cxs_support_history where SUPPORT_REQUEST_ID = $HeaderId");
		$num_rows = mysql_num_rows($result);
		$Counter = $num_rows+1;
		
		unset($inArr1);	
		$insArr1['SUPPORT_REQUEST_ID']	 = 	$HeaderId;
		$insArr1['UPDATE_COUNTER'] 		 =  $Counter;
		$insArr1['UPDATE_STMT'] 		 =  $Text_IssueDesc;		
		$insArr1['CREATED_BY'] 			= $LoginUserId ;
		$insArr1['CREATION_DATE'] 		= date('Y-m-d H:i:s');
		$insArr1['LAST_UPDATED_BY'] 		= $LoginUserId;	
		insertdata("cxs_support_history",$insArr1);	
		
		$qry = "SELECT UserName,ResourceEmail,SupervisorId,(SELECT cxs_users.USER_NAME FROM cxs_resources INNER JOIN cxs_users ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_resources.resource_id = a.SupervisorId) AS SupervisorEmail 
					FROM ( SELECT cxs_users.USER_NAME AS ResourceEmail, cxs_resources.SUPREVISOR_ID AS SupervisorId,concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as UserName FROM cxs_users INNER JOIN cxs_resources ON cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID WHERE cxs_users.USER_ID = $LoginUserId ) AS a"; 
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$UserName = $row['UserName'];
			$ResourceEmail = $row['ResourceEmail'];
			$SupervisorEmail = $row['SupervisorEmail'];
		}
		
		mysql_query("update cxs_support_request set SR_STATUS = 'In Progress' where SUPPORT_REQUEST_ID = $HeaderId");
			/**************** Code for sending email *****************/		
		$SystemDate = date('Y-m-d H:i:s');
		$s_html = "";
		$s_html = "	<html>
					<head></head>
					<body>
					<table align='left' width='600' border=0 cellspacing='1' cellpadding='2'>					
						<tr height='25px'>
							<td style='font-family:Verdana;font-size:10pt;'> Service Request $SrNo has been submitted by user $UserName on $SystemDate. </td>
						</tr>
					</table>
					</body>
					</html>";
		$from_name='Coexsys Time Accounting'; //Website Name
		$from_email='admin@testrbam.com'; //Admin Email		
		$to=$ResourceEmail." ,".$SupervisorEmail;		
		$subject = "Approval for Submit Task";		
		//include "email/newUser.php"; //email design with content included		
		$message = $s_html;		
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: $from_name < $from_email >\r\n";		
	    mail($to, $subject, $message, $headers);				
		/*********************************************************/	
	}
?>

<style type="text/css">
.requirefieldcls{	background-color: #fff99c;	}
</style>
<div class="row tab-edit">
	<div class="cr-user mar-btm20">
		<h3>
		<span style = "font-family: Calibri;"> <b>Request Number : </b> </span>	<span style = "font-family: Calibri;padding-right:50px;" id = "Span_RequestNumber"> <?php	echo $RequestNumber;  ?></span>
		<span style = "font-family: Calibri;"> <b>Issue Statment : </b> </span>	<span style = "font-family: Calibri;padding-right:50px;" id = "Span_IssueStatment"> <?php	echo $IssueStatment;  ?></span>		
		</h3>
	</div>	
	<div class="col-md-12 ">
	<form method="post" >
		<?php if($mode=='' && $SupportStatus !='Close') {?>
		<div class="row" id = "Div_Entry">
			<div class="col-sm-12 form-group">
			  <label> Issue Description </label> 								  
			  <textarea class="form-control requirefieldcls" required rows="2" id="Text_IssueDesc" name="Text_IssueDesc" maxlength="2000"></textarea>
			</div>
			<!--
			<div class="col-sm-3 form-group">
			  <label> Page or Issue Type </label>								  
			  <?php
					$ComboPageValues = "<option value=''>- Page or Issue Type -</option>";
					$qry = "select * from cxs_page_list order by UI_VALUES";
					$result = mysql_query($qry);
					while($row=mysql_fetch_array($result))
					{
						$PageId= $row['PAGE_ID'];
						$UIValue = $row['UI_VALUES'];
						$ComboPageValues .= "<option value='$PageId'> $UIValue  </option>";
					}
			  ?>
			  <select id = "Combo_Page" name = "Combo_Page" class="form-control requirefieldcls" required >
					<?php echo $ComboPageValues;  ?>
			  </select>								  
			</div>
			-->
			<div class="col-sm-12 form-group">
				<button type="submit" id = "cmdSubmit"  name = "cmdSubmit" class="btn btn-primary btn-style"> Submit </button>
			</div>
		</div>
		<?php } ?>
		<div class="row" >
			<div class="data-bx col-sm-12">
				<div class="table-responsive">						
					<table class="table table-bordered " width="100%" id='TableTimesheetHistory'>
						<thead>
							<tr>
								<th width="75%"><span> Update Statment</span></th>
								<th width="15%"><span> Updated Date & Time </span></th>
								<th width="10%"><span> Updated By</span></th>								
							</tr>
						</thead>							  
						<tbody>
							<?php
								$qry = "select cxs_support_history.UPDATE_STMT,cxs_support_history.LAST_UPDATE_DATE,cxs_users.USER_NAME from cxs_support_history inner join cxs_users on cxs_users.USER_ID = cxs_support_history.LAST_UPDATED_BY  where cxs_support_history.SUPPORT_REQUEST_ID = $HeaderId order by cxs_support_history.LAST_UPDATE_DATE desc";
								$result = mysql_query($qry);
								while($row = mysql_fetch_array($result))
								{?>
									<tr>
										<td><?php echo $row['UPDATE_STMT']; ?> </td>
										<td><?php echo $row['LAST_UPDATE_DATE']; ?> </td>
										<td><?php echo $row['USER_NAME']; ?> </td>
						<?php	}
							?>
						</tbody>
					</table>
				</div>
			</div>	
		</div>		
	</div>	
	</form>
	</div>