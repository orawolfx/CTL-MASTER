

<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">

<script src="../js/jquery.dataTables.min.js"></script>

<script src="../js/dataTables.bootstrap.min.js"></script>



<style>

	/*.bootstrap-select > .dropdown-menu > .dropdown-menu li a 

	{

		background-color: #fff99c;

	}*/

	/*.btn-default {    

    background-color: #fff99c;

	}

	.mycs {    

    background-color: #fff99c;

	}*/

	</style>

		 <!-- Notes detail pop up  start -->

		<div id="note-modal" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">

			<div class="modal-dialog modal-sm cus-modal-lg" role="document">

				<div class="modal-content">

					<div class="modal-body">

						<!-- field start-->

						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

						<form id = "FormNote" >

							<div class="col-sm-12">						

								<div class="cus-form-cont">

									<div class="form-group">

										<label> Notes </label>

										<textarea class="form-control" rows="5" id="comment" maxlength="150"></textarea>

										<input type = "hidden" id = "PopupClickedElement" >

									</div>

								</div>

							</div>

						</form>	

						<!-- end -->

					</div>

					<div class="clear-both"></div>

					<div class="modal-footer cr-user">

						<button type="button" class="btn btn-primary btn-style" id = "cmdOK_Popup"> OK </button>

					</div>

				</div>

			</div>

		</div>

		<!-- Notes detail pop up end -->

		

		<div class="row tab-edit">

			<div id="tabs">

				<ul>

					<li><a href="#tabs-1">Approval List</a></li>

					<li><a href="#tabs-2">Time Sheet History</a></li>

					<li><a href="#tabs-3">Approval History</a></li>

				</ul>

				<div id="tabs-1">

					<form action="" method="post"id="Form1" name="Form1" onsubmit = "return chkRoleSearch()">

						<div class="col-sm-12">

							<div class="cus-form-cont">				

							  <!-- find block start-->

								<div class="pr" >

									<div class="cus-form-cont" >

										<div class="col-sm-5 form-group">

											<label> Resource Name </label>

											<?php 

												$SupervisorId =0;

												$qry = "select cxs_resources.RESOURCE_ID from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID where cxs_users.USER_ID = $LoginUserId";

												$result = mysql_query($qry);

												while($row = mysql_fetch_array($result))

												{

													$SupervisorId = $row['RESOURCE_ID'];

												}

												$ResourceList = "<option value = '' style = 'color: #000;'> - Resource Name - </option>";

												$ResourceListHistory = "<option style = 'color: #000;' value = ''> - Resource Name - </option>";

												//echo$qry = "select distinct RESOURCE_ID,FIRST_NAME,LAST_NAME from cxs_resources order by FIRST_NAME,LAST_NAME ";

												$qry = "select cxs_resources.RESOURCE_ID,FIRST_NAME,LAST_NAME from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID where cxs_resources.SUPREVISOR_ID = $SupervisorId  or cxs_resources.RESOURCE_ID =$SupervisorId order by FIRST_NAME,LAST_NAME ";

												$result = mysql_query($qry)		;

												while($row = mysql_fetch_array($result))

												{

													$ResourceId = $row['RESOURCE_ID'];

													$ResourceName = $row['FIRST_NAME']." ".$row['LAST_NAME'];

													$ResourceList .= "<option style = 'color: #000;' value = '$ResourceId'> $ResourceName </option>";													

													if($ResourceId!=$SupervisorId)

													{

														$ResourceListHistory .= "<option style = 'color: #000;' value = '$ResourceId'> $ResourceName </option>";

													}

												}

											?>											

											<select class='form-control selectpicker mycs' id = "Combo_FindResourceId" name = 'Combo_FindResourceId' style = "font-weight:normal; background-color: #fff99c; " data-show-subtext="true" data-live-search="true"> <?php echo $ResourceList; ?> </select>

											<span id = "span_resource"></span>

										</div>

										

										<div class="col-sm-5 form-group">

											<label> Time Sheet Name </label>

											<?php 

												$TimeSheetList = "<option value = '' style = 'color: #000;'> - Time Sheet Name - </option>";

												

												//echo$qry = "select distinct RESOURCE_ID,FIRST_NAME,LAST_NAME from cxs_resources order by FIRST_NAME,LAST_NAME ";

												$qry = "select * from cxs_te_header  where cxs_te_header.SUPERVISOR_ID = $SupervisorId or cxs_te_header.RESOURCE_ID = $SupervisorId order by TE_Name,PAY_PERIOD_ID desc";

												$result = mysql_query($qry)		;

												while($row = mysql_fetch_array($result))

												{

													$TimeSheetId = $row['TE_ID'];

													$TimeSheetName = $row['TE_NAME'];													

													$TimeSheetList .= "<option style = 'color: #000;' value = '$TimeSheetId'> $TimeSheetName </option>";													

												}

											?>											

											<select class='form-control selectpicker mycs' id = "Combo_FindTimeSheetId" name = 'Combo_FindTimeSheetId' style = "font-weight:normal; background-color: #fff99c; " data-show-subtext="true" data-live-search="true"> <?php echo $TimeSheetList; ?> </select>

											<span id = "span_timesheet"></span>

										</div>

										<div class="col-sm-2 form-group ">	

											<label> &nbsp;</label>

											<button type="button" id="cmdFindApproval" name="cmdFindApproval" class="btn btn-primary btn-style2 w100 " > <i class="fa fa-search" aria-hidden="true"></i> Find </button>

										</div>

										<input type = "hidden" id = "h_SupervisorID" value = "<?php echo $SupervisorId; ?>" >

										<div class="data-bx">

											<div class="table-responsive" id = "DivApprovalList">

												

											</div>

										</div>

										

									</div>

								</div>

							</div>	

						</div>

						<div class="clearfix"></div>

					</form>

				</div>

				

				<div id="tabs-2">

					

					<div class="data-bx">

						<div class="table-responsive">						

							<table class="table table-bordered " width="100%" id='TableTimesheetHistory'>

							  <thead>

								<tr>

									<th width="50%"><span> Time Sheet Name </span></th>

									<th width="30%"><span> Period </span></th>

									<th width="20%"><span> Status </span></th>

								</tr>

							  </thead>							  

							  <tbody>

								<?php

									$qry = "select cxs_resources.RESOURCE_GROUP_ID from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_users.USER_ID = $LoginUserId";

									$result = mysql_query($qry);

									while($row = mysql_fetch_array($result))

									{

										$ResourceGroupId = $row['RESOURCE_GROUP_ID'];

									}

									if($ResourceGroupId =='0')

									{

										$subQuery = " where RESOURCE_GROUP_ID = $ResourceGroupId ";

									}

									else

									{

										$subQuery = " where USER_ID = $LoginUserId ";

									}

									$TimeSheetHistoryLimit = "";

									$TimeCards = 0;

									$TimeCards = getvalue("cxs_am_ta_rules","RECENT_TIMECARDS",$subQuery);									

									if($TimeCards>0)

									{

										$TimeSheetHistoryLimit = "Limit 0,$TimeCards";

									}

									$i=1;

									$qry = "SELECT cxs_te_header.TE_ID , cxs_te_header.TE_NAME,cxs_periods.PERIOD_NAME,cxs_te_header.STATUS,cxs_te_header.PAY_PERIOD_ID  FROM cxs_te_header

											inner join cxs_periods on cxs_periods.PERIOD_ID = cxs_te_header.PAY_PERIOD_ID WHERE cxs_te_header.RESOURCE_ID = $SupervisorId order by cxs_te_header.PAY_PERIOD_ID desc $TimeSheetHistoryLimit"; //and cxs_te_header.STATUS = 'OPEN'

									$result = mysql_query($qry)	;

									while($row= mysql_fetch_array($result))

									{?>

										<tr class = "clsTimeSheetH" id = "<?php echo$i; ?>" >

										<td><?php echo$row['TE_NAME']; ?></td>	

										<td><?php echo$row['PERIOD_NAME']; ?></td>	

										<td><?php echo$row['STATUS']; ?></td>

										<input type = "hidden"	id = "<?php echo'h_History_TE'.$i ?>" value = "<?php echo $row['TE_ID'] ?>"  >

										<input type = "hidden"	id = "<?php echo'h_History_PeriodId'.$i ?>" value = "<?php echo $row['PAY_PERIOD_ID'] ?>">

										</tr>

							<?php 		$i++;

									}

								?>	

							  </tbody>

							</table>

						</div>

					</div>	

						

					<div class="clearfix"></div>

					

				</div>

				

				<div id="tabs-3">

					

					<div class="data-bx">

						<div class="col-sm-5 form-group">

							<label> Resource Name </label>	

							<select class='form-control selectpicker ' id = "Combo_FindResourceIdHistory"  style = "font-weight:normal; background-color: #fff99c; " data-show-subtext="true" data-live-search="true"> <?php echo $ResourceListHistory; ?> </select>

							<span id = "span_resourceHistory"></span>

						</div>

						<?php

							$TimeSheetListHistory = "<option style = 'color: #000;' value = ''> - Time Sheet Name - </option>";

							$qry = "select * from cxs_te_header  where cxs_te_header.SUPERVISOR_ID = $SupervisorId order by TE_Name,PAY_PERIOD_ID desc";

							$result = mysql_query($qry)		;

							while($row = mysql_fetch_array($result))

							{

								$TimeSheetId = $row['TE_ID'];

								$TimeSheetName = $row['TE_NAME'];													

								$TimeSheetListHistory .= "<option style = 'color: #000;' value = '$TimeSheetId'> $TimeSheetName </option>";

							}

						?>

						<div class="col-sm-5 form-group">

							<label> Time Sheet Name </label>																	

							<select class='form-control selectpicker ' id = "Combo_FindTimeSheetIdHistory"  style = "font-weight:normal; background-color: #fff99c; " data-show-subtext="true" data-live-search="true"> <?php echo $TimeSheetListHistory; ?> </select>

							<span id = "span_timesheetHistory"></span>

						</div>

						<div class="col-sm-2 form-group ">	

							<label> &nbsp;</label>

							<button type="button" id="cmdFindApprovalHistory" name="cmdFindApprovalHistory" class="btn btn-primary btn-style2 w100 " > <i class="fa fa-search" aria-hidden="true"></i> Find </button>

						</div>

						<div class="data-bx">

							<div class="table-responsive">

								<div class="table-responsive" id = "DivApprovalHistory">

									

								</div>

							</div>

						</div>

					</div>	

						

					<div class="clearfix"></div>

					

				</div>

			</div>

		</div>	

	</div>

<script>

	$(document).ready(function(){	

		$( "#tabs" ).tabs({		

			active: 0		

			});

	});		



	$("#cmdFindApproval").click(function()

	{

		var ResourceId = $("#Combo_FindResourceId").val();

		var TimeSheetId = $("#Combo_FindTimeSheetId").val();

		$("#span_resource").text("");

		$("#span_timesheet").text("");

		if(ResourceId=='')

		{

			$("#span_resource").text("Please select resource name.");

		}

		if(TimeSheetId=='')

		{

			$("#span_timesheet").text("Please select time sheet name.");

		}

		

		if(ResourceId=='' || TimeSheetId=='')

		{

			return false;

		}

		var SupervisorId = $("#h_SupervisorID").val();			

		$.ajax({

				url : "../ajax-supervisor.php",

				method : "POST",

				data :{REQUEST:"FindApprovalList",ResourceId : ResourceId,TimeSheetId : TimeSheetId,SupervisorId:SupervisorId},

				success:function(response)

				{

					//alert(response);

					$("#DivApprovalList").text('');

					$("#DivApprovalList").append(response.trim());

					$("#TableApprovalList").DataTable({"searching": false,order: [],orderable: false});

				}

			});			

	});	

	

	

	

	$("#cmdFindApprovalHistory").click(function()

	{

		var ResourceId = $("#Combo_FindResourceIdHistory").val();

		var TimeSheetId = $("#Combo_FindTimeSheetIdHistory").val();

		$("#span_resourceHistory").text("");

		$("#span_timesheetHistory").text("");

		if(ResourceId=='')

		{

			$("#span_resourceHistory").text("Please select resource name.");

		}

		if(TimeSheetId=='')

		{

			$("#span_timesheetHistory").text("Please select time sheet name.");

		}

		if(ResourceId=='' || TimeSheetId=='')

		{

			return false;

		}

		var SupervisorId = $("#h_SupervisorID").val();			

		$.ajax({

				url : "../ajax-supervisor.php",

				method : "POST",

				data :{REQUEST:"FindApprovalHistory",ResourceId : ResourceId,TimeSheetId : TimeSheetId,SupervisorId:SupervisorId},

				success:function(response)

				{

					//alert(response);

					$("#DivApprovalHistory").text('');

					$("#DivApprovalHistory").append(response.trim());

					$("#TableApprovalHistory").DataTable({"searching": false,order: [],orderable: false});

				}

			});			

	});	



	

	function ActionFun(rowno,Action)

	{	

		var TimeSheetId = $("#hTimeSheetId").val();

		var ResourceId = $("#hResourceId").val();

		var AliasId = $("#hAliasId"+rowno).val();

		var SeedAlias = $("#hSeedAlias"+rowno).val();

		var EntryDate = $("#Span_EntryDate"+rowno).text();

		var Comment = "";

		Comment = $("#h_comment"+rowno).val();

		

		$.ajax({

				url : "../ajax-supervisor.php",

				method : "POST",

				data :{REQUEST:"SetAction",Action:Action,TimeSheetId : TimeSheetId,ResourceId : ResourceId,AliasId:AliasId,SeedAlias:SeedAlias,EntryDate:EntryDate,Comment:Comment},

				success:function(response)

				{

					alert("Successfully set");

					if(Action!='Comment')

					{

						$("#cmdApprove"+rowno).attr("disabled",true);

						$("#cmdReject"+rowno).attr("disabled",true);

						$("#cmdNotes"+rowno).attr("disabled",true);

					}

				}

			});		

	}

	function ShowPopup(CurrentValue)

	{

		/*var comment1 = $("#h_comment"+CurrentValue).val();

		$("#PopupClickedElement").val('h_comment'+CurrentValue);

		$("#comment").val(comment1);

		$("#note-modal").modal('show');	*/

		

		var comment1 = $("#h_comment"+CurrentValue).val();

		$("#PopupClickedElement").val(CurrentValue);

		$("#comment").val(comment1);

		$("#note-modal").modal('show');	

		

	}

	$("#cmdOK_Popup").click(function()

	{

		/*var Element = $("#PopupClickedElement").val();

		$("#"+Element).val($("#comment").val());

		$("#note-modal").modal('hide');

		ActionFun();*/

		

		

		var Element = $("#PopupClickedElement").val();		

		$("#note-modal").modal('hide');

		if( $("#h_SupervisorID").val() != $("#hResourceId").val()  )

		{

			$("#h_comment"+Element).val($("#comment").val());

			//ActionFun(Element,'Comment');

		}

	});

	$(".clsTimeSheetH").dblclick(function()

	{

		var name = location.pathname.split('/').slice(-1)[0];		

		var id = $(this).attr('id');

		//var PeriodId = $('#h_History_TE'+id).val();			

		var PeriodId = $('#h_History_PeriodId'+id).val();			

		if(name=="te.php")

		{

			window.open('time-entry.php?pid='+PeriodId, '_blank');

		}

		else if(name=="rbam.php")

		{

			window.open('../te/time-entry.php?pid='+PeriodId, '_blank');

		}

		return false;	

	});

</script>

	