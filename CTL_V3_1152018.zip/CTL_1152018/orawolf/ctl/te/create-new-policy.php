<?php ob_start ();
	 
	include("te-functions.php");
	include("sitename.php");
	
	check_login();
?>
<?php
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_TimePolicy_PERMISSION = "Y";
		$UPDATE_PRIV_TimePolicy_PERMISSION = "Y";		
	}
	else
	{
		$CREATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Management Policy',$_SESSION['user_id']);
		$UPDATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Management Policy',$_SESSION['user_id']);
	}	
	if($CREATE_PRIV_TimePolicy_PERMISSION=='N' && $UPDATE_PRIV_TimePolicy_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "create-new-policy.php";	
	$AliasNameList = '<option value="">option 1</option>  <option value="">Option 2</option> <option value="">Option 3</option> <option value="">Option 4</option>';	
	$SiteId = $_SESSION['user-siteid'];
	
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];	
	}	
	if ($HeaderId != '')
	{
		$qry = "SELECT cxs_policy_header.* from cxs_policy_header where cxs_policy_header.POLICY_ID = $HeaderId and cxs_policy_header.SITE_ID = $SiteId ";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_PolicyProfileName = $row['NAME'];
			$Display_Description = $row['DESCRIPTION'];
			$Display_Active = $row['ACTIVE_FLAG'];
			$Display_InUse = $row['ADDINUSE_FLAG'];
		}
		
		$qry = "SELECT cxs_policy_general.* from cxs_policy_general where cxs_policy_general.POLICY_ID = $HeaderId limit 0,1";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_Workshift = $row['WORKSHIFT_ID'];			
			$Display_ExcessHour = $row['EXCESS_HOURS_ALLOWED'];
			$Display_HolidayEarnCredit = $row['HOLIDAY_EARN_CREDIT'];			
			$Display_CTO = $row['CTO_OVERTIME'];
			$Display_OverTime = $row['OVERTIME_ALLOWED'];
		}

		$qry = "SELECT cxs_am_roles.ROLE_NAME,cxs_am_roles.OVERRIDE_INUSE FROM `cxs_am_roles` inner join cxs_users on cxs_users.ROLE_ID = cxs_am_roles.ROLE_ID where cxs_users.USER_ID = ".$LoginUserId."";

			$result = mysql_query($qry);
			//echo $rows = mysql_num_rows($result);
			while($row = mysql_fetch_array($result))
			{
				$IsOverrideInUse = $row['OVERRIDE_INUSE'];
				$ROLE_NAME = $row['ROLE_NAME'];
			}
			//echo $IsOverrideInUse.'= name'. $ROLE_NAME;
		

		echo'overideValue = '. $IsOverrideInUse.' Role name =>'.$ROLE_NAME;


	}	
?>
<script type="text/javascript" >
	var ConfirmMessage="";
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create New Policy";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function InsertNewRow()
	{
		var table = document.getElementById("Table_GeneralTab");
		var rowCount = table.rows.length;
		var row = table.insertRow(rowCount);
		
		var cell1 = row.insertCell(0);
		var element1 = 	'<input class="check-bx " type="checkbox" id="inlineCheckbox1" value="1">';
		cell1.innerHTML = element1;
		
		var cell2 = row.insertCell(1);
		var element2 = 	'<div class="form-group"> <select class="form-control" onchange="InsertNewRow()" > <?php echo $AliasNameList; ?> 	</select> </div> ';
		cell2.innerHTML = element2;
		
		var cell3 = row.insertCell(2);
		var element3 = 	'';
		cell3.innerHTML = element3;
		
		var cell4 = row.insertCell(3);
		var element4 = 	'';
		cell4.innerHTML = element4;
		
		var cell5 = row.insertCell(4);
		var element5 = 	'';
		cell5.innerHTML = element5;
		
		var cell6 = row.insertCell(5);
		var element6 = 	'';
		cell6.innerHTML = element6;
		
		var cell7 = row.insertCell(6);
		var element7 = 	'<button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Created By: VAISHNAVR Updated By: JBOB Creation Date: 11th March 2017 4:40 PM Last Update Date: 12th March 2017 4:40 PM" > <i class=" fa fa-eye"></i> </button>';
		cell7.innerHTML = element7;
		
		$('#Table_GeneralTab td:first-child').addClass('check-bx');		
	}
	function setWorkshift()
	{ 
		var TableTimeOff = document.getElementById("Table_TimeOffTab").rows.length;		
		var WorkshiftValue = "";		
		var totalDisplayRecord;
		var HeaderId = "";
		
		var Flag_TimeOffRows="";
		
		var table= "";
		HeaderId = '<?php echo $HeaderId; ?>';
		
		if ($('#Combo_Workshift').val()!='')
		{
			WorkshiftValue = $("#Combo_Workshift option:selected").text(); 
		}
		if (HeaderId == '')
		{
			Flag_TimeOffRows="Y";
		}
		else
		{
			table = $('#Table_TimeOffTab').DataTable();
			if (  table.data().any() ) 
			{
				Flag_TimeOffRows="Y";
			}			
		}
		if (Flag_TimeOffRows=="Y")
		{	
			for (i=1;i<TableTimeOff;i++)
			{
				//$('#TimeOff_'+i+'_3').text(WorkshiftValue)
				$('#TimeOff_Workshift'+i).text(WorkshiftValue);
				$('#h_TimeOffWorkshiftId'+i).val($('#Combo_Workshift').val());
			}
		}
		/*
		$.ajax(
		{
			url : "ajax2_te.php",
			method:"POST",
			data:{REQUEST:"SearchRequiredHours",WorkshiftId:$('#Combo_Workshift').val()},
			success : function(response)
			{
				var RequiredHours="";
				RequiredHours = ($.trim(response));
				RequiredHours = RequiredHours.replace(/"/g,'');//to find all sub string use / /g
				$(".myClassRHours").each(function(index)
				{
					$(this).text(RequiredHours);
				});				
			}
		});		*/
	}
	function SearchPopUp(currentRow,AliasClass)
	{	
		$('#Text_FindAliasName').val('');
		$('#span_currentRow').text(currentRow);		
		$('#Text_FindAliasName').focus();
		$('#divFindAlias').text('');
		$('#h_AliasClass').val(AliasClass);
		$('#ModalFindAlias').modal();			
	}
	function FindAliasData()
	{	
		KEY = "FindAliasData";
		var formdata = $( "#Find-Alias-Form" ).serialize();		
		makeRequest("ajax-finddata.php","REQUEST=FindData-Policy-Alias&"+formdata);			
	}	
	function SelectedAlias(s1)	
	{	
		if(s1!="")
		{	
			var AliasClass = $('#h_AliasClass').val();				
			KEY = "SelectedAlias";			
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName=cxs_aliases&FieldName=ALIAS_ID&FieldValue=" +s1);
		}
	}	
	function SaveData(TabName)
	{		
		var v1 = $('#Text_PolicyProfileName').val();
		if (v1=='')
		{
			alert("Please Enter Policy Profile Name");
			document.getElementById("Text_PolicyProfileName").focus();
			return false;
		}
		var v2 = $('#Text_Description').val();
		var v3 = "N";
		var v4 = "N";
		if($('#Check_Active').prop('checked'))
		{
			v3 = "Y";
		}
		if($('#Check_AddInUse').prop('checked'))
		{
			v4 = "Y";
		}
		var v5 = $('#h_PolicyId').val();	
		
		var formdata ;	
		var flag_required1="",flag_required2="";
		if(TabName=='General')
		{
			if ($('#Combo_Workshift').val()=='')
			{
				$('#Combo_Workshift').focus();
				$('#Span_Workshift').text('Select workshift.');				
				flag_required1="N";
			}			
			if($("#Text_AliasName1").val()=='')
			{
				alert("Please select atleast one alias detail");
				$("#Text_AliasName1").focus();
				flag_required2="N";
			}
			var TotalRows = $('#Table_GeneralTabBody tr').length;		
			if (flag_required1=="" && flag_required2=="")
			{
				//KEY='IsStatusNeverOpen';				
				//makeRequest("ajax-validations.php","REQUEST=IsStatusNeverOpen");
				//above checking not require now because calendar connectivity remove from timepolicy rightnow.
				SaveDataFinal('General');
			}
			else
			{
				return false;
			}
		}
		else if(TabName=='TimeOff')
		{
			KEY = "SaveRecord";
			KEY1="TimeOff";			
			formdata = $( "#form_time-op" ).serialize();				
			makeRequest("ajax-insert-record.php","REQUEST=InsertPolicy-Record&"+formdata+"&PolicyProfile="+v1+"&Description="+v2+"&Active="+v3+"&AddInUse="+v4+"&h_PolicyId="+v5+"&DetailTable=cxs_policy_time_off");
		}
	}
	function SaveDataFinal(TabName)
	{
		var v1 = $('#Text_PolicyProfileName').val();		
		var v2 = $('#Text_Description').val();
		var v3 = "N";
		var v4 = "N";
		if($('#Check_Active').prop('checked'))
		{
			v3 = "Y";
		}		
		var v5 = $('#h_PolicyId').val();	
		
		
		if(TabName=='General')
		{
			KEY = "SaveRecord";	
			KEY1 = "General";	
			if( $("#h_duplicate").val()=="")
			{
				formdata = $("#form_general").serialize();	
				var updateRecords=[];
				$(".myInlineG").each(function(index)
				{
					if($(this).prop("checked")==true)
					{
						thestring = $(this).attr('id');
						thenum = thestring.match(/\d+$/)[0];
						updateRecords.push(thenum);
					}
				});						
				/*if(updateRecords.length==0 && v5 != '')
				{
					//alert("Please select atleast one alias detail");
					alert("Please tick alias row check box for update record.");
					return false;
				}*/
				openModal();			
				makeRequest("ajax-insert-record.php","REQUEST=InsertPolicy-Record&"+formdata+"&PolicyProfile="+v1+"&Description="+v2+"&Active="+v3+"&h_PolicyId="+v5+"&DetailTable=cxs_policy_general&Update_Rows="+updateRecords);
			}	
		}
	}
	
	function CheckValidationForCheckBoxes()
	{
		KEY='CheckBoxesValidation';
		var WorkshiftId = $('#Combo_Workshift').val();
		makeRequest("ajax-validations.php","REQUEST=CheckBoxesValidation&WorkshiftId="+WorkshiftId);
	}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<!-- <title>Coexsys | Time Accounting</title> -->
<title>Coexsys | <?php echo strtoupper($SiteName); ?></title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">
<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../js/bootstrap-timepicker.min.js"></script>
<script src="../js/loader-function.js"></script>
<!--<script type="text/javascript" src="http://www.datejs.com/build/date.js"></script> <!-- for display current time in 12 hours here it is use in dynamic row addition -->

<style type="text/css">
	.option_color  
	{
		color: #000;
		font-size: 12px;
	}
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.EditModeWidth
	{
		min-width : 100px;
	}
	.EditModeWidth1
	{
		min-width : 60px;
	}
	.EditModeWidth2 
	{
		min-width : 380px;
	}
	
	/* Desktops and laptops ----------- */
	@media only screen and (min-width : 1224px) 
	{
		.EditModeWidth
		{
			min-width : 300px;
		}
		.EditModeWidth1
		{
			min-width : 180px;
		}
		.EditModeWidth2
		{
			min-width : 380px;
		}
		.myMargin
		{
			text-align: right;
			margin-bottom:-30px;	
		}
	}
	
	/* Large screens ----------- */
	@media only screen and (min-width : 1824px) 
	{
		.EditModeWidth
		{
			min-width : 440px;
		}
		.EditModeWidth1
		{
			min-width : 440px;
		}
		.EditModeWidth2
		{
			min-width : 510px;
		}
		.myMargin
		{
			text-align: right;
			margin-bottom:-30px;	
		}
	}
	 
	@media screen and (max-width: 250px)
	{
		margin-top:10px;
		margin-bottom:0px;
		text-align: left;
	}
</style>
<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">	
</head>

<body>
<?php include("header.php"); ?>
<!--  alias pop up start-->
	<form id="Find-Alias-Form" >
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalFindAlias" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Find Alias</h4>					
					</div>
					<div class="modal-body"> 
					<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">							
								<span id = "span_currentRow" style = "display:none;"></span>
								<input type = "hidden" id = "h_AliasClass" name = "h_AliasClass" value = "">
								<div class="col-sm-5 form-group">
								  <label>Alias Name</label>
								  <input type="text" id="Text_FindAliasName" name="Text_FindAliasName" class="form-control "  style = "font-weight: normal" maxlength="100">							 
								</div>							
								<div class="col-sm-2 form-group cr-user">
									<br>
									<button type="button" id="cmdFindAliasPopup" name="cmdFindAliasPopup" class="btn btn-primary btn-style " onclick="FindAliasData()" >Find</button>
								</div>
								
								<div class="col-sm-12 form-group" style = "margin: 0px;">									
									<div class="data-bx">
										<div class="table-responsive" id = "divFindAlias">											
										</div>	
									</div>			
								</div>								
							</div>
						</div>
					<!-- end --> 
				  </div>
				
				<div class="modal-footer cr-user">
					
				</div>					
			</div>
		</div>
	</div>
	</form>
	<!-- end alias pop up -->	
	<section class="md-bg">
		<div class="container-fluid">
			<div class="row"> 
			  <!-- brd crum-->
				<div class="brd-crmb">
					<ul>
					  <li> <a href="#"> Set Up </a></li>
					  <li> <a href="time-management-policy.php"> Time Management Policy </a></li>
					  <li> <a href="#"> <?php echo $s_caption; ?> Policy </a></li>
					</ul>
				</div>
			  <!-- Dash board -->
				<div class="dash-strip">
					<!-- <div class="fleft cr-user">
					  <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button> -->
					</div>
					<div class="fright">
						 <?php
							$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
							$result=mysql_query	($qry);
							$TotalRecords = mysql_num_rows($result);
							if($TotalRecords == 0)
							{
								$s_Style = "";
							}
							else
							{
								$s_Style = "background-color: #000;";
							}
						?>          
					  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
					</div>
				</div>
			  <!-- inner work-->
				<div class="cont-box">
					<div class="row">
						<h4 class="text-center"  id="msg_section123"><?php echo $msg; ?></h4>
					</div>
					<form id="form_createnewpolicy" action = "" method="post">
						<div class="pge-hd">
						  <h2 class="sec-title"> <label> <?php echo $s_caption; ?> Policy</label> </h2>
						</div>				
						<div class="row">
							<div class="col-sm-5">
								<div class="inline-form">
									<label> Policy Profile Name </label>
									<input type="text" id = "Text_PolicyProfileName" name = "Text_PolicyProfileName" class="form-control requirefieldcls" required maxlength="40" value = "<?php echo $Display_PolicyProfileName; ?>" autofocus onblur = "CheckDuplicate(this.id)">
									<span  id = "Span_PolicyProfile" style = "color:red"></span>
									<input type = "hidden"	id = "h_PolicyId" name = "h_PolicyId" value = "<?php echo $HeaderId; ?>">	
								</div>
							</div>
							<div class="col-sm-4 ">
								<div class="inline-form">  
									<label> Description </label>
									<input type="text" id = "Text_Description" name = "Text_Description" class="form-control" maxlength="40" value = "<?php echo $Display_Description; ?>">
								</div>
							</div>
							<div class="col-sm-3 ">
							  <div class="inline-form">
								 <label> <input type="checkbox" id = "Check_Active" name = "Check_Active" value = "1" <?php echo ($Display_Active=='Y')?"checked":""; ?> > Active </label>
								 <label> <input type="checkbox" id = "Check_AddInUse" name = "Check_AddInUse" value = "1"  <?php echo ($Display_InUse=='Y')?"checked":""; ?>  disabled="disabled"> In Use </label>
							  </div>
							</div>
						</div>
						<input type = "hidden" id = "h_duplicate" value = "">
					</form>
				<!-- tabing  -->
					<div class="check-bx"  style = "  text-align:center;  width:100%;">
						<div id="fade">
						</div>
						<div id="modal" >
							<img id="loader" src="../img/loading.gif" style="top:15px;left:15px;" />
						</div>	
					</div>	
					<div class="manage-bx" id = "tabs">           
						<!-- Nav tabs -->
						<ul class="nav nav-tabs tab-menu-bx" role="tablist">
							<li role="presentation" class="active"><a href="#genrnal" aria-controls="home" role="tab" data-toggle="tab"> General </a></li>
							<li role="presentation"><a href="#time-op" aria-controls="profile" role="tab" data-toggle="tab"> Time off Policy </a></li>							
						</ul>
						<!-- Tab panes -->
					  
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active in" id="genrnal">
							<div class="tab-info-bx"></div>                
								<form id ="form_general" action = "" method="POST">
									<div class="tabbable">
										<div class="row">
											<div class="col-sm-12 ">
												<div class="des-bx">
													<input type = "hidden"	id = "h_PolicyId_Gen" name = "h_PolicyId_Gen" value = "">													
													<label class="col-md-1 text-right"  > Workshift </label>
													<div class="col-md-2" >
													  <select class="form-control requirefieldcls" required  id = "Combo_Workshift" name = "Combo_Workshift" onchange="SelectedDropDownValue(this);" >
														<option value=""> - Workshift - </option>
														<?php
															$selectQuery = "select * from cxs_workshifts where SITE_ID = $SiteId order by NAME";
															$result = mysql_query($selectQuery);
															while($row = mysql_fetch_array($result))
															{
																$WorkShiftName = $row['NAME'];
																$IsSelected="";
																if($Display_Workshift== $row['WORKSHIFT_ID'])
																{
																	$IsSelected = "selected";
																}
															?>
																<option value="<?php echo $row['WORKSHIFT_ID']; ?>" <?php echo $IsSelected; ?>> <?php echo $WorkShiftName; ?> </option>
													<?php	}?>
													  </select>
													  <span id = "Span_Workshift" style = "color:red"></span>									  
													</div>		
													<div class="col-md-9" >
														<div class="">                      
														  <label style = "padding-right:15px;"> <input type="checkbox" id = "Check_ExcessHour_TEarn" name = "Check_ExcessHour_TEarn" value = "1" <?php echo ($Display_ExcessHour=='Y')?"checked":""; ?> > Excess Hour Allowed </label>
														  <label style = "padding-right:15px;"> <input type="checkbox" id = "Check_HolidayEarnCredit_TEarn" name = "Check_HolidayEarnCredit_TEarn" value = "1" <?php echo ($Display_HolidayEarnCredit=='Y')?"checked":""; ?> > Holiday Earn Credit Allowed </label>
														  <label style = "padding-right:15px;"> <input type="checkbox" id = "Check_CTO_TEarn" name = "Check_CTO_TEarn" value = "1" <?php echo ($Display_CTO=='Y')?"checked":""; ?> > CTO For Overtime </label>
														  <label style = "padding-right:15px;"> <input type="checkbox" id = "Check_OverTime_TEarn" name = "Check_OverTime_TEarn" value = "1" <?php echo ($Display_OverTime=='Y')?"checked":""; ?> > Overtime </label>														 
														</div> 	
													</div> 	
												</div>
											</div>
										</div>							
										<div class="data-bx">	
											<?php if($HeaderId!='' && $Display_InUse!= 'Y') { ?>
											<div class = "myMargin" id = "testDiv" >							
												<button type="button" class="btn-style btn "  id = "cmdUpdateSelectedG" name = "cmdUpdateSelectedG"  > Update Selected </button>
											</div>
										<?php } ?>	
											<div class="table-responsive">
												<table class="table table-bordered mar-cont" id = "Table_GeneralTab">
													<thead>
														<tr>
															<th data-orderable="false" width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAllG" value="1" ></th>
															<th width="15%"> Alias Name </th>
															<th width="15%"> Alias Type </th>
															<th width="23%"> Description </th>
															<th width="7%"> Alias Class </th>
															<th width="30%"> Project WBS </th>
															<th width="5%"> </th>
														</tr>
													</thead>									
													<tbody id="Table_GeneralTabBody">
														<?php
															if($HeaderId=='')
															{ ?>
																<tr id = "row1">
																	<td class="check-bx "><input type="checkbox" disabled  class = "myInlineG" id="inlineCheckboxG1" value="1"></td>
																	<td>
																		<div class="form-group">												
																			<input type='hidden' id='h_AliasId1' name = '<?php echo 'Text_AliasId[]' ?>' value=''>
																			<input type="text" class="form-control" id = "Text_AliasName1" onfocus = "SearchPopUp(<?php echo "1" ?>,'Policy')" onkeypress="return false" >
																			<span id = "General_1_2"> </span>																
																		</div>
																	</td>
																	<td id = "General_1_3"></td> <td id = "General_1_4"></td> <td id = "General_1_5"></td> <td id = "General_1_6"></td>
																	<td class = "check-bx"><button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="" > <i class=" fa fa-eye"></i> </button></td>
																</tr>
													<?php 	}
															else
															{ 
																$i=1;
																$qry = "select cxs_policy_general.*,cxs_aliases.ALIAS_NAME,cxs_aliases.ALIAS_CLASS,cxs_aliases.ALIAS_TYPE,cxs_aliases.DESCRIPTION,cxs_users.USER_NAME as CreatedBy, cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4,cxs_wbs.SEGMENT5,cxs_wbs.SEGMENT6,cxs_wbs.SEGMENT7,cxs_wbs.SEGMENT8,cxs_wbs.SEGMENT9,cxs_wbs.SEGMENT10,cxs_wbs.SEGMENT11,cxs_wbs.SEGMENT11,cxs_wbs.SEGMENT12,cxs_wbs.SEGMENT13,cxs_wbs.SEGMENT14,cxs_wbs.SEGMENT15
																from cxs_policy_general inner join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_policy_general.ALIAS_ID left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID 
																inner join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY
																where cxs_policy_general.POLICY_ID = $HeaderId order by ROW_NO";
																$result = mysql_query($qry);
																while($row = mysql_fetch_array($result))
																{
																	$WBSValue = "";
																	if ($row['SEGMENT1']!="")
																	{
																		$WBSValue = "";
																		for($j=1;$j<=15;$j++)
																		{
																			$value = "SEGMENT$j";															
																			$WBSValue .= $row[$value].".";
																		}
																	}
																	if(substr($WBSValue,-1)==".")
																	{
																		$WBSValue = substr_replace($WBSValue, '', -1);														
																	}
																	$Display_CreatedByName	= $row['CreatedBy'];	
																	$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));							
																	$UpdatedBy	= $row['LAST_UPDATED_BY'];
																	$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							
																	$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
													?>
																	<tr id = "<?php echo "row$i"?>">
																		<td class="check-bx "><input type="checkbox"  class = "myInlineG" id="<?php echo "inlineCheckboxG$i"; ?>" value="1"></td>
																		<td>
																		<div class = "form-group">
																			<input type='hidden' id = "<?php echo "h_AliasId$i"; ?>"  name = '<?php echo 'Text_AliasId[]' ?>' value='<?php echo $row['ALIAS_ID']; ?>'> 																														
																			<input type="text" class="form-control" id = "<?php echo "Text_AliasName$i"; ?>" style = 'width:100%;  display:none; ' value='<?php echo  $row['ALIAS_NAME']; ?>' onfocus = "SearchPopUp(<?php echo $i; ?>,'Policy')" onkeypress="return false" >	
																			<span id = "<?php echo "General_".$i."_2";?>"><?php  echo $row['ALIAS_NAME']; ?> </span>		
																		</div>	
																		</td>
																		<td id = "<?php echo "General_".$i."_3";?>"><?php echo $row['ALIAS_TYPE']; ?></td>
																		<td id = "<?php echo "General_".$i."_4";?>"><?php echo $row['DESCRIPTION']; ?></td>
																		<td id = "<?php echo "General_".$i."_5";?>"><?php echo $row['ALIAS_CLASS']; ?></td>
																		<td id = "<?php echo "General_".$i."_6";?>"><?php echo $WBSValue; ?></td>
																		<td class = "check-bx">
																			<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
																			Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
																			<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
																		</td>
																	</tr>		
													<?php		
																	$i=$i+1;
																}?>												
																<tr id = "<?php echo "row$i"?>">
																	<td class="check-bx "><input class = "myInlineG" disabled  type="checkbox" id="<?php echo "inlineCheckboxG$i"; ?>" value="1"></td>
																	<td> <div class="form-group" style = 'width:100%'> 
																			<input type='hidden' id = '<?php echo "h_AliasId$i";?>' name = '<?php echo 'Text_AliasId[]' ?>' value=''>
																			<input type="text" class="form-control" id = "<?php echo "Text_AliasName$i"; ?>" style = 'width:100%' onfocus = "SearchPopUp(<?php echo $i; ?>,'Policy')" onkeypress="return false" >	
																			<span id = "<?php echo "General_".$i."_2";?>"> </span>																				
																		</div>
																	</td>
																	<td id = "<?php echo "General_".$i."_3";?>" ><?php //echo $row['ALIAS_TYPE']; ?></td>
																	<td id = "<?php echo "General_".$i."_4";?>" ><?php //echo $row['DESCRIPTION']; ?></td>
																	<td id = "<?php echo "General_".$i."_5";?>" ><?php //echo $row['ALIAS_CLASS']; ?></td>
																	<td id = "<?php echo "General_".$i."_6";?>" ><?php //echo $WBSValue; ?></td>
																	<td class = "check-bx">
																		<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content=""> <i class=" fa fa-eye"></i> </button>
																	</td>
																</tr>
													<?php	}
													?>	
													</tbody>
												</table>
											</div>
										</div>
										
										<div class="text-right cr-user">							
											<!-- <button class="btn btn-primary btn-style"  <?php if(($CREATE_PRIV_TimePolicy_PERMISSION=='Y'  || $UPDATE_PRIV_TimePolicy_PERMISSION =='Y') && $Display_InUse!= 'Y' ){ ?> type="button" id = "cmdGeneralSave" name = "cmdGeneralSave" onclick = "SaveData('General')"<?php }else {?> disabled = "disabled" <?php } ?> > Save Changes </button> -->
											<?php //echo $IsOverrideInUse.'  '.$Display_InUse; ?>
										<button class="btn btn-primary btn-style" type="button" id = "cmdGeneralSave" name = "cmdGeneralSave" onclick = "SaveData('General')"	<?php							
												 if($Display_InUse == 'Y' && $IsOverrideInUse == 'N' )
												 	{ 
												 		
												 		?>
												 		disabled = disabled
												 		<?php
												} if($Display_InUse == 'Y' && $IsOverrideInUse == 'Y')
												{ 
												 	
												}
											 ?>> Save Changes </button>
										</div>										
										<input type="hidden" id = "h_ACalendarStatus" value = "">
										<input type="hidden" id="h_IsOverrideInUse" name="h_IsOverrideInUse" value="<?php echo $IsOverrideInUse; ?>"/>
										<input type="hidden" id="h_IsEditAllowed" <?php if(($CREATE_PRIV_TimePolicy_PERMISSION=='Y' || $UPDATE_PRIV_TimePolicy_PERMISSION == 'Y') && $Display_InUse!='Y'){ ?> value = "Y" <?php } else {?> value = "N" <?php } ?> >
									</div>
								</form>
							</div>
						<!-- genral end -->					   
							<div role="tabpanel" class="tab-pane" id="time-op">              
								<form id ="form_time-op" action = "" method="POST">					
									<div class="data-bx col-sm-12" style = "margin-top: 0px;">
										<div class = " form-group text-center " id = "div_TO_warning" style = "font-weight:bold;color:red" ></div>
										<?php if($HeaderId!='' && $Display_InUse != 'Y') { ?>
												<div class = "myMargin" >							
													<button type="button" class="btn-style btn "  id = "cmdUpdateSelectedTO" name = "cmdUpdateSelectedTO"  > Update Selected </button>
												</div>	
											<?php } ?>	
										<div class="table-responsive">				                  
											<table class="table table-bordered mar-cont" id = "Table_TimeOffTab">
												<thead>
												  <tr>								
													<th data-orderable="false" width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAllTO" value="1" ></th>
													<th width="20%"> Leave Aliases </th>                        
													<th width="15%" >Workshift </th>								
													<th width="5%"></th>
												  </tr>
												</thead>					
												<tbody id="Table_TimeOffTabBody">
													<?php
														if($HeaderId=='')
														{ ?>
															<tr id = "row1_TOff">							
																<td class="check-bx ">
																	<input type="checkbox" class = "myInlineTO" id="inlineCheckbox1_Toff" value="1" disabled ></td>											
																<td>
																	<div class="form-group">																									
																		<input type='hidden' id='h_AliasId1_TOff' name = '<?php echo 'Text_AliasIdTOff[]' ?>' value=''>													
																		<input type="text" class="form-control" id = "Text_AliasName1_TOff" onfocus = "SearchPopUp(<?php echo "1" ?>,'Leave')" onkeypress="return false">
																		<span id = "TOff_1_2"> </span>
																	</div>
																</td>											
																<td> 
																	<span id="TimeOff_Workshift1"></span>
																	<input type ="hidden" id = "h_TimeOffWorkshiftId1" name = '<?php echo 'h_TimeOffWorkshiftId[]' ?>' value = "">
																</td> 												
																<td class = "check-bx"><button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="" > <i class=" fa fa-eye"></i> </button></td>
															</tr>
												<?php 	}
														else
														{
															$i=1;
															$qry = "SELECT cxs_policy_time_off.*,cxs_aliases.ALIAS_NAME,cxs_users.USER_NAME AS CreatedBy,cxs_workshifts.NAME as workshiftname,cxs_periods.PERIOD_NAME FROM cxs_policy_time_off 
																	INNER JOIN cxs_aliases ON cxs_aliases.ALIAS_ID = cxs_policy_time_off.ALIAS_ID INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_aliases.CREATED_BY
																	LEFT JOIN cxs_workshifts ON cxs_workshifts.WORKSHIFT_ID = cxs_policy_time_off.WORKSHIFT_ID 
																	LEFT JOIN cxs_periods ON cxs_periods.PERIOD_ID = cxs_policy_time_off.PERIOD_ID 
																	where cxs_policy_time_off.POLICY_ID = $HeaderId order by ROW_NO";
															$result = mysql_query($qry);
															while($row = mysql_fetch_array($result))
															{
																$Display_CreatedByName	= $row['CreatedBy'];	
																$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));							
																$UpdatedBy		= $row['LAST_UPDATED_BY'];
																$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							
																$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
														?>		
																<tr id = "<?php echo "row$i"."_TOff"?>">
																	<td class="check-bx "><input type="checkbox" class = "myInlineTO" id="<?php echo "inlineCheckbox$i"."_Toff"; ?>" value="1"></td>
																	<td>
																		<div class="form-group" style = "width : 100%;">
																		<input type='hidden' id='<?php echo "h_AliasId".$i."_TOff"?>' name = '<?php echo 'Text_AliasIdTOff[]' ?>' value='<?php  echo $row['ALIAS_ID']; ?>'>													
																		<input type="text" class="form-control" id = "<?php echo "Text_AliasName".$i."_TOff"; ?>" onfocus = "SearchPopUp(<?php echo $i; ?>,'Leave')" onkeypress="return false" style = ' display:none; width:100%;' value='<?php echo  $row['ALIAS_NAME']; ?>'  >													
																		<span id = "<?php echo "TOff_".$i."_2";?>"><?php  echo $row['ALIAS_NAME']; ?> </span>
																		</div>
																	</td>
																	<td>
																		<input type ='hidden' id = '<?php echo"h_TimeOffWorkshiftId$i";?>' name = '<?php echo 'h_TimeOffWorkshiftId[]' ?>' value = '<?php echo $row['WORKSHIFT_ID']; ?>'>
																		<?php  echo $row['workshiftname']; ?>
																	</td>												
																	<td class = "check-bx">
																		<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
																		Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
																		<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
																	</td>
																</tr>	
													<?php		$i=$i+1; 
															}?>
															<tr id = "<?php echo "row$i"."_TOff"?>">	
																<td class="check-bx "><input type="checkbox" disabled  id="<?php echo "inlineCheckbox$i"."_Toff";?>"  value="1"></td>
																<td>
																	<div class="form-group" style = 'width:100%'>																									
																		<input type='hidden' id="<?php echo "h_AliasId".$i."_TOff";?>"  name = '<?php echo 'Text_AliasIdTOff[]' ?>' value=''>
																		<input type="text" class="form-control " style = 'width:100%' id="<?php echo "Text_AliasName".$i."_TOff";?>" onfocus = "SearchPopUp(<?php echo $i; ?>,'Leave')" onkeypress="return false" >
																		<span id = "<?php echo"TOff_".$i."_2";?>"></span>
																	</div>
																</td>
																<td> 
																	<span id="<?php echo "TimeOff_Workshift$i";?>"></span>
																	<input type ="hidden" id="<?php echo "h_TimeOffWorkshiftId$i";?>" name = '<?php echo 'h_TimeOffWorkshiftId[]' ?>' value = "" >
																</td> 												
																<td class = "check-bx"><button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="" > <i class=" fa fa-eye"></i> </button></td>
															</tr>	
												<?php	}
												?>
												</tbody>	        
											</table>
										</div>
									</div>
									<div class="text-right cr-user">
										<button class="btn btn-primary btn-style" <?php if(($CREATE_PRIV_TimePolicy_PERMISSION=='Y'  || $UPDATE_PRIV_TimePolicy_PERMISSION =='Y')&& $Display_InUse != 'Y'){ ?> type="button" id = "cmdTimeOffSave" name = "cmdTimeOffSave" onclick = "SaveData('TimeOff')" <?php }else {?> disabled = "disabled" <?php } ?>> Save Changes </button>
									</div>
								</form>
							</div>						
							
						<!-- Approval Rules --> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<script type="text/javascript">	
	function SelectedDropDownValue(element)
	{
		if(element.id=="Combo_Workshift" && element.value!='')
		{
			$('#Span_Workshift').text('');
			setWorkshift();
		}	
	}
	
		
	$(document).ready(function() 
	{
		closeModal();
        var HeaderId = "<?php echo $HeaderId; ?>";		
		if (HeaderId!='')
		{
			$('#Table_GeneralTab').DataTable( 
			{
				'searching': false,
				"paging":   true,
				"bSort" :false,
				'order': [[ 1, "desc" ],[ 2, "asc" ]],
				'aoColumnDefs': [{'bSortable': false,'aTargets': [0,-1] }]
			});
			
			$('#Table_TimeOffTab').DataTable( 
			{
				'searching': false,"bSort" :false,
				'order': [[ 1, "desc" ],[ 2, "asc" ]],
				'aoColumnDefs': [{'bSortable': false,'aTargets': [0,-1] }],
				"bAutoWidth" : false
			});
			setWorkshift();
			$("#div_TO_warning").text("");
		}
		else
		{
			$('#time-op :input').attr('disabled', true);			  			
			$("#div_TO_warning").text("Please first save data on general tab.");
		}

		if ($("#h_IsEditAllowed").val()=="N" && $("#h_IsOverrideInUse").val()=="N" )  
		{
			$("#form_createnewpolicy :input").prop("disabled",true);
			$("#form_general :input").prop("disabled",true);
			$("#form_time-op :input").prop("disabled",true);
			$("#div_TO_warning").text("Please first save data on general tab.");
		}
		
    });
	
	$('.form_time').timepicker({
			//format : 'H:i:s',
			template: false,
			showInputs: false,			
			minuteStep: 1			
	});
	
	function makeRequest(url,data)
	{
		var http_request = false;
		if (window.XMLHttpRequest) { // Mozilla, Safari, ...
			http_request = new XMLHttpRequest();
			if (http_request.overrideMimeType) {
				http_request.overrideMimeType('text/xml');
				// See note below about this line
			}
		} else if (window.ActiveXObject) { // IE
			try {
				http_request = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					http_request = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}

		if (!http_request) {
			alert('Giving up :( Cannot create an XMLHTTP instance');
			return false;
		}
		http_request.onreadystatechange = function() { alertContents(http_request); };
		http_request.open('POST', url, true);
		http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}				
				else if(KEY == 'FindAliasData')
				{	
					$("#divFindAlias").html(http_request.responseText);
					$("#TableFindAlias").DataTable({"searching": false});					
				}
				else if(KEY === 'SelectedAlias')
				{
					var AliasClass = $('#h_AliasClass').val();					
					var JSONObject = JSON.parse(http_request.responseText);					
					//alert(JSON.stringify(JSONObject));										
					
					var functionName1,DetailTableRows,DetailTableRows1;										
					var cell1,cell2,cell3,cell4,cell5,cell6,cell7;
					var CurrentRow = $('#span_currentRow').text();					
					if(AliasClass=='Policy')
					{	
						DetailTableRows = document.getElementById("Table_GeneralTabBody").rows.length;
					}
					else if(AliasClass=='Leave')
					{
						DetailTableRows = document.getElementById("Table_TimeOffTabBody").rows.length;
					}
						
					DetailTableRows1 = DetailTableRows + 1;
					functionName1 = " onfocus = \"SearchPopUp("+DetailTableRows1+",'"+AliasClass+"')\" ";
					if(AliasClass=='Policy')
					{	
						//$('#inlineCheckboxG'+CurrentRow).prop("disabled",false);
						$('#Text_AliasName'+CurrentRow).val(JSONObject['cxs_aliases']["ALIAS_NAME"]);						
						$('#h_AliasId'+CurrentRow).val(JSONObject['cxs_aliases']["ALIAS_ID"]);
						$('#General_'+CurrentRow+'_3').text(JSONObject['cxs_aliases']["ALIAS_TYPE"]);
						$('#General_'+CurrentRow+'_4').text(JSONObject['cxs_aliases']["DESCRIPTION"]);
						$('#General_'+CurrentRow+'_5').text(JSONObject['cxs_aliases']["ALIAS_CLASS"]);
						$('#General_'+CurrentRow+'_6').text(JSONObject['cxs_aliases']["WBSValue"]);
						if (CurrentRow==DetailTableRows)
						{
							cell1="<td class = 'check-bx'><input type ='checkbox' class = 'myInlineG' id='inlineCheckboxG"+DetailTableRows1+"' disabled='disabled' > </td>";							
							cell2 = "<td><div class='form-group'><input type='hidden' id='h_AliasId"+DetailTableRows1+"' name = '<?php echo 'Text_AliasId[]' ?>' value=''> <input type='text' class='form-control EditModeWidth' id ='Text_AliasName"+DetailTableRows1+"' value ='' " + functionName1 +">"+
									"<span id = 'General_"+DetailTableRows1+"_2' style = 'display:none'> </span></div></td>";
							cell3="<td id = 'General_"+DetailTableRows1+"_3'></td>";
							cell4="<td id = 'General_"+DetailTableRows1+"_4'></td>";
							cell5="<td id = 'General_"+DetailTableRows1+"_5'></td>";
							cell6="<td id = 'General_"+DetailTableRows1+"_6'></td>";
							EyeIcon="<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";							
							$('#Table_GeneralTab').append('<tr id = "row'+DetailTableRows1+'">'+cell1+cell2+cell3+cell4+cell5+cell6+EyeIcon+'</tr>');							
						}
					}
					else if (AliasClass=='Leave')
					{	
						//$('#inlineCheckbox'+CurrentRow+'_Toff').prop("disabled",false);
						$('#Text_AliasName'+CurrentRow+'_TOff').val(JSONObject['cxs_aliases']["ALIAS_NAME"]);						
						$('#h_AliasId'+CurrentRow+'_TOff').val(JSONObject['cxs_aliases']["ALIAS_ID"]);						
						var WorkshiftValue = "";
						if ($('#Combo_Workshift').val()!='')
						{
							WorkshiftValue = $("#Combo_Workshift option:selected").text(); 
						}
						if (CurrentRow==DetailTableRows)
						{
							cell1="<td class = 'check-bx'><input type ='checkbox' class = 'myInlineTO' id='inlineCheckbox"+DetailTableRows1+"_Toff' disabled='disabled'> </td>";							
							cell2 = "<td><div class='form-group'><input type='hidden' id='h_AliasId"+DetailTableRows1+"_TOff' name = '<?php echo 'Text_AliasIdTOff[]' ?>' value=''> <input type='text' class='form-control EditModeWidth' id ='Text_AliasName"+DetailTableRows1+"_TOff' value ='' " + functionName1 +"></div>"+
							"<span id = 'TOff_"+DetailTableRows1+"_2'> </span> </td>";
							//cell3="<td id = 'TimeOff_"+DetailTableRows1+"_3'>"+WorkshiftValue+"</td>";
							cell3="<td><span id='TimeOff_Workshift"+DetailTableRows1+"'>"+WorkshiftValue+"</span> <input type ='hidden' id = 'h_TimeOffWorkshiftId"+DetailTableRows1+"' name = '<?php echo 'h_TimeOffWorkshiftId[]' ?>' value = '"+$('#Combo_Workshift').val()+"'></td>";							
							EyeIcon="<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";							
							$('#Table_TimeOffTab').append('<tr id = "row'+DetailTableRows1+'">'+cell1+cell2+cell3+cell6+EyeIcon+'</tr>');							
						}
					}
					$('#ModalFindAlias .close').click();
				}
				else if (KEY == 'SaveRecord')
				{
					//alert(http_request.responseText);
					var JSONObject = JSON.parse(http_request.responseText);							
					$("input[name=h_PolicyId]").val(JSONObject['getPolicyHeaderId']);
					if(KEY1=="General")
					{
						//window.location.href = "create-new-policy.php?hid="+JSONObject['getPolicyHeaderId']+"";
					}
					else if(KEY1=="TimeOff")
					{
						var TABLE_ROW = $('#Table_TimeOffTab tr').length-1;												
						for(i=1;i<TABLE_ROW;i++)
						{	
							if ( $("#Text_AliasName"+i+"_TOff").length > 0) 
							{   
								$("#Text_AliasName"+i+"_TOff").hide();
								$("#TOff_"+i+"_2").show(); 
								$("#TOff_"+i+"_2").text($("#Text_AliasName"+i+"_TOff").val());
								
								$("#inlineCheckbox"+i+"_Toff").prop("checked",false);
							}
							$("#inlineCheckbox"+i+"_Toff").show();							
						} 
						$('#cmdUpdateSelectedTO').text("Update Selected");
						$('#cmdUpdateSelectedTO').css({"visibility":"visible"});
						$('#Checkbox_SelectAllTO').prop("checked",false);
					}					
					
					$("#msg_section123").empty();
					$("#msg_section123").append("<div class='alert alert-success'>Records Updated Successfully</div>");
					$("#div_TO_warning").text("");
					$('#time-op :input').attr('disabled', false);
					CheckValidationForCheckBoxes();
					
					var body = $("html, body");
					body.stop().animate({scrollTop:0}, 500, 'swing');
					
				}
				else if (KEY=='CheckBoxesValidation')
				{
					var s1 = http_request.responseText.trim();					
					if(s1=='9/8/80 Shift' || s1 == '4/10/40 Shift')
					{
						$('#Check_HolidayEarnCredit_TEarn').attr('disabled',false);
						$('#Check_ExcessHour_TEarn').attr('disabled',false);
						$('#Check_CTO_TEarn').attr('disabled',false);
						$('#Check_OverTime_TEarn').attr('disabled',false);
					}
					else if(s1=='Regular 40Hours Shift' || s1 == 'Flexible Shift' || s1 == 'Six Days Shift'|| s1 == 'Part Time Shift')
					{
						$('#Check_HolidayEarnCredit_TEarn').attr('disabled',false);						
						$('#Check_CTO_TEarn').attr('disabled',false);
						$('#Check_OverTime_TEarn').attr('disabled',false);
						
						$('#Check_ExcessHour_TEarn').attr('disabled',true);
					}
					else if(s1=='Hourly Shift')
					{
						$('#Check_HolidayEarnCredit_TEarn').attr('disabled',true);
						$('#Check_ExcessHour_TEarn').attr('disabled',true);
						$('#Check_CTO_TEarn').attr('disabled',true);
						$('#Check_OverTime_TEarn').attr('disabled',true);
					}
					closeModal();		
				}
				else if (KEY == 'IsStatusNeverOpen')
				{
					if (http_request.responseText.trim()!="" )
					{
						
						alert(http_request.responseText.trim());
						$('#h_ACalendarStatus').val("Never Opened");
					}
					else
					{
						SaveDataFinal('General');
					}
					/*KEY='IsHCalendarCurrent';
					var HCalendarId = $('#Combo_HolidayCalendar').val();
					makeRequest("ajax-validations.php","REQUEST=IsCalendarCurrent&HCalendarId="+HCalendarId);*/
				}				
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	$('#Checkbox_SelectAllG').click(function()
	{
		var TABLE_ROW = $('#Table_GeneralTab tr').length-1;	
		var checkboxValue=document.getElementById('Checkbox_SelectAllG').checked;
		for(i=1;i<TABLE_ROW;i++)
		{	
			if ( !$("#inlineCheckboxG"+i).is(':disabled') ) 
			{   
				document.getElementById("inlineCheckboxG"+i).checked = checkboxValue;
			}
		}
	});
	
	$('.myInlineG').click(function()
	{
		if($(this).prop("checked")==false)
		{
			$('#Checkbox_SelectAllG').prop("checked",false);
		}
	});
	$('#cmdUpdateSelectedG').click(function()
	{
		var TABLE_ROW = $('#Table_GeneralTab tr').length-1;
		var flag_updaterecord="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("inlineCheckboxG"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedG").innerHTML;
			if (ButtonCaption != "Save")
			{
				document.getElementById("cmdUpdateSelectedG").innerHTML = "Save";				
				$('#cmdUpdateSelectedG').css({"visibility":"hidden"});
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("inlineCheckboxG"+i).checked )
					{
						$('#General_'+i+"_2").hide();
						$('#Text_AliasName'+i).show();
					}
					else
					{
						$('#inlineCheckboxG'+i).hide();
					}
				}
				//$('#cmdUpdateSelectedG').hide();			
			}
		}
	});
	
	$('#Checkbox_SelectAllTO').click(function()
	{
		var TABLE_ROW = $('#Table_TimeOffTab tr').length-1;	
		var checkboxValue=document.getElementById('Checkbox_SelectAllTO').checked;		
		for(i=1;i<TABLE_ROW;i++)
		{	
			if ( !$("#inlineCheckbox"+i+"_Toff").is(':disabled') ) 
			{ 
				document.getElementById("inlineCheckbox"+i+"_Toff").checked = checkboxValue;
			}
		}
	});
	
	$('.myInlineTO').click(function()
	{
		
		if($(this).prop("checked")==false)
		{
			$('#Checkbox_SelectAllTO').prop("checked",false);
		}
	});
	
	$('#cmdUpdateSelectedTO').click(function()
	{
		var TABLE_ROW = $('#Table_TimeOffTab tr').length-1;
		//document.getElementById("h_NumRows").value = TABLE_ROW;
		
		var flag_updaterecord="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("inlineCheckbox"+i+"_Toff").checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedTO").innerHTML;
			if (ButtonCaption != "Save")
			{
				document.getElementById("cmdUpdateSelectedTO").innerHTML = "Save";				
				$('#cmdUpdateSelectedTO').css({"visibility":"hidden"});
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("inlineCheckbox"+i+"_Toff").checked )
					{
						$('#TOff_'+i+"_2").hide();
						$('#Text_AliasName'+i+"_TOff").show();
						
						$('#TOff_'+i+"_4").hide();
						$('#Text_Hours'+i+"_TOff").show();
						
						$('#TOff_'+i+"_5").hide();
						$('#Combo_PayPeriod'+i+"_TOff").show();
					}
					else
					{
						$('#inlineCheckbox'+i+"_Toff").hide();
					}
				}	
			}
		}
	});	
	
	function CheckDuplicate(name)
	{
		if (name!='')
		{
			var SelectedId = "<?php echo $HeaderId; ?>";				
			var FieldId = "POLICY_ID";
			KEY = "CheckDuplicate";
			FieldName = "NAME";
			FieldValue = $("#Text_PolicyProfileName").val();												
			$.ajax({
			url:"ajax-checkduplicate.php" , 
			method:"POST",
			data:{REQUEST:"CheckDuplicate",TableName:"cxs_policy_header",FieldName:FieldName,FieldValue:FieldValue,FieldId:FieldId,SelectedId:SelectedId},
			success:function(response)
			{
				if (response.trim().length>1)
				{
					$("#Span_PolicyProfile").text(response.trim());
					$("#h_duplicate").val("Y");	
					$("#Text_PolicyProfileName").focus();
				}
				else
				{
					$("#Span_PolicyProfile").text('');
					$("#h_duplicate").val("");						
				}	
			}
			});			
		}
	}	
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
</body>
</html>