<?php
//include('../conn.php');
include("te-functions.php");
?>

<?php
	if($_REQUEST['REQUEST'] == "CheckBoxesValidation")
	{
		$WorkshiftId = $_REQUEST['WorkshiftId'];
		$qry = "select WORKSHIFT_TYPE from cxs_workshifts where WORKSHIFT_ID = $WorkshiftId limit 1";	
		$result=mysql_query($qry);
		while($row=mysql_fetch_array($result))
		{
			/*if($row['WORKSHIFT_TYPE']=='9/8/80 Shift' || $row['WORKSHIFT_TYPE']=='4/10/40 Shift')
			{
				echo "AWWS";//Alternate Work Work Shift
			}
			else
			{
				echo "";
			}*/
			echo $row['WORKSHIFT_TYPE'];
		}		
	}
	
	if($_REQUEST['REQUEST'] == "IsStatusNeverOpen")
	{
		$currentDay = date("Y-m-d");
		$SiteId = $_SESSION['user-siteid'];
		$qry = "SELECT PERIOD_ID,CALENDAR_ID FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$currentDay'  AND TO_PERIOD_DATE>='$currentDay') and SITE_ID = $SiteId";
		$result = mysql_query($qry);
		while($row=mysql_fetch_array($result))
		{
			$ACalendarId = $row['CALENDAR_ID'];
		}
		$TotalRecords=0;
		$ConditionRecords=0;		
		$qry='';
		
		if($ACalendarId!='')
		{
			$qry = "select * from cxs_periods where cxs_periods.CALENDAR_ID = $ACalendarId and cxs_periods.SITE_ID = $SiteId ";
		}		
		if($qry!='')
		{
			$result=mysql_query($qry);
			while($row=mysql_fetch_array($result))
			{
				$Status = $row['STATUS'];
				if ( 'Never Opened'==$Status)
				{
					$ConditionRecords++;										
				}
				$TotalRecords++;
			}
		}
		if($TotalRecords==$ConditionRecords)
		{
			$CalendarName = getvalue("cxs_calendars","NAME","where CALENDAR_ID=$ACalendarId"); 
			echo "All periods in $CalendarName are Never Opened. Please set Open before use.";
		}		
	}
	
	if($_REQUEST['REQUEST'] == "IsCalendarCurrent")
	{
		//date_default_timezone_set('America/Los_Angeles');
		$CurrentYear = date('Y');
		$GetYear='';
		$flag_succeed='';
		$HCalendarId = $_REQUEST['HCalendarId'];
		$ACalendarId = $_REQUEST['ACalendarId'];
		$qry='';
		
		if($HCalendarId!='')
		{
			$qry = "select PERIOD_YEAR from cxs_holidays where cxs_holidays.HOLIDAY_CALENDAR_ID = $HCalendarId ";	
		}
		else if($ACalendarId!='')
		{
			$qry = "select PERIOD_YEAR from cxs_calendars where cxs_calendars.CALENDAR_ID = $ACalendarId ";	
		}
		if($qry!='')
		{
			$result=mysql_query($qry);
			while($row=mysql_fetch_array($result))
			{
				$GetYear = $row['PERIOD_YEAR'];
				if ( $CurrentYear==$GetYear)
				{
					$flag_succeed='Y';
					break;
				}
			}
		}
		if($flag_succeed!='Y')
		{
			echo $CurrentYear; 
		}
		else
		{
			echo $flag_succeed;
		}
	}	
	else if($_REQUEST['REQUEST'] == "AccountingPeriodRows")
	{	
		$PeriodType = $_REQUEST['PeriodType'];
		$StartDate = $_REQUEST['StartDate'];	
		
		$StartDate = strtotime($StartDate);		
		$StartDate = date('m/d/Y', $StartDate);
		
		$EndDate = date("m/d/Y", strtotime(date("m/d/Y", strtotime($StartDate)) . " + 1 year"));
		$EndDate = date('m/d/Y', strtotime('-1 day', strtotime($EndDate)));
		
		$date1 = $StartDate;
		if($PeriodType=='Weekly')
		{	
			$date2= date('m/d/Y', strtotime('6 day', strtotime($date1)));
		}
		else if($PeriodType=='Semi-Monthly')
		{
			$date2= date('m/d/Y', strtotime('14 day', strtotime($date1)));
		}
		else if($PeriodType=='Monthly')
		{
			$date2= date("Y/m/t", strtotime($date1)) ;
			$date2 = date("m/d/Y",strtotime($date2));			
		}
		$i=1;
		do
		{
			if($PeriodType=='Weekly')
			{
				$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1))."-W".week_number($date1);
			}
			else if($PeriodType=='Semi-Monthly')
			{
				$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1))."-H".semiMonth_number( $date1);
			}
			else if($PeriodType=='Monthly')
			{
				$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1));
			}
			if($i==1)
			{	
		?>
				<tr id="<?php echo "row$i";?>">
					<td class="check-bx ">
						<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()" disabled>
						<input type="hidden" id = <?php echo "h_PeriodId$i"; ?> name = <?php echo "h_PeriodId$i"; ?> value = "<?php echo $rows['PERIOD_ID']; ?>">
					</td>
					<td> 
						<span id = "<?php echo "span".$i."_2"; ?>" style = " display:none"> <?php echo $date1; ?> </span>
						<input type="text" id="<?php echo "Text_StartDate$i"; ?>" name="<?php echo "Text_StartDate$i"; ?>" class="form-control small form_datetime"  value = "<?php echo $date1; ?>" onchange='SetYear(<?php echo $i?>,this);'  >
					</td>					
		<?php
			}
			else
			{?>
					<tr id="<?php echo "row$i";?>">
					<td class="check-bx ">
						<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
						<input type="hidden" id = "<?php echo "h_PeriodId$i"; ?>" name = "<?php echo "h_PeriodId$i"; ?>" value = "<?php echo $rows['PERIOD_ID']; ?>">
					</td>
					<td> 
						<span id = "<?php echo "span".$i."_2"; ?>" > <?php echo $date1; ?> </span>
						<input type="hidden" id = "<?php echo "Text_StartDate$i"; ?>" name = "<?php echo "Text_StartDate$i"; ?>" value = "<?php echo $date1; ?>">
					</td>
		<?php	}?>
					<td> 
						<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $date2; ?> </span>
						<input type="hidden" id = "<?php echo "Text_EndDate$i"; ?>" name = "<?php echo "Text_EndDate$i"; ?>" value = "<?php echo $date2; ?>">
					</td>
					<td><span id="<?php echo "span".$i."_4"; ?>"><?php echo date("Y",strtotime($date1)); ?></span></td>	
					<td>
						<span id="<?php echo "span".$i."_5"; ?>"><?php echo $PeriodName; ?></span>
						<input type="hidden" id = "<?php echo "Text_PeriodName$i"; ?>" name = <?php echo "Text_PeriodName$i"; ?> value = "<?php echo $PeriodName; ?>">	
					</td>	
					
					<td><select class='form-control' id = '<?php echo "Combo_Status$i"?>' name = '<?php echo "Combo_Status$i"?>' class='form-control' > <option value='Never Opened'> Never Opened </option> </select></td>
					<td class='check-bx'><input type='checkbox' id='Check_InUse$i' name='Check_InUse$i' value='1' disabled></td>
					<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>
				</tr>
		<?php	
				
			if($PeriodType=='Weekly')
			{
				$date1 = date('m/d/Y', strtotime('7 day', strtotime($date1)));
				$date2= date('m/d/Y', strtotime('6 day', strtotime($date1)));
			}
			else if($PeriodType=='Semi-Monthly')
			{
				if($i%2==1)
				{
					$date1 = date('m/d/Y', strtotime('15 day', strtotime($date1)));
					$date2= date("Y/m/t", strtotime($date1)) ;
					$date2 = date("m/d/Y",strtotime($date2));
				}
				else
				{
					$date1 = date('m/d/Y', strtotime('1 day', strtotime($date2)));
					$date2=date('m/d/Y', strtotime('14 day', strtotime($date1)));					
				}
			}
			else if($PeriodType=='Monthly')
			{
				$date1 = date('m/d/Y', strtotime('1 month', strtotime($date1)));
				$date2= date("Y/m/t", strtotime($date1)) ;
				$date2 = date("m/d/Y",strtotime($date2));
			}
			$i=$i+1;
		}while(strtotime($date2)<=strtotime($EndDate));
	}	
	else if($_REQUEST['REQUEST'] == "HolidayDatePeriod")
	{
		$date1 = $_REQUEST['date1'];
		$date2 = $_REQUEST['date2'];	
		$PeriodYear = $_REQUEST['PeriodYear'];
		$SiteId = $_SESSION['user-siteid'];
		
		 $date1 = date('Y-m-d',strtotime($date1));
		 $date2 = date('Y-m-d',strtotime($date2));
		
		$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$PeriodYear' and cxs_periods.SITE_ID = $SiteId ";
		$qry.= "and ('$date1' >= FROM_PERIOD_DATE and '$date1' <= TO_PERIOD_DATE) and ('$date2' >= FROM_PERIOD_DATE and '$date2' <= TO_PERIOD_DATE)";  
	
		$result = mysql_query($qry);
		$noofrecords = mysql_num_rows($result);
		if ($noofrecords>0)
		{
			echo "valid";
		}
		else
		{
			$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$PeriodYear' and cxs_periods.SITE_ID = $SiteId ";
			$qry.= "and ('$date1' >= FROM_PERIOD_DATE and '$date1' <= TO_PERIOD_DATE) ";
			$result = mysql_query($qry);
			$noofrecords = mysql_num_rows($result);
			if ($noofrecords>0)
			{
				$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$PeriodYear' and cxs_periods.SITE_ID = $SiteId ";
				$qry.= "and ('$date2' >= FROM_PERIOD_DATE and '$date2' <= TO_PERIOD_DATE) ";	
				$result1 = mysql_query($qry);
				$noofrecords = mysql_num_rows($result1);
				if ($noofrecords>0)
				{
					echo "valid";
				}
			}		
		}		
	}
	
	else if($_REQUEST['REQUEST'] == "AllHolidayPeriods")
	{
		$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
		$Combo_PayPeriod = isset($_POST["Combo_PayPeriod"] )? $_POST["Combo_PayPeriod"]: false;
		$flag_valid="";
		$SiteId = $_SESSION['user-siteid'];
		for($i=1;$i<=$TotalRows;$i++)
		{
			$date1 = isset( $_POST['Text_StartDate'.$i] )? $_POST['Text_StartDate'.$i]: false;
			$date2 = isset( $_POST['Text_EndDate'.$i] )? $_POST['Text_EndDate'.$i]: false;
			if ($date1!='' && $date2 != '')	
			{
				$date1 = date('Y-m-d',strtotime($date1));
				$date2 = date('Y-m-d',strtotime($date2));
		
				$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$Combo_PayPeriod'";
				$qry.= "and ('$date1' >= FROM_PERIOD_DATE and '$date1' <= TO_PERIOD_DATE) and ('$date2' >= FROM_PERIOD_DATE and '$date2' <= TO_PERIOD_DATE) and cxs_periods.SITE_ID = $SiteId and cxs_calendars.SITE_ID = $SiteId ";  
	
				$result = mysql_query($qry);
				$noofrecords = mysql_num_rows($result);
				if ($noofrecords==0)
				{
					//$flag_valid=$i;				
					//break;
					
					$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$Combo_PayPeriod' and cxs_periods.SITE_ID = $SiteId and cxs_calendars.SITE_ID = $SiteId ";
					$qry.= "and ('$date1' >= FROM_PERIOD_DATE and '$date1' <= TO_PERIOD_DATE) ";
					$result = mysql_query($qry);
					$noofrecords = mysql_num_rows($result);
					if ($noofrecords>0)
					{
						$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_calendars.PERIOD_YEAR = '$Combo_PayPeriod' and cxs_periods.SITE_ID = $SiteId and cxs_calendars.SITE_ID = $SiteId ";
						$qry.= "and ('$date2' >= FROM_PERIOD_DATE and '$date2' <= TO_PERIOD_DATE) ";	
						$result1 = mysql_query($qry);
						$noofrecords = mysql_num_rows($result1);
						if ($noofrecords==0)
						{
							$flag_valid=$i;	
							break;
						}
					}
					else
					{
						$flag_valid=$i;	
						break;
					}
				}
			}
		}
		if($flag_valid=="")
		{
			$flag_valid = "valid";
		}		
		echo $flag_valid;
		
	}
	else if($_REQUEST['REQUEST'] == "PreApprovalByResourceGroup")
	{
		$ResourceGroupId = $_REQUEST['ResourceGroupId'];
		$ResultArray=array();
		$qry = "select PREAPPROVAL_RULE_ID,TIME_POLICY_ID from cxs_resource_groups where cxs_resource_groups.RESOURCE_GROUP_ID = '$ResourceGroupId'";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$ResultArray=$row;
		}
		echo json_encode($ResultArray);
	}
	
?>