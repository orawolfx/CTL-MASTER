<?php ob_start ();
	 		
	include("te-functions.php");
	include("sitename.php");
	check_login();
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_TimePolicy_PERMISSION = "Y";
		$UPDATE_PRIV_TimePolicy_PERMISSION = "Y";
		$VIEW_PRIV_TimePolicy_PERMISSION = "Y";
		$ENABLE_AUDIT_TimePolicy_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Management Policy',$_SESSION['user_id']);
		$UPDATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Management Policy',$_SESSION['user_id']);
		$VIEW_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Time Management Policy',$_SESSION['user_id']);
		$ENABLE_AUDIT_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Time Management Policy',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_TimePolicy_PERMISSION=='N' && $UPDATE_PRIV_TimePolicy_PERMISSION=='N' && $VIEW_PRIV_TimePolicy_PERMISSION=='N' && $ENABLE_AUDIT_TimePolicy_PERMISSION=='N')
	{
		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "time-management-policy.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
		$OrderBY = " desc";
		$FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";
	

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	
	$start_from = ($page-1) *  $RecordsPerPage;
	
?>
<script type="text/javascript" >
	var TABLE_ROW;
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Time Management Policy";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	
	function ShowReadOnly(Id)
	{
/*		KEY= "SingleRecord";			
		//ReadonlyInputElements(true);
		$('#DisplayPopup').modal();		
		var str = Id;		
		makeRequest("ajax.php","REQUEST=SingleUserRecord&PeriodId=" + str);
	*/	
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{				
			KEY= "SingleRecord";				
			$("#ModalElements :input").prop('disabled', true);
			$('#ModalDisplayPopup').modal();		
			var FieldValue = Id;
			var FieldName = "POLICY_ID";
			var TableName = "cxs_policy_header";
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
		
	}
	
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		
		}
	}   	
	function checkInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;		
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
			
		}		
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_PolicyId"+selectedRow).value;
			location.href="create-new-policy.php?hid="+s;
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}
	}
	
	function FindData()
	{
		KEY = "FindData";
		var formdata = $( "#Find-Policy-Form" ).serialize();		
		makeRequest("ajax-finddata.php","REQUEST=FindDataPolicies&"+formdata);
	}
	/*function RefreshData()
	{
		PolicyList.submit();
	}	*/
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<!-- <title>Coexsys | Time Accounting</title> -->
<title>Coexsys | <?php echo strtoupper($SiteName);?></title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">
	<style>
	@media (min-width: 992px) 
	{
	
		.modal-lg {	width: 1090px; }
	}	
	</style>
</head>

<body>
<?php include("header.php"); ?>

<!--Search modals start -->
	<form id="Find-Policy-Form" >
		<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title " id="myModalLabel">Find Time Management Policy </h4>
			  </div>
			  <div class="modal-body"> 
				<!-- field start-->
				<div class="col-sm-12">
				  <div class="cus-form-cont">				
					<div class="col-sm-6 form-group">
						<label> Policy Profile Name </label>
						 <input type="text" id = "Text_FindPolicyProfileName" name = "Text_FindPolicyProfileName" class="form-control" placeholder="" maxlength="100">
					</div>				
				  </div>
				  
				</div>
				<!-- end --> 
			  </div>
			  <div class="clear-both"></div>
			  <div class="modal-footer cr-user">
				<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
			  </div>
			</div>
		  </div>
		</div>
	</form>
	<!-- Search Modal  -->
	
	<!--Display modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ModalDisplayPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Time Management Policy</h4>
		  </div>
		  <div class="modal-body"  id = "ModalElements"> 
			<!-- field start-->
			<div class="col-sm-12">
				<div class="cus-form-cont">
					<div class="row">
						<div class="col-sm-5">
						  <div class="inline-form">							
							<label> Policy Profile Name </label>
							<input type="text" class="form-control" id="Text_PolicyProfile" >
						  </div>
						</div>
						<div class="col-sm-4 ">
						  <div class="inline-form">
							<label> Description </label>
							<input type="text" class="form-control" id="Text_Description">
						  </div>
						</div>
						
						<div class="col-sm-3 ">
						  <div class="inline-form">
							 <label> <input type="checkbox" id = "Check_Active"> Active </label>
							 <label> <input type="checkbox" id = "Check_AddInUse"> In USe </label>
						  </div>
						</div>
					</div>
						<div class="manage-bx"> 
							  <!-- Nav tabs -->
							<ul class="nav nav-tabs tab-menu-bx" role="tablist">
								<li role="presentation" class="active"><a href="#genrnal" aria-controls="home" role="tab" data-toggle="tab"> General </a></li>
								<li role="presentation"><a href="#time-op" aria-controls="profile" role="tab" data-toggle="tab"> Time off Policy </a></li>								
							</ul>
						  
						  <!-- Tab panes -->
							<div class="tab-content" style = "padding-top:10px;padding-bottom:10px;">
								<div role="tabpanel" class="tab-pane active in" id="genrnal">									
									<!-- pop up end -->
									<div class="tabbable">
										<div class="row">
											<div class="col-sm-12 ">
												<div class="des-bx">													
													<label class="col-md-1 text-right"  > Workshift </label>
													<div class="col-md-2" style = "width:20%" >
													  <select class="form-control requirefieldcls" required  id = "Combo_Workshift" name = "Combo_Workshift" onchange = "setWorkshift();">
														<option value=""> - Workshift - </option>
														<?php
															$selectQuery = "select * from cxs_workshifts order by NAME";
															$result = mysql_query($selectQuery);
															while($row = mysql_fetch_array($result))
															{
																$WorkShiftName = $row['NAME'];
																$IsSelected="";
																if($Display_Workshift== $row['WORKSHIFT_ID'])
																{
																	$IsSelected = "selected";
																}
															?>
																<option value="<?php echo $row['WORKSHIFT_ID']; ?>" <?php echo $IsSelected; ?>> <?php echo $WorkShiftName; ?> </option>
													<?php	}?>
													  </select>												  
													</div>
													<div class="col-md-8">														                    
														<label> <input type="checkbox" id = "Check_ExcessHour_TEarn" name = "Check_ExcessHour_TEarn" value = "1" <?php echo ($Display_ExcessHour=='Y')?"checked":""; ?> > Excess Hour Allowed </label>
														<label> <input type="checkbox" id = "Check_HolidayEarnCredit_TEarn" name = "Check_HolidayEarnCredit_TEarn" value = "1" <?php echo ($Display_HolidayEarnCredit=='Y')?"checked":""; ?> > Holiday Earn credit Allowed </label>
														<label> <input type="checkbox" id = "Check_CTO_TEarn" name = "Check_CTO_TEarn" value = "1" <?php echo ($Display_CTO=='Y')?"checked":""; ?> > CTO For Overtime </label>
														<label> <input type="checkbox" id = "Check_OverTime_TEarn" name = "Check_OverTime_TEarn" value = "1" <?php echo ($Display_CTO=='Y')?"checked":""; ?> > Overtime </label>
													</div>
												</div>
											</div>
										</div>	
										
										<div class="data-bx">
											<div class="table-responsive">
												<table class="table table-bordered mar-cont" id = "Table_GeneralTab">
													<thead>
														<tr>														
															<th width="15%"> Alias Name </th>
															<th width="22%"> Alias Type </th>
															<th width="23%"> Description </th>
															<th width="15%"> Alias Class </th>
															<th width="20%"> Project WBS </th>								
															<th width="5%"> </th>
														</tr>
													</thead>
													<tbody  id="Table_GeneralTabBody">													
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<!-- genral end -->
								
								<div role="tabpanel" class="tab-pane" id="time-op">
									<div class="data-bx">
										<div class="table-responsive">
										  <table class="table table-bordered mar-cont" id = "Table_TimeOffTab">
											<thead>
											  <tr>
												<th width="20%"> Leave Aliases </th>
												<th width="15%" >Workshift </th>												
												<th width="5%"></th>
											  </tr>
											</thead>
											<tbody id="Table_TimeOffTabBody">
											  
											</tbody>
										  </table>
										</div>
									</div>
								</div>
								<!-- time off policy -->
							</div>
						</div>				
				</div>
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			
		  </div>
		</div>
	  </div>
	</div>
	<!-- Display Modal  -->
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="#"> Time Management Policy </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">

        <div class="fright">
			
			<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
			<!-- <button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button> -->
        </div>
      </div>
      <!-- inner work-->
      <div class="cont-box">
        <div class="pge-hd">
          <h2 class="sec-title"> <label id="Label_Title"> Time Management Policy </label> </h2>
        </div>
		<?php
			$selectQuery = "SELECT  NAME,DESCRIPTION,cxs_policy_header.ACTIVE_FLAG,cxs_policy_header.*,cxs_users.USER_NAME as CreatedBy FROM cxs_policy_header inner join cxs_users on cxs_users.USER_ID = cxs_policy_header.CREATED_BY  WHERE cxs_policy_header.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";
			$selectQueryForPages  = $selectQuery;
			$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
			
			$ExportQry = $selectQuery;
			
			$RunUserQuery=mysql_query($selectQuery);
			$StdNumRows = mysql_num_rows($RunUserQuery);
			$msg = "";
			if($StdNumRows == 0 )
			{
				$msg = "No Record Found";
			}			
		?>
		<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
		
        <div>   
			<div class="fleft two">				
				<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_TimePolicy_PERMISSION=='Y'){ ?>id="cmdUpdateSelected" name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>
				<button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>
			</div>			
			<div class="fright cr-user">
				<a <?php $sDisabled = ""; if($CREATE_PRIV_TimePolicy_PERMISSION=='Y'){ ?> href="create-new-policy.php" <?php } else $sDisabled ="disabled=disabled"; ?>> 
				<button type="button" class="btn btn-primary btn-style" <?php echo $sDisabled; ?>> Create Policy</button></a>									
			</div>
			<form name = "PolicyList" id = "PolicyList" method="post" >
				<div class="data-bx">
					<div class="table-responsive">
					  <table class="table table-bordered mar-cont" id = "Table1" name = "Table1">
						<thead>
						  <tr>
							<th width="3%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>							
							 <th width="30%">
									<?php if($Sorts == 'desc' && $FileName == 'NAME') { ?>
										  <span style="">
											Policy Profile Name
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('NAME','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Policy Profile Name
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('NAME','desc');"></i>
										  </span>
									<?php } ?>
								</th>
							
							
							<th width="30%"> Description <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a></th>
							<th width="8%"> Active Flag <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a> </th>
							<th width="5%"> </th>
						  </tr>
						</thead>
						<tbody>
							<?php
								$i= 1;
								while($rows=mysql_fetch_array($RunUserQuery))
								{
									$Display_PolicyId = $rows['POLICY_ID'];
									$Display_CreatedByName	= $rows['CreatedBy'];	
									$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));							
									$UpdatedBy		= $rows['LAST_UPDATED_BY'];
									$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							
									$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATED']));
							?>
							<tr  <?php if($VIEW_PRIV_TimePolicy_PERMISSION=='Y') {?> ondblclick="ShowReadOnly('<?php echo $Display_PolicyId; ?>')" <?php } ?>>								
								<td class="check-bx "><input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
									<input type="hidden" id = <?php echo "h_PolicyId".$i; ?> name = <?php echo "h_PolicyId".$i; ?> value = "<?php echo $Display_PolicyId; ?>">	
								</td>
								<td> <?php echo $rows['NAME']; ?> </td>
								<td> <?php echo $rows['DESCRIPTION']; ?> </td>
								<td class = "check-bx"> <input type="checkbox" id="<?php echo "Checkbox_Active$i"; ?>" name="<?php echo "Checkbox_Active$i"; ?>" value="1" <?php echo($rows['ACTIVE_FLAG'] == "Y")?"checked":""; ?> disabled >  </td>						
								<td>
									<?php if($VIEW_PRIV_TimePolicy_PERMISSION=='Y') {?>
									<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
									Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
									<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
									<?php } else {?> <button type="button" class="btn btn-default"><i class=" fa fa-eye"></i></button> <?php } ?>
								</td>  
							</tr>
						<?php $i=$i+1;
								}
						?>
						</tbody>
					  </table>
					</div>
				</div>
				<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
				<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	
				<input type="hidden" id="h_query" name="h_query" value=""/>
			</form>  
			<!-- pagination start-->
			  <div class="pagination-bx">
					<div class="bs-example">
					  <ul class="pagination">
						<?php

								//$selectQueryForPages=$selectQueryForPages;
								$RunDepQuery=mysql_query($selectQueryForPages);
								$num_records = mysql_num_rows($RunDepQuery);
								$total_pages= ceil($num_records/$RecordsPerPage);
								if (($page-1)==0){ ?>
									<li class="disabled">
										<!--<a rel="0" href="#"> «</a>-->
										<a rel="0" href="#">&laquo;</a>
									</li>
						  <?php  } else{  ?>
							<li class="">
							<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
							</li>
							<?php }
						   for($i=1;$i<=$total_pages;$i++){ ?>
								<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
								<?php }
								 if (($page+1)>$total_pages){   ?>
								<li class="disabled"><a href="#">&raquo;</a></li>
									<?php  }else{    ?>
							   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
										  <?php } ?>

					  </ul>

					</div>
				</div>
			  <!-- pagination end --> 
        </div>
      </div>
    </div><div class="dash-strip">

        <div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
			<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
	
        </div>
      </div>
  </div>
</section>
<footer> </footer>
<script type="text/javascript">
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText);
					//alert(JSON.stringify(JSONObject));
					
					$('#Text_PolicyProfile').val(JSONObject['cxs_policy_header']["NAME"]);
					$('#Text_Description').val(JSONObject['cxs_policy_header']["DESCRIPTION"]);					
					if(JSONObject['cxs_policy_header']["ACTIVE_FLAG"]=="Y"){document.getElementById("Check_Active").checked=true;}else{document.getElementById("Check_Active").checked=false;}
					if(JSONObject['cxs_policy_header']["ADDINUSE_FLAG"]=="Y"){document.getElementById("Check_AddInUse").checked=true;}else{document.getElementById("Check_AddInUse").checked=false;}
					
					
					var GeneralRows = JSONObject['GeneralRows'];
					var WBSValue ="";
					$('#Table_GeneralTab').find('tbody').remove();					
					for(i=0;i<GeneralRows;i++)
					{
						WBSValue = "";
						if(JSONObject[i]['SEGMENT1']!=null)
						{
							WBSValue = JSONObject[i]['SEGMENT1'];
							if (WBSValue!='' && JSONObject[i]['SEGMENT2']!='')
							{
								WBSValue += "."+JSONObject[i]['SEGMENT2'];
							}
							if (WBSValue!='' && JSONObject[i]['SEGMENT3']!='')
							{
								WBSValue += "."+JSONObject[i]['SEGMENT3'];
							}
							if (WBSValue!='' && JSONObject[i]['SEGMENT4']!='')
							{
								WBSValue += "."+JSONObject[i]['SEGMENT4'];
							}
							if (WBSValue!='' && JSONObject[i]['SEGMENT5']!='')
							{
								WBSValue += "."+JSONObject[i]['SEGMENT5'];
							}
						}	
						Value = "Created By:  "+JSONObject[i]['CreatedByName']+"&#013;"+"Updated By : "+JSONObject[i]['UpdatedByName']+"&#013;Creation Date : "+MyDateFormat(JSONObject[i]['CREATION_DATE'])+"&#013;Last Update Date : "+MyDateTimeFormat(JSONObject[i]['LAST_UPDATE_DATE']);						
						LastCell = "<button type='button' class='btn btn-default' data-toggle='tooltip'  data-placement='left' title='"+Value+"'> <i class=' fa fa-eye'></i> </button>";						
						$('#Table_GeneralTab').append('<tr><td>'+JSONObject[i]["AliasNameG"]+'</td><td>'+JSONObject[i]["AliasTypeG"]+'</td><td>'+JSONObject[i]["AliasDescriptionG"]+'</td><td>'+JSONObject[i]["AliasClassG"]+'</td><td>'+WBSValue+'</td><td>'+LastCell+'</td></tr>');	
					}					
					$('#Combo_Workshift').val(JSONObject[0]['WORKSHIFT_ID']);						
					
					if(JSONObject[0]['EXCESS_HOURS_ALLOWED']=="Y"){document.getElementById("Check_ExcessHour_TEarn").checked=true;}else{document.getElementById("Check_ExcessHour_TEarn").checked=false;}
					if(JSONObject[0]['HOLIDAY_EARN_CREDIT']=="Y"){document.getElementById("Check_HolidayEarnCredit_TEarn").checked=true;}else{document.getElementById("Check_HolidayEarnCredit_TEarn").checked=false;}					
					if(JSONObject[0]['CTO_OVERTIME']=="Y"){document.getElementById("Check_CTO_TEarn").checked=true;}else{document.getElementById("Check_CTO_TEarn").checked=false;}
					if(JSONObject[0]['OVERTIME_ALLOWED']=="Y"){document.getElementById("Check_OverTime_TEarn").checked=true;}else{document.getElementById("Check_OverTime_TEarn").checked=false;}
					
					var TimeOffRows = JSONObject['TimeOffRows'];					
					$('#Table_TimeOffTab').find('tbody').remove();					
					for(i=GeneralRows;i<TimeOffRows+GeneralRows;i++)
					{
						Value = "Created By:  "+JSONObject[i]['CreatedByNameTimeOff']+"&#013;"+"Updated By : "+JSONObject[i]['UpdatedByNameTimeOff']+"&#013;Creation Date : "+MyDateFormat(JSONObject[i]['CreateDateTimeOff'])+"&#013;Last Update Date : "+MyDateTimeFormat(JSONObject[i]['UpdateDateTimeOff']);						
						LastCell = "<button type='button' class='btn btn-default' data-toggle='tooltip'  data-placement='left' title='"+Value+"'> <i class=' fa fa-eye'></i> </button>";						
						$('#Table_TimeOffTab').append('<tr><td>'+JSONObject[i]["AliasNameTimeOff"]+'</td><td>'+JSONObject[i]["WorkshiftNameTimeOff"]+'</td><td>'+LastCell+'</td></tr>');	
					}					
					/*var TimeEarnRows = JSONObject['TimeEarnRows'];					
					$('#Table_TimeEarnTab').find('tbody').remove();						
					for(i=TimeOffRows+GeneralRows;i<TimeEarnRows+TimeOffRows+GeneralRows;i++)
					{	
						Value = "Created By:  "+JSONObject[i]['CreatedByNameTimeEarn']+"&#013;"+"Updated By : "+JSONObject[i]['UpdatedByNameTimeEarn']+"&#013;Creation Date : "+MyDateFormat(JSONObject[i]['CreateDateTimeEarn'])+"&#013;Last Update Date : "+MyDateTimeFormat(JSONObject[i]['UpdateDateTimeEarn']);						
						LastCell = "<button type='button' class='btn btn-default' data-toggle='tooltip'  data-placement='left' title='"+Value+"'> <i class=' fa fa-eye'></i> </button>";						
						$('#Table_TimeEarnTab').append('<tr><td></td><td>'+JSONObject[i]["WorkshiftNameTimeEarn"]+'</td><td>'+JSONObject[i]["PeriodNameTimeEarn"]+'</td><td>'+JSONObject[i]["EARN_TYPE"]+'</td><td>'+LastCell+'</td></tr>');	
					}
					//if(JSONObject[TimeOffRows+GeneralRows]['EXCESS_HOURS_ALLOWED']=="Y"){document.getElementById("Check_ExcessHour_TEarn").checked=true;}else{document.getElementById("Check_ExcessHour_TEarn").checked=false;}
					if(JSONObject[TimeOffRows+GeneralRows]['HOLIDAY_EARN_CREDIT']=="Y"){document.getElementById("Check_HolidayEarnCredit_TEarn").checked=true;}else{document.getElementById("Check_HolidayEarnCredit_TEarn").checked=false;}
					if(JSONObject[TimeOffRows+GeneralRows]['SHIFT_DIFFERENTIAL']=="Y"){document.getElementById("Check_EnableShift_TEarn").checked=true;}else{document.getElementById("Check_EnableShift_TEarn").checked=false;}
					if(JSONObject[TimeOffRows+GeneralRows]['OVERTIME_ALLOWED']=="Y"){document.getElementById("Check_CTO_TEarn").checked=true;}else{document.getElementById("Check_CTO_TEarn").checked=false;}
					*/					
				}
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;					
					s1=s1.trim();
					document.getElementById("h_query").value=s1;											
					PolicyList.submit();
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	function MyDateFormat(inputDate)
	{
		var date = new Date(inputDate);
		if (!isNaN(date.getTime())) {
			// Months use 0 index.
			return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear();
		}
		else
		{
			return '';
		}
	}
	
	function MyDateTimeFormat(inputDate)
	{
		var date = new Date(inputDate);
		if (!isNaN(date.getTime())) 		
		{
			// Months use 0 index.					
			var hour   = date.getHours();
			var minute = date.getMinutes();
			var second = date.getSeconds();
			var ap = "AM";
			if (hour   > 11) { ap = "PM";             }
			if (hour   > 12) { hour = hour - 12;      }
			if (hour   == 0) { hour = 12;             }
			if (hour   < 10) { hour   = "0" + hour;   }
			if (minute < 10) { minute = "0" + minute; }
			if (second < 10) { second = "0" + second; }
			var timeString = hour + ':' + minute + ':' + second + " " + ap;
			return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear() + ' '+ timeString;
		}
		else
		{
			return '';
		}
	}
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = "<?php echo $ExportQry; ?>";	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#CheckboxInline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_PeriodId"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'POLICY_ID', ExportIdList:exportIds,
						  ExportFileName:'_time-management-policy.xls', ExportSheetTitle:"Time Management Policy"
						 },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>