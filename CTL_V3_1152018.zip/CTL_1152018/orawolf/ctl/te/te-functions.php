<?php
include("../conn.php"); 
//check_login();
if( !isset($_SESSION["CurrentPayPeriod"] ))
{
	$currentDate = date('Y-m-d');
	$SiteId = $_SESSION['user-siteid'];
	$qry = "select  * from cxs_periods  where STATUS != 'Never Opened' and ('$currentDate' >= FROM_PERIOD_DATE and '$currentDate' <= TO_PERIOD_DATE) and SITE_ID = $SiteId ";
	$result = mysql_query ($qry);
	while($row=mysql_fetch_array($result))
	{ 
		$CurrentAccountingPeriod = $row['PERIOD_NAME'];
		$CurrentAccountingPeriodId = $row['PERIOD_ID'];
		$CurrentAccountingCalendarId = $row['CALENDAR_ID'];
	}
	$_SESSION["CurrentPayPeriod"]   =   $CurrentAccountingPeriod;
	$_SESSION['CurrentPayPeriodId'] = $CurrentAccountingPeriodId;
	$_SESSION['CurrentCalendarId']  =  $CurrentAccountingCalendarId;
} 
$RecordsPerPage = 25;
$ModuleName = "Time Accounting";
function week_number( $date) 
{ 
	return ceil( date( 'j', strtotime( $date ) ) / 7 ); 
}

function semiMonth_number( $date) 
{ 
	return ceil( date( 'j', strtotime( $date ) ) / 15); 
}

function getTimeAccountingModuleStatusByUserId($field_name,$module_name,$user_id)
{ 
	$sql="select $field_name from cxs_ta_modules where USER_ID='".$user_id."' and MODULE_NAME='".$module_name."'";
	$res = mysql_query($sql);
	if(mysql_num_rows($res)>0)
	{
		$row = mysql_fetch_array($res);
		return $row[0];
	}
	else
	{
		return 'N';
	}	
}

function getTimeAccountingRulesByUserId($field_name,$user_id)
{
	$sql="select $field_name from cxs_am_ta_rules where USER_ID='".$user_id."'";
	$res = mysql_query($sql);
	if(mysql_num_rows($res)>0)
	{
		$row = mysql_fetch_array($res);
		return $row[0];
	}
	else
	{
		return 'N';
	}	
}

	function CheckWorkshiftFlexibleType($CurrentWorkshiftId,$EntryFirstDate)
	{
		$msg = "";
		$SiteId = $_SESSION['user-siteid'];
		$divStyle="<div class='alert alert-success justify-content-center'>";
		$qry = "select cxs_flex_schedule.*,cxs_workshifts.NAME from cxs_flex_schedule inner join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_flex_schedule.WORKSHIFT_ID where cxs_flex_schedule.WORKSHIFT_ID = '$CurrentWorkshiftId' and cxs_flex_schedule.SITE_ID = $SiteId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$WorkshiftName = $row['NAME'];
			$ScheduleType = $row['SCHEDULE_TYPE'];
			if($ScheduleType == 'DATE_RANGE')
			{
				$Sch_StartDate = $row['SCHEDULE_START_DATE'];
				$Sch_EndDate = $row['SCHEDULE_END_DATE'];
				
				$qry = "select * from cxs_flex_schedule where SCHEDULE_END_DATE >= '$EntryFirstDate' and WORKSHIFT_ID = '$CurrentWorkshiftId' and cxs_flex_schedule.SITE_ID = '$SiteId'";
				$result = mysql_query($qry);
				$noofrows = mysql_num_rows($result);
				if($noofrows==0)
				{
					$EntryFirstDate = date("D, M d, Y", strtotime($EntryFirstDate));
					$msg = $divStyle."$EntryFirstDate is not under date range of Workshift - $WorkshiftName. Contact your administrator. </div>";
					//$msg = "$EntryFirstDate is not under date range of Workshift - $WorkshiftName. Contact your administrator.";
				}
			}
			return $msg;
		}
	}
	function UserValidationsForTE($userid,$CurrentPayPeriodId)
	{
		$msg = "";
		$SiteId = $_SESSION['user-siteid'];
		$divStyle="<div class='alert alert-success'>";	
		$ResourceGroup = "";
		$RetroPeriods =0;
		$qry = "select cxs_resources.RESOURCE_GROUP_ID from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_users.USER_ID = $userid and cxs_resources.SITE_ID = $SiteId";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$ResourceGroup = $row['RESOURCE_GROUP_ID'];
		}
		
		if($ResourceGroup == '0' || $ResourceGroup == '')
		{//INNER
			$JoinQuery1 = " LEFT JOIN cxs_am_ta_rules ON cxs_am_ta_rules.USER_ID = cxs_users.USER_ID";
		}
		else 
		{
			$JoinQuery1 = " INNER JOIN cxs_resource_groups ON cxs_resource_groups.RESOURCE_GROUP_ID = cxs_resources.RESOURCE_GROUP_ID 
							INNER JOIN cxs_am_ta_rules ON cxs_am_ta_rules.RESOURCE_GROUP_ID = cxs_resources.RESOURCE_GROUP_ID";
		}
		$qry = "SELECT cxs_am_ta_rules.RETRO_PERIOD_NUM,cxs_am_ta_rules.ALLOW_PREAPPROVAL,cxs_preapp_rules.RULE_NAME,cxs_resources.SUPREVISOR_ID,cxs_policy_header.NAME as TimePolicy,cxs_policy_header.ACTIVE_FLAG as TimePolicyActiveFlag FROM cxs_users 
					inner JOIN cxs_resources ON cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID LEFT JOIN cxs_policy_header ON cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID
					LEFT JOIN cxs_policy_general ON cxs_policy_general.POLICY_ID = cxs_policy_header.POLICY_ID left join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID $JoinQuery1 where cxs_users.USER_ID = $userid and cxs_users.SITE_ID = $SiteId limit 0,1";
//					, cxs_policy_general.CALENDAR_ID
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$RetroPeriods = $row['RETRO_PERIOD_NUM'];
			//$PolicyCalendarId = $row['CALENDAR_ID'];
			$IsAllowPreApproval = $row['ALLOW_PREAPPROVAL'];
			$PreApprovalName = $row['RULE_NAME'];
			$SupervisorId = $row['SUPREVISOR_ID'];
			$TimePolicy = $row['TimePolicy'];
			$IsTimePolicyActive = $row['TimePolicyActiveFlag'];
		}
		$qry = "select * from cxs_periods where PERIOD_ID =$CurrentPayPeriodId  ";		
		$result = mysql_query($qry);		
		while($row = mysql_fetch_array($result))
		{
			$PeriodName = $row['PERIOD_NAME'];
			if($row['STATUS']!='Open')
			{
				$msg = $divStyle."No period open for $PeriodName. Contact your administrator. </div>";
			}
		}
		if($msg=="")
		{
			if($IsAllowPreApproval=="Y" && $PreApprovalName == '')
			{
				$msg = $divStyle."You are Pre Approved for Pre Approval Time Entry, However, the your profile does not comply all rules for Pre Approval Entry. Please contact your Administrator.</div>";
			}
		}
		/*if($msg=="")
		{
			$RefrenceApproverId = getvalue("cxs_am_approval_mgmt","REFERENCE_APPROVER_ID","where USER_ID = $userid and SITE_ID = $SiteId");			
			if(!isset($RefrenceApproverId))
			{
				$msg = $divStyle."No Approver assigned for this time entry.  Please contact your administrator.</div>";				
			}
		}*/
		if($msg=="" && $SupervisorId == 0)
		{
			$msg = $divStyle."Supervisor must be assigned in order to access Time Entry Page. Please contact your administrator.</div>";
		}
		else if ($msg=="" && $IsTimePolicyActive!='Y')
		{
			$msg = $divStyle."The Time Policy $TimePolicy that is assigned to your account is inactive or disabled.  You may not proceed.  Please contact your administrator.</div>";
		}
		else if($msg=="")
		{
			$msg1 = RetroAdvancePeriodChecking($RetroPeriods,$CurrentPayPeriodId,$userid);
			if($msg1!='')
			{
				$msg = $divStyle.$msg1."</div>";
			}
		}
		return $msg;
	}
	
	function RetroAdvancePeriodChecking($RetroPeriods,$RequiredPayPeriodId,$userid)
	{
		//echo "RequiredPayPeriodId ".$RequiredPayPeriodId;
		$ActualSystemCurrentPeriodId = $_SESSION["CurrentPayPeriodId"];
		$ActualCalendarId = $_SESSION['CurrentCalendarId'];
		$ActualPeriodStartDate = getvalue("cxs_periods","FROM_PERIOD_DATE","where PERIOD_ID = $ActualSystemCurrentPeriodId");
		$SiteId = $_SESSION['user-siteid'];
		
		$qry = "select FROM_PERIOD_DATE,PERIOD_NAME,TO_PERIOD_DATE from cxs_periods where PERIOD_ID = $RequiredPayPeriodId and SITE_ID = $SiteId";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$RequiredPeriodStartDate = $row['FROM_PERIOD_DATE'];
			$RequiredPeriodEndDate = $row['TO_PERIOD_DATE'];
			$RequiredPeriodName = $row['PERIOD_NAME'];			
		}		
		$msg1 = "";
		if(strtotime($RequiredPeriodStartDate) >  strtotime($ActualPeriodStartDate))
		{
			$msg1 = "Advance period entry not allow.";
		}
		if ($msg1=='')
		{
			$qry = "select START_DATE from cxs_users where USER_ID = $userid";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$UserStartDate = $row['START_DATE'];				
			}
			
			if(strtotime($UserStartDate) > strtotime($RequiredPeriodStartDate))
			{
				if((strtotime($UserStartDate) > strtotime($RequiredPeriodEndDate))) // 123
				{
					$msg1 = "You have not permission to access $RequiredPeriodName";				
				}
			}
		}
		if ($msg1=='')
		{
			if($ActualSystemCurrentPeriodId==$RequiredPayPeriodId)
			{
				$msg1="match";
			}
		}
		if($msg1=='')
		{
			$qry = "select PERIOD_TYPE from cxs_calendars where CALENDAR_ID = $ActualCalendarId";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$ActualPeriodType = $row['PERIOD_TYPE'];
			}
			
		/*$qry = "select PERIOD_TYPE from cxs_calendars where CALENDAR_ID = $ActualCalendarId";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$ActualPeriodType = $row['PERIOD_TYPE'];
			}*/
			$CurrentDate = date("Y-m-d");
			if($ActualPeriodType=='Monthly')
			{
				$StartDate = date('Y-m',strtotime($CurrentDate))."-01";
			}
			else if($ActualPeriodType=='Semi-Monthly')
			{
				$OnlyDate = date("d");
				if($OnlyDate >=16)
				{
					$StartDate = date('Y-m',strtotime($CurrentDate))."-16";
				}
				else
				{
					$StartDate = date('Y-m',strtotime($CurrentDate))."-01";
				}
			}
			else if($ActualPeriodType=='Weekly')
			{
				if(date('l',strtotime($CurrentDate))=='Monday')
				{
					$StartDate = $CurrentDate;
				}
				else										
				{
					$StartDate = date('Y-m-d',strtotime("last Monday",strtotime($CurrentDate)));
				}
			}
			$date1 = $StartDate;
			if($OnlyDate >=16) { $j=2;}
			else {$j=1;}
			
			for($i=1;$i<=$RetroPeriods;$i++)
			{
				if($ActualPeriodType=='Monthly')
				{
					$date2= date('Y-m-d', strtotime('-1 day', strtotime($date1)));			
					$date1 = date('Y-m',strtotime($date2))."-01";
				}
				else if($ActualPeriodType=='Semi-Monthly')
				{
					if($j%2==1)
					{
						$date2= date('Y-m-d', strtotime('-1 day', strtotime($date1)));			
						$date1 = date('Y-m',strtotime($date2))."-16";			
					}
					else
					{
						$date2= date('Y-m-d', strtotime('-1 day', strtotime($date1)));
						$date1 = date('Y-m',strtotime($date2))."-01";			
					}		
					$j++;
				}
				else if($ActualPeriodType=='Weekly')
				{
					$date1= date('Y-m-d', strtotime('-7 day', strtotime($date1)));
					$date2= date('Y-m-d', strtotime('6 day', strtotime($date1)));
				}
				
				$condition1 = " where (FROM_PERIOD_DATE <= '$date1' and TO_PERIOD_DATE >= '$date1') and (FROM_PERIOD_DATE <= '$date2' and TO_PERIOD_DATE >= '$date2') and SITE_ID = $SiteId ";
				$qry = "select PERIOD_ID,STATUS from cxs_periods $condition1";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					if($row['PERIOD_ID']==$RequiredPayPeriodId )
					{
						if($row['STATUS']=='Open')
						{
							$msg1 = "match";							
						}
					}
				}
				if($msg1=="match")
				{
					$msg1="";
					return $msg1;
				}
			}
			if($msg1=="")
			{
				$msg1 = "You have not permission to access $RequiredPeriodName";
			}
		}
		if($msg1=="match")
		{
			$msg1="";
		}
		return $msg1;
	}
?>