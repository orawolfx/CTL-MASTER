<?php
include('../conn.php');
 
?>

<?php
	if($_REQUEST['REQUEST'] == "CreateShift")
	{
		$ShiftName = $_REQUEST['ShiftName'];
		$desc = $_REQUEST['desc'];
		$timezone = $_REQUEST['timezone'];
		$LoginUserId = $_SESSION["user_id"];
		
		$insArr = array();
		$insArr['NAME'] = $ShiftName;
		$insArr['DESCRIPTION'] = $desc;
		$insArr['TIMEZONE'] = $timezone;
		
		$insArr['CREATION_DATE']='now()' ;
		$insArr['CREATED_BY']=$LoginUserId;
		$insArr['LAST_UPDATED_BY']=$LoginUserId;
		
		insertdata("cxs_workshifts",$insArr);
	echo	$HeaderId= mysql_insert_id(); 
	}
	if($_REQUEST['REQUEST'] == "Add-Record")
	{
		$TableName = $_REQUEST['TableName'];
		$HeaderId = $_REQUEST['HeaderId'];
		$ScheduleType = $_REQUEST['ScheduleType'];
		$TabValues = $_REQUEST['TabValues'];
		$LoginUserId = $_SESSION["user_id"];
		
		$insArr = array();
		$insArr['WORKSHIFT_ID'] = $HeaderId;
		$insArr['SCHEDULE_TYPE'] = $ScheduleType;
		$insArr['CREATION_DATE']='now()' ;
		$insArr['CREATED_BY']=$LoginUserId;
		$insArr['LAST_UPDATED_BY']=$LoginUserId;
		
				/*	do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."RESOURCE_ID=$s1 or ";
			$s = substr($s, $pos+1);
			
		}while($s.length>0);
			*/
			
		if($ScheduleType == 'DATE_RANGE')
		{
			$pos = strpos($TabValues,"|");
			$s1 = trim(substr($TabValues, 0, $pos));  //id
			$s2 = trim(substr($TabValues, $pos+1));	
			if($s1!='')
			{
				$s1 = date("Y/m/d", strtotime($s1));	
			}
			if($s2!='')
			{
				$s2 = date("Y/m/d", strtotime($s2));	
			}
			
			$insArr['SCHEDULE_START_DATE'] = $s1;
			$insArr['SCHEDULE_END_DATE'] = $s2;			
		}
		else if($ScheduleType=='DAYS_IN_MONTH')
		{
			$s = $TabValues;
			do
			{
				$pos = strpos($s,"|");
				$s1 = trim(substr($s, 0, $pos));  //id
				$insArr['DAYS_IN_MONTH'.$s1] = 'X';				
				$s = substr($s, $pos+1);				
			}while(strlen($s)>0);			
		}
		else if($ScheduleType=='DAYS_IN_WEEK')
		{
			$s = $TabValues;			
			do
			{
				$pos = strpos($s,"|");
				$s1 = trim(substr($s, 0, $pos)); 				
				$insArr[$s1] = 'X';				
				$s = substr($s, $pos+1);								
			}while(strlen($s)>0);			
		}		
		
		$qry = "delete from cxs_flex_schedule where WORKSHIFT_ID = $HeaderId";
		mysql_query ($qry);
		
		insertdata($TableName,$insArr);		
	}	
	if($_REQUEST['REQUEST'] == "InsertPolicy-Record")
	{	
		//$HolidayCalendar = $_REQUEST['Combo_HolidayCalendar'];
		//$AccountingCalendar = $_REQUEST['Combo_AccountingCalendar'];
		
		$Workshift = $_REQUEST['Combo_Workshift'];
		$PolicyProfile = $_REQUEST['PolicyProfile'];
		$Description = $_REQUEST['Description'];
		$Active = $_REQUEST['Active'];
	//	$AddInUse = $_REQUEST['AddInUse'];	
		$DetailTable = $_REQUEST['DetailTable'];		
		$h_PolicyId = $_REQUEST['h_PolicyId'];		
		$h_ACalendarStatus = $_REQUEST['h_ACalendarStatus'];		
		$LoginUserId = $_SESSION['user_id']; 		// $_SESSION["LogUserId"];
		$SiteId = $_SESSION['user-siteid'];
	
	
		$insArr['NAME']=$PolicyProfile;
		$insArr['DESCRIPTION']=$Description;		
		$insArr['ACTIVE_FLAG']=$Active;
	//	$insArr['ADDINUSE_FLAG']=$AddInUse;
		
		$insArr['LAST_UPDATED_BY']=$LoginUserId;
		$insArr['SITE_ID']=$SiteId;
		if($h_PolicyId!='')
		{
			$get_tblPolicyHeaderId = $h_PolicyId;
			//updatedata("cxs_policy_header",$insArr,"where POLICY_ID = $h_PolicyId");			
		}
		else
		{	
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;
			insertdata("cxs_policy_header",$insArr);						
			$get_tblPolicyHeaderId=mysql_insert_id();						
			//$insArr
		}
		if($DetailTable=='cxs_policy_general')
		{
			$Check_ExcessHours =$_REQUEST['Check_ExcessHour_TEarn'];
			$Check_HolidayEarn =$_REQUEST['Check_HolidayEarnCredit_TEarn'];
			$Check_EnableShift =$_REQUEST['Check_EnableShift_TEarn'];
			$Check_Overtime =$_REQUEST['Check_OverTime_TEarn'];
			$Check_CTOOvertime =$_REQUEST['Check_CTO_TEarn'];
			
			//mysql_query("delete from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId");
			$Updatable_Rows = explode(",",$_REQUEST['Update_Rows']);
			$currentRow = 1;
		//	$Update_Rows = $_REQUEST['Update_Rows'];	
			$i=0;
			foreach($_REQUEST['Text_AliasId'] as $Text_AliasId)
			{ 
				//$AliasId = $_REQUEST['h_AliasId'][$i];				
				if( $Text_AliasId !='')
				{
					$insArr1['POLICY_ID']=$get_tblPolicyHeaderId;
					//$insArr1['HOLIDAY_CALENDAR_ID']=$HolidayCalendar;
					//$insArr1['CALENDAR_ID']=$AccountingCalendar;
					$insArr1['WORKSHIFT_ID']=$Workshift;
					
					$insArr1['LAST_UPDATED_BY']=$LoginUserId;	
					$insArr1['EXCESS_HOURS_ALLOWED']=($Check_ExcessHours==1)?"Y":"N";
					$insArr1['HOLIDAY_EARN_CREDIT']=($Check_HolidayEarn==1)?"Y":"N";
					$insArr1['CTO_OVERTIME']=($Check_CTOOvertime==1)?"Y":"N";					
					$insArr1['OVERTIME_ALLOWED']=($Check_Overtime==1)?"Y":"N";
					
					$qry = "Select * from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $currentRow";
					$result = mysql_query($qry);
					$norows=mysql_num_rows($result);
					if($norows>0 )
					{
						updatedata($DetailTable,$insArr1,"where POLICY_ID = $get_tblPolicyHeaderId");
						
						if(in_array($currentRow,$Updatable_Rows))
						{
							$insArr1['ALIAS_ID']=$Text_AliasId;
							updatedata($DetailTable,$insArr1,"where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $currentRow");
						}						
					}	
					else
					{
						$insArr1['ALIAS_ID']=$Text_AliasId;
						
						$insArr1['CREATION_DATE']='now()';
						$insArr1['CREATED_BY']=$LoginUserId;					
						$insArr1['ROW_NO']=$currentRow;//($i+1);
						insertdata($DetailTable,$insArr1);		
					}	
					
					$qry1 = "update cxs_aliases set ADDINUSE_FLAG = 'Y' where ALIAS_ID = $Text_AliasId and ADDINUSE_FLAG <> 'Y'";
					mysql_query($qry1);
					
				}
				//$i++;
				$currentRow++;
			}
			/*
			if($h_ACalendarStatus=="")
			{
				$qry = "select * from cxs_periods where CALENDAR_ID = $AccountingCalendar ";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$PeriodId = $row['PERIOD_ID'];
					$qry = "Update cxs_periods set cxs_periods.FLAG_INUSE = 'Y' where cxs_periods.STATUS='Open' and PERIOD_ID = '$PeriodId' and FLAG_INUSE = 'N' ";
					mysql_query($qry);					
				}
			}*/
			
		}
		else if($DetailTable=='cxs_policy_time_off')
		{
			//mysql_query("delete from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId");
			$i=0;
			$rowno =1;
			foreach($_REQUEST['Text_AliasIdTOff'] as $Text_AliasIdTOff)
			{	//echo "id ".$Text_AliasIdTOff;
				//$AliasId = $_REQUEST['h_AliasId'][$i];				
				if( $Text_AliasIdTOff !='')
				{
					//$_REQUEST['Combo_PayPeriodTOff'][$i];
					$insArr1['POLICY_ID']=$get_tblPolicyHeaderId;					
					$insArr1['ALIAS_ID']=$Text_AliasIdTOff;
					$insArr1['WORKSHIFT_ID']=$_REQUEST['h_TimeOffWorkshiftId'][$i];
					$insArr1['MAXIMUM_HOURS_ALLOWED']=$_REQUEST['Text_HoursTOff'][$i];
					//$insArr1['PERIOD_ID']=$_REQUEST['Combo_PayPeriodTOff'][$i]; hide from design so here too
					$insArr1['LAST_UPDATED_BY']=$LoginUserId;
					$insArr1['ROW_NO']=$rowno;
					
					$qry = "select * from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno";	
					$result = mysql_query($qry);
					$num = mysql_num_rows($result);
					if($num > 0)
					{
						//echo mysql_num_rows($result);
						updatedata($DetailTable,$insArr1,"where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno");	
					}
					else
					{
						$insArr1['CREATED_BY']=$LoginUserId;
						$insArr1['CREATION_DATE']= 'now()'; //date('Y-m-d H:i:s') ;
						insertdata($DetailTable,$insArr1);						
					}
					$qry1 = "update cxs_aliases set ADDINUSE_FLAG = 'Y' where ALIAS_ID = $Text_AliasIdTOff and ADDINUSE_FLAG <> 'Y'";
					mysql_query($qry1);
				}
				$i++; 
				$rowno++;
			}
		}
		
		else if($DetailTable=='cxs_policy_time_earned')
		{
			//$qry = "delete from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId";			;
			//mysql_query($qry);
			$i=0;$rowno =1;
			$Check_ExcessHours =$_REQUEST['Check_ExcessHour_TEarn'];
			$Check_HolidayEarn =$_REQUEST['Check_HolidayEarnCredit_TEarn'];
			$Check_EnableShift =$_REQUEST['Check_EnableShift_TEarn'];
			$Check_Overtime =$_REQUEST['Check_OverTime_TEarn'];
			$Check_CTOOvertime =$_REQUEST['Check_CTO_TEarn']; 
				
			foreach($_REQUEST['Combo_EarnTypeTEarn'] as $Combo_EarnTypeTEarn)
			{	
				if( $Combo_EarnTypeTEarn !='' && $_REQUEST['Combo_PayPeriodTEarn'][$i] !='')
				{
					$insArr1['POLICY_ID']=$get_tblPolicyHeaderId;					
					$insArr1['EXCESS_HOURS_ALLOWED']=($Check_ExcessHours==1)?"Y":"N";
					$insArr1['HOLIDAY_EARN_CREDIT']=($Check_HolidayEarn==1)?"Y":"N";
					$insArr1['SHIFT_DIFFERENTIAL']=($Check_EnableShift==1)?"Y":"N";
					$insArr1['OVERTIME_ALLOWED']=($Check_Overtime==1)?"Y":"N";
					
					$insArr1['REQUIRED_HOURS']=$_REQUEST['h_RHours_TE'];		
					$insArr1['WORKSHIFT_ID']=$_REQUEST['h_TimeEarnWorkshiftId'][$i];					
					$insArr1['PERIOD_ID']=$_REQUEST['Combo_PayPeriodTEarn'][$i];				
					$insArr1['EARN_TYPE']=$_REQUEST['Combo_EarnTypeTEarn'][$i];
					$insArr1['CTO_OVERTIME']=($Check_CTOOvertime==1)?"Y":"N";					
					$insArr1['LAST_UPDATED_BY']=$LoginUserId;
					$insArr1['ROW_NO']=$rowno;
					
					$qry = "select * from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno";	
					$result = mysql_query($qry);
					$num = mysql_num_rows($result);
					if($num > 0)
					{
						//echo mysql_num_rows($result);
						updatedata($DetailTable,$insArr1,"where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno");	
					}
					else
					{
						$insArr1['CREATION_DATE']='now()' ;
						$insArr1['CREATED_BY']=$LoginUserId;
						insertdata($DetailTable,$insArr1);	
					}					
				}
				$i++;
				$rowno++;
			}
		}
		
		else if($DetailTable=='cxs_hours_deduction')
		{
			//mysql_query("delete from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId");
			$i=0;$rowno=1;
			$Check_PaidBreak = $_REQUEST['Check_PaidBreak_HDeduct'];
			foreach($_REQUEST['Text_BreakHours_HDeduct'] as $Text_BreakHours_HDeduct)
			{
				if( trim($Text_BreakHours_HDeduct) !=0)
				{
					$insArr1['POLICY_ID']=$get_tblPolicyHeaderId;					
					$insArr1['ALLOW_PAID_BREAK']=($Check_PaidBreak==1)?"Y":"N";					
					$insArr1['WORKSHIFT_ID']=$_REQUEST['h_HDeductWorkshiftId'][$i];					
				//	$insArr1['PERIOD_ID']=$_REQUEST['Combo_PayPeriodTEarn'][$i];
					$insArr1['BREAK_HOURS']=$Text_BreakHours_HDeduct;
					$insArr1['BREAK_START_TIME']=$_REQUEST['Text_BreakStartHours_HDeduct'][$i];
					$insArr1['BREAK_END_TIME']=$_REQUEST['Text_BreakEndHours_HDeduct'][$i];					
					$insArr1['LAST_UPDATED_BY']=$LoginUserId;
					$insArr1['ROW_NO']=$rowno;
					$insArr1['REQUIRED_HOURS']=$_REQUEST['h_RHours_HD'];
					
					$qry = "select * from $DetailTable where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno";	
					$result = mysql_query($qry);
					$num = mysql_num_rows($result);
					if($num > 0)
					{
						updatedata($DetailTable,$insArr1,"where POLICY_ID = $get_tblPolicyHeaderId and ROW_NO = $rowno");	
					}
					else
					{
						$insArr1['CREATION_DATE']='now()' ;
						$insArr1['CREATED_BY']=$LoginUserId;
						insertdata($DetailTable,$insArr1);	
					}
				}
				$i++;
				$rowno++;
			}
			
		}
		//echo $get_tblPolicyHeaderId;		
		$data['getPolicyHeaderId'] = $get_tblPolicyHeaderId;
			
		echo json_encode($data);
	}
?>