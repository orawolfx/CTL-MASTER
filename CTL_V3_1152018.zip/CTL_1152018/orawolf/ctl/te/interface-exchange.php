<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> -->
<?php include('sitename.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- <title>Coexsys | Time Accounting</title> -->
    <title>Coexsys | <?php echo strtoupper($SiteName); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	
	<script src="../datepicker/jquery.js"></script>
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />
	<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet"> 
	<style type="text/css">
		.requirefieldcls
		{
			background-color: #fff99c;
		}
		.btn-bx2
		{
			background: #e9e9e9;
			border-style:none;
		}
		.form-control,.my-span-style 
		{
			padding: 6px 6px;
			font-weight: bold;			
		}
		.my-span-style
		{
			font-size:14px;
		}
		.btn1 
		{    
			padding: 6px 6px;
		}	
		.input-sm
		{
		   border: 1px solid #333;
		   border-radius: 4px;
		   background: rgba( 255, 255, 255, .05);
		}
		.my-link{ font-weight: bold;}
		.alert-success { color: #e61d16; }
		.option_color { color: #000; font-size: 12px;	}
		@media (max-width: 800px) 
		{
			.showOnMobile
			{
				 white-space: pre;
			}
		}
		.custome-btn{font-size: 16px;
				font-weight: normal;
				padding: 2px 10px;
				border-color: #000;
				border: none;
				color: #000;
				background-color:grey;
				display: inline-block
				margin-bottom: 0;
				line-height: 1.42857143;
				text-align: center;
				white-space: nowrap;
				vertical-align: middle;
				touch-action: manipulation;
				cursor: pointer;
				border-radius: 2px;
		}
		.cmd-ok-btn{
			font-size: 14px;
			font-weight: normal;
			padding: 5px 5px;
			border-color: #3b763b;
			border: none;
			color: #fff;
			background-color: #337ab7; 
		}
		.popup-body {
		width: 402px;
		position: relative;
        }		
		.custom-modal .verysmall-popup-body {
			width: 402px;
			position: relative;
		}
		.custom-modal .verysmall-popup {
			width: 400px;
			position: relative;
		}	
		.custom-modal .modal-footer {
			background: #fff;
			padding-right: 40px;
			border-radius: 0 0 8px 8px;
		}		
	</style>
</head>

<body>

<!--Search modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Time Keeping </h4>
				</div>
				<div class="modal-body"> 
				<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
						  <!-- find block start-->
							<div class="pr" >
								<div class="cus-form-cont" >
									
									
									
									<div class="col-sm-3 form-group">
										<div class="checkbox ">
											<label><input type="checkbox" id = "Check_CurrentPayPeriod" checked  >Current Pay Period </label>
										</div>
									</div>
									 
								</div>
							</div>
                    <!--find -block end -->
				
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
					<button type="button" id="cmdFindResourcePopup" name="cmdFindResourcePopup" class="btn btn-primary btn-style" >Find</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Search Modal  -->
	
	
	<!--STD634 Model Start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "STD634Model" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg popup-body" role="document">
			<div class="modal-content verysmall-popup-body">
				<div class="modal-header verysmall-popup">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<!--<h4 class="modal-title " id="myModalLabel">Copy Time Sheet </h4>-->
				</div>
				<div class="modal-body" style="padding:0px;"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
							<div class="col-sm-4 form-group" style="margin-top:27px">
								<label>Pay Period </label>										
							</div>						
							<div class="col-sm-8 form-group" id = "div_PayPeriod">										
									
								<select class="form-control" id =  "Combo_PayPeriod" name =  "Combo_PayPeriod" >
								  <option value=""> - Select - </option>
								  <?php 								  
								  for($y=2018;$y<=2019;$y++)
								  {
									  for($m=1;$m<=12;$m++)
									  {
										  if(strlen($m)<2){$m="0".$m;}
										  $date =$y."-".$m;
										  echo "<option value='$date'>".date('M-Y',strtotime($date))."</option>";
									  }
								  }
								  ?>	
								</select>
															
							</div>
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user" style="padding:5px 30px;">
					<button type="submit" id="cmdSTD634Save" name="cmdSTD634Save" class="btn cmd-ok-btn" >&nbsp;OK&nbsp;</button>
				</div>
			</div>
		</div>
	</div>
	<!--STD634 Model End -->
	
<!--Human Resource Model Start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "HumanResourceModel" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg popup-body" role="document">
			<div class="modal-content verysmall-popup-body">
				<div class="modal-header verysmall-popup">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<!--<h4 class="modal-title " id="myModalLabel">Copy Time Sheet </h4>-->
				</div>
				<div class="modal-body" style="padding:0px;"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
							<div class="col-sm-8 form-group" style="float:left; margin-left:25%">										
								<input type="checkbox" name="ActiveEmployeeOnly" id="ActiveEmployeeOnly" value="ActiveEmployeeOnly" />&nbsp;&nbsp;Active Employee Only<br />	
								<input type="checkbox" name="IncludePositionHierarchy" id="IncludePositionHierarchy" value="IncludePositionHierarchy" />&nbsp;&nbsp;Include Position Hierarchy<br />
								<input type="checkbox" name="IncludeCBIDInformation" id="IncludeCBIDInformation" value="IncludeCBIDInformation" />&nbsp;&nbsp;Include CBID Information<br />
							</div>
							<!--find -block end -->
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer modal-footer cr-user" style="padding:5px 30px;">
					<button type="submit" id="cmdHumanResourceSave" name="cmdHumanResourceSave" class="btn cmd-ok-btn">&nbsp;OK&nbsp;</button>
				</div>
			</div>
		</div>
	</div>
	<!--Human Resource Model End -->
     <!--Project Model Start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ProjectModel" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg popup-body" role="document">
			<div class="modal-content verysmall-popup-body">
				<div class="modal-header verysmall-popup">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<!--<h4 class="modal-title " id="myModalLabel">Copy Time Sheet </h4>-->
				</div>
				<div class="modal-body" style="padding:0px;"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
							<!-- find block start-->
							<div class="pr">
								<div class="cus-form-cont">                            
									<div class="col-sm-4 form-group" style="margin-top:27px">
										<label>Project</label>										
									</div>
                            
									<div class="col-sm-8 form-group">																					
										<select class="form-control" id =  "Combo_PayPeriod" name =  "Combo_PayPeriod" >
										  <option value=""> - Project DropDown - </option>
										  <option value="1"> Option 1</option>									  
										  <option value="2"> Option 2</option>									  
										  <option value="3"> Option 3</option>				 					  
										</select>												
									</div>
								</div>
							</div>
							<!--find -block end -->
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer modal-footer cr-user" style="padding:5px 30px;">
					<button type="submit" id="cmdProjectSave" name="cmdProjectSave" class="btn cmd-ok-btn" >&nbsp;OK&nbsp;</button>
				</div>
			</div>
		</div>
	</div>
	<!--Project Model End -->
    <!--Labor Extract Model Start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "LaborExtractModel" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg popup-body" role="document">
			<div class="modal-content verysmall-popup-body">
				<div class="modal-header verysmall-popup">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<!--<h4 class="modal-title " id="myModalLabel">Copy Time Sheet </h4>-->
				</div>
				<div class="modal-body" style="padding:0px;"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">                            
							<div class="col-sm-4 form-group" style="margin:10px 0px 0px 0px;padding:0px;">
								<label>Start Date</label>										
							</div>
							<div class="col-sm-7 form-group cus-form-ico" style="margin:5px 0px 5px 0px;padding:0px;">																					
							<input type="text" class="form-control form_datetime" id = "Text_StartDate" name = "Text_StartDate"  maxlength="20"/>																									
							<span class="inp-icons"><i class="fa fa-calendar"></i></span>
							</div>
						</div>
						<div class="cus-form-cont">                            
							<div class="col-sm-4 form-group" style="margin:10px 0px 0px 0px;padding:0px;">
								<label>End Date</label>										
							</div>
							<div class="col-sm-7 form-group cus-form-ico" style="margin:5px 0px 5px 0px;padding:0px;">																					
							<input type="text" class="form-control form_datetime" id = "Text_EndDate" name = "Text_EndDate"  maxlength="20"/>																									
							<span class="inp-icons"><i class="fa fa-calendar"></i></span>
							</div>
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer modal-footer cr-user" style="padding:5px 30px;">
					<button type="submit" id="cmdProjectLaborExtractSave" name="cmdProjectLaborExtractSave" class="btn cmd-ok-btn" >&nbsp;OK&nbsp;</button>
				</div>
			</div>
		</div>
	</div>
	<!--Labor Extract Model End -->
	

	
	
	<?php //include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <!-- brd crum-->
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#"> Time Accounting </a></li>
                        <li> <a href="#"> Time Entry </a></li>
                    </ul>
                </div>
                <!-- Dash board -->
                <div class="dash-strip">
                    <div class="fleft cr-user"> <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> </div>
					<div class="fright">				         
					<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = ""> <i class="fa fa-star"></i></button>
					<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" <?php if ($IsSearchTimeSheets=="Y"){ ?> data-toggle="modal" data-target="#FindPopup" <?php }else{ echo "disabled:disabled";} ?> > <i class="fa fa-search" aria-hidden="true"></i> Time Keeping </button>
					<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2"  ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>					
					</div>
                </div>
                <!-- inner work-->
									
                <div class="cont-box"> 
					<form id = "form1" method="post">
                    <!-- Heading start-->
						<div class="col-md-12 renderClass">
							<div class="row">
								<div class="col-sm-8 cr-user" style="margin-left:-15px"> <h4>STD 634 Interfaces</h4></div>
								<div class="col-sm-4"></div> 
							</div>
						</div>					
                    <!-- Heading end-->
                    
						
						
                    <!-- table -->
						
						<div class="row">
							<div class="col-md-8">							
								<div class="data-bx">
									<div class="table-responsive " id = "">	
										<table class="table table-bordered mar-cont table-freeze-multi" data-scroll-height="300" data-cols-number="2">
											<thead>
												<tr>
													<th width="55%">Interface Process</th>													
													<th width="20%" style="text-align: center;">Parameters</th>													
													<th width="22%" style="text-align: center;">Select</th>													
												</tr>
												
											</thead>											
												<tbody id="">
												
												<tr class = "">
													<td><label>Shift Differential</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdInterface1" id="CmdInterface1" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" name="stdchk1" class = "" id="" value=""></td>
												</tr>
												<tr class = "fetchData">
													<td><label>Leave Balances</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdInterface2" id="CmdInterface2" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" name="stdchk1" class = "GridCheckBox" id="" value=""></td>
												</tr>	
												 
												<tr class = "fetchData">
													<td><label>Leave Interface</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdInterface3" id="CmdInterface3" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" name="stdchk1" class = "GridCheckBox" id="" value=""></td>
												</tr>
												
												<tr class = "fetchData">
													<td><label>Positive Pay</label></td>
													<td align="center"><input type="button" name="stdchk1" class="custome-btn" name="CmdInterface4" id="CmdInterface4" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" class = "GridCheckBox" id="" value=""></td>
												</tr>
												
												<tr class = "fetchData">
													<td><label>Overtime</label></td>
													<td align="center"><input type="button" name="stdchk1" class="custome-btn" name="CmdInterface5" id="CmdInterface5" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" class = "GridCheckBox" id="" value=""></td>
												</tr>
													
													
											</tbody>
										</table>
									</div>
									
								</div>
								
								<div class="fright cr-user z-10">
									<button type="button" class="custome-btn" name = "cmdSTDRunSelected"  id = "cmdSTDRunSelected" onClick = "valstdform();" style="padding:2px 30px">Run Selected </button>
									<button type="button" class="custome-btn" name = "CmdSTDDownloadSelected" id = "CmdSTDDownloadSelected">Download Selected</button>
								</div>
							</div>		
						</div>
					    <!-- Heading start-->
						<div class="col-md-12 renderClass">
							<div class="row">
								<div class="col-sm-8 cr-user" style="margin-left:-15px"> <h4>Human Resource</h4></div>
								<div class="col-sm-4"></div> 
							</div>
						</div>					
                       <!-- Heading end-->
                        <div class="row">
							<div class="col-md-8">							
								<div class="data-bx">
									<div class="table-responsive " id = "">	
										<table class="table table-bordered mar-cont table-freeze-multi" data-scroll-height="300" data-cols-number="2">
											<thead>
												<tr>
													<th width="55%">Interface Process</th>													
													<th width="20%" style="text-align: center;">Parameters</th>													
													<th width="22%" style="text-align: center;">Select</th>													
												</tr>
												
											</thead>											
												<tbody>												
												<tr>
													<td><label>Employee Information Extract</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdEmpInfo" id="CmdEmpInfo" value="...." style="width:40px" /></td>
													<td class="check-bx"><input type="checkbox" name="Humanchk1" class = "" id="Humanchk1" value=""></td>
												</tr>
											</tbody>
										</table>
									</div>
									
								</div>
								
								<div class="fright cr-user z-10">
									<button type="button" class="custome-btn" name = "cmdHumanRunSelected"  id = "cmdHumanRunSelected" style="padding:2px 30px">Run Selected </button>
									<button type="button" class="custome-btn" name = "CmdHumanDownloadSelected" id = "CmdHumanDownloadSelected">Download Selected</button>
								</div>
							</div>		
						</div>						
					<!-- end table -->
						
						
					<!-- Heading start-->
						<div class="col-md-12 renderClass">
							<div class="row">
								<div class="col-sm-8 cr-user" style="margin-left:-15px"> <h4>Projects</h4></div>
								<div class="col-sm-4"></div> 
							</div>
						</div>					
                       <!-- Heading end-->
                        <div class="row">
							<div class="col-md-8">							
								<div class="data-bx">
									<div class="table-responsive " id = "">	
										<table class="table table-bordered mar-cont table-freeze-multi" data-scroll-height="300" data-cols-number="2">
											<thead>
												<tr>
													<th width="55%">Interface Process</th>													
													<th width="20%" style="text-align: center;">Parameters</th>													
													<th width="22%" style="text-align: center;">Select</th>													
												</tr>
												
											</thead>											
												<tbody>
												
												<tr>
													<td><label>Project WBS Import</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdProjectImport" id="CmdProjectImport" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" class = "" id="" value=""></td>
												</tr>
												<tr>
													<td><label>Labor Distribution Extract</label></td>
													<td align="center"><input type="button" class="custome-btn" name="CmdLabor" id="CmdLabor" value="...." style="width:40px" /></td>
													<td class="check-bx "><input type="checkbox" class = "" id="" value=""></td>
												</tr>
												</tbody>
										</table>
									</div>
									
								</div>
								
								<div class="fright cr-user z-10">
									<button type="button" class="custome-btn" name = "cmdRunSelected"  id = "cmdRunSelected" style="padding:2px 30px">Run Selected </button>
									<button type="button" class="custome-btn" name = "CmdDownloadSelected" id = "CmdDownloadSelected">Download Selected</button>
								</div>
							</div>		
						</div>						
					<!-- end table -->	
						
						
						
					</form>
					
				</div>
			</div>
        </div>		
    </section>
	<script type="text/javascript">
	$('.form_datetime').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});		
		
	$('#cmdProjectLaborExtractSave').click(function()
	{	
		$("#LaborExtractModel").modal('hide');
	});
	
	$('#cmdProjectSave').click(function()
	{	
		$("#ProjectModel").modal('hide');
	});
	
	$('#cmdHumanResourceSave').click(function()
	{	
		$("#HumanResourceModel").modal('hide');
	});
	
	$('#cmdSTD634Save').click(function()
	{	
		$("#STD634Model").modal('hide');
	});
	
	$('#CmdInterface1').click(function()
	{	
		$("#STD634Model").modal('show');
	});
	$('#CmdInterface2').click(function()
	{	
		$("#STD634Model").modal('show');
	});
	$('#CmdInterface3').click(function()
	{	
		$("#STD634Model").modal('show');
	});
	$('#CmdInterface4').click(function()
	{	
		$("#STD634Model").modal('show');
	});
	$('#CmdInterface5').click(function()
	{	
		$("#STD634Model").modal('show');
	});
	$('#CmdEmpInfo').click(function()
	{	
		$("#HumanResourceModel").modal('show');
	});
	$('#CmdProjectImport').click(function()
	{	
		$("#ProjectModel").modal('show');
	});
	$('#CmdLabor').click(function()
	{	
		$("#LaborExtractModel").modal('show');
	});
	
	
	</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/dataTables.bootstrap.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
	<script src="../js/jsfunctions.js" type="text/javascript"></script>
	<script src="../livesearch/bootstrap-select.min.js"></script>	
	<!--SAVE Time Sheet modals start -->
	<script type="text/javascript">
	function valstdform()
	{
		var checkboxs=document.getElementsByName("stdchk1");
		var okay=false;
		for(var i=0,l=checkboxs.length;i<l;i++)
		{
			if(checkboxs[i].checked)
			{
				okay=true;
				break;
			}
		}
		if(okay==true)
		{			
			$("#cmdSTDRunSelected").css("background-color","#D3D3D3");
			document.getElementById("cmdSTDRunSelected").disabled = true;
			
		}
		else
		{
			alert("Please Check one of the checkbox");	
		}		
	}
	
	$("#cmdHumanRunSelected").click(function(){		
		
		
	});
	
	</script>
	
</body>

</html>