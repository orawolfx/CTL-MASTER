<?php ob_start (); 
	 
	include("te-functions.php");
	include("sitename.php");
	check_login();
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_TimeEntry_PERMISSION = "Y";
		$UPDATE_PRIV_TimeEntry_PERMISSION = "Y";
		$VIEW_PRIV_TimeEntry_PERMISSION = "Y";
		$ENABLE_AUDIT_TimeEntry_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Entry',$_SESSION['user_id']);
		$UPDATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Entry',$_SESSION['user_id']);
		$VIEW_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Time Entry',$_SESSION['user_id']);
		$ENABLE_AUDIT_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Time Entry',$_SESSION['user_id']);
	}	
	if($VIEW_PRIV_TimeEntry_PERMISSION!='Y')
	{
	   header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];	
	$PageName = "time-entry.php";
	$SiteId = $_SESSION['user-siteid'];		
	
	/*function last_sunday($date) 
	{
		if (!is_numeric($date))
		{
			$date = strtotime($date);
		}
		if (date('w', $date) == 1)
		{
			return $date;
		}	
		elseif (date('w', $date) == 0)
		{
			return strtotime('next sunday',$date);
		}
		else
		{
			return strtotime('last sunday',$date);
		}
	}*/
	$i=0;
	//$qry = "Select PERIOD_ID,PERIOD_NAME from cxs_periods where STATUS != 'Never Opened' order by PERIOD_NAME";
	$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_periods.status = 'Open' order by cxs_calendars.NAME, cxs_periods.PERIOD_ID desc ";
								
	$result = mysql_query($qry);
	while($row = mysql_fetch_array($result))
	{
		$PayPeriodArray[$i]['PERIOD_ID']=$row['PERIOD_ID'];
		$PayPeriodArray[$i]['PERIOD_NAME']=$row['PERIOD_NAME'];
		$i=$i+1;
	}
	$PayPeriodList .= "<option class = 'option_color' value=''>- Pay Period -</option>";
	if(sizeof($PayPeriodArray)>0)
	{
		foreach ( $PayPeriodArray as $var ) 
		{
			$tempPeriodID = $var['PERIOD_ID'];
			$tempPeriodName = $var['PERIOD_NAME'];
			$PayPeriodList .="<option class = 'option_color'  value = '$tempPeriodID'> $tempPeriodName </option>";	
		}
	}
	$insArr = array();
	$HeaderId = "";
	
	if (isset($_GET["pid"]))
	{
		$GetPeriodId = $_GET["pid"];	
	}
?>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> -->
<script type="text/javascript" >
	var SelectedRows; 
	var ShiftHours = 0;	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Time Entry";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function CheckCopyValue()
	{	
		if (document.getElementById("Check_CopyAllowed").checked)			
		{
			document.getElementById("div_PreviosTimeSheet").style.display = "block"		;
		}
		else
		{		
			document.getElementById("div_PreviosTimeSheet").style.display = "none"		;
		}
	}
	function allowNegPosNumber(e) 
	{
		var charCode = (e.which) ? e.which : event.keyCode
		if (charCode > 31 && (charCode < 45 || charCode > 57 )) 
		{
			return false;
		}
		return true;					
	}	
	function EnteredValue(currentRow,CurrentSpan,CurrentElement)
	{	 
		var n= CurrentElement.value;
		var n1= CurrentElement.id;
		if (document.getElementById("Text_Task"+currentRow).value == "" && n!="")
		{
			alert("First Select Task.");
			document.getElementById(CurrentElement.id).value = "";
			document.getElementById("Text_Task"+currentRow).focus();
		}
		/*$.ajax({
			url:"ajax_time-entry.php" , 
			method:"POST",
			data:{REQUEST:"IsAllowNegative",PolicyId:$("#CurrentTimePolicyId").val()},
			success:function(response)
			{
				if (response.trim()="N")
				{
					AllowNegativeValue(n1);
				}
			}
		});*/
	}
	
	function TotalHours(currentElement) 
	{
		var TotalHoursHorizontal=0;
		var TotalHoursVertical=0;
		var CurrentHours=0;
		var TotalDaysCols=0;	 	
		var TotalTaskRows=document.getElementById("DetailTable").rows.length;
		
		if(currentElement!= undefined )
		{
			var n= currentElement.value;
			if(n>24)
			{
				alert("Hours must be less or equal to 24");
				$("#"+currentElement.id).focus();
				$("#"+currentElement.id).val('24');						
				$("#"+currentElement.id).focus();
				TotalHours();
				//return false;
			}
		}	
		TotalTaskRows=TotalTaskRows-2;//remove header and footer row from counting
		/*if ($('#Check_Weekends').length)	
		{
			if (document.getElementById("Check_Weekends").checked )	
			{
				TotalDaysCols =7;
			}	
			else
			{
				//TotalDaysCols =5;
				TotalDaysCols =7;
			}
		}
		else
		{
			TotalDaysCols =7;
		}*/
		
		TotalDaysCols =7;
		var Total =0;
		for(i=1;i<=TotalTaskRows;i++)
		{
			TotalHoursHorizontal=0;			
			for(j=1;j<=TotalDaysCols;j++)   
			{
				CurrentHours = 0;
				if($('#Text_Hours'+i+"_"+j).length)
				{
					num = $('#Text_Hours'+i+"_"+j).val();					
					if (num!='')
					{
						$('#Text_Hours'+i+"_"+j).val(timeConvert(num)) ;
					}
					if($('#row'+i).is(':visible')) 
					{
						if($('#Hours'+i+'_'+j).is(':visible'))
						{
							CurrentHours = document.getElementById("Text_Hours"+i+"_"+j).value;
							//CurrentHours = $("#Text_Hours"+i+"_"+j).attr('value');
						}
					}
					else
					{
						CurrentHours = 0;
					}						
				}
				if (CurrentHours!='')
				{
					CurrentHours = parseFloat(CurrentHours);
				}
				else
				{
					CurrentHours = 0;
				}
				TotalHoursHorizontal = TotalHoursHorizontal+CurrentHours;			
			}
			
			document.getElementById("Text_LineTotalHours"+i).value = TotalHoursHorizontal;			
						
		}	
		
		for(i=1;i<=TotalDaysCols;i++)
		{
			TotalHoursVertical=0;			
			for(j=1;j<=TotalTaskRows;j++)
			{	
				CurrentHours = document.getElementById("Text_Hours"+j+"_"+i).value;				
				if (CurrentHours!='')
				{
					if($('#row'+j).is(':visible'))
					{
						if($('#Hours'+j+'_'+i).is(':visible'))
						{
							CurrentHours = parseFloat(CurrentHours);
						}
						else
						{
							CurrentHours = 0;
						}
					}
					else
					{
						CurrentHours = 0;
					}
				}
				else
				{
					CurrentHours = 0;
				}
				if (CurrentHours!='')
				{
					CurrentHours = parseFloat(CurrentHours);
				}
				TotalHoursVertical = TotalHoursVertical+CurrentHours;			
			}			
			document.getElementById("Text_TotalTaskHours"+i).value = TotalHoursVertical;
			Total = Total+TotalHoursVertical;
		}
		document.getElementById("Text_TotalFinal").value = Total;		
			
	}
	
	function CheckWeekDays()
	{
		if (document.getElementById("Check_Weekends").checked )	
		{
			<?php  $TotalWeekDaysActual = 7; ?>
			TableElementsVisibility(true);

			
		}
		else
		{
			<?php  $TotalWeekDaysActual = 5; ?>
			TableElementsVisibility(false);

		}
	}
	function TableElementsVisibility(jFlag)
	{	
		
		var displauvalues = $('.displayclass');

		var TableRow = document.getElementById("DetailTable").rows.length;
		
		var val1="none";
		if (jFlag==true)
		{
			for(i=5; i<=displauvalues.length; i++) {

			$(displauvalues[i]).css('display','');	
			}


//		$('.displayclass').css('display','block');			
			val1="table-cell";
		}
		else if (jFlag==false){
			for(i=5; i<=displauvalues.length; i++) {

			$(displauvalues[i]).css('display','none');	
			}
		}				
		
		for(j=6;j<=7;j++)
		{
			document.getElementById("TopHeading"+j).style.display = val1;
			document.getElementById("HoursHeading"+j).style.display = val1;
			document.getElementById("StatusHeading"+j).style.display = val1;
			document.getElementById("NotesHeading"+j).style.display = val1;				
			document.getElementById("TotalTaskHours"+j).style.display = val1;
			document.getElementById("TotalTaskStatus"+j).style.display = val1;
			document.getElementById("TotalTaskNotes"+j).style.display = val1;				
			document.getElementById("SubmitForApproval"+j).style.display = val1;				
		}
		for(var i=1;i<=TableRow-2;i++)
		{
			$("#row"+i).show();
			for(j=6;j<=7;j++)
			{
				document.getElementById("Hours"+i+"_"+j).style.display = val1;
				document.getElementById("Status"+i+"_"+j).style.display = val1;
				document.getElementById("Notes"+i+"_"+j).style.display = val1;	
				if (jFlag==false)
				{
					document.getElementById("Text_Hours"+i+"_"+j).value = "";	
					document.getElementById("Text_Status"+i+"_"+j).value = "";
					document.getElementById("Span_Hours"+i+"_"+j).innerHTML = "";	
					document.getElementById("span_Status"+i+"_"+j).innerHTML = "";														
				}	
			}
		}
		
		$(".week-end-cls").each(function()
		{

			$(this).hide();				
		});
		
		if (jFlag==true)
		{
			$(".week-end-cls").each(function()
			{

				$(this).show();	

			});
		}		
		//document.getElementById("weekly").style.display = "block";
		
		TotalHours();
	}
	function SearchPopUp(CurrentRow)
	{	
		document.getElementById("Text_FindAliasName").value = "";
		document.getElementById("TablePopupHeading").style.display = "none";
		document.getElementById("cmdAliasAddItem").style.visibility = "hidden";
		document.getElementById("TablePopupList").innerHTML = "";
		document.getElementById("span_msg").innerHTML = "";
		$("#CurrentParentRowNo").val(CurrentRow);
		$('#Text_FindAliasName').focus();
		$('#ModalFindAlias').modal();			
	}
	function TaskDescriptionPopUp(currentRow)
	{
		var s1 = document.getElementById("h_Taskid"+currentRow).value;		
		s1 = s1.trim();
		if (s1!='')
		{
			KEY = "Show-WBSDescription";
			makeRequest("ajax-TE-TableRows.php","REQUEST=Show-WBSDescription&AliasId="+s1);
		}
	 
	}
	function FindAliasData()
	{	
		var s1 = document.getElementById("Text_FindAliasName").value;		
		var s2 = document.getElementById("Combo_FindAliasClass").value;							
		if((s1!='' && s2 != '') || (s1=='' && s2 == ''))
		{
			alert("Please Find Either Alias Name Or Alias Class");
			document.getElementById("Text_FindAliasName").focus();
			document.getElementById("TablePopupList").innerHTML="";
			return false;
		}
		$("#cmdFindAliasPopup").prop("disabled",true);
		KEY = "FindAliasData";
		makeRequest("ajax-finddata.php","REQUEST=FindDataTE-Aliases&AliasName="+s1+"&AliasClass="+s2+"&ResourceId="+$("#ResourceId").val());
	}
	function AddAliasRecord()
	{ 
		var Flag_IsSelect = false;
		var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
		var s1="",s2="",j;
		for(i=1;i<=POPUP_TABLE_ROW;i++)
		{
			if (document.getElementById("PopupCheckboxInline"+i).checked == true)
			{
				Flag_IsSelect = true;
				break;
			}
		}
		var DetailTableRows = document.getElementById("DetailTable").rows.length;
		/*if (Flag_IsSelect == true)
		{
			for(i=1;i<=POPUP_TABLE_ROW;i++)
			{
				if (Flag_IsSelect == true)
				{
					if (document.getElementById("PopupCheckboxInline"+i).checked == true)
					{
						s1 = document.getElementById("Span-AliasName"+i).innerHTML ;
						s1 = s1.trim();
						/*for(j=1;j<=DetailTableRows-2;j++)
						{
							s2 = document.getElementById("Text_Task"+j).value;
							s2 = s2.trim();
							if (s1==s2)
							{
								alert("Project / Task - " + s2 + " is already exist.");
								Flag_IsSelect = false;
								return false;
							}
						}*-/
					}
				}	
			}
		}*/
		if (Flag_IsSelect == false)
		{
			alert("Please Select Item For Add");
			document.getElementById("CheckboxPopup_SelectAll").focus();
			return false;
		}
		else
		{
			$("#cmdAliasAddItem").prop("disabled",true);
			
			KEY = "AddAliasRecord";
			s1="";
			var TotalWeekDays = 0,LastRowId=0;			
			LastRowId=DetailTableRows-2;
			SelectedRows = 0;
			for(i=1;i<=POPUP_TABLE_ROW;i++)
			{
				if (document.getElementById("PopupCheckboxInline"+i).checked == true)
				{
					s1 = s1 + document.getElementById("Span-AliasId"+i).innerHTML + "|";
					SelectedRows++;
				}
			}		
			TotalWeekDays =5;
			if ($('#Check_Weekends').length)	
			{
				if (document.getElementById("Check_Weekends").checked )	
				{
					TotalWeekDays =7;
				}	
			}
			var IsEdit="";
			if($("#CurrentParentRowNo").val()=="")
			{
				IsEdit= "N";
			}
			else
			{
				IsEdit= "Y";
			}
			if(IsEdit=="N")
			{
				row = document.getElementById('row'+LastRowId);
				row.parentNode.removeChild(row);						
				row = document.getElementById('row-WBSTotal1');
				row.parentNode.removeChild(row);
				row = document.getElementById('row-WBSTotal2');
				row.parentNode.removeChild(row);			
			}
			makeRequest("ajax-TE-TableRows.php","REQUEST=Add-AliasRows&AliasId="+s1+"&TotalWeekDays=" + TotalWeekDays+"&LastRowId=" + LastRowId+"&WorkshiftId="+$('#CurrentWorkshiftId').val()+"&TimePolicyId="+$('#CurrentTimePolicyId').val()+"&IsEdit="+IsEdit+"&StartDate="+$("#TopHeading1").text()+"&PayPeriodId="+$("#PayPeriodId").val());			
		}
	}
	
	function RefreshTableList()
	{//alert("refresh");
		document.getElementById("TablePopupList").innerHTML = "";
		if($("#CheckboxPopup_SelectAll").length)
		{
			document.getElementById("CheckboxPopup_SelectAll").checked = false;
		}
	}
	function SelectedValue(id,value)
{
	$("#"+id).val(value);
}
	
</script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- <title>Coexsys | Time Accounting</title> -->
    <title>Coexsys | <?php echo strtoupper($SiteName); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	
	<script src="../datepicker/jquery.js"></script>
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />
	<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet"> 
	<style type="text/css">
		.requirefieldcls
		{
			background-color: #fff99c;
		}
		.btn-bx2
		{
			background: #FAFAFA;
			border-style:none;
		}
		.form-control,.my-span-style 
		{
			padding: 6px 6px;
			font-weight: bold;			
		}
		.my-span-style
		{
			font-size:14px;
		}
		.btn1 
		{    
			padding: 6px 6px;
		}	
		.input-sm
		{
		   border: 1px solid #333;
		   border-radius: 4px;
		   background: rgba( 255, 255, 255, .05);
		}
		.my-link{ font-weight: bold;}
		.alert-success { color: #e61d16; }
		.option_color { color: #000; font-size: 12px;	}
		@media (max-width: 800px) 
		{
			.showOnMobile
			{
				 white-space: pre;
			}
		}	
	</style>
</head>

<body>

<!--Search modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Time Keeping </h4>
				</div>
				<div class="modal-body"> 
				<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
						  <!-- find block start-->
							<div class="pr" >
								<div class="cus-form-cont" >
									<div class="col-sm-6 form-group">
										<label> Resource Name </label>
										<?php 
											$ResourceList = "<option value = ''> - Resource Name - </option>";
											//echo$qry = "select distinct RESOURCE_ID,FIRST_NAME,LAST_NAME from cxs_resources order by FIRST_NAME,LAST_NAME ";
											$qry = "select cxs_resources.RESOURCE_ID,FIRST_NAME,LAST_NAME from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID order by FIRST_NAME,LAST_NAME ";
											$result = mysql_query($qry)		;
											while($row = mysql_fetch_array($result))
											{
												$ResourceId = $row['RESOURCE_ID'];
												$ResourceName = $row['FIRST_NAME']." ".$row['LAST_NAME'];
												$ResourceList .= "<option value = '$ResourceId'> $ResourceName </option>";
											}
										?>
										<!--<input type="text" class="form-control requirefieldcls" id = "Text_FindReourceName" name = "Text_FindReourceName"  style = "font-weight:normal">-->
										<select class='form-control selectpicker requirefieldcls' id = "Combo_FindResourceId" name = 'Combo_FindResourceId' style = "font-weight:normal; background-color: #fff99c; " data-show-subtext="true" data-live-search="true"> <?php echo $ResourceList; ?> </select>
									</div>
									<div class="col-sm-6 form-group">
										<label> Pay Period </label>  <!--selectpicker-->                              
										<select class='form-control requirefieldcls selectpicker' id = "Combo_FindPayPeriod" name = 'Combo_FindPayPeriod' style = "font-weight:normal" data-show-subtext="true" data-live-search="true"> <?php echo $PayPeriodList; ?> </select>
									</div>
									
									<!--	<div class="col-sm-4 form-group">
											<label> Region </label>
											<input type="text" class="form-control" placeholder="" maxlength="20">
										</div> 
									<div class="col-sm-6 form-group cus-form-ico">
										<label> Start Date </label>
										<input type="text" class="form-control form_datetime" id = "Text_StartDate" name = "Text_StartDate" placeholder="Start Date" maxlength="20" style = "font-weight:normal">
										<span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>
									<div class="col-sm-6 form-group cus-form-ico">
										<label> End Date </label>
										<input type="text" class="form-control form_datetime" id = "Text_EndDate" name = "Text_EndDate" placeholder="End Date" maxlength="20" style = "font-weight:normal">
										<span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>-->
									<div class="col-sm-3 form-group">
										<div class="checkbox ">
											<label><input type="checkbox" id = "Check_CurrentPayPeriod" checked  >Current Pay Period </label>
										</div>
									</div>
									 <!--    <div class="col-sm-4 form-group pd-tp20 cr-user">
											<button type="button" class="btn btn-primary btn-style"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
										</div> -->
								</div>
							</div>
                    <!--find -block end -->
				
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
					<button type="button" id="cmdFindResourcePopup" name="cmdFindResourcePopup" class="btn btn-primary btn-style" >Find</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Search Modal  -->
	
	
	<!--Copy Time Sheet modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "Popup2" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Copy Time Sheet </h4>
				</div>
				<div class="modal-body"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">				
							<!-- find block start-->
							<div class="pr">
								<div class="cus-form-cont">                            
									<div class="col-sm-4 form-group">
										<label> &nbsp;&nbsp;&nbsp;&nbsp; </label>
										<div class="checkbox">
											<label style = "padding-right:5px;"> <input type="checkbox" id="Check_CopyAllowed" name="Check_CopyAllowed" value = "1" onclick = "CheckCopyValue()"> Copy Previous Pay Period's Time Sheet </label>								
										</div>
									</div>	
                            
									<div class="col-sm-4 form-group" id = "div_PreviosTimeSheet" style = "display:none" >
										<label> Previous Time Sheet </label>
										<select class="form-control" id =  "Combo_PreviousTimeSheet" name =  "Combo_PreviousTimeSheet"  >
										  <option value=""> - Previous Time Sheet - </option>
										  <option value="1" > Option 1</option>									  
										  <option value="2" > Option 2</option>									  
										  <option value="3" > Option 3</option>				 					  
										</select>												
									</div>
								</div>
							</div>
							<!--find -block end -->
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
					<button type="submit" id="cmdPopup1_Save1" name="cmdPopup1_Save1" class="btn btn-primary btn-style" >Copy Time Sheet</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Copy Time Sheet Modal  -->
	
<!-- leave-bal start -->
<div id="leave-bal" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title " id="myModalLabel"> Leave Balance Details </h4>
      </div>
      <div class="modal-body"> 
        <!-- field start-->
            <div class="data-bx">
            <div class="table-responsive">
              <table class="table table-bordered mar-cont">
                <thead>
                  <tr>
                    <th width="50%"> Leave Benefit <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a></th>
                    <th width="20%"> Hours <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a></th>
                    <th width="25%"> Period Name <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a> </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                   
                  </tr>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                   
                  </tr>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    
                  </tr>
                  <tr class="bal-bx">
                    <td> Total PTD Leave Balance Hours </td>
                    <td> </td>
                    <td>  </td>
                  </tr>
                  <tr class="bal-bx">
                    <td> Total YTD Leave Balance Hours </td>
                    <td> </td>
                    <td>  </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        <!-- end --> 
      </div>
      <div class="clear-both"></div>
      <div class="modal-footer cr-user">
        <button type="button" class="btn btn-primary btn-style"> Ok </button>
      </div>
    </div>
  </div>
</div>
<!-- lleave bal end -->

     <!-- Notes detail pop up  start -->
    <div id="note-modal" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-sm cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <!-- field start-->
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <form id = "FormNote" >
						<div class="col-sm-12">						
							<div class="cus-form-cont">
								<div class="form-group">
									<label> Notes </label>
									<textarea class="form-control" rows="5" id="comment" maxlength="150"></textarea>
									<input type = "hidden" id = "PopupClickedElement" >
								</div>
							</div>
						</div>
					</form>	
                    <!-- end -->
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                    <button type="button" class="btn btn-primary btn-style" id = "cmdOK_Popup"> OK </button>
                </div>
            </div>
        </div>
    </div>
    <!-- Notes detail pop up end -->
	
	<!-- WBS description pop up  start -->
	
    <div id="WBSDescription-modal" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <!-- field start-->
                    <div class="col-sm-12">
                        <div class="cus-form-cont">
                            <div class="form-group">								
                                <label> WBS Description </label>
                                <textarea class="form-control" rows="5" id="Text_WBSDescription" style = "font-weight:normal;" >								
								</textarea>
                            </div>
                        </div>
                    </div>
                    <!-- end -->
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                    <button type="button" class="btn btn-primary btn-style" data-dismiss="modal"> OK </button>					
                </div>
            </div>
        </div>
    </div>
	
    <!-- WBS description pop up end -->
	
	<!--  alias pop up start-->
	<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalFindAlias" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel"> Find Projects / Tasks</h4>
				</div>
				<div class="modal-body"> 
		<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">
							
							<div class="col-sm-5 form-group">
							  <label>Alias Name</label>
							  <input type="text" id="Text_FindAliasName" name="Text_FindAliasName" class="form-control "  style = "font-weight: normal" maxlength="100">							 
							</div>
							
							<div class="col-sm-5 form-group">
							  <label> Alias Class </label>
							  <select id = "Combo_FindAliasClass" name = "Combo_FindAliasClass" class="form-control" maxlength="20" style = "font-weight: normal" onchange="RefreshTableList()">								
								<option value="">- Class -</option>
								
								<!--<option value="Shift">Shift</option>
								<option value="Overtime">Overtime</option>-->
								<option value="Leave">Leave</option> 
								<option value="Policy">Policy</option>
								<option value="no class">Resource Specific</option>
							  </select>
							</div>
						
							<div class="col-sm-2 form-group">
								<br>
							  <button type="button" id="cmdFindAliasPopup" name="cmdFindAliasPopup" class="btn btn-primary btn-style " onclick="FindAliasData()" >Find</button>
							</div>
							
							<div class="col-sm-12 form-group">
									<div id="span_msg" class="text-center" style = "font-weight:bold"> </div>
									<div class="data-bx">
										<div class="table-responsive">
											<table id='TablePopupHeading' class="table table-bordered " width="100%" >
												<thead>
													<tr>													
														<th width="5%" class="check-bx "><input type="checkbox" id="CheckboxPopup_SelectAll" onchange="PopupCheckAll()"></th>
														<th width="10%"> <span > Alias Name</span></th>
														<th width="20%"><span > Alias Type</span></th>
														<th width="30%"><span > Description</span></th>
														<th width="5%"><span > Active</span></th>
														<th width="30%"><span > Project WBS</span></th>
													</tr>
												</thead>
												<tbody id = "TablePopupList">
														
												</tbody>
											</table>
										</div>	
										<input type = "hidden" id = "CurrentParentRowNo" value = "" >
									</div>			
							</div>	
							
						</div>
						
						
					</div>
					<!-- end --> 
				  </div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
					<button type="button" id="cmdAliasAddItem" name="cmdAliasAddItem" class="btn btn-primary btn-style "  onclick="AddAliasRecord()"  >Add Item(s)	</button>
				</div>					
			</div>
		</div>
	</div>
	<!-- end alias pop up -->
	
	<!-- Audit pop up  start -->
	
    <div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "EyeIcon-modal" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Daily Audit </h4>					
				</div>
				<div class="modal-body"> 
				<!-- field start-->
					<div class="data-bx">
						<div class="table-responsive">			
						  <!-- find block start-->	
							<input type = "hidden" id = "auditdate_qry" value = "" >
							<h3> <div id = "div_AuditDate" class="text-center" > </div></h3>
							<table id = "Table-EyeIconH1" class="table table-bordered mar-cont">
								<thead>								
									<tr>
										<th> Employee Number</th>
										<th> Employee Name </th>									
										<th> Hours  </th>
										<th> Status  </th>									
									</tr>
								</thead>
								<tbody>
									<tr>
										<td id="td_HEmpNum" >  </td>
										<td id="td_HEmpName">  </td>
										<td id="td_Hhours">  </td>
										<td id="td_HStatus">  </td>
									</tr>									
								</tbody> 
							</table>
							<table id = "Table-EyeIconH2" class="table table-bordered mar-cont">
								<thead>								
									<tr>
										<th> Alias Name</th>
										<th> Project WBS </th>																			
									</tr>
								</thead>
								<tbody>
									<tr>
										<td style = "width : 35%"> 
										<div>
											<select id = "Combo_EyeIconH-Alias" class='form-control' readonly >
												<option class = 'option_color' value=''> - Alias - </option>
											</select>
										</div>
										</td>
										<td id = "td_projectWBS">  </td>										
									</tr>									
								</tbody> 
							</table>
							 <table id = "Table-EyeIcon" class="table table-bordered mar-cont">
								<thead>								
								  <tr>
									<th> Resource Name</th>
									<th> Employee Number </th>
									<th> Hours </th>
									<th> Status </th>
									<th> Last Update Date </th>
									<th> Updated By Resource Name </th>
									<th> Updated By Resource Number </th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td id = "td_resourceName">  </td>
									<td id = "td_EmpName">  </td>
								    <td id = "td_Hours"> </td>
									<td id = "td_Status">  </td>
									<td id = "td_LastUpdate">  </td>
									<td id = "td_UpdateByResourceName">  </td>
									<td id = "td_UpdateByResourceNo"> </td>
								  </tr>	
								  
								  
								</tbody> 
							</table>		
                    <!--find -block end -->				
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
				 	<button type="button" id="cmdFindResourcePopup" name="cmdFindResourcePopup" class="btn btn-primary btn-style" >Find</button>
				
				</div>
			</div>
		</div>
	</div>
	
    <!-- Audit pop up end -->
	
	
	<?php include("header.php"); ?>
	<style type="text/css">
		#bread-crumb .same{
			display: inline-block;
		}
	</style>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <!-- brd crum-->
                <div class="brd-crmb col-sm-2" style="padding: 10px 0">
                    <ul>
                        <li> <a href="#"> Time Accounting </a></li>
                        <li> <a href="#"> Time Entry </a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
						<div class="btn-bx2" >
							<div class="cr-user">
								<button type="button" class="btn btn-primary " <?php if ($msg == '') { ?> id = "cmdEnterTime" name = "cmdEnterTime" <?php } else { echo "disabled = 'disabled'" ; } ?>  > Enter Time </button>
								<button type="button" id = "cmdCancel" name = "cmdCancel" class="btn btn-primary"> Cancel </button>
							</div>
						</div>
					</div>
                <div class="col-sm-7" id="bread-crumb" style="margin-left: -10px;">
                    

					<div class="btn-bx2 col-sm-offset-4 same">
					   <div class="cr-user">
						 <!--	<button type="button" class="btn btn-primary"> Attachments</button> -->
							<button type="button" class="btn btn-primary saverecord" <?php if(($CREATE_PRIV_TimeEntry_PERMISSION=='Y' || $UPDATE_PRIV_TimeEntry_PERMISSION=='Y') && ($msg == '')){?> id = "cmdSaveTimeSheet"  name = "cmdSaveTimeSheet" <?php } else { echo "disabled=disabled"; } ?> > Save Time Sheet</button>
						</div>
					</div>
					<div class="btn-bx2 same">
						<div class="cr-user">
							<button type="button" class="btn btn-primary approve" <?php if($msg == '') { ?> name = "CmdApproval" id = "CmdApproval" <?php } else { echo "disabled=disabled"; } ?> > Submit for Approval</button>
						</div>
					</div>
					<div class="btn-bx2 same">
						<div class="cr-user">
							<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" <?php if ($IsSearchTimeSheets=="Y"){ ?> data-toggle="modal" data-target="#FindPopup" <?php }else{ echo "disabled:disabled";} ?> > <i class="fa fa-search" aria-hidden="true"></i> Time Keeping </button>
						</div>										
					</div>
				</div>
                
                <!-- Dash board -->
                
                
                <!-- inner work-->
				<?php
					//$IsAllowPreApproval = getvalue("cxs_am_ta_rules","ALLOW_PREAPPROVAL","where USER_ID = $LoginUserId");
					$IsWorkshiftOverride = "";
					$qry = "select* from cxs_am_ta_rules where USER_ID = $LoginUserId and SITE_ID = $SiteId";
					$result = mysql_query($qry);
					while($row=mysql_fetch_array($result))
					{
						$IsAllowPreApproval = $row['ALLOW_PREAPPROVAL'];
						$IsWorkshiftOverride = $row['ALLOW_OVERRIDE_WORKSHIFT'];
					}
					$HolidayFlag = "";
					$WeekendFlag = "";
					$HolidayEarnCredit = "";
					$OvertimeAllowed = "";
					$CTOOvertime="";
					$IsAllowWeekEnd = "N";
					$SupervisorId = 0;
					$CurrentWorkshiftId = "";
					/*$qry = "select  cxs_resources.FIRST_NAME ,  cxs_resources.LAST_NAME,cxs_resources.SUPREVISOR_ID,cxs_preapp_rules.RULE_NAME,cxs_policy_header.NAME as TimePolicy,cxs_workshifts.NAME as WorkshiftName,cxs_preapp_rules.HOLIDAY_FLAG,cxs_preapp_rules.WEEKEND_HOURS_FLAG,  
							cxs_policy_time_earned.HOLIDAY_EARN_CREDIT,cxs_policy_time_earned.OVERTIME_ALLOWED from cxs_users 
					inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID left join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID
					INNER JOIN cxs_policy_header ON cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID LEFT JOIN cxs_policy_general ON cxs_policy_general.POLICY_ID = cxs_policy_header.POLICY_ID
					left join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_general.WORKSHIFT_ID LEFT JOIN cxs_policy_time_earned ON cxs_policy_time_earned.POLICY_ID = cxs_policy_header.POLICY_ID where cxs_users.USER_ID = $LoginUserId";*/
					$ResourceId=""; 
					$qry = "select  cxs_users.USER_ID as CurrentUseId,cxs_policy_general.WORKSHIFT_ID as CurrentWorkshiftId,cxs_resources.FIRST_NAME , cxs_resources.LAST_NAME,cxs_policy_header.NAME as TimePolicy,cxs_workshifts.NAME as WorkshiftName, cxs_policy_header.ACTIVE_FLAG as TimePolicyActiveFlag ,
							cxs_policy_header.POLICY_ID as TimePolicyId, cxs_resources.*,cxs_workshifts.*,cxs_preapp_rules.*,cxs_policy_header.*,cxs_policy_general.* from cxs_users 
					inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID left join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID
					left JOIN cxs_policy_header ON cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID LEFT JOIN cxs_policy_general ON cxs_policy_general.POLICY_ID = cxs_policy_header.POLICY_ID
					left join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_general.WORKSHIFT_ID where cxs_users.USER_ID = $LoginUserId and cxs_users.SITE_ID = $SiteId  limit 0,1";
					//,cxs_policy_general.HOLIDAY_CALENDAR_ID as CurrentHolidayCalendarId
					$result = mysql_query ($qry);
					while($row=mysql_fetch_array($result))
					{	$Resource_FirstName = $row['FIRST_NAME'];
						$Resource_LastName = $row['LAST_NAME'];
						$ResourceId = $row['RESOURCE_ID'];
						$PreApprovalName = $row['RULE_NAME'];
						$WorkshiftName = $row['WorkshiftName'];
						$CurrentWorkshiftId = $row['CurrentWorkshiftId'];
						$CurrentUseId = $row['CurrentUseId'];
						//$CurrentHolidayId = $row['CurrentHolidayCalendarId'];
						$TimePolicy = $row['TimePolicy'];
						$TimePolicyId = $row['TimePolicyId'];
						$HolidayFlag = $row['HOLIDAY_FLAG'];
						$WeekendFlag = $row['WEEKEND_HOURS_FLAG'];
						$HolidayEarnCredit = $row['HOLIDAY_EARN_CREDIT'];
						$OvertimeAllowed = $row['OVERTIME_ALLOWED'];
						$CTOOvertime = $row['CTO_OVERTIME'];
						$SupervisorId = $row['SUPREVISOR_ID'];
						$WorkshiftType = $row['WORKSHIFT_TYPE'];
						$IsTimePolicyActive = $row['TimePolicyActiveFlag'];
						$CalendarId = $row['CALENDAR_ID'];
						$PreApprovalType = $row['PREAPPROVAL_TYPE'];
						$QuotaHours = $row['QUOTA_HOURS'];
						$RequiredHours 	= $row['REQUIRED_HOURS'];
					}
					$currentDate = date('Y-m-d');
					$qry = "select  * from cxs_periods  where '$currentDate' >= FROM_PERIOD_DATE and '$currentDate' <= TO_PERIOD_DATE and SITE_ID = $SiteId ";
					$result = mysql_query ($qry);
					while($row=mysql_fetch_array($result))
					{
						$CurrentCalendarId1 = $row['CALENDAR_ID'];
						$CurrentAccountingPeriod = $row['PERIOD_NAME'];
						$CurrentAccountingPeriodId = $row['PERIOD_ID'];
					}					
					$CurrentAccountingPeriod1  = $_SESSION["CurrentPayPeriod"];
					
					$SupervisorName="";
					if ($SupervisorId!='')
					{
						$qry = "Select concat(FIRST_NAME,' ',LAST_NAME) as supervisor from cxs_resources where RESOURCE_ID = $SupervisorId and SITE_ID = $SiteId";
						$result=mysql_query($qry);
						while($row=mysql_fetch_array($result))
						{
							$SupervisorName = $row['supervisor'];
						}
					}
					$AliasChildValues="";
					
					$AliasChildValues.="<option class = 'option_color' value = 'STD - Straight Time /Day'>STD - Straight Time /Day</option>";
					$AliasChildValues.="<option class = 'option_color' value = 'STE - Straight Time /Evening'>STE - Straight Time /Evening</option>";
					$AliasChildValues.="<option class = 'option_color' value = 'STN - Stright  Time /Night'>STN - Stright  Time /Night</option>";
						
					if($OvertimeAllowed=="Y")
					{
						$IsAllowWeekEnd = "Y";
						$AliasChildValues.="<option class = 'option_color' value = 'OTD - Overtime/Day'>OTD - Overtime/Day</option>";
						$AliasChildValues.="<option class = 'option_color' value = 'OTE - Overtime/Evening'>OTE - Overtime/Evening</option>";
						$AliasChildValues.="<option class = 'option_color' value = 'OTN - Overtime/Night'>OTN - Overtime/Night</option>";
					}
					if($CTOOvertime=="Y") 
					{
						$IsAllowWeekEnd = "Y";
						$AliasChildValues.="<option class = 'option_color' value = 'CTO - Compensatory Time Off'>CTO - Compensatory Time Off</option>";
						/*$AliasChildValues.="<option class = 'option_color' value = 'CTH'>CTH - Time & Half</option>";			
						$AliasChildValues.="<option class = 'option_color' value = 'CTS'>CTS - Compensatory Time off @ Stratight time</option>";*/
					}
					if($AliasChildValues!='')
					{
						$AliasChildValues = "<option class = 'option_color' value = ''>- Shift -</option>".$AliasChildValues;
					}
					if($IsAllowPreApproval=="Y")
					{
						echo "<script>";
						echo "$('#cmdFind').attr('disabled',true);";
						echo "</script>";
					}
					$CurrentPayPeriod1 = $_SESSION['CurrentPayPeriodId'];
					$msg="";
					if(isset($CurrentPayPeriod1))
					{
						$msg = UserValidationsForTE($LoginUserId,$CurrentPayPeriod1);
					}
					else
					{
						$divStyle="<div class='alert alert-success'>";
						$qry = "select  * from cxs_periods  where '$currentDate' >= FROM_PERIOD_DATE and '$currentDate' <= TO_PERIOD_DATE ";
						$result = mysql_query ($qry);
						while($row=mysql_fetch_array($result))
						{
							$PeriodName = $row['PERIOD_NAME'];
						}
						$msg = $divStyle."No period open for $PeriodName. Contact your administrator. </div>";
					}
					$TE_Name = ""; 
					$TE_Prefix = "";
					$TE_Status = "";
					$TE_Id = "";
					$qry = "select cxs_te_header.*,cxs_users.USER_NAME as CreatedByName  from cxs_te_header left join cxs_users on cxs_users.USER_ID = cxs_te_header.CREATED_BY  where cxs_te_header.PAY_PERIOD_ID = '$CurrentAccountingPeriodId' and cxs_te_header.RESOURCE_ID = '$ResourceId'";
					$result = mysql_query($qry);					
					while($row = mysql_fetch_array($result))
					{
						$TE_Id = $row['TE_ID'];
						$TE_Name = $row['TE_NAME'];
						$TE_Prefix = $row['TE_PREFIX'];
						$TE_Status = $row['STATUS']; 
						
						$Display_CreatedByName = $row['CreatedByName'];
						$Display_CreationDate = date('m/d/Y ', strtotime($row['CREATION_DATE']));
						$UpdatedBy	= $row['LAST_UPDATED_BY'];
						$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");
						$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
					}					
					?>					
                <div class="cont-box"> 
					<form id = "form1" method="post">
						<div class="row"> 
							<h4 class="text-center"  id="msg_section"><?php echo $msg; ?></h4>
						</div>
						
						<!-- <div class="pge-hd">
							<h2 class="sec-title"> <label id="Label_Title"> Time Entry </label> </h2>
						</div> -->
						<div class="clear-both"> </div>
						
						<div class="pge-hd" style="margin: 0">	
							<h3 style="margin: 0"> <span style = "padding-right:50px; font-family: Calibri; color:#0202ff;" id = "span_TETitle"><?php if ($TE_Name!='') {?> <b>Name : </b><?php	echo $TE_Prefix."-".$TE_Name."[".$TE_Status."]"; } ?></span></h3>								 
						</div>					
						
						<div class="clear-both"> </div>
						<?php 
							/*$RetroPeriod = 0;
							$qry = "select RETRO_PERIOD_NUM from cxs_am_ta_rules where USER_ID = $LoginUserId ";
							$result = mysql_query($qry);
							while($row = mysql_fetch_array($result))
							{
								$RetroPeriod = $row['RETRO_PERIOD_NUM'];
							}
							if($RetroPeriod>0)
							{
								$PeriodType = getvalue("cxs_calendars","PERIOD_TYPE","where CALENDAR_ID = $CurrentCalendarId1");
								if($PeriodType=="Monthly")
								{
									$EndDate = date('Y-m',strtotime($currentDate))."-01";
									$BeginDate = date('Y-m-d', strtotime($EndDate.' -'.$RetroPeriod.' months')); 
								}
								else if($PeriodType=="Weekly")
								{
									if(date('l',strtotime($currentDate))=='Monday')
									{
										$firstday = strtotime($currentDate);
									}
									else										
									{
										$firstday = strtotime("last Monday",strtotime($currentDate));
									}									
									$EndDate = date('Y-m-d',$firstday); 
									$BeginDate = date('Y-m-d', strtotime($EndDate.' -'.($RetroPeriod*7).' days')); 
								
								}
								else if($PeriodType=="Semi-Monthly")
								{
									$tempDate1 = date('Y-m',strtotime($currentDate))."-15";
									if(strtotime($currentDate)>strtotime($tempDate1))
									{
										$EndDate = date('Y-m',strtotime($currentDate))."-16";
									}
									else
									{
										$EndDate = date('Y-m',strtotime($currentDate))."-01";
									}
									$tempPeriods = intval($RetroPeriod/2);									
									$BeginDate = date('Y-m-d', strtotime($EndDate.' -'.$tempPeriods.' months')); 
									
									if($tempPeriods%2==1)
									{
										$BeginDate = date('Y-m-d', strtotime($BeginDate.' -15 days')); 
									}
								}	*/							
								$PeriodList = "";								
								//$qry = "Select * from cxs_periods where FROM_PERIOD_DATE between '$BeginDate' and '$EndDate' order by PERIOD_ID desc";
								$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID 
										where cxs_periods.status = 'Open' and cxs_periods.SITE_ID = $SiteId order by cxs_calendars.NAME, cxs_periods.PERIOD_ID desc ";
								$result = mysql_query($qry);
								while($row = mysql_fetch_array($result))
								{
									$PeriodName = $row['PERIOD_NAME'];
									$PeriodId = $row['PERIOD_ID'];	
									$IsSelected = ($CurrentAccountingPeriodId==$PeriodId)?'selected="selected"':'';	
									$PeriodList .= "<option class = 'option_color' value = '$PeriodId' $IsSelected > $PeriodName </option>";
								}
						//	}
						?>
						
						<div class="cr-user mar-btm20 marbtm-ner">
							<ul>
								<li><p class="br-tp"> <b>Resource  </b> </p>	<span class="br-btm" id = "Span_ResourceName"> <?php	echo $Resource_FirstName.",".$Resource_LastName;  ?> </span></li>
								<li><p class = "showOnMobile br-tp"><b>Pay Period  </b></p>
								<span style = " <?php echo ($PeriodList!='')?'display:none':''; ?>" class="lat-wit br-btm" id = "Span_Payperiod"><?php	if($CalendarId==$CurrentCalendarId1){echo $CurrentAccountingPeriod ; }?></span>
								<?php if($PeriodList!='') { ?>
									<span class="lat-wit br-btm"> <b> Pay Period</b> : <select  class="input-sm option_color"  id = "Combo_PeriodList" name = "Combo_PeriodList"><?php echo $PeriodList; ?></select></span>
								<?php } ?>		</li>						
								<li><p class = "showOnMobile br-tp"><b>Workshift  </b></p><span class="lat-wit br-btm"  id = "Span_Workshift"><?php	echo $WorkshiftName; ?></span></li>
								<li><p class = "showOnMobile br-tp"><b>Supervisor  </b></p><span class="lat-wit br-btm"  id = "Span_Supervisor"><?php	echo $SupervisorName;  ?></span> 
                                </li>
                           <div class="clear"></div>
							</ul> 
                                 
								<input type="hidden" id = "ResourceId" name = "ResourceId" value = "<?php echo $ResourceId; ?>" >
								<input type="hidden" id = "PayPeriodId" name = "PayPeriodId" value = "<?php echo $_SESSION['CurrentPayPeriodId']; ?>" >
								<input type="hidden" id = "CurrentWorkshiftId" name = "CurrentWorkshiftId" value = "<?php echo $CurrentWorkshiftId; ?>" >
								<input type="hidden" id = "CurrentSupervisorId" name = "CurrentSupervisorId" value = "<?php echo $SupervisorId; ?>" >								
								<input type="hidden" id = "CurrentTimePolicyId" name = "CurrentTimePolicyId" value = "<?php echo $TimePolicyId; ?>" >
								<input type="hidden" id = "hCurrentTEId" name = "hCurrentTEId" value = "<?php echo $TE_Id; ?>" >
								<input type="hidden" id = "hCurrentUId" name = "hCurrentUId" value = "<?php echo $CurrentUseId;?>" >
								<input type="hidden" id = "hIsPreApprove" name = "hIsPreApprove" value = "<?php echo $IsAllowPreApproval;?>" >
								<input type="hidden" id = "hPreApprovalType" name = "hPreApprovalType" value = "<?php echo $PreApprovalType;?>" >
								<input type="hidden" id = "hQuotaHours" name = "hQuotaHours" value = "<?php echo $QuotaHours;?>" >
								<input type="hidden" id = "hOvertimeAllowed" name = "hOvertimeAllowed" value = "<?php echo $OvertimeAllowed;?>" >
						</div>
                        
                        
                        
                        
                        
                        
                        
					<!--	<div class="cr-user text-right mar-btm20 renderClass">
							 <a href="#leave-bal" data-toggle="modal"> 
								<button type="button" class="btn btn-primary btn-style " > Leave balance </button>
							</a>
						</div>	 
						<div class="col-sm-row">
							<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
								<div class="panel panel-default panel2">
									<div class="panel-heading" role="tab" id="headingOne">
									  <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne" class="collapsed"> PTD & YTD Balance <i class="fa fa-plus"></i> </a></h4>
									</div>
									<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
										<div class="panel-body">
										   
											<div class="row cus-block">
												<div class="col-sm-6 pd-contr">
													<div class="tble-hd  bdr-right-sm"> PTD Balance </div> 
													<div class="pdb-block bdr-right-sm">
														<div class="row">													
															<div class="form-group col-sm-6">
																<label for=" "> EHE-Excess Hours Earned :</label>
																<input type="text" class="form-control" id="Text_PTD_ExcessHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> HEC-Holiday Earned Credit :</label>
																<input type="text" class="form-control" id="Text_PTD_HolidayEarn"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Overtime Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_OvertimeHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> CTO Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_CTOHours"  maxlength="10">
															</div>	
															<div class="form-group col-sm-6">
																<label for=" "> Regular Shift Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_RegularShiftHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Workshift Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_WorkshiftHours"  maxlength="10">
															</div>	
															
															<div class="form-group col-sm-6">
																<label for=" "> Project Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_OvertimeHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Pre Approval Quota Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_QuotaHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Submitted Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_SubmittedHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Approved Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_AppovedHours"  maxlength="10">
															</div>	
															<div class="form-group col-sm-6">
																<label for=" "> Total Pre Approved Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_PreApprovedHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Not Approved Hours :</label>
																<input type="text" class="form-control" id="Text_PTD_NotApprovedHours"  maxlength="10">
															</div>	
														</div>
													</div>
												</div>
												<div class="col-sm-6 pd-contr">
													<div class="tble-hd  bdr-right-sm"> YTD Balance </div>
													<div class="pdb-block bdr-right-sm">
														<div class="row">													
															<div class="form-group col-sm-6">
																<label for=" "> EHE-Excess Hours Earned :</label>
																<input type="text" class="form-control" id="Text_YTD_ExcessHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> HEC-Holiday Earned Credit :</label>
																<input type="text" class="form-control" id="Text_YTD_HolidayEarn"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Overtime Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_OvertimeHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> CTO Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_CTOHours"  maxlength="10">
															</div>	
															<div class="form-group col-sm-6">
																<label for=" "> Regular Shift Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_RegularShiftHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Workshift Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_WorkshiftHours"  maxlength="10">
															</div>	
															
															<div class="form-group col-sm-6">
																<label for=" "> Project Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_OvertimeHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Pre Approval Quota Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_QuotaHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Submitted Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_SubmittedHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Approved Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_AppovedHours"  maxlength="10">
															</div>	
															<div class="form-group col-sm-6">
																<label for=" "> Total Pre Approved Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_PreApprovedHours"  maxlength="10">
															</div>
															<div class="form-group col-sm-6">
																<label for=" "> Total Not Approved Hours :</label>
																<input type="text" class="form-control" id="Text_YTD_NotApprovedHours"  maxlength="10">
															</div>	
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>   
						</div> -->
                    <!-- Buttons start-->
						
					
                    <!-- Buttons end-->
                    <!-- pagination start-->
						<?php
						//	$currentDate1 = strtotime(date('Y-m-d'));
						?>
						<div class="pagination-bx renderClass">
							<div class="bs-example text-left">
								<ul class="pagination">
									<?php if($msg==''){ ?>
									<li><a href="javascript:void(0)">&laquo; Previous </a></li>
									<li><a href="javascript:void(0)">Next &raquo; </a></li>									
									<?php } ?>
								</ul>
							</div>
						</div>
                    <!-- pagination end -->
						<div class="fix-dox renderClass">
							<div class="tab-info-bx tp46">
								<label > <input type="checkbox" class="mar-tp3" <?php if ($IsAllowWeekEnd=="Y") { ?> id = "Check_Weekends" name = "Check_Weekends" value="1"  onchange = "CheckWeekDays()" <?php } else { echo "disabled='disabled'"; } ?> > Weekends &nbsp; </label>								
								<button id = "cmdHeaderInfo" type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left"  data-content="Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
								<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>" data-original-title="" title=""> <i class=" fa fa-eye"></i> </button>
							</div>						
						</div>
						<?php
						$TotalWeekDays=7;	
						$currentDate1 = strtotime(date('Y-m-d'));						
						$firstday = strtotime("last Monday",$currentDate1);
						$firstday = date('w', $firstday)==date('w') ? $firstday+7*86400 : $firstday;
						$lastday = strtotime(date("Y-m-d",$firstday)." +6 days");			 
						$this_week_sd = date("Y-m-d",$firstday);
						$this_week_ed = date("Y-m-d",$lastday);
						$displayDate = $this_week_sd;
						/*$IsNegativeEntryAllowed = getvalue("cxs_am_ta_rules","ALLOW_NEGATIVE","where USER_ID = $LoginUserId");
						if ($IsNegativeEntryAllowed=="")
						{
							$IsNegativeEntryAllowed="N";
						}
							//echo date('m/d/y', last_sunday('11/18/2017'));
						*/	
							
						if($TE_Id!="")
						{
							$TE_AliasList = array();
							$qry = "select * from cxs_te_file where TE_ID = $TE_Id and ENTRY_DATE >= '$this_week_sd' and ENTRY_DATE <= '$this_week_ed' group by ROW_NO order by DETAIL_ID";
							$result = mysql_query($qry);
							while($row = mysql_fetch_array($result))
							{
								$TE_AliasList[] = $row['ALIAS_ID'];
							}
						}	
						?>
                    <!-- table -->
						<input type="hidden" id = "hIsExistRecord" name = "hIsExistRecord" value = "<?php if( sizeof($TE_AliasList) > 0) {echo 'Y';}else{echo ''; }?>" >
						<div class="row">
							<div class="col-md-12">							
								<div class="data-bx">
									<div class="table-responsive " id = "DivProjectDetails">	
										<table class="table table-bordered mar-cont table-freeze-multi" data-scroll-height="300" data-cols-number="2">
											<thead>
												<tr>
													<th width="5%" rowspan="2" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" ></th>													
													<th rowspan="2" style = "min-width :300px;"> Projects/Tasks</th>
													<th id = "tableHeading3" rowspan="2" style = "min-width :70px; "> Shift Type</th> <?php// if($OvertimeAllowed!="Y" && $CTOOvertime!="Y"){ echo "display:none"; } ?>
													<?php	
														$h_WorkshifHours = array();
														if($CurrentWorkshiftId!='')
														{
															$qry = "select * from cxs_workshifts_detail where WORKSHIFT_ID = $CurrentWorkshiftId order by ROW_NO";
															$result = mysql_query($qry);
															while($row = mysql_fetch_array($result))
															{
																$h_WorkshifHours[]=$row['SHIFT_HOURS'];
															}
														}	
														$qry = "select * from cxs_periods where PERIOD_ID ='$CurrentAccountingPeriodId'";
														$result = mysql_query($qry);
														while($row = mysql_fetch_array($result))
														{
															$BeginDate = $row['FROM_PERIOD_DATE'];
															$EndDate = $row['TO_PERIOD_DATE'];
														}
														$firstday = strtotime($BeginDate);
														$lastday = strtotime($EndDate);
														$CurrentWeekDates = array();
														for($i=1;$i<=$TotalWeekDays;$i++)
														{	
															$my_date = strtotime($displayDate);
															$my_date1 = date("Y-m-d",$my_date);
															$CurrentWeekDates[] = $my_date1;
															$my_date = date("D, M d, Y", $my_date);	
															if(strtotime($my_date1) >= $firstday && strtotime($my_date1) <= $lastday )															
															{
																$IsAllowEntry[]='Y';
															}
															else
															{
																$IsAllowEntry[]='N';
															}	

													?>
													
															<th colspan="3" class="text-center displayclass"  <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"style='display:none'":"":""; ?>   > 
																<div class = "pull-left" id = "<?php echo "TopHeading$i"; ?>"><?php echo $my_date; ?> </div>
																<div class = "pull-right"> 
																	<!--<button id = "<?php echo "cmdTopHeadingEyeIcon$i" ?>" type="button" class="btn btn-default TopHeadingEyeIcon"> <i class=" fa fa-eye"></i> </button>-->
																	<button id = "<?php echo "cmdTopHeadingEyeIcon$i" ?>" type="button" class="btn btn-default <?php if ($_SESSION['IsEnableAudit']=="Y"){ ?> TopHeadingEyeIcon <?php }else{ } ?> " > ... </button>
																	
																</div>
															</th>
															
															<input type = "hidden" id = '<?php echo "h_currentweek$i"; ?>'  name = '<?php echo "h_currentweek[]"; ?>' value = "<?php echo $my_date1; ?>">
															<input type = "hidden" id = '<?php echo "IsAllowEntry$i"; ?>'  name = '<?php echo "IsAllowEntry[]"; ?>' value = "<?php echo $IsAllowEntry[$i-1]; ?>">
															<input type = "hidden" id = '<?php echo "h_WorkshifHours$i"; ?>'  name = '<?php echo "h_WorkshifHours[]"; ?>' value = "<?php echo $h_WorkshifHours[$i-1]; ?>">
															<input type = "hidden" id = '<?php echo "h_IsHoliday$i"; ?>'  name = '<?php echo "h_IsHoliday[]"; ?>' value = "">
												<?php 	 
															$displayDate = date('Y-m-d', strtotime("$displayDate +1 day"));
														} 
														
						1
												?>
													<th  class="text-center red-clr"  style = "min-width :80px;" bgcolor="#d35854">Line Total </th>
												</tr>
												<tr class="tr-sunhd">
													<?php												
														for($i=1;$i<=$TotalWeekDays;$i++)
														{ ?>
															<th style = "min-width :60px; <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"display:none":"":""; ?> " id = "<?php echo "HoursHeading$i"; ?>"> Hours </th>
															<th style = "min-width :80px; <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"display:none":"":""; ?> " id = "<?php echo "StatusHeading$i"; ?>" > Status </th>
															<th style = "min-width :40px; <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"display:none":"":""; ?> " id = "<?php echo "NotesHeading$i"; ?>" > Notes </th>
												<?php 	} ?>		
														<th > Hours </th>
												</tr>
											</thead>
											<?php 	
													if($msg == '' && $WorkshiftType == 'Flexible Shift')
													{
														$i=0;
														foreach($CurrentWeekDates as $key1)
														{
															if($IsAllowEntry[$i]=="Y")
															{
																$EntryFirstDate = $key1;
																break;
															}
															$i++;
														}														
														 $msg123 = CheckWorkshiftFlexibleType($CurrentWorkshiftId,$EntryFirstDate); 
														 if($msg123!='')
														 {
															 //echo $msg123; //echo "<style>alert($msg1);</style>";
															 $msg = $msg123;
														 ?>
															<script>
															var a = "<?php echo $msg; ?>";
															$("#msg_section").text('');			
															$("#msg_section").append(a);	
															$("#cmdEnterTime").attr("disabled",true);	
															</script> 
															 
													<?php 	 }
													} ?>
											<tbody id = "DetailTable">
												<?php 
													$x=0;
													$TotalRows = 1;
													$TotalHoursVertical=array();
													if ($TE_Id!='')
													{
														$qry = "select cxs_te_file.ALIAS_ID as AliasId,cxs_aliases.ALIAS_NAME,cxs_te_file.SEED_ALIAS,cxs_te_file.SHIFT,cxs_te_file.HOURS from cxs_te_header inner join cxs_te_file on cxs_te_file.TE_ID = cxs_te_header.TE_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID where cxs_te_header.TE_ID = $TE_Id and ENTRY_DATE >= '$this_week_sd' and ENTRY_DATE <= '$this_week_ed' group by ROW_No";
														$result=mysql_query($qry);
														while($row = mysql_fetch_array($result))
														{ 
															$x=$x+1;
															if($row['AliasId']==0)
															{
																$AliaName = $row['SEED_ALIAS'];
															}
															else
															{
																$AliaName = $row['ALIAS_NAME'];
															}
															$AliasId = $row['AliasId'];
													?>
															<tr id = "<?php echo "row$x"; ?>" class = "fetchData">
																<td class="check-bx ">
																	<input type = "hidden" name = "h_rows[]" value = "<?php echo $x; ?>" >
																	<input type="checkbox" class = "GridCheckBox" id="<?php echo "CheckboxInline$x" ?>" value="1"></td>
																<td>
																	<div class="form-group">																		
																		<input type="text" id = "<?php echo "Text_Task$x"; ?>" name = "<?php echo "Text_Task$x"; ?>" class="input-sm form" onfocus = "SearchPopUp(<?php echo $x; ?>)" style = "width : 85%;display : none" value = "<?php echo $AliaName; ?> ">
																		<span id = "<?php echo "Span_Task$x"; ?>" name = "<?php echo "Span_Task$x";?>" style="float:left;width:86%;margin-top:10px;"><?php echo "$AliaName"; ?></span>
																		<input type="button" id = "<?php echo "cmdTaskDescription$x"; ?>" name = "<?php echo "cmdTaskDescription$x"; ?>" class="btn btn-primary btn-style-bdronly my-link" value = "..." onclick = "TaskDescriptionPopUp(<?php echo $x; ?>)" >
																		<input type = "hidden" id = "<?php echo "h_Taskid$x"; ?>" name = "<?php echo "h_Taskid$x"; ?>"  value = "<?php echo $AliasId; ?>" >
																	</div>
																</td> 
																<td <?php $ShiftName = $row['SHIFT']; $ComboName = "Combo_Shift$x"; $SpanName = "Span_Shift$x"; if($AliasChildValues==''){ echo "style='display:none'"; } ?>>
																	<div class="form-group" <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>
																		<?php if($AliasChildValues!=''){?><span><select  class="input-sm option_color" id = "<?php echo $ComboName ?>" name = "<?php echo $ComboName ?>" style = "display:none" onclick="setSpanValue('<?php echo $ComboName ?>','<?php echo $SpanName;?>')"> <?php echo $AliasChildValues; ?></select></span><?php } ?>
																		<span id = "<?php echo $SpanName;?>" name = "<?php echo $SpanName;?>" > <?php echo $ShiftName; ?> </span>
																	</div>
																	<script>	
																		SelectedValue("<?php echo $ComboName; ?>","<?php echo $row['SHIFT']; ?>");
																	</script> 
																</td>
																<?php 
																	$TempHours = array();
																	$TempStatus = array();
																	$TempComment = array();
																	$TotalHoursHorizontal = 0;																	
																	foreach($CurrentWeekDates as $key)
																	{
																		 $qry1 = "select HOURS,STATUS_FLAG,COMMENT from cxs_te_file inner join cxs_te_header on cxs_te_header.TE_ID = cxs_te_file.TE_ID 
																				WHERE cxs_te_header.TE_ID = $TE_Id and cxs_te_file.ROW_NO = $x and ENTRY_DATE = '$key' ORDER BY cxs_te_file.DETAIL_ID ";
																		$result1 = mysql_query($qry1);
																		$noofrows = mysql_num_rows($result1);
																		while($row1 = mysql_fetch_array($result1))
																		{
																			$TempHours[] = 	$row1['HOURS'];
																			$TempComment[] = 	$row1['COMMENT'];
																			$TotalHoursHorizontal = $TotalHoursHorizontal + $row1['HOURS'];
																			if( $row1['STATUS_FLAG']=='W')
																			{
																				$TempStatus[] = "Working";
																			}
																			else if( $row1['STATUS_FLAG']=='H')
																			{
																				$TempStatus[] = "Holiday";
																			}
																			else if( $row1['STATUS_FLAG']=='S')
																			{
																				$TempStatus[] = "Submitted";
																			}
																			else if( $row1['STATUS_FLAG']=='A')
																			{
																				$TempStatus[] = "Approved";
																			}
																			else if( $row1['STATUS_FLAG']=='R')
																			{
																				$TempStatus[] = "Rejected";
																			}
																		}
																		if($noofrows == 0)
																		{
																			$TempHours[] = "";
																			$TempComment[] = "";
																			$TempStatus[] = "";
																		}
																	}
																	for($j=1;$j<=$TotalWeekDays;$j++)
																	{
																		if($x==1)
																		{
																			$TotalHoursVertical[$j-1] = $TempHours[$j-1];
																		}
																		else
																		{
																			$TotalHoursVertical[$j-1] = $TotalHoursVertical[$j-1] + $TempHours[$j-1];
																		}
																?>
																	<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?>  id = "<?php echo "Hours$x"."_$j"?>" >
																		<div class="form-group  text-right " >
																			<span id = "<?php echo "Span_Hours$x"."_$j"?>" class = "my-span-style"  > <?php echo $TempHours[$j-1]; ?> </span>
																			<input style = "display:none" type="text" id = "<?php echo "Text_Hours$x"."_$j"?>" name = "<?php echo "Text_Hours$x"."_$j"?>" class="form-control text-right" maxlength="6"  onkeyup = "EnteredValue('<?php echo $x; ?>','<?php echo "Span_Hours$x"."_$j"; ?>',this)" onkeypress="return allowNegPosNumber(event);" onblur = "TotalHours(this)" style = "min-width :40px; " value = "<?php echo $TempHours[$j-1];?>">
																		</div>
																	</td>
																	
																	<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?> id = "<?php echo "Status$x"."_$j"?>">
																		<div class="form-group">
																			<span id = "<?php echo "span_Status$x"."_$j"; ?>" name = "<?php echo "span_Status$x"."_$j"; ?>" class = "my-span-style" style = "font-size:12px;" > <?php echo $TempStatus[$j-1]; ?> </span>
																			<input type="text" id = "<?php echo "Text_Status$x"."_$j"?>" name = "<?php echo "Text_Status$x"."_$j"?>" class="form-control setStatus" maxlength="12" onkeyup = "EnteredValue('<?php echo $x; ?>','<?php echo "span_Status$x"."_$j"; ?>',this)" style = "font-weight: bold;min-width : 50px;font-size:12px; display :none" value = "<?php echo $TempStatus; ?>" readonly>
																		</div>
																	</td>												
																	<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?> id = "<?php echo "Notes$x"."_$j"?>" >
																		<div>
																			<!--<a href="javascript:ShowPopup('<?php echo$x."_$j"?>')"  class="btn btn-primary btn-style-bdronly" > <i class="fa fa-ellipsis-h" aria-hidden="true"></i> </a>-->
																			<input type="button" id = "<?php echo "cmdNotes$x"; ?>" name = "<?php echo "cmdNotes$x"; ?>" class="btn btn-primary btn-style-bdronly my-link" onclick = "ShowPopup('<?php echo$x."_$j"?>')" value = "..."  >
																			<input type="hidden" id = "<?php echo "h_comment$x"."_$j"; ?>" name = "<?php echo "h_comment$x"."_$j"; ?>" value = "<?php echo $TempComment[$j-1]?>">
																		</div>
																	</td>
																	<?php
																		}
																	?>
																	<td>
																		<div class="form-group">
																			<input type="text" id = "<?php echo "Text_LineTotalHours$x"?>" name = "<?php echo "Text_LineTotalHours$x"?>" class="form-control text-right" readonly  value = "<?php echo $TotalHoursHorizontal; ?>" >
																		</div>
																	</td>																	
															</tr>
													<?php }
													}
													for($i=$x+1;$i<=$x+$TotalRows;$i++)
													{ //echo "hi $TotalWeekDays $TotalWeekDaysActual";
												?>
												<tr id = "<?php echo "row$i"; ?>">
													<!-- Part12 -->
													<td class="check-bx "><!--<input type="checkbox" id="<?php echo "CheckboxInline$i" ?>" value="1" disabled="disabled">--></td>
													<td>
														<div class="form-group">														
															<span id = "<?php echo "Span_Task$i"; ?>"> </span>
															<input type="text" id = "<?php echo "Text_Task$i"; ?>" name = "<?php echo "Text_Task$i"; ?>" class="input-sm form" onfocus = "SearchPopUp('')" style = "width : 85%;height:34px;" >
															<input type="button" id = "<?php echo "cmdTaskDescription$i"; ?>" name = "<?php echo "cmdTaskDescription$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" value = "..." onclick = "TaskDescriptionPopUp(<?php echo $i; ?>)" >
														</div>
													</td>
													<td <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>
														<div class="form-group" <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>
															<?php if($AliasChildValues!=''){?><span><select  class="input-sm option_color" id = "Combo_Shift" name = "Combo_Shift" ><?php echo $AliasChildValues; ?></select></span><?php } ?>
														</div>	
													</td>
													<!-- Part2 -->
													<?php
														for($j=1;$j<=$TotalWeekDays;$j++)
														{													
													?>
													<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?>  id = "<?php echo "Hours$i"."_$j"?>" >
														<div class="form-group" >
															<span id = "<?php echo "Span_Hours$i"."_$j"?>" style = "display:none">  </span>
															<input type="text" id = "<?php echo "Text_Hours$i"."_$j"?>" name = "<?php echo "Text_Hours$i"."_$j"?>" class="form-control " maxlength="3" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onchange = "TotalHours()"  style = "min-width :40px;" value = "<?php echo ""; ?>">
														</div>
													</td>
													
													<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?> id = "<?php echo "Status$i"."_$j"?>">
														<div class="form-group">
															<span id = "<?php echo "span_Status$i"."_$j"; ?>" name = "<?php echo "span_Status$i"."_$j"; ?>" class = "my-span-style" style = "font-size:12px; display:none;" >  </span>
															<input type="text" id = "<?php echo "Text_Status$i"."_$j"?>" name = "<?php echo "Text_Status$i"."_$j"?>" class="form-control setStatus" maxlength="12" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "span_Status$i"."_$j"; ?>',this)" style = "font-weight: bold;min-width : 80px;font-size: 12px;" value = "" readonly>
														</div>
													</td>												
													<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==7)?"style='display:none'":"":""; ?> id = "<?php echo "Notes$i"."_$j"?>" >
														<div>
															<!--<div> <a href="javascript: void(0);" class="btn btn-primary btn-style-bdronly "> <i class="fa fa-ellipsis-h" aria-hidden="true"></i> </a> </div>-->
															<input type="button" id = "<?php echo "cmdNotes$i"; ?>" name = "<?php echo "cmdNotes$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" value = "..."  >
														</div>
													</td>
													<?php
														}
													?>	
													<!-- Part3 -->
													<td>
														<div class="form-group">
															<input type="text" id = "<?php echo "Text_LineTotalHours$i"?>" name = "<?php echo "Text_LineTotalHours$i"?>" class="form-control" readonly >
														</div>
													</td>
													
												</tr>
												<?php } ?>
												
												<tr id = "row-WBSTotal1">
													<!-- Part1 -->
													<td rowspan="2"></td>
													<td rowspan="2" <?php if($AliasChildValues!=''){ echo "colspan='2'"; } ?> bgcolor="#d35854" style = "color: #ffffff;"><b>WBS  Total</b></td>
													
													<!-- Part2 -->
													<?php
														$FinalTotal = 0;
														for($i=1;$i<=$TotalWeekDays;$i++)
														{
															$FinalTotal = $FinalTotal+$TotalHoursVertical[$i-1];
													?>	
														<td bgcolor="#d35854" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskHours$i"; ?>">
															<div class="form-group ">
																<input type="text" id = "<?php echo "Text_TotalTaskHours$i"?>" name = "<?php echo "Text_TotalTaskHours$i"?>" class="form-control text-right" readonly style = "min-width :40px;" value = "<?php echo $TotalHoursVertical[$i-1]; ?>">
															</div>
														</td>
														<td bgcolor="#d35854" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskStatus$i"; ?>" ></td>
														<td bgcolor="#d35854" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskNotes$i"; ?>" ></td>
													<?php
														}
													?>
													<!-- Part3 -->
													<td rowspan="2" bgcolor="#d35854" style = "color: #ffffff;">
														<div class="form-group">
															<input type="text" id = "Text_TotalFinal" name = "Text_TotalFinal" class="form-control text-right" readonly style = "min-width :60px;color: #ffffff;" value = <?php echo $FinalTotal; ?>>															
														</div>
													</td>
													
												</tr>
												
												<tr class="cr-user " id = "row-WBSTotal2">
													<!-- Part2 -->
													<?php
														for($i=1;$i<=$TotalWeekDays;$i++)
														{
													?>	
													<td colspan="3" class="submit-tbe approve-btn " <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==7)?"style='display:none'":"":""; ?> id = "<?php echo "SubmitForApproval$i"; ?>"> <button type="button" class="btn btn-primary btn-style approve" id = "<?php echo "CmdApproval$i"; ?>" name = "<?php echo "CmdApproval$i"; ?>"> Submit for Approval </button>
													</td>
													<?php
														}
													?>
												</tr>
													
													
											</tbody>
										</table>
									</div>
								<!--	<div class="fix-dox">
										<span ><h5><b>Task Description </b></h5></span>
										<div class="cus-form-cont ">
											<div class="form-group">
												<textarea class="form-control color-white" rows="3" id="comment" maxlength="200"></textarea>
											</div>

										</div>							
									</div>-->	
								</div>	
							</div>		
						</div>
					
					<!-- end table -->
						<div class="clear-both"></div>
						<div class="fright cr-user mar-tp20 z-10">
							<button type="button" class="btn btn-primary btn-style saverecord" <?php if(($CREATE_PRIV_TimeEntry_PERMISSION=='Y' || $UPDATE_PRIV_TimeEntry_PERMISSION=='Y') && ($msg == '')){?> id = "cmdSaveTimeSheet1" name = "cmdSaveTimeSheet1" <?php }else {?> disabled = "disabled" <?php } ?> > Save Time Sheet </button>
							<button type="button" class="btn btn-primary btn-style approve" <?php if(($CREATE_PRIV_TimeEntry_PERMISSION=='Y' || $UPDATE_PRIV_TimeEntry_PERMISSION=='Y')&& ($msg == '')){ ?> name = "CmdApproval" id = "CmdApproval" <?php }else {?> disabled = "disabled" <?php } ?>> Submit for Approval </button>
						</div>
						
						<!-- pagination start-->
						<div class="pagination-bx nxt-pre z-1">
							<div class="bs-example">
								<ul class="pagination">
									<?php if($msg==''){ ?>
									<li id = 'li-prev'><a href="javascript:void(0)">&laquo; Previous </a></li>
									<li id = 'li-next'><a href="javascript:void(0)">Next &raquo; </a></li>
									<?php 
									} ?>
								</ul>
							</div>
						</div>
						<!-- pagination end -->
						<div class="clear-both"></div>
						<div class="row">
							<h4 class="text-center"  id="msg_section1"><?php echo $msg; ?></h4>
						</div>
					</form>
					
				</div>
			</div>
            
            <div class="dash-strip">
                  
					<div class="fright">
				<?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						}
						$IsSearchTimeSheets = getvalue("cxs_ta_modules","VIEW_PRIV","where USER_ID = $LoginUserId and MODULE_NAME = 'Search TimeSheets'");
				?>          
					<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
									
					</div>
                </div>
        </div>		
    </section>
	<script type="text/javascript">
	$('.form_datetime').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});		
	
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if(KEY=="FindAliasData")
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					//alert(s1);
					$("#cmdFindAliasPopup").prop("disabled",false);
					
					document.getElementById("TablePopupList").innerHTML = s1;	
					document.getElementById("TablePopupHeading").style.display = "block";	
					document.getElementById("CheckboxPopup_SelectAll").checked=false;	
					
					var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
					if (POPUP_TABLE_ROW == 0)
					{
						document.getElementById("span_msg").innerHTML = "No Record Found.";
					}
					else
					{
						document.getElementById("span_msg").innerHTML = "";
						document.getElementById("cmdAliasAddItem").style.visibility = "visible";
					}
				}
				else if(KEY=="AddAliasRecord")
				{
					var s = http_request.responseText.trim();	//alert(s);
					var pos,s1="",row="";						
					if($("#CurrentParentRowNo").val()=="")
					{
						$('#DetailTable').append(s);
					}
					else
					{
						var AliasId = FindNumFromString(s);						
						AliasId = AliasId.toString();
						var l = AliasId.length;						
						s1 = s.substr(0, (s.length)-l); 
						$("#h_Taskid"+$("#CurrentParentRowNo").val()).val(AliasId);
						$("#Text_Task"+$("#CurrentParentRowNo").val()).val(s1);
						//var AliasId = FindNumFromString(s);
					}
					var TotalRows = $("#DetailTable tr").length-3; //last two total rows + one blank row					
					SetHolidaysDateDisable();
					
					TotalHours();
					
					/*var lastWorkRow = document.getElementById("DetailTable").rows.length;					
					lastWorkRow=lastWorkRow-3;					
					if(SelectedRows>1)
					{
						var counter=0;
						do{
							CheckRowStatus(lastWorkRow,"");
							lastWorkRow--;
							counter++;
						}while(counter!=SelectedRows);
					}
					else
					{
						CheckRowStatus(lastWorkRow,"");
					}
					/* ============= */
				/*	var TotalWeekDays =0;
					if ($('#Check_Weekends').length)	
					{
						if (document.getElementById("Check_Weekends").checked )	
						{
							TotalWeekDays =7;
						}	
						else
						{
							TotalWeekDays =5;
						}
					}
					else
					{
						TotalWeekDays =5;
					}
					alert("after call check row");
					var DetailTableRows = document.getElementById("DetailTable").rows.length;
					for(var i=1;i<=DetailTableRows-3;i++)
					{
						s = document.getElementById("Span_Task"+i).innerHTML;
						s=s.trim();
						if(s!='')
						{ 
							//document.getElementById("Text_Task"+i).value = s;							 
						}
						for (var j=1;j<=TotalWeekDays;j++)
						{
							s = document.getElementById("Span_Hours"+i+"_"+j).innerHTML;
							s=s.trim();
							if(s!='')
							{
								document.getElementById("Text_Hours"+i+"_"+j).value = s;
							}
							s1 = document.getElementById("Span_Status"+i+"_"+j).innerHTML;
							s1=s1.trim();
							if(s1!='')
							{
								document.getElementById("Text_Status"+i+"_"+j).value = s1;
							}
						}
					}
					//TotalHours();
					
					for(var i=1; i<=7; i++)
					{
					   (function(index){
						  
						   currentDateVal = $("#TopHeading"+index).text();
						   //alert(currentDateVal);
						  $.ajax({
							url:"ajax_time-entry.php",
							method:"POST",
							data:{REQUEST:"CheckEachDateValidation",CurrentDate:currentDateVal,PayPeriodId : $("#PayPeriodId").val()},
						   success:function(response)
						   {
								//var JSONObject = JSON.parse(response);
								//alert(response);
								s1 = response.trim(); //It checks date with TE - current period date that isdisable or not
								//s1 = JSONObject['IsDisable'];

								for(j=1;j<=DetailTableRows-3;j++)									
								{
									if(s1=="false")
									{ 
										//status = false;
										//$('#Text_Hours'+j+'_'+index).val(ShiftHours);
									//	$('#Text_Hours'+j+'_'+index).attr("disabled",false);
									//	$('#Text_Hours'+j+'_'+index).attr("readonly",false);
										//$('#Text_Hours'+j+'_'+index).removeAttr('name','none');
									}
									else
									{
										//status = true;  
										$('#Text_Hours'+j+'_'+index).attr("disabled",true);
										$('#Text_Hours'+j+'_'+index).attr("readonly",true);
										$('#Text_Hours'+j+'_'+index).removeAttr('name','none');
										
									}	
								}
								
							}
						  });
					   })(i);
					}
					TotalHours();
					*/
					$("#cmdAliasAddItem").prop("disabled",false);
					$("#ModalFindAlias .close").click();
				}
				else if (KEY=="Show-WBSDescription")
				{
					var s = http_request.responseText;										
					s = s.trim();						
					$('#WBSDescription-modal').modal();
					$("#Text_WBSDescription").val(s);					
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	$(document).ready(function()
	{
		$("#DivProjectDetails :input").prop("disabled", true);
		//$("#DivProjectDetails").find("input[type=text],[type=checkbox],TEXTAREA,BUTTON,SELECT").prop("disabled", true);
		//$(".renderClass :input").prop("disabled", true);			
		$('.my-link').bind('click', false);	
		var GetPeriodId = "<?php echo $GetPeriodId;	?>";		
		if(GetPeriodId!='')
		{
			$("#Combo_PeriodList").val(GetPeriodId);
			$("#Combo_PeriodList").change();			
		}
		
		//$("#Table-EyeIcon").DataTable({"searching": false});
		
    });	
	function GetHeaderId()
	{
		$.ajax({
				url : "ajax_time-entry.php",
				method : "POST",
				data :{REQUEST:"TEHeader-SearchData",ResourceId : $("#ResourceId").val(),PayPeriodId : $("#PayPeriodId").val()},
				success:function(response)
				{
					$("#hCurrentTEId").val(response.trim());
					/*if($("#hCurrentTEId").val()!="")	
					{
						CheckRowStatus(1,"Y");
					}*/
				}
			});
	}
	$('#cmdEnterTime').click(function()
	{	
		if($('#ResourceId').val()!="")
		{
			if($("#hCurrentTEId").val()=="")	
			{
				var RFirstName = '<?php echo $Resource_FirstName; ?>';
				var RLastName = '<?php echo $Resource_LastName; ?>';				
				RFirstName = RFirstName.substr(0,1);
				$("#Text_TEName").val(RFirstName + RLastName +'-'+$("#Combo_PeriodList :selected").text());
				$("#ModalSaveTimeSheet").modal('show');
			}
			if($("#Text_TEPrefix").val()!='')
			{
				$("#DivProjectDetails :input").prop("disabled", false);			
				$('.my-link').unbind('click', false);
				
				var TotalRows = $("#DetailTable tr").length-3; //last two total rows + one blank row
				var counter = 1;
				var TotalCols = 5;
				if ($('#Check_Weekends').length)
				{
					TotalCols=7;
				}
				var FalgCheckboxAllowUpdate="";
				for(var i=1;i<=TotalRows;i++)
				{
					$("#row"+i).find("INPUT[type=text],TEXTAREA").attr("readonly",true);
					
					for(var j=1;j<=TotalCols;j++)
					{
						if($("#span_Status"+i+"_"+j).text().trim()=="Working" || $("#span_Status"+i+"_"+j).text().trim()=="Rejected")
						{
							FalgCheckboxAllowUpdate="Y";
							break;
						}	
					}
					if(FalgCheckboxAllowUpdate=="Y")
					{
						$("#CheckboxInline"+i).prop("disabled",false);
					}
				} 
				/*
				<?php if( sizeof($TE_AliasList) > 0){}else{?>					
					CheckRowStatus(1,"Y");				
				<?php } ?>*/						
				if($("#hIsExistRecord").val()=="")
				{
					CheckRowStatus(1,"Y");	
				}				
				$('#cmdEnterTime').prop("disabled","true");
				//IsEntryAllowed();
			}
		}	
	});
	
	function CheckRowStatus(currentrow,FlagEnterTime)
	{ 
		var callCurrentRow = currentrow; 
		$.ajax({
			url:"ajax_time-entry.php",
			method:"POST",
			data:{REQUEST:"CheckRowStatus",StartDate:$("#TopHeading1").text()},
			success : function(response)
			{			
				//alert(response);				
				var JSONObject = JSON.parse(response);
				var j=0;
				var s1 = "";
				var TotalWeekDays=7;
				var TotalWeekDaysActual=0;
				var IsHolidayDisable="";
				var Flag_Shift="";
				var TaskStatus = "";
				Flag_Shift = "<?php if($AliasChildValues=="") {echo"display:none"; }?>";
				if(Flag_Shift=="")
				{
					Flag_Shift="display:block";
				}
				TotalWeekDaysActual = 5;
				if ($('#Check_Weekends').length)	
				{
					if (document.getElementById("Check_Weekends").checked )	
					{
						TotalWeekDaysActual = 7;
					}
				}				
				var EarnType = JSONObject['EarnType'];								
				if (currentrow==1 && FlagEnterTime=='Y')
				{
					if(FlagEnterTime == 'Y')
					{
						row = document.getElementById('row1');
						row.parentNode.removeChild(row);
						row = document.getElementById('row-WBSTotal1');
						row.parentNode.removeChild(row);
						row = document.getElementById('row-WBSTotal2');
						row.parentNode.removeChild(row);	
					}	
					for(var i=1;i<=7;i++)// loop is always 7 because its week days
					{
						j = i-1;
						s1 = JSONObject['WeekDays'][j];	
						$("#h_IsHoliday"+i).val(s1);
						s2 = JSONObject['CurrentWeek'][j];
						ShiftHours=""; 
						TaskStatus = "Working";
						if( typeof JSONObject['ShiftHours'] !== 'undefined' && JSONObject['ShiftHours'].length>0)	
						{
							ShiftHours = JSONObject['ShiftHours'][j]; //here first							
							if(ShiftHours=='-')
							{
								ShiftHours = "";
							}
						}
						if(s1=="Holiday" && s2 == $('#TopHeading'+i).text().trim()) 
						{ 
							IsHolidayDisable = JSONObject['HolidaysHourIsDisable'][j];
							/*s2 = JSONObject['ProjectTaskIsDisable'][j];
							if (s2=="true")
							{
								TaskStyle = "style = 'width : 85%;disabled:disabled' readonly onkeypress='return false'";
							}
							else if(s2=="false")
							{
								TaskStyle = "onfocus = 'SearchPopUp()' style = 'width : 85%;' readonly onkeypress='return false'";
							}*/
							TaskStyle = "style = 'width : 85%;disabled:disabled' readonly onkeypress='return false'";
							if(TotalWeekDaysActual==5 && (i==6||i==7))
							{
								IsStyle="style='display:none' class = 'week-end-cls'";
							}
							else
							{
								IsStyle="";
							}
							TaskStatus = JSONObject['ProjectTaskStatus'][j];
							row = "<tr id = 'row"+currentrow+"' "+IsStyle+">";
							row += "<td class='check-bx '><input type = 'hidden' name = 'h_rows[]' value = '"+currentrow+"'>"+
									//"<input type='checkbox' id='CheckboxInline"+currentrow+"' value='1'></td>"+
									"<td> <div class='form-group'>  <input type = 'hidden' id = 'h_Taskid"+currentrow+"' name = 'h_Taskid"+currentrow+"' value = ''>"+
									"<input type='text' id = '"+"Text_Task"+currentrow+"' name = 'Text_Task"+currentrow+"' class='input-sm'  value = '"+ JSONObject['ProjectTask'][j] +"'"+TaskStyle+" >"+	
									"   <input type='button' id = 'cmdTaskDescription"+currentrow+"' name = 'cmdTaskDescription"+currentrow+"' class='btn btn-primary btn-style-bdronly my-link' value = '...' onclick = 'TaskDescriptionPopUp("+currentrow+")' >"+
									"</div></td> <td></td>";
									//"<td style='"+Flag_Shift+"'><span><select  class='input-sm option_color'><?php echo $AliasChildValues; ?></select></span></td>";
							 
							row1= "";		
							for(var k=1;k<=7;k++)		
							{
								var tempHolidayStatus = $("#h_IsHoliday"+k).val();
								if (JSONObject['ProjectTaskStatus'][j]=="Holiday")
								{
									if (tempHolidayStatus!="Holiday")
									{
										TaskStatus = "";
									}
									else
									{
										TaskStatus = JSONObject['ProjectTaskStatus'][j];
									}
								}
								
								if(TotalWeekDaysActual==5 && (k==6||k==7))
								{
									IsStyle="style='display:none'";
								}
								else
								{
									IsStyle = "";
								}
								if(k==i)
								{
									if(IsHolidayDisable=='true')
									{
										setValue = "value='"+ShiftHours+"' disabled = 'disabled'";
									}
									else
									{
										setValue = "value='"+ShiftHours+"'";
									}
									s_string1 = "EnteredValue(&quot;"+currentrow+"&quot;,&quot;Span_Hours"+currentrow+"_"+k+"&quot;,this);";
									s_string2 = "return allowNegPosNumber(event);";
									//s_string2 = "";
								}
								else
								{
									setValue = "value='' disabled = 'disabled'";
									s_string1 = "";
									s_string2 = "return false";
								}
								
								row1 += "<td "+IsStyle+"id = 'Hours"+currentrow+"_"+k+"'>"+
									  "<div class='form-group text-right'>"+
									  "<span id = 'Span_Hours"+currentrow+"_"+k+"' style = 'display:none'>  </span>"+
									  "<input type='text' id = 'Text_Hours"+currentrow+"_"+k+"' name = 'Text_Hours"+currentrow+"_"+k+"' class='form-control text-right' onkeyup = '"+s_string1+"'"+
									  "onchange = 'TotalHours();' onkeypress='"+s_string2+"'  style = 'min-width :40px;'"+setValue+" ></div></td>"+
									  
									  "<td "+IsStyle+"id = 'Status"+currentrow+"_"+k+"'><div class='form-group'>"+
									  "<span id = 'span_Status"+currentrow+"_"+k+"' style = 'display:none'></span>"+
									  "<input type='text' id = 'Text_Status"+currentrow+"_"+k+"' name = 'Text_Status"+currentrow+"_"+k+"' class='form-control' maxlength='12' onkeyup = '"+s_string1+"' style = 'font-weight: bold;min-width : 50px;font-size:12px;' value = '"+TaskStatus+"' readonly></div></td>"+									  
									  "<td "+IsStyle+"id = 'Notes"+currentrow+"_"+k+"'><div><a href='#' class='btn btn-primary btn-style-bdronly ' data-toggle='modal' data-target='#note-modal'> <i class='fa fa-ellipsis-h' aria-hidden='true'></i> </a></div></td>";	  
							}
							row = row+row1; 
							
							row += "<td><div class='form-group text-right'><input type='text' id = 'Text_LineTotalHours"+currentrow+"' name = 'Text_LineTotalHours"+currentrow+"' class='form-control text-right' readonly style = 'min-width :40px;'></div></td>"+								   
								   "</tr>";
							$('#DetailTable').append(row);
						//	$('#Text_Task'+currentrow).val(JSONObject['ProjectTask'][j]);
							
							/*$('#Text_Hours'+currentrow+'_'+i).attr("disabled",true);
							$('#Text_Hours'+currentrow+'_'+i).attr("readonly",true);
							$('#Text_Hours'+currentrow+'_'+i).removeAttr('name','none');*/
							
							//$('#CmdApproval'+i).attr("disabled",true);
							//$('#CmdApproval'+i).removeAttr("id",'none');
							newrow = parseInt(currentrow)+1;
							currentrow = newrow;
						}
						else
						{
							if(FlagEnterTime!='Y') // it never comes here
							{
								$('#Text_Hours'+currentrow+'_'+i).val(ShiftHours);
								$('#Text_Hours'+currentrow+'_'+i).attr("disabled",false);
								$('#Text_Hours'+currentrow+'_'+i).attr("readonly",false);
							}
						}
					}
					//===== start auto populate or not in both data ======		
					var s1 = "";var i=0;		
					if (typeof JSONObject['AutoPopulateAlias']['Id'] !== 'undefined' && JSONObject['AutoPopulateAlias']['Id'].length > 0) 
					{
						while(i<JSONObject['AutoPopulateAlias']['Id'].length)
						{
							s1 = s1 + JSONObject['AutoPopulateAlias']['Id'][i]+ "|";i++;
						}
					}	
					TotalWeekDays =5;
					if ($('#Check_Weekends').length)	
					{
						if (document.getElementById("Check_Weekends").checked){TotalWeekDays =7;}	
					}
						
					var LastRowId = document.getElementById("DetailTable").rows.length; //$("#DetailTable").rows.length;
						
						//if (LastRowId>0){LastRowId++;}
					LastRowId++;
					$.ajax({ url:"ajax-TE-TableRows.php",method:"POST",
					data:{REQUEST:"Add-AliasRows",AliasId:s1,TotalWeekDays:TotalWeekDays,LastRowId:LastRowId,WorkshiftId:$('#CurrentWorkshiftId').val(),TimePolicyId:$('#CurrentTimePolicyId').val(),StartDate:$("#TopHeading1").text(),PayPeriodId:$("#PayPeriodId").val()},
					success : function(response1)
					{
						//alert(response1); 						
						$('#DetailTable').append(response1.trim());							
						SetHolidaysDateDisable();
						TotalHours();
					}
					});
					//===== end auto populate data ======
				}				
			}
		});	
	}
	
	function PopupCheckAll()
	{		
		var checkboxValue=document.getElementById('CheckboxPopup_SelectAll').checked;					
		var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
		var i=1;		
		for(i=1;i<=POPUP_TABLE_ROW;i++)
		{
			document.getElementById("PopupCheckboxInline"+i).checked = checkboxValue;		
		}
	}   
	
	function PopupCheckInline()
	{
		var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
		for(i=1;i<=POPUP_TABLE_ROW;i++)
		{
			if (document.getElementById("PopupCheckboxInline"+i).checked == false)
			{
				document.getElementById('CheckboxPopup_SelectAll').checked = false;
			}
		}
	}
	$("#cmdRefresh").click(function()
	{
		form1.submit();			
	});
	function timeConvert(n) 
	{
		var num = n;
		var substr = num.split('.');		
		var hours = parseFloat(substr[0]);
		var minutes = parseFloat(substr[1]);		
		
		if(!isNaN(minutes))
		{
			while (minutes>60)
			{
				minutes=minutes-60;
				hours++;
			}
			return hours+"."+minutes;
		}			
		else 
		{
			return hours;
		}
	}
	
	//$('#li-prev')	
	$("ul.pagination").on("click","li", function()
	{
		//$("#cmdEnterTime").attr("disabled",true);
		var Value = $(this).text();
		var result = Value.split(" ");
		
		var Event="";
		if (result[0] == "Next")
		{
			Event="Next";
		}
		else
		{
			Event="Previous";
		}
		var IsWeekEndAllowed = "N";
		if ($('#Check_Weekends').length)
		{
			if (document.getElementById("Check_Weekends").checked )	
			{
				IsWeekEndAllowed = "Y";
			}
		}
		$.ajax({
			url:"ajax_time-entry.php",
			method:"POST",
			data:{REQUEST:"MoveDates",StartDate:$("#TopHeading1").text(),EndDate:$("#TopHeading7").text(),PayPeriodId : $("#PayPeriodId").val(),Event:Event,IsWeekEndAllowed:IsWeekEndAllowed},
			success:function(response)
			{
				var JSONObject = JSON.parse(response);				
				if( typeof JSONObject['weekList'] !== 'undefined' && JSONObject['weekList'].length>0)
				{
					for(i=0;i<=6;i++)
					{
						j=i+1;		 			
						$("#TopHeading"+j).text(JSONObject['weekList'][i]);						
						$("#h_currentweek"+j).val(JSONObject['weekListHiddenValue'][i]);
						$("#IsAllowEntry"+j).val(JSONObject['IsAllowEntry'][i]);
					}
					$( "ul.pagination li" ).eq(1).show();
					$( "ul.pagination li" ).eq(0).show();
					$("#li-prev").show();
					$("#li-next").show();										
					FindTimeKeepingData("No popup",Event);
				}
				else
				{
				//	alert(Event);
					if(Event=="Next")
					{	
						$( "ul.pagination li" ).eq(1).hide();
						//$( "ul.pagination li" ).eq(0).show();						
						$("#li-next").hide();						
					}
					else if(Event=="Previous")
					{
						$( "ul.pagination li" ).eq(0).hide();
						//$( "ul.pagination li" ).eq(1).show();
						$("#li-prev").hide();					
					} 
				}
				$("#PayPeriodId").val(JSONObject['NewPeriodId']);				
				
				if($("#hCurrentTEId").val()=="" && $("#ResourceId").val()!="" && $("#PayPeriodId").val()!="")	
				{ 
					$("#hIsExistRecord").val('');
					GetHeaderId();
				}
				
				
				//var body = $("html, body");
				//	body.stop().animate({scrollTop:100}, 00, 'swing');
				// $("html, body").animate({ scrollTop: $(document).height() }, 0);
			}
		});
	}
	);
	
	</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/dataTables.bootstrap.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
	<script src="../js/jsfunctions.js" type="text/javascript"></script>
	<script src="../livesearch/bootstrap-select.min.js"></script>	
	<!--SAVE Time Sheet modals start -->
	<form id = "Form_TEHeader"  method="post">
		<div id = "ModalSaveTimeSheet" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1"  role="dialog" aria-labelledby="myLargeModalLabel">
		  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title " id="myModalLabel">Save Time Sheet </h4>
			  </div>
			  <div class="modal-body"> 
				<!-- field start-->
			
				<div class="col-sm-12">
				  <div class="cus-form-cont">				
						<div class="pr">
							<div class="cus-form-cont">
								<div class="col-sm-2 form-group">
									<label> Prefix </label>
									<input type="text" id = "Text_TEPrefix" name = "Text_TEPrefix" class="form-control requirefieldcls" style = "font-weight: normal;" maxlength="20" oninput="this.value=this.value.toUpperCase()" value = "<?php echo $TE_Prefix; ?>" required>
									<span id = "span_prefix" style = "color:red"></span>
								</div>
								<div class="col-sm-4 form-group">
									<label> User Name - Pay Period </label>
									<input type="text" id="Text_TEName" name="Text_TEName" class="form-control requirefieldcls"  style = "font-weight: normal;" value = "<?php echo substr($Resource_FirstName, 0, 1).$Resource_LastName."-$CurrentAccountingPeriod "; ?>" readonly>									
								</div>	 
								<div class="col-sm-6 form-group">
									<label> Description </label>
									<input type="text" id="Text_TEDescription" name="Text_TEDescription" class="form-control" style = "font-weight: normal;">
									
								</div>		
							</div>
						</div>                
				  </div>			  
				</div>
				
				<!-- end --> 
			  </div>
			  <div class="clear-both"></div>
			  <div class="modal-footer cr-user">
				<button type="button" id="cmdPopup1_Save" name="cmdPopup1_Save" class="btn btn-primary btn-style" >Save</button>
			  </div>
			</div>
		  </div>
		</div>
	</form>
	<!-- SAVE Time Sheet Modal  -->			
<script>
$("#cmdPopup1_Save").click(function()
{
	if($("#Text_TEPrefix").val()=="")
	{
		$("#span_prefix").text("Please fill prefix.");
		$("#Text_TEPrefix").focus();
	}
	else
	{
		var formdata = $("#Form_TEHeader").serialize();		
		
		$.ajax({
			url:"ajax_time-entry.php",
			method:"POST",
			data:{REQUEST:'TE-header-data',form : formdata,PayPeriodId : $("#PayPeriodId").val(),ResourceId : $("#ResourceId").val(),SupervisorId : $("#CurrentSupervisorId").val(),CurrentUserId : $("#hCurrentUId").val()},
			success:function(response)
			{
				//alert(response);
				$("#hCurrentTEId").val(response.trim());
				$("#span_TETitle").text("Name : " +$("#Text_TEPrefix").val()+"-"+$("#Text_TEName").val() + "[Open]");
				$("#ModalSaveTimeSheet").modal('hide');
				
				$("#DivProjectDetails :input").prop("disabled", false);
				$('.my-link').unbind('click', false);
				
				 $(".fetchData").each(function() {        
					//$(this).doSomejQueryWithElement();
					 $(this).find("input,button,textarea").attr("disabled", true); 
				});
				CheckRowStatus(1,"Y");				
				$('#cmdEnterTime').prop("disabled","true");
			}
		})
	}
});
$("#Text_TEPrefix").focusout(function()
{
	if($("#Text_TEPrefix").val()!="")
	{
		$("#span_prefix").text("");		
	}
});
	
	
function CheckValidations(Event,ColumnNo)
{
	var TotalTaskRows=document.getElementById("DetailTable").rows.length;
	TotalTaskRows=TotalTaskRows-3;//remove header and footer row from counting
	
	for(i=1;i<=TotalTaskRows;i++)
	{
		if($("#Text_Task"+i).val()!='' && $("#Combo_Shift"+i).val()=="" && $("#h_Taskid"+i).val()!=0)
		{
			a = "<div class='alert alert-success'>Select Shift of Task - " + $("#Text_Task"+i).val() + ".</div>";
			$("#msg_section").text('');			
			$("#msg_section").append(a);	
			
			$("#msg_section1").text('');			
			$("#msg_section1").append(a);	
			
			$("#Combo_Shift"+i).focus();
			return false;
		}
	}
	TotalDaysCols =7;	
	for(i=1;i<=TotalDaysCols;i++)
	{	
		if($('#Text_TotalTaskHours'+i).length)
		{
			if($('#Text_TotalTaskHours'+i).val()>24)
			{
				alert( $("#TopHeading"+i).html() + " WBS Total Hours must be less or equal to 24.");				
				return false;
			}
		}	
	}
	if(Event=='approval')
	{
		var BaseValueChecking = false;
		if ($('#CheckboxInline1').is(":checked"))
		{
			BaseValueChecking = true;
		}
		for(i=1;i<=TotalTaskRows;i++)
		{
			if($("#CheckboxInline"+i).length)
			{	
				if ($('#CheckboxInline'+i).is(":checked") == true)//BaseValueChecking
				{
				}
				else
				{
					TempStatus = $("#span_Status"+i+"_"+ColumnNo).text().trim();
					if(TempStatus=="Working" || TempStatus=="Rejected")
					{
						alert("You must select all projects in Submitted status for <Day>. Submitting all eligible records");
						return false;
					}
				}
			}	
		}
	}
	
	TotalDaysCols =7;	
	WorkshiftHours = 0;
	for(i=1;i<=TotalDaysCols;i++)
	{
		a = $("#h_WorkshifHours"+i).val();
		WorkshiftHours = WorkshiftHours +parseFloat(a);
	}
	var TotalEnteredHours = $("#Text_TotalFinal").val();
	if($.isNumeric(TotalEnteredHours))
	{
		if(TotalEnteredHours > WorkshiftHours  )
		{
			if ($("#hOvertimeAllowed").val()=="N")
			{
				a = "<div class='alert alert-success'>Your total hours for this week exceed workshift hours.  re-enter.</div>";
			}
			else
			{
				a = "<div class='alert alert-success'>Your total hours for this week exceed workshift hours.  Enter over time hours under  Overtime shift.</div>";
			}		
			$("#msg_section").text('');			
			$("#msg_section").append(a);
			
			$("#msg_section1").text('');			
			$("#msg_section1").append(a);
			return false; 
		}
		else
		{
			$("#msg_section").text('');
			$("#msg_section1").text('');							
		}
	}
}

function SaveRecords(RecordSaveDate,DisplayDate,Event)
{
	$("#DivProjectDetails :input").prop("disabled", false);
	var formdata = $("#form1").serialize();		
	//alert(formdata);
	$.ajax({
		url:"ajax_time-entry.php",
		method:"POST",
		data:{REQUEST:'TE-Grid-data',form : formdata,RecordSaveDate:RecordSaveDate,Event:Event},
		success:function(response)
		{
			//alert(response+" save record");
			var TotalTaskRows=$("#DetailTable tr").length-3;
			for(i=1;i<=TotalTaskRows;i++)
			{
				if($("#CheckboxInline"+i).length)
				{	
					if ($('#CheckboxInline'+i).is(":checked") )
					{
						$("#CheckboxInline"+i).prop('checked',false);						
						$("#Span_Task"+i).text($("#Text_Task"+i).val());
						$("#Span_Shift"+i).text($("#Combo_Shift"+i).val());
						for(j=1;j<=7;j++)
						{
							$("#Span_Hours"+i+"_"+j).text($("#Text_Hours"+i+"_"+j).val()) ;
						}	
						CheckRowObjectsVisibility(i);
					}
				}	
			}
			
			var msg = "";
			if(Event=="save")
			{
				msg = "Record has been saved.";
			}
			else
			{
				msg = "Record has been approved.";
				if(RecordSaveDate!='')
				{
					msg = "Record has been approved for dated "+DisplayDate+".";
				}
			}
			a = "<div class='alert alert-success'>"+msg+"</div>";
			$("#msg_section").text('');			
			$("#msg_section").append(a);

			$("#msg_section1").text('');			
			$("#msg_section1").append(a);
		}
	}); 
}
 
//$("#cmdSaveTimeSheet").click(function()
$(".saverecord").click(function()
{
	if(CheckValidations('save','') != false)
	{
		SaveRecords('','','save');
	}
});


$(document).on('click', '.approve', function () 
{
	
	var TotalRows = $("#DetailTable tr").length-2;	
	if(TotalRows == 1)
	{
		alert("Please Enter Project / Tasks");
		//$("#Text_Task1").focus();
		return false;
	}
	
	var id = $(this).prop('id');		
	var ButtonNo = "";	
	var Date1  = "";
	var Event = "";
	var Date2 ="";
	ButtonNo = FindNumFromString(id);
	var RowNoForUpdate = new Array();
	if(id=="cmdSaveTimeSheet"||id=="cmdSaveTimeSheet1")
	{
		Event = "save";
	}
	else
	{
		Event = "approval";
	}	
	if (ButtonNo == null) 
	{
		ButtonNo = "";
	}
	else
	{
		Date1 = $("#h_currentweek"+ButtonNo).val();						
		Date2 = $("#TopHeading"+ButtonNo).text();			
		
	}
	if(CheckValidations(Event,ButtonNo) != false)
	{
		SaveRecords(Date1,Date2,Event);
	}
	
	
	/*if($('#hIsPreApprove').val()=="Y" && CheckValidations() != false)
	{
		$.ajax({
			url:"ajax_time-entry.php",
			method:"POST",
			data:{REQUEST:'SaveRecordValidation',form : $("#form1").serialize()},
			success:function(response)
			{
				alert(response);
				var JSONObject = JSON.parse(response);
				
				$("#hPreApprovalType").val(JSONObject['PreApprovalType']);
				$("#hQuotaHours").val(JSONObject['QuotaHours']);
				var TotalHours = JSONObject['TotalHours'];
			}
		});
	}*/
	 
});


/*$("#note-modal").open(function(){
	alert("jo");
	var form = $("#FormNote");
	form.validate().resetForm();      // clear out the validation errors
		
});*/
$(".showModal").click(function(){
	var currentId = $(this).prop('id');
	
	$("#note-modal").modal('show');
});
function ShowPopup(CurrentValue)
{
	var comment1 = $("#h_comment"+CurrentValue).val();
	$("#PopupClickedElement").val('h_comment'+CurrentValue);
	$("#comment").val(comment1);
	$("#note-modal").modal('show');	
}

$("#cmdOK_Popup").click(function()
{
	var Element = $("#PopupClickedElement").val();
	$("#"+Element).val($("#comment").val());
	$("#note-modal").modal('hide');
});

function setSpanValue(ComboId,SpanId)
{
	$("#"+SpanId).text($("#"+ComboId).val());
}
$("#Checkbox_SelectAll").change(function()
{
	//var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
	var checkboxValue=$('#Checkbox_SelectAll').prop("checked");
	var i=1;
	var TotalRows = $("#DetailTable tr").length-3;
	for(i=1;i<=TotalRows;i++)
	{
		$("#CheckboxInline"+i).prop('checked',checkboxValue);				
		CheckRowObjectsVisibility(i);   		
	}	
});

$(document).on('click', '.GridCheckBox', function () {    
	var id = $(this).prop('id');
	var RowId = FindNumFromString(id);
	CheckRowObjectsVisibility(RowId);
});

function CheckRowObjectsVisibility(RowId)
{
	//alert(RowId); if(!$("#Span_Task"+RowId).is(':visible'))
	var TotalCols = 5;
	var FalgCheckboxAllowUpdate="";
	var RowUpdateStatus= new Array();
	var IsProjectShiftUpdate="";
	var EntryObjects="";
	var DisplayObjects="";
	var IsRowHolidayTask = "N";
	if ($('#Check_Weekends').length)
	{
		TotalCols=7;
	}
	
	//if($("#CheckboxInline"+RowId).checked)
	if ($('#CheckboxInline'+RowId).is(":checked"))
	{
		if($("#Span_Task"+RowId).is(':visible'))
		{
			if($("#h_Taskid"+RowId).val()==0)
			{
				IsRowHolidayTask =  "Y";
			}
			for(var j=1;j<=TotalCols;j++)
			{
				FalgCheckboxAllowUpdate="N";
				if($("#span_Status"+RowId+"_"+j).text().trim()=="" || $("#span_Status"+RowId+"_"+j).text().trim()=="Working" || $("#span_Status"+RowId+"_"+j).text().trim()=="Rejected")
				{
					FalgCheckboxAllowUpdate="Y";
					if(IsRowHolidayTask=="Y" )
					{
						FalgCheckboxAllowUpdate="N";
						tempValue = $("#Text_Hours"+RowId+"_"+j).val();
						if($.isNumeric(tempValue))
						{
							FalgCheckboxAllowUpdate="Y";
						}		
					}	
				}
				else
				{
					IsProjectShiftUpdate="N";
				}		
				RowUpdateStatus.push(FalgCheckboxAllowUpdate);
			}
			if(IsProjectShiftUpdate=="" && IsRowHolidayTask != 'Y')
			{
				$("#Span_Task"+RowId).hide();
				$("#Text_Task"+RowId).show();
				$("#Span_Shift"+RowId).hide();
				$("#Combo_Shift"+RowId).show();
				for(var j=1;j<=TotalCols;j++)
				{
					$("#Span_Hours"+RowId+"_"+j).hide();
					$("#Text_Hours"+RowId+"_"+j).prop("readonly",false);
					$("#Text_Hours"+RowId+"_"+j).show();
				}
			}
			else
			{
				for(var j=1;j<=TotalCols;j++)
				{
					if(RowUpdateStatus[j-1]=="Y")
					{
						$("#Span_Hours"+RowId+"_"+j).hide();
						$("#Text_Hours"+RowId+"_"+j).prop("readonly",false)
						$("#Text_Hours"+RowId+"_"+j).show();					
					}
				}
			}
		}
		else
		{
			$("#Span_Task"+RowId).show();
			$("#Text_Task"+RowId).hide();
			$("#Span_Shift"+RowId).show();
			$("#Combo_Shift"+RowId).hide();
			for(var j=1;j<=TotalCols;j++)
			{
				$("#Span_Hours"+RowId+"_"+j).show();
				$("#Text_Hours"+RowId+"_"+j).hide();
			}
		}
	}
	else
	{
		$("#Span_Task"+RowId).show();
		$("#Text_Task"+RowId).hide();
		$("#Span_Shift"+RowId).show();
		$("#Combo_Shift"+RowId).hide();
		for(var j=1;j<=TotalCols;j++)
		{
			$("#Span_Hours"+RowId+"_"+j).show();
			$("#Text_Hours"+RowId+"_"+j).hide();
		}
	}
}
/*$(document).on('focusout', doStuff);
$('.text-right').change(function(){
  if ($(this).val() > 24){
    alert("No numbers above 24");
    $(this).val('24');
  }
});*/ 

$("#Combo_FindPayPeriod").change(function()
{ 
	if ($('#Combo_FindPayPeriod').val()!='')	
	{
		$("#Check_CurrentPayPeriod").prop("checked",false);
	}
});
 
$("#Check_CurrentPayPeriod").change(function()
{
	if ($('#Check_CurrentPayPeriod').is(":checked") && $('#Combo_FindPayPeriod').val()!='' )		
	{
		$('#Combo_FindPayPeriod').val('');
		$("#Combo_FindPayPeriod").change();
	}
}
); 
 
$("#cmdFindResourcePopup").click(function()
{
	if($("#Combo_FindResourceId :selected").val() == "")
	{	alert("Please select resource name"); $("#Combo_FindResourceId").focus(); return false;	}		
	//var s1 = $('#Combo_FindPayPeriod').val(); 	
	var s1 = $('#Combo_FindPayPeriod').val(); 	
	var msg = "Either Pay period or Current pay period, only ONE can be used to find time for entered resource at a time.";
	if(s1!='' && ($('#Check_CurrentPayPeriod').is(":checked")))
	{
		alert(msg);
		return false;
	}
	else if(s1=='' && ($('#Check_CurrentPayPeriod').is(":checked")==false))	
	{
		alert("Please select pay period.");
		$("#Combo_FindPayPeriod").focus();
		return false;
	}
	FindTimeKeepingData('Y',"");	
});

function FindTimeKeepingData(IsPopup,Event1)
{
	//var s1 = $('#Combo_FindPayPeriod').val();  		
	var s2 = "";
	var s3 = "";
	var CurrentPayPeriod = "";
	var ResourceId = "";
	var PayPeriod = "";
	if(IsPopup=='Y')
	{ 
		if($('#Check_CurrentPayPeriod').is(":checked")) 
		{
			CurrentPayPeriod="Y";
		}
		ResourceId = $('#Combo_FindResourceId :selected').val();
		PayPeriod = $('#Combo_FindPayPeriod :selected').val();
	}
	else
	{
		ResourceId = $("#ResourceId").val();
		//s2 = $("th#TopHeading1").text(); 
		//s3 = $("th#TopHeading7").text(); 
		for(i=1;i<=7;i++)
		{
			if($("#IsAllowEntry"+i).val()=="Y")
			{
				s2 = $("#TopHeading"+i).text(); //th
				break;
			}
		}
		for(i=7;i>=1;i--)
		{
			if($("#IsAllowEntry"+i).val()=="Y")
			{
				s3 = $("#TopHeading"+i).text(); //th
				break;
			}
		}
		
		PayPeriod = $('#Combo_PeriodList :selected').val();
	}		
	$.ajax({
		url : "ajax_time-entry.php",
		method:"POST",		
		data:{REQUEST:"TimeKeeping",ResourceId:ResourceId,PayPeriod:PayPeriod,CurrentPayPeriod:CurrentPayPeriod,StartDate:s2,EndDate:s3,Event1:Event1 },
		success:function(response)
		{ 
			//alert(response);
			var JsonObject = JSON.parse(response);
			$("#span_TETitle").text("Name : ");
			$("#Span_ResourceName").text("");
			$("#Span_Payperiod").text("");
			$("#Span_Workshift").text("");
			$("#Span_Supervisor").text("");			
			//$("#ResourceId").val("");
		//	$("#PayPeriodId").val("");
			$("#CurrentWorkshiftId").val("");
			$("#CurrentSupervisorId").val("");
			$("#CurrentTimePolicyId").val("");
			//$("#hCurrentTEId").val("");
			$("#DetailTable").empty();		
			//$('th:nth-child(3)').hide();
			//document.getElementById('tableHeading3').style.display = 'none';
			$("#hIsExistRecord").val('');
			$("#cmdHeaderInfo").attr('data-content',"").data('bs.popover').setContent();
		//	$("#cmdHeaderInfo").popover('show');
			 
			 //$(this).attr('data-content', data);
			s1 = JsonObject['row']['TE_NAME']; 
			s2 = "";var i=0,j=0;
			var AliasHolidayList = "";
			if(Event1=="")
			{
				$("#PayPeriodId").val("");
			}
			if(s1!=null || s1!= undefined)
			{
				if(s1=='')
				{
					$("#span_TETitle").text('');
				}
				else
				{
					$("#span_TETitle").text( "Name : "+s1);
				}				
				$("#Span_ResourceName").text((JsonObject['row']['FIRST_NAME']) + ',' +(JsonObject['row']['LAST_NAME']));
				$("#Span_Payperiod").text((JsonObject['row']['PERIOD_NAME']));
				$("#Span_Workshift").text((JsonObject['row']['WorkshifName']));
				$("#Span_Supervisor").text((JsonObject['SupervisorName']));
				$("#ResourceId").val((JsonObject['row']['RESOURCE_ID']));
				if(Event1=="")
				{
					$("#PayPeriodId").val((JsonObject['row']['PAY_PERIOD_ID']));
					$("#Combo_PeriodList").val((JsonObject['row']['PAY_PERIOD_ID']));
				}	
				$("#CurrentWorkshiftId").val((JsonObject['row']['WORKSHIFT_ID']));
				$("#CurrentSupervisorId").val((JsonObject['row']['SUPREVISOR_ID']));
				$("#CurrentTimePolicyId").val((JsonObject['row']['TIMEMANAGEMENTPOLICY_ID']));
				if(s1!='')
				{
					$("#hCurrentTEId").val((JsonObject['row']['TE_ID']));
					$("#Text_TEPrefix").val(JsonObject['row']['TE_PREFIX']);
					var CreateDate = JsonObject['row']['CREATION_DATE'];
					var UpdateDate = JsonObject['row']['LAST_UPDATE_DATE'];
					var Content = "Creation Date : "+CreateDate+"\n Last Update Date : "+UpdateDate
					$("#cmdHeaderInfo").attr('data-content',Content).data('bs.popover').setContent();
				}
				else
				{
					$("#hCurrentTEId").val("");
					$("#Text_TEPrefix").val("");					
					$("#span_prefix").text("");
				}
				$('#cmdEnterTime').attr("disabled",false);
				
				if(JsonObject['row']['OVERTIME_ALLOWED']=='Y' || JsonObject['CTO_OVERTIME']=='Y')
				{
					//$('th:nth-child(3)').show();
					document.getElementById('tableHeading3').style.display = '';
				}			
				if (typeof JsonObject['AliasList'] !== 'undefined' && JsonObject['AliasList'].length > 0) 
				{
					while(i<JsonObject['AliasList'].length)
					{
						s2 = s2 + JsonObject['AliasList'][i]+ "|";i++;						
						
					}	
					$("#hIsExistRecord").val('Y');
				}
				
				if (typeof JsonObject['AliasHolidayList'] !== 'undefined' && JsonObject['AliasHolidayList'].length > 0) 
				{
					while(j<JsonObject['AliasHolidayList'].length)
					{
						AliasHolidayList = AliasHolidayList + JsonObject['AliasHolidayList'][j]+ "|";
						j++;
					}	
					$("#hIsExistRecord").val('Y');
				}				
				TotalWeekDays =5;
				if ($('#Check_Weekends').length)	
				{
					if (document.getElementById("Check_Weekends").checked )	
					{
						TotalWeekDays =7;
					}	
				}
				var TotalAddedRows = '';
				TotalAddedRows = JsonObject['AliasList'].length;
				var TotalVerticalHours = [];
				for(j=0;j<=6;j++)	
				{
					TotalVerticalHours[j]=0;
				}
				 
				$.ajax({ url:"ajax-TE-TableRows.php",method:"POST",
				data:{REQUEST:"Add-AliasRows",AliasId:s2,AliasHolidayList:AliasHolidayList,TotalWeekDays:TotalWeekDays,LastRowId:1,WorkshiftId:$('#CurrentWorkshiftId').val(),TimePolicyId:$('#CurrentTimePolicyId').val(),CallFrom:'TimeKeeping'},
				success : function(response1)
				{
					//alert(response1);
					$('#DetailTable').append(response1.trim());
					//TotalHours();	
					$("#DivProjectDetails :input").prop("disabled", true);		
					$('.my-link').bind('click', false);
					
					var TotalRows = $("#DetailTable tr").length-3; //last two total rows + one blank row					
					//alert(TotalRows);
					var TotalHoursValue = 0;
					for(j=0;j<=6;j++)
					{
						TotalVerticalHours[j]=0;
					}
					
					if(TotalRows>=1)
					{
						$("#hIsExistRecord").val('Y');
					}
					for(i=1;i<=TotalRows;i++)	
					{
						(function(index)
						{
							currentDateVal = $("#TopHeading"+index).text();
							var Hours="";
							var Status="";
							var Notes = "";
							var CurrentEntryDate="";
							var l=1;
							$("#Text_Task"+index).hide();
							$("#Span_Task"+index).show();
							$.ajax({
								url:"ajax_time-entry.php",
								method:"POST",
								data:{REQUEST:"SetDatewiseValue",HeaderId : $("#hCurrentTEId").val(),PayPeriodId : $("#PayPeriodId").val(),AliasId : $("#h_Taskid"+index).val(),RowNo:index,StartDate:$("#TopHeading1").text()},
								success:function(response2) 
								{
									//alert(response2); 
									//alert("AliasId "+ $("#h_Taskid"+index).val() + " RowNo " + index);
									var JsonObject2 = JSON.parse(response2);
									var TotalHours=0;
									var TotalJsonCol=0;
									if(JsonObject2!= null)
									{
										TotalJsonCol = JsonObject2.length;
									}
									for(j=0;j<=6;j++)	
									{
										$("#Text_Hours"+index+"_"+(j+1)).val('');
										$("#Text_Hours"+index+"_"+(j+1)).attr('value', '');										
										$("#Span_Hours"+index+"_"+(j+1)).text('');										
										$("#Text_Status"+index+"_"+(j+1)).val('');
										$("#span_Status"+index+"_"+(j+1)).text('');	
										$("#h_comment"+index+"_"+(j+1)).val('');
										$("#Combo_Shift"+index).val('');
										$("#Span_Shift"+index).text('');
										
										$("#Text_Hours"+index+"_"+(j+1)).hide();
										$("#Span_Hours"+index+"_"+(j+1)).show();										
										$("#Text_Status"+index+"_"+(j+1)).hide();
										$("#span_Status"+index+"_"+(j+1)).show();	
										$("#Combo_Shift"+index).hide();
										$("#Span_Shift"+index).show();	
									}
									for(j=0;j<TotalJsonCol;j++)	
									{
										k = j+1;
										Hours = JsonObject2[j]['HOURS'];
										Status = JsonObject2[j]['STATUS_FLAG'];																				
										Notes = JsonObject2[j]['COMMENT'];
										Shift = JsonObject2[j]['SHIFT'];
										CurrentEntryDate = JsonObject2[j]['ENTRY_DATE'];
										
										//TotalVerticalHours[j]= parseFloat(TotalVerticalHours[j])+ parseFloat(Hours);
										TotalHours = parseFloat(TotalHours)+parseFloat(Hours);
										if(Status=='W'){Status = "Working";}
										else if(Status=='H'){ Status = "Holiday";}
										else if(Status=='S'){ Status = "Submitted";}
										else if(Status=='A'){Status = "Approved";}
										else if(Status=='R'){Status = "Rejected";} 
										
										for(l=1;l<=7;l++)
										{
											if($("#h_currentweek"+l).val()==CurrentEntryDate)
											{
												break; 
											}
										}
									//document.getElementById("Text_Hours"+index+"_"+(j+1)).value = Hours;
										$("#Text_Hours"+index+"_"+(l)).val(Hours);
										$("#Text_Hours"+index+"_"+(l)).attr('value', Hours);										
										$("#Span_Hours"+index+"_"+(l)).text(Hours);										
										$("#Text_Status"+index+"_"+(l)).val(Status);
										$("#span_Status"+index+"_"+(l)).text(Status);	
										$("#h_comment"+index+"_"+(l)).val(Notes);
										$("#Combo_Shift"+index).val(Shift);
										$("#Span_Shift"+index).text(Shift);
										TotalVerticalHours[l-1]= parseFloat(TotalVerticalHours[l-1])+ parseFloat(Hours);
										
										$("#Text_Hours"+index+"_"+(l)).hide();
										$("#Span_Hours"+index+"_"+(l)).show();										
										$("#Text_Status"+index+"_"+(l)).hide();
										$("#span_Status"+index+"_"+(l)).show();	
										$("#Combo_Shift"+index).hide();
										$("#Span_Shift"+index).show();	
										
										for(k=1;k<=7;k++)
										{
											temp = parseFloat(TotalVerticalHours[k-1]);
											$("#Text_TotalTaskHours"+k).val(temp);
											
										}	
									}
									$("#Text_LineTotalHours"+index).val(TotalHours);
									//IsEntryAllowed();
									FinalTotal();
								}
							  });
						})(i);
					}
					//TotalHours();
					
				}
				});		
				
			}
			else // if TE name undefined or null
			{				
				$("#hCurrentTEId").val("");
				$("#span_TETitle").text('');
				s2="";
				TotalWeekDays =5;
				$.ajax({ url:"ajax-TE-TableRows.php",method:"POST",
				data:{REQUEST:"Add-AliasRows",AliasId:s2,TotalWeekDays:TotalWeekDays,LastRowId:1,WorkshiftId:$('#CurrentWorkshiftId').val(),TimePolicyId:$('#CurrentTimePolicyId').val()},
				success : function(response1)
				{
					//alert(response1);
					$('#DetailTable').append(response1.trim());							
					TotalHours();	
					
					$("#DivProjectDetails :input").prop("disabled", true);		
					$('.my-link').bind('click', false);
					//$('#cmdEnterTime').prop("disabled","false");	
				}
				});
			}	
				
			if(($("#hCurrentTEId").val()==""||$("#hCurrentTEId").val()==undefined) && $("#ResourceId").val()!="" )	//&& $("#PayPeriodId").val()!=""
			{ 
				$("#hIsExistRecord").val('');
				GetHeaderId();
			}
			
			if( $("#Span_Workshift").text()=='')
			{
				a = "<div class='alert alert-success'>No Records Found</div>";
				$("#msg_section").text('');
				$("#msg_section").append(a);
				
				$("#msg_section1").text('');			
				$("#msg_section1").append(a);
			}
			else			
			{
				$("#msg_section").text('');
				$("#msg_section1").text('');							
			}		
			
			if(JsonObject['row']['msg'] == 'Not match')
			{	//alert(JsonObject['row']['msg']);
				a = "<div class='alert alert-success'>You have not permission111 to access "+$("#Combo_FindPayPeriod option:selected").text();+"</div>";
				$("#msg_section").text('');
				$("#msg_section").append(a);
				
				$("#msg_section1").text('');			
				$("#msg_section1").append(a);
				$("#cmdEnterTime").attr("disabled",true); 
			} 
			else if(JsonObject['row']['msg']!='')
			{
				a = JsonObject['row']['msg'];
				$("#msg_section").text('');
				$("#msg_section").append(a);
				
				$("#msg_section1").text('');			
				$("#msg_section1").append(a);
				$("#cmdEnterTime").attr("disabled",true);
			}
			$("#FindPopup").modal('hide');
		}
	});
}

$("#Combo_PeriodList").change(function()
{
	$("#PayPeriodId").val($("#Combo_PeriodList :selected").val());	
	
	$.ajax({
			url:"ajax_time-entry.php",
			method:"POST",
			data:{REQUEST:"ChangePeriod",PayPeriodId : $("#PayPeriodId").val()},
			success:function(response)
			{
				//alert(response);
				var JSONObject = JSON.parse(response);
				
				if( typeof JSONObject['weekList'] !== 'undefined' && JSONObject['weekList'].length>0)
				{
					for(i=0;i<=6;i++)
					{
						j=i+1;					
						$("#TopHeading"+j).html(JSONObject['weekList'][j]);				//th		
						$("#h_currentweek"+j).val(JSONObject['weekListHiddenValue'][j]);
						$("#IsAllowEntry"+j).val(JSONObject['IsAllowEntry'][j]);						
					}
					$( "ul.pagination li" ).eq(1).show();
					$( "ul.pagination li" ).eq(0).show();
					$("#li-prev").show();
					$("#li-next").show();
					FindTimeKeepingData("No popup","Previous");
				}				
			}
		});	
});

function IsEntryAllowed()
{
	var TotalRows = $("#DetailTable tr").length-2;
	var status = "";
	 for(j=1;j<=7;j++)
	 {
		if($("#IsAllowEntry"+j).val()=="N") 
		{
			for(i=1;i<=TotalRows;i++)	
			{
				$("#Text_Hours"+i+"_"+j).attr("disabled",true); 
			}			 
		}
	}				
}
$("#cmdCancel").click(function()
{
	if ( $("#Checkbox_SelectAll").is(":checked") )
	{
		$("#Checkbox_SelectAll").prop("checked",false);
		$("#Checkbox_SelectAll").change();
	}
	else
	{
		var TotalRows = $("#DetailTable tr").length-3;
		for(i=1;i<=TotalRows;i++)	
		{
			if( $("#CheckboxInline"+i).length )
			{
				if ($('#CheckboxInline'+i).is(":checked") )
				{
					CheckRowObjectsVisibility(i);
					$("#CheckboxInline"+i).prop ('checked',false);
				}
			} 
		}
	}
});

function FinalTotal()
{
	var TotalTaskRows=document.getElementById("DetailTable").rows.length;
	TotalTaskRows=TotalTaskRows-2;
	var TotalHoursVertical=0;
	for(j=1;j<=TotalTaskRows;j++)
	{	
		CurrentHours = document.getElementById("Text_LineTotalHours"+j).value;							
		if (CurrentHours!='')
		{
			CurrentHours = parseFloat(CurrentHours);
		}
		else
		{
			CurrentHours=0;
		}
		TotalHoursVertical = TotalHoursVertical+CurrentHours;			
	}				
	document.getElementById("Text_TotalFinal").value = TotalHoursVertical;				
}
function SetHolidaysDateDisable()
{
	var TotalWeekDays =5;
	if ($('#Check_Weekends').length)	
	{
		if (document.getElementById("Check_Weekends").checked )	
		{
			TotalWeekDays =7;
		}	
	}
	var lastWorkRow = document.getElementById("DetailTable").rows.length;					
	lastWorkRow=lastWorkRow-3;
	
	for (var j=1;j<=TotalWeekDays;j++)
	{
		if($("#h_IsHoliday"+j).val()=="Holiday")
		{
			for(var i=1;i<=lastWorkRow;i++)
			{
				$("#Text_Hours"+i+"_"+j).attr("disabled",true);
				$("#Text_Status"+i+"_"+j).val("Holiday");								
			}
		}	
	}
}
$(".TopHeadingEyeIcon").click(function()
{
	var CurID = $(this).attr("id");	
	var num = FindNumFromString(CurID);
	var SelectedCol = $("#TopHeading"+num).text();	
	var testcol =  $("#h_currentweek"+num).val();
	$("#auditdate_qry").val(SelectedCol);
	
	//alert(num);
	//alert(SelectedCol);
	//alert(testcol);
	
	var weekdays = new Array(7);
	weekdays[0] = "Sunday";
	weekdays[1] = "Monday";
	weekdays[2] = "Tuesday";
	weekdays[3] = "Wednesday";
	weekdays[4] = "Thursday";
	weekdays[5] = "Friday";
	weekdays[6] = "Saturday";
	
	var month = new Array();
	month[0] = "January";
	month[1] = "February";
	month[2] = "March";
	month[3] = "April";
	month[4] = "May";
	month[5] = "June";
	month[6] = "July";
	month[7] = "August";
	month[8] = "September";
	month[9] = "October";
	month[10] = "November";
	month[11] = "December";
	
	var current_date = new Date(testcol);
	
	current_date.setDate(current_date.getDate() + 1);
	
	//alert(current_date);
	
	var weekday_value = current_date.getDay();
	var FullDate = weekdays[weekday_value]+", "+month[current_date.getMonth()] +" " + current_date.getDate()+", "+ current_date.getFullYear();
	
	//alert(FullDate);
	
	$("#div_AuditDate").text(FullDate);
	$("#td_Hhours").html('');
	$("#td_HStatus").html('');
	$("#td_projectWBS").html('');
	/*alert(SelectedCol);
	alert($("#hCurrentTEId").val());
	alert($("#ResourceId").val());
	alert($("#PayPeriodId").val());
	*/
	$.ajax({
				url : "ajax_time-entry.php",
				method : "POST",
				data :{REQUEST:"AuditDetails",AuditDate : SelectedCol,CurrentTEId : $("#hCurrentTEId").val(),ResourceId : $("#ResourceId").val(),PayPeriodId : $("#PayPeriodId").val()},
				success:function(response)
				{
					//alert(response);
					var JSONObject = JSON.parse(response);					
					$("#td_HEmpNum").html(JSONObject['EMPLOYEE_NUMBER']);
					$("#td_HEmpName").html(JSONObject['EMPLOYEE_NAME']);
				//	$("#td_Hhours").html(JSONObject['cxs_period_audit']['EMPLOYEE_NUMBER']);
				//	$("#td_HStatus").html(JSONObject['cxs_period_audit']['EXP_STATUS']);
					var TotalAlias = JSONObject['TotalAlias'];					
					var newOption="";	
					$("#Combo_EyeIconH-Alias").empty();
					newOption = $('<option value=""> - Select Alias - </option>');
					$('#Combo_EyeIconH-Alias').append(newOption);
					for(i=0;i<TotalAlias;i++)
					{
						AliasCaption = JSONObject["AliasCaption"][i];
						AliasValue = JSONObject["AliasValue"][i];
						newOption = $('<option value="'+AliasValue+'">'+AliasCaption+'</option>');
						$('#Combo_EyeIconH-Alias').append(newOption);
					}
					$("#Table-EyeIcon tr").empty();
					row = "<thead><tr> <th> Resource Name</th> <th> Employee Number </th> <th> Hours </th><th> Status </th> <th> Last Update Date </th> <th> Updated By Resource Name </th> <th> Updated By Resource Number </th> </tr></thead>";
					
				}
			});
	$('#EyeIcon-modal').modal();	
});

$("#Combo_EyeIconH-Alias").change(function()
{
	//data :{REQUEST:"AuditAliasChange",AuditDate : $("#div_AuditDate").html(),CurrentTEId : $("#hCurrentTEId").val(),ResourceId : $("#ResourceId").val(),PayPeriodId : $("#PayPeriodId").val(),AliasId : $("#Combo_EyeIconH-Alias").val()},
	if($("#Combo_EyeIconH-Alias").val()!='')
	{
		$.ajax({
				url : "ajax_time-entry.php",
				method : "POST",
				data :{REQUEST:"AuditAliasChange",AuditDate : $("#auditdate_qry").val(),CurrentTEId : $("#hCurrentTEId").val(),ResourceId : $("#ResourceId").val(),PayPeriodId : $("#PayPeriodId").val(),AliasId : $("#Combo_EyeIconH-Alias").val()},
				success:function(response)
				{	
					var JSONObject = JSON.parse(response);
					//alert(response);
					$("#td_Hhours").html(JSONObject['Hours']);
					$("#td_HStatus").html(JSONObject['StatusFlag']);
					$("#td_projectWBS").html(JSONObject['WBSValue']);		
					
					var TotalRecords = JSONObject['TotalRecords'];	
					row = "";
					
					$("#Table-EyeIcon tr").empty();
					row = "<thead><tr> <th> Resource Name</th> <th> Employee Number </th> <th> Hours </th><th> Status </th> <th> Last Update Date </th> <th> Updated By Resource Name </th> <th> Updated By Resource Number </th> </tr></thead>";
					
					for(i=0;i<TotalRecords;i++)
					{	
						row += "<tr>";
						row += "<td>"+JSONObject[i]["EMPLOYEE_NAME"]+"</td>";
						row += "<td>"+JSONObject[i]["EMPLOYEE_NUMBER"]+"</td>";
						row += "<td>"+JSONObject[i]["EXPENDITURE_QTY"]+"</td>";
						row += "<td>"+JSONObject[i]["STATUS_FLAG"]+"</td>";
						row += "<td>"+JSONObject[i]["LAST_UPDATE"]+"</td>";
						row += "<td>"+JSONObject[i]["UPDATEDBY_ENAME"]+"</td>";
						row += "<td>"+JSONObject[i]["UPDATEDBY_EMPNO"]+"</td>";
						row += "</tr>";
					}						
					$('#Table-EyeIcon').append(row);
				}
			});
	}
	else
	{
		$("#td_Hhours").html('');
		$("#td_HStatus").html('');
		$("#td_projectWBS").html('');
		$("#Table-EyeIcon tr").empty();
		row = "<thead><tr> <th> Resource Name</th> <th> Employee Number </th> <th> Hours </th><th> Status </th> <th> Last Update Date </th> <th> Updated By Resource Name </th> <th> Updated By Resource Number </th> </tr></thead>";
		$('#Table-EyeIcon').append(row);			
	}
	
});
</script>	
</body>

</html>