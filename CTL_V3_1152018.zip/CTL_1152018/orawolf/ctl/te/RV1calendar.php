<?php ob_start (); 
	 
	include("te-functions.php");
	include("sitename.php");
	check_login();
?>

<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Calendar</title>
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	
	<script src="../datepicker/jquery.js"></script>
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />
	<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet"> 
	    
    <link href="fullcalendar.css" rel="stylesheet">
</head>
<script>
function OpenAuditEntryForm()
{
	$("#DailyAuditPopUp").modal();
}
function OpenSupervisorNoteForm()
{
	$("#SupervisorNotePopUp").modal();
}
</script>
<body>

<!-- Audit pop up  start -->
	
    <div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "DailyAuditPopUp" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Daily Audit </h4>					
				</div>
				<div class="modal-body"> 
				<!-- field start-->
					<div class="data-bx">
						<div class="table-responsive">			
						  <!-- find block start-->	
							<input type = "hidden" id = "auditdate_qry" value = "" >
							<h3> <div id = "div_AuditDate" class="text-center" > </div></h3>
							<table id = "Table-EyeIconH1" class="table table-bordered mar-cont">
								<thead>								
									<tr>
										<th> Employee Number</th>
										<th> Employee Name </th>									
										<th> Hours  </th>
										<th> Status  </th>									
									</tr>
								</thead>
								<tbody>
									<tr>
										<td id="td_HEmpNum" >  </td>
										<td id="td_HEmpName">  </td>
										<td id="td_Hhours">  </td>
										<td id="td_HStatus">  </td>
									</tr>									
								</tbody> 
							</table>
							<table id = "Table-EyeIconH2" class="table table-bordered mar-cont">
								<thead>								
									<tr>
										<th> Alias Name</th>
										<th> Project WBS </th>																			
									</tr>
								</thead>
								<tbody>
									<tr>
										<td style = "width : 35%"> 
										<div>
											<select id = "Combo_EyeIconH-Alias" class='form-control' readonly >
												<option class = 'option_color' value=''> - Alias - </option>
											</select>
										</div>
										</td>
										<td id = "td_projectWBS">  </td>										
									</tr>									
								</tbody> 
							</table>
							 <table id = "Table-EyeIcon" class="table table-bordered mar-cont">
								<thead>								
								  <tr>
									<th> Resource Name</th>
									<th> Employee Number </th>
									<th> Hours </th>
									<th> Status </th>
									<th> Last Update Date </th>
									<th> Updated By Resource Name </th>
									<th> Updated By Resource Number </th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td id = "td_resourceName">  </td>
									<td id = "td_EmpName">  </td>
								    <td id = "td_Hours"> </td>
									<td id = "td_Status">  </td>
									<td id = "td_LastUpdate">  </td>
									<td id = "td_UpdateByResourceName">  </td>
									<td id = "td_UpdateByResourceNo"> </td>
								  </tr>	
								  
								  
								</tbody> 
							</table>		
                    <!--find -block end -->				
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
				 	<button type="button" id="cmdFindResourcePopup" name="cmdFindResourcePopup" class="btn btn-primary btn-style" >Find</button>
				
				</div>
			</div>
		</div>
	</div>
	
    <!-- Audit pop up end -->
	
	<!-- Notes detail pop up  start -->
    <div id="SupervisorNotePopUp" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-sm cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <!-- field start-->
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <form id = "FormNote" >
						<div class="col-sm-12">						
							<div class="cus-form-cont">
								<div class="form-group">
									<label> Notes </label>
									<textarea class="form-control" rows="5" id="comment" maxlength="150"></textarea>
									<input type = "hidden" id = "PopupClickedElement" >
								</div>
							</div>
						</div>
					</form>	
                    <!-- end -->
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                    <button type="button" class="btn btn-primary btn-style" id = "cmdOK_Popup"> OK </button>
                </div>
            </div>
        </div>
    </div>
    <!-- Notes detail pop up end -->
	
<?php
$s_CalenderCellRows = "";
$s_CalenderCellRows = "<div style='position:relative;background-color:#4688A8;align:centr;color:white;height:25px;padding-top:5px;padding-left:10px;font-size:13px;font-weight:bold;'>
							<a href='#' style='color:white;text-decoration:underline;' onclick='OpenAuditEntryForm(); return false;' >Daily Audit</a>
					   </div>
					   <div style='position:relative;background-color:#F7000F;align:centr;color:white;height:25px;padding-top:5px;padding-left:10px;font-size:13px;font-weight:bold;'>Rejected [#i_value#]</div>
					   <div style='position:relative;background-color:#008324;align:centr;color:white;height:25px;padding-top:5px;padding-left:10px;font-size:13px;font-weight:bold;'>Approved [8]</div>
					   <div style='position:relative;background-color:#F8A233;align:centr;color:white;height:25px;padding-top:5px;padding-left:10px;font-size:13px;font-weight:bold;'>
							<a href='#' style='color:white;text-decoration:underline;' onclick='OpenSupervisorNoteForm(); return false;' >Supervisor Notes</a>
					   </div>
					   <div style='position:relative;background-color:#408AA7;align:centr;color:white;height:25px;padding-top:5px;padding-left:10px;font-size:13px;font-weight:bold;'>Submitted [8]</div>";
?>
															
<div class="container">
    <div class="box">
        <div class="header"><h4>Calendar</h4></div>
        <div class="content"> 
            <div id="calendar" class="fc">
				<div class="fc-header" style="width:100%">
					<div>
						<div class="fc-header-left">
							<span class="fc-button fc-button-prev fc-state-default fc-corner-left">
								<span class="fc-button-inner">
									<span class="fc-button-content"></span>
								</span>
							</span>
							<span class="fc-button fc-button-next fc-state-default fc-corner-right">
								<span class="fc-button-inner">
									<span class="fc-button-content"></span>
								</span>
							</span>
						</div>
						<div class="fc-header-center">
							<span>
								<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary " style="margin-top:-5px;margin-left:20px;width:90px;"> Previous </button>
							</span>
							<span class="fc-header-title">
								<h4 style="margin-top:5px;margin-left:20px;">October 2018</h4>
							</span>
							<span>
								<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary " style="margin-top:-5px;margin-left:20px;width:90px;"> Next </button>								
							</span>
						</div>
						<div class="fc-header-right"></div>
					</div>
				</div>
				<div class="fc-content" style="position: relative; min-height: 1px;">
					<div class="fc-view fc-view-month fc-grid" style="position: relative; -moz-user-select: none;" unselectable="on">
						<table class="fc-border-separate" style="width:100%" cellspacing="0">
							<thead>
								<tr class="fc-first fc-last">
									<th class="fc-sun fc-widget-header fc-first" style="width: 166px;">Sun</th>
									<th class="fc-mon fc-widget-header" style="width: 165px;">Mon</th>
									<th class="fc-tue fc-widget-header" style="width: 165px;">Tue</th>
									<th class="fc-wed fc-widget-header" style="width: 165px;">Wed</th>
									<th class="fc-thu fc-widget-header" style="width: 165px;">Thu</th>
									<th class="fc-fri fc-widget-header" style="width: 165px;">Fri</th>
									<th class="fc-sat fc-widget-header fc-last">Sat</th>
								</tr>
							</thead>
							<tbody>
								<tr class="fc-week0 fc-first">
									<td class="fc-sun fc-widget-content fc-day0 fc-first fc-other-month">
										<div style="min-height: 139px;">
											<div class="fc-day-number">30</div>
											<div class="fc-day-content">
												<div style="position: relative; height: 72px;">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-mon fc-widget-content fc-day1">
										<div>
											<div class="fc-day-number">1</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "0", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-tue fc-widget-content fc-day2">
										<div>
											<div class="fc-day-number">2</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "1", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-wed fc-widget-content fc-day3">
										<div>
											<div class="fc-day-number">3</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "0", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-thu fc-widget-content fc-day4">
										<div>
											<div class="fc-day-number">4</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "1", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-fri fc-widget-content fc-day5">
										<div>
											<div class="fc-day-number">5</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "0", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-sat fc-widget-content fc-day6 fc-last">
										<div>
											<div class="fc-day-number">6</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "1", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
								</tr>
								<tr class="fc-week1">
									<td class="fc-sun fc-widget-content fc-day7 fc-first">
										<div style="min-height: 139px;">
											<div class="fc-day-number">7</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "0", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-mon fc-widget-content fc-day8">
										<div>
											<div class="fc-day-number">8</div>
											<div class="fc-day-content">
												<?php echo str_replace("#i_value#", "1", $s_CalenderCellRows); ?>
											</div>
										</div>
									</td>
									<td class="fc-tue fc-widget-content fc-day9">
										<div>
											<div class="fc-day-number">9</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-wed fc-widget-content fc-day10">
										<div>
											<div class="fc-day-number">10</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-thu fc-widget-content fc-day11">
										<div>
											<div class="fc-day-number">11</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-fri fc-widget-content fc-day12">
										<div>
											<div class="fc-day-number">12</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-sat fc-widget-content fc-day13 fc-last">
										<div>
											<div class="fc-day-number">13</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
								</tr>
								<tr class="fc-week2">
									<td class="fc-sun fc-widget-content fc-day14 fc-first">
										<div style="min-height: 139px;">
											<div class="fc-day-number">14</div>
											<div class="fc-day-content">
												<div style="position: relative; height: 24px;">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-mon fc-widget-content fc-day15">
										<div>
											<div class="fc-day-number">15</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-tue fc-widget-content fc-day16">
										<div>
											<div class="fc-day-number">16</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-wed fc-widget-content fc-day17">
										<div>
											<div class="fc-day-number">17</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-thu fc-widget-content fc-day18">
										<div>
											<div class="fc-day-number">18</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-fri fc-widget-content fc-day19">
										<div>
											<div class="fc-day-number">19</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-sat fc-widget-content fc-day20 fc-last">
										<div>
											<div class="fc-day-number">20</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
								</tr>
								<tr class="fc-week3">
									<td class="fc-sun fc-widget-content fc-day21 fc-first">
										<div style="min-height: 139px;">
											<div class="fc-day-number">21</div>
											<div class="fc-day-content">
												<div style="position: relative; height: 48px;">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-mon fc-widget-content fc-day22">
										<div>
											<div class="fc-day-number">22</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-tue fc-widget-content fc-day23">
										<div>
											<div class="fc-day-number">23</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-wed fc-widget-content fc-day24">
										<div>
											<div class="fc-day-number">24</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-thu fc-widget-content fc-day25">
										<div>
											<div class="fc-day-number">25</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-fri fc-widget-content fc-day26">
										<div>
											<div class="fc-day-number">26</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-sat fc-widget-content fc-day27 fc-last">
										<div>
											<div class="fc-day-number">27</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
								</tr>
								<tr class="fc-week4">
									<td class="fc-sun fc-widget-content fc-day28 fc-first">
										<div style="min-height: 139px;">
											<div class="fc-day-number">28</div>
											<div class="fc-day-content">
												<div style="position: relative; height: 24px;">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-mon fc-widget-content fc-day29">
										<div>
											<div class="fc-day-number">29</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-tue fc-widget-content fc-day30">
										<div>
											<div class="fc-day-number">30</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-wed fc-widget-content fc-day31">
										<div>
											<div class="fc-day-number">31</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-thu fc-widget-content fc-day32 fc-other-month">
										<div>
											<div class="fc-day-number">1</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-fri fc-widget-content fc-day33 fc-other-month">
										<div>
											<div class="fc-day-number">2</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
									<td class="fc-sat fc-widget-content fc-day34 fc-last fc-other-month">
										<div>
											<div class="fc-day-number">3</div>
											<div class="fc-day-content">
												<div style="position:relative">&nbsp;</div>
											</div>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>	
				</div>
			</div>						
        </div> 
    </div>
</div> <!-- /container -->

<script>
$(".opendailyauditform").click(function()
{
	alert("hi");
	//$("#DailyAuditPopUp").modal('show');
});
</script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../js/jquery.min.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jsfunctions.js" type="text/javascript"></script>
<script src="../livesearch/bootstrap-select.min.js"></script>
    
</body></html>