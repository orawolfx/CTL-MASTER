<?php

include('../conn.php');



if($_REQUEST['REQUEST'] == "Show-WBSDescription")
   {

		$AliasId = $_REQUEST['AliasId'];

		$WBSValue = "";

		$SelectQuery = "select * FROM cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where cxs_aliases.ALIAS_ID = $AliasId  ";

		$Result = mysql_query($SelectQuery);		

		while($row = mysql_fetch_array($Result))

		{

			$Segment1 =  $row['SEGMENT1'];	

			$Segment2 =  $row['SEGMENT2'];

			$Segment3 =  $row['SEGMENT3'];

			$Segment4 =  $row['SEGMENT4'];

			$Segment5 =  $row['SEGMENT5'];	

			$Segment6 =  $row['SEGMENT6'];	

			$Segment7 =  $row['SEGMENT7'];

			$Segment8 =  $row['SEGMENT8'];

			$Segment9 =  $row['SEGMENT9'];

			$Segment10 =  $row['SEGMENT10'];	

			$Segment11 =  $row['SEGMENT11'];	

			$Segment12 =  $row['SEGMENT12'];

			$Segment13 =  $row['SEGMENT13'];

			$Segment14 =  $row['SEGMENT14'];

			$Segment15 =  $row['SEGMENT15'];	

		}

		if ($Segment1!="")

		{

			$WBSValue = $Segment1;

			$WBSValue .= ($Segment2!='')?".$Segment2":"";

			$WBSValue .= ($Segment3!='')?".$Segment3":"";

			$WBSValue .= ($Segment4!='')?".$Segment4":"";

			$WBSValue .= ($Segment5!='')?".$Segment5":"";

			$WBSValue .= ($Segment6!='')?".$Segment6":"";

			$WBSValue .= ($Segment7!='')?".$Segment7":"";

			$WBSValue .= ($Segment8!='')?".$Segment8":"";

			$WBSValue .= ($Segment9!='')?".$Segment9":"";

			$WBSValue .= ($Segment10!='')?".$Segment10":"";

			$WBSValue .= ($Segment11!='')?".$Segment11":"";

			$WBSValue .= ($Segment12!='')?".$Segment12":"";

			$WBSValue .= ($Segment13!='')?".$Segment13":"";

			$WBSValue .= ($Segment14!='')?".$Segment14":"";

			$WBSValue .= ($Segment15!='')?".$Segment15":"";

		}

		echo $WBSValue;

	}

	if($_REQUEST['REQUEST'] == "Add-AliasRows")

	{

		$AliasId = $_REQUEST['AliasId'];//*

		$AliasHolidayList = $_REQUEST['AliasHolidayList'];

		$TotalWeekDaysActual=$_REQUEST['TotalWeekDays'];

		$LastRowId =$_REQUEST['LastRowId'];

		$WorkshiftId = $_REQUEST['WorkshiftId'];

		$TimePolicyId = $_REQUEST['TimePolicyId'];

		$LoginUserId  = $_SESSION['user_id'];//*

		$CallFrom = isset($_REQUEST['CallFrom'])?$_REQUEST['CallFrom']:'';

		$FirstDate = $_POST['StartDate'];

		$FirstDate = strtotime($FirstDate);

		$FirstDate = date("Y-m-d",$FirstDate);

		$PayPeriodId = isset($_REQUEST['PayPeriodId'])?$_REQUEST['PayPeriodId']:'';

		

		$CurrentWeek = GetCurrentWeekDates($FirstDate);

		$IsAllowEntry = array();

		$IsHoliday = array();

		$SiteId = $_SESSION['user-siteid'];

		foreach($CurrentWeek as $key)

		{

			$qry = "SELECT PERIOD_ID FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$key'  AND TO_PERIOD_DATE>='$key') AND SITE_ID = $SiteId";			

			$result = mysql_query($qry);

			while($row = mysql_fetch_array($result))

			{

				if($row['PERIOD_ID']==$PayPeriodId) { $IsAllowEntry[] = "Y";}

				else { $IsAllowEntry[] = "N"; }

			}

			

		}

		/*$startDate = $CurrentWeek[0]; 

		$endDate = $CurrentWeek[6];

		$CurrentWeekHolidayList=array();	

		$qry = "select * from cxs_holiday_calendar where ((HOLIDAY_START_DATE >= '$startDate' and HOLIDAY_START_DATE <= '$endDate') or (HOLIDAY_END_DATE >= '$startDate' and HOLIDAY_END_DATE <= '$endDate')) and ENABLED_FLAG = 'Y' and cxs_holiday_calendar.SITE_ID =$SiteId order by HOLIDAY_START_DATE";

		$result = mysql_query($qry);

		while($row = mysql_fetch_array($result))

		{

			$HolidayStartDate = $row['HOLIDAY_START_DATE'];

			$HolidayEndDate = $row['HOLIDAY_END_DATE'];

			$RecessAllowed = $row['RECESS_ALLOWED'];						

			for($i=0;$i<=6;$i++)

			{

				$WeekDate = strtotime($CurrentWeek[$i]);

				if($WeekDate >= strtotime($HolidayStartDate) && $WeekDate <= strtotime($HolidayEndDate))

				{

					if($RecessAllowed=="Y")

					{

						$WeekDay = date('l',strtotime($CurrentWeek[$i]));						

						if($WeekDay=='Saturday')

						{

							$UpdateDate = strtotime('-1 day', strtotime($CurrentWeek[$i]));

						}

						else if($WeekDay=='Sunday')

						{

							$UpdateDate = strtotime('+1 day', strtotime($CurrentWeek[$i]));

						}

						$CurrentWeekHolidayList['Dates'][]=date('Y-m-d',$UpdateDate);	

						

					}

					else

					{

						$CurrentWeekHolidayList['Dates'][]=$CurrentWeek[$i];					

					}					

				}

			} 

		}	

		*/

		

		$ShiftHours = array();

		if ($WorkshiftId!='')

		{

			$qry = "select * from cxs_workshifts inner join cxs_workshifts_detail on cxs_workshifts_detail.WORKSHIFT_ID = cxs_workshifts.WORKSHIFT_ID where cxs_workshifts.WORKSHIFT_ID= $WorkshiftId and cxs_workshifts.SITE_ID = $SiteId";

			$result = mysql_query($qry);

			while($row=mysql_fetch_array($result))

			{

				$ShiftHours[] = $row['SHIFT_HOURS'];

			}

		//	print_r($ShiftHours);

			if(sizeof($ShiftHours) == 0 )

			{

				$qry = "select * from cxs_workshifts inner join cxs_flex_schedule on cxs_flex_schedule.WORKSHIFT_ID = cxs_workshifts.WORKSHIFT_ID where cxs_workshifts.WORKSHIFT_ID= $WorkshiftId and cxs_workshifts.SITE_ID = $SiteId";

				$result = mysql_query($qry);

				while($row=mysql_fetch_array($result))

				{

					$ScheduleType = $row['SCHEDULE_TYPE'];

					if($ScheduleType == 'DATE_RANGE')

					{

						$Sch_StartDate = $row['SCHEDULE_START_DATE'];

						$Sch_EndDate = $row['SCHEDULE_END_DATE'];

					}

					else if($ScheduleType == 'DAYS_IN_MONTH')

					{

						$MonthDateList = array();

						for($i=1;$i<=31;$i++)

						{

							$MonthDateList[] = $i;

						}

						$EntryMonthDateList=array();

						foreach($MonthDateList as $key)

						{

							$FieldName = "DAYS_IN_MONTH$key";

							if($row[$FieldName]=="X")

							{

								$EntryMonthDateList[]=$key;

							}

						}

					}

					else if($ScheduleType == 'DAYS_IN_WEEK')

					{

						$WeekNameList=array('MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY');

						$EntryWeekList=array();

						foreach($WeekNameList as $key)

						{

							if($row[$key]=='X')

							{

								$EntryWeekList[] = ucwords(strtolower($key));

							}

						}

					}

				}

			}

		}	

		$EvenFriday = array();

		$EvenFriday[] = date('Y-m-d',strtotime('second fri of '.date('F Y')));

		$EvenFriday[] = date('Y-m-d',strtotime('fourth fri of '.date('F Y')));

		$IsExist = "";

		foreach($EvenFriday as $key)

		{

			if($key ==$CurrentWeek[5])

			{

				$IsEvenFridayExist = "Y";

				break;

			}

		}

		$EarnType = "";

		$OvertimeAllowed="";

		$CTOOvertime="";

		$AliasChildValues="";

		$AliasChildValues.="<option class = 'option_color' value = 'STD - Straight Time /Day'>STD - Straight Time /Day</option>";

		$AliasChildValues.="<option class = 'option_color' value = 'STE - Straight Time /Evening'>STE - Straight Time /Evening</option>";

		$AliasChildValues.="<option class = 'option_color' value = 'STN - Stright  Time /Night'>STN - Stright  Time /Night</option>";

				

		if($TimePolicyId!='')

		{

			$qry = "select 'Manual' as EARN_TYPE ,OVERTIME_ALLOWED,CTO_OVERTIME,cxs_workshifts.WORKSHIFT_TYPE from cxs_policy_general left join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_general.WORKSHIFT_ID where POLICY_ID = $TimePolicyId limit 0,1";

			$result = mysql_query($qry);

			while($row=mysql_fetch_array($result))

			{

				$EarnType = $row['EARN_TYPE'];

				$OvertimeAllowed = $row['OVERTIME_ALLOWED'];

				$CTOOvertime = $row['CTO_OVERTIME'];

				$WorkshiftType = $row['WORKSHIFT_TYPE'];

			}

			if($OvertimeAllowed=="Y")

			{

				$AliasChildValues.="<option class = 'option_color' value = 'OTD - Overtime/Day'>OTD - Overtime/Day</option>";

				$AliasChildValues.="<option class = 'option_color' value = 'OTE - Overtime/Evening'>OTE - Overtime/Evening</option>";

				$AliasChildValues.="<option class = 'option_color' value = 'OTN - Overtime/Night'>OTN - Overtime/Night</option>";

			}

			if($CTOOvertime=="Y")

			{

				$AliasChildValues.="<option class = 'option_color' value = 'CTO - Compensatory Time Off'>CTO - Compensatory Time Off</option>";

				/*

				$AliasChildValues.="<option class = 'option_color' value = 'CTH'>CTH - Time & Half</option>";

				$AliasChildValues.="<option class = 'option_color' value = 'CTS'>CTS - Compensatory Time off @ Stratight time</option>";

				*/

				

			}

			if($AliasChildValues!='')

			{

				$AliasChildValues = "<option class = 'option_color' value = ''>- Shift -</option>".$AliasChildValues;

			}

		}

		/*

		$AllowPaidBreak = "";

		$qry = "select ALLOW_PAID_BREAK from cxs_hours_deduction where POLICY_ID = $TimePolicyId limit 0,1";

		$result = mysql_query($qry);

		while($row=mysql_fetch_array($result))

		{

			$AllowPaidBreak = $row['ALLOW_PAID_BREAK'];

		}

		*/		

		$TotalWeekDays = 7;

		$s = $AliasId;		

		if($s!='')		

		{

			$s2 = "";

			$s3 = "ALIAS_ID";

			do

			{

				$pos = strpos($s,"|");

				$s1 = trim(substr($s, 0, $pos));  //id

				$s2 = $s2."ALIAS_ID=$s1 or ";

				$s3 = $s3.",$s1";

				$s = substr($s, $pos+1);				

			}while(strlen($s)>0);	

			$s2=substr( $s2, 0, -3 );

		}	

		

		$s = $AliasHolidayList;

		$HolidayListName = array();

		if($s!='')		

		{		

			do

			{

				$pos = strpos($s,"|");

				$s1 = trim(substr($s, 0, $pos));  //name

				$HolidayListName[] = $s1;				

				$s = substr($s, $pos+1);				

			}while(strlen($s)>0);	

			

		}

		$style = "";

		if ($EarnType=="Manual")

		{

			$style = ""; 

		}

		else

		{

			//$style = "disabled='disabled'";

			$style = "disabled";

			if ($WorkshiftType == "Flexible Shift")

			{

				$style = ""; 

			}

		} 

		if ($WorkshiftType == "Flexible Shift")

		{

			if($ScheduleType == 'DATE_RANGE')

			{

				for($i=0;$i<=6;$i++)

				{

					if($IsAllowEntry[$i] == "Y")

					{	

						$CheckDate = strtotime($CurrentWeek[$i]);

						if ($CheckDate >= strtotime($Sch_StartDate) && $CheckDate <= strtotime($Sch_EndDate))

						{

						  

						}

						else

						{

							$IsAllowEntry[$i] = "N";

						}

					}

				}

			}

			else if($ScheduleType == 'DAYS_IN_MONTH')

			{

				for($i=0;$i<=6;$i++)

				{

					if($IsAllowEntry[$i] == "Y")

					{

						$IsAllowEntry[$i] = "N"; 

						$CheckDate = $CurrentWeek[$i]; 						

						foreach($EntryMonthDateList as $key)

						{

							$key=(int)$key;

							$num = date('d',strtotime($CheckDate));

							$num = (int)$num;							

							if($num == $key)

							{

								$IsAllowEntry[$i] = "Y";

							} 

						}

					}

				}	

			}

			else if($ScheduleType == 'DAYS_IN_WEEK')

			{

				for($i=0;$i<=6;$i++)

				{

					if($IsAllowEntry[$i] == "Y")

					{

						$IsAllowEntry[$i] = "N"; 

						$CheckDate = $CurrentWeek[$i]; 						

						foreach($EntryWeekList as $key)

						{

							if(date('l',strtotime($CheckDate))==$key)							

							{

								$IsAllowEntry[$i] = "Y";

							} 

						}

					}

				}	

			}

		}	

		

		$IsEdit = isset($_REQUEST['IsEdit'])?$_REQUEST['IsEdit']:"N";

		if($IsEdit=="N")

		{

			$i = $LastRowId;//+1;

			$OrderBy = "";

			if($CallFrom=='TimeKeeping') 

			{

				$OrderBy = " order by FIELD($s3) ";

			}

			else

			{

				$OrderBy = " order by ALIAS_NAME ";

			}

			$NumHolidays = sizeof($HolidayListName);

			if($s2!='' || $NumHolidays >0) // if any alias id is selected

			{

				if($NumHolidays>0) // when holiday list as alias name 

				{

					foreach($HolidayListName as $value) 

					{ 

					?>

					

					<tr id = "<?php echo "row$i";?>">			

						<td class="check-bx">
							<input type = "hidden" name = "h_rows[]" value = "<?php echo $i; ?>" >

							<?php if($CallFrom=='TimeKeeping') { ?>

							<input type="checkbox" class = "GridCheckBox" id="<?php echo "CheckboxInline$i" ?>" value="1" disabled="disabled">

							<?php } ?>

						</td>

						<td>

							<div class="form-group">	

								<input type = "hidden" id = "<?php echo "h_Taskid$i"; ?>" name = "<?php echo "h_Taskid$i"; ?>"  value = "0" >

								<span id = "<?php echo "Span_Task$i"; ?>" name = "<?php echo "Span_Task$i";?>" style="float:left;width:86%;display:none;"><?php echo "$value"; ?></span>

								<input type="text" id = "<?php echo "Text_Task$i"; ?>" name = "<?php echo "Text_Task$i"; ?>" class="input-sm" onfocus = "SearchPopUp(<?php echo $i; ?>)" style = "width : 85%;height:34px;" value = "<?php echo $value; ?>">	

								<input type="button" id = "<?php echo "cmdTaskDescription$i"; ?>" name = "<?php echo "cmdTaskDescription$i"; ?>" class="btn btn-primary btn-style-bdronly my-link form-group" value = "..." onclick = "TaskDescriptionPopUp(<?php echo $i; ?>)" >

							</div>

						</td>

					

						<td <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

							<div class="form-group" <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

								<?php if($AliasChildValues!=''){?><span><select  class="input-sm option_color" id = "<?php echo "Combo_Shift$i";?>" name = "<?php echo "Combo_Shift$i";?>" onclick='setSpanValue("<?php echo "Combo_Shift$i"?>","<?php echo "Span_Shift$i";?>")'><?php echo $AliasChildValues; ?></select></span><?php } ?>

								<span id = "<?php echo "Span_Shift$i";?>" name = "<?php echo "Span_Shift$i";?>" style = "display:none"> </span>

							</div>	

						</td>

						<!-- Part2 -->

						<?php	

							for($j=1;$j<=$TotalWeekDays;$j++)

							{	

								if ($WorkshiftType=='9/8/80 Shift' && ($j==6||$j==7) && $IsEvenFridayExist=="Y" && $OvertimeAllowed !='Y')

								{

									$ShiftHoursValue = 0;

								}

								else

								{

									$ShiftHoursValue = $ShiftHours[($j-1)];

								}

								if($IsAllowEntry[$j-1]=="N" && ($CallFrom!='TimeKeeping'))

								{

									$ShiftHoursValue = "";

								}

								$StatusValue= "Working"; 

								$CommentValue="";									

								

								if ($EarnType=="Manual")

								{

									$style = "";  

									if ($WorkshiftType=='9/8/80 Shift' && $j==6 && $IsEvenFridayExist=="Y" && $OvertimeAllowed !='Y')

									{ 

										$style = "disabled";

									}

									else if ($WorkshiftType=='4/10/40 Shift' && $j==6 && $OvertimeAllowed !='Y') // for all fridays

									{ 

										$style = "disabled"; 

									}

									else if($IsAllowEntry[$j-1]=="N" )

									{

										$style = "disabled"; 

									}

									$ShiftHoursValue = "";

								}

								else{ $style = "disabled";} 

								

								if($OvertimeAllowed=="Y" && ($j==6||$j==$TotalWeekDays))

								{

									$style="";

								}

						?>	

						<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?>  id = "<?php echo "Hours$i"."_$j"?>" >

							<div class="form-group text-right " >

								<span id = "<?php echo "Span_Hours$i"."_$j"?>" class = "my-span-style" style = "display:none">  </span>							

								<input type="text" id = "<?php echo "Text_Hours$i"."_$j"?>" name = "<?php echo "Text_Hours$i"."_$j"?>" class=" form-control text-right " maxlength="6"  onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onkeypress="return allowNegPosNumber(event);" onblur = "TotalHours(this)" style = "min-width :40px;" <?php  echo $style; ?> value = "<?php echo $ShiftHoursValue; ?>" >

							<!--	<?php if($AliasChildValues!=''){?><br><input type="text" id = "<?php echo "Text_HoursOT$i"."_$j"?>" name = "<?php echo "Text_HoursOT$i"."_$j"?>" class="form-control" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onkeypress="return allowNegPosNumber(event);" onchange = "TotalHours()" style = "min-width :40px;" <?php //echo $style; ?> value = ""><?php } ?> -->						

							</div>

						</td>

						

						<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Status$i"."_$j"?>">

							<div class="form-group">					

								<span id = "<?php echo "span_Status$i"."_$j"?>" class = "my-span-style" style = "font-size:12px; display:none" >  </span>

								<input type="text" id = "<?php echo "Text_Status$i"."_$j"?>" name = "<?php echo "Text_Status$i"."_$j"?>" class="form-control" maxlength="12" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "span_Status$i"."_$j"; ?>',this)" style = "font-weight: bold;min-width : 50px;font-size:12px;" value = "<?php echo $StatusValue; ?>" readonly>

							</div>

						</td>												

						<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Notes$i"."_$j"?>" >

							<div>

								<!--<a href="javascript:ShowPopup('<?php echo$i."_$j"?>')" class="btn btn-primary btn-style-bdronly" > <i class="fa fa-ellipsis-h" aria-hidden="true"></i> </a> -->

								<input type="button" id = "<?php echo "cmdNotes$i"; ?>" name = "<?php echo "cmdNotes$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" onclick = "ShowPopup('<?php echo$i."_$j"?>')" value = "..."  >

								<input type="hidden" id = "<?php echo "h_comment$i"."_$j"; ?>" name = "<?php echo "h_comment$i"."_$j"; ?>" value = "<?php echo $CommentValue; ?>">

							</div>

							

						</td>

						<?php

							}

						?>	

						

						<!-- Part3 -->

						<td>

							<div class="form-group">

								<input type="text" id = "<?php echo "Text_LineTotalHours$i"?>" name = "<?php echo "Text_LineTotalHours$i"?>" class="form-control text-right" readonly style = "min-width :40px;">

							</div>

						</td>					

							

					</tr>

	<?php	

					$i=$i+1;

					}

			}

			//============ holiday list complete here===========

				$SelectQuery = "select * FROM cxs_aliases  where $s2 $OrderBy ";

				$Result = mysql_query($SelectQuery);		

				while($row = mysql_fetch_array($Result))

				{

					$AliasName = $row['ALIAS_NAME'];

					$AliasId = $row['ALIAS_ID'];

		?>	

				<tr id = "<?php echo "row$i";?>">			

					<td class="check-bx"><input type = "hidden" name = "h_rows[]" value = "<?php echo $i; ?>" >
						<!-- <i class="fa fa-refresh" onclick="reset();"></i> -->
						<?php if($CallFrom=='TimeKeeping') { ?>

						<input type="checkbox" class = "GridCheckBox" id="<?php echo "CheckboxInline$i" ?>" value="1" disabled="disabled">

						<?php } ?>

						

					</td>

					<td>

						<div class="form-group">	

							<input type = "hidden" id = "<?php echo "h_Taskid$i"; ?>" name = "<?php echo "h_Taskid$i"; ?>"  value = "<?php echo $AliasId; ?>" >

							<span id = "<?php echo "Span_Task$i"; ?>" name = "<?php echo "Span_Task$i";?>" style="float:left;width:86%;display:none;"><?php echo "$AliasName"; ?></span>

							<input type="text" id = "<?php echo "Text_Task$i"; ?>" name = "<?php echo "Text_Task$i"; ?>" class="input-sm" onfocus = "SearchPopUp(<?php echo $i; ?>)" style = "width : 85%;height:34px;" value = "<?php echo $AliasName; ?>">	

							<input type="button" id = "<?php echo "cmdTaskDescription$i"; ?>" name = "<?php echo "cmdTaskDescription$i"; ?>" class="btn btn-primary btn-style-bdronly my-link form-group" value = "..." onclick = "TaskDescriptionPopUp(<?php echo $i; ?>)" >

						<!--	 -->

						</div>

					</td>

				

					<td <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

						<div class="form-group" <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

							<?php if($AliasChildValues!=''){?><span><select  class="input-sm option_color" id = "<?php echo "Combo_Shift$i";?>" name = "<?php echo "Combo_Shift$i";?>" onclick='setSpanValue("<?php echo "Combo_Shift$i"?>","<?php echo "Span_Shift$i";?>")'><?php echo $AliasChildValues; ?></select></span><?php } ?>

							<span id = "<?php echo "Span_Shift$i";?>" name = "<?php echo "Span_Shift$i";?>" style = "display:none"> </span>

						</div>	

					</td>

					<!-- Part2 -->

					<?php	

						for($j=1;$j<=$TotalWeekDays;$j++)

						{	

							/*if($j==1)

							{

								$ShiftHoursValue = $ShiftHours[6];//monday

							}

							else

							{*/

								if ($WorkshiftType=='9/8/80 Shift' && ($j==6||$j==7) && $IsEvenFridayExist=="Y" && $OvertimeAllowed !='Y')

								{

									$ShiftHoursValue = 0;

								}

								else

								{

									$ShiftHoursValue = $ShiftHours[($j-1)];

								}

								if($IsAllowEntry[$j-1]=="N" && ($CallFrom!='TimeKeeping'))

								{

									$ShiftHoursValue = "";

								}

								$StatusValue= "Working"; 

								$CommentValue="";

								/*elseif($CallFrom=='TimeKeeping') 

								{

									$tempDate = $CurrentWeek[$j-1];

								echo $qry1 = "SELECT * FROM cxs_te_file WHERE ENTRY_DATE='$tempDate' and ALIAS_ID = $AliasId";			

									$result1 = mysql_query($qry1);

									while($row1 = mysql_fetch_array($result1))

									{

										$ShiftHoursValue = $row1['HOURS'];

										$StatusValue= $row1['STATUS_FLAG'];

										$CommentValue= $row1['COMMENT'];

									}

								}*/

							//}

							

							if ($EarnType=="Manual")

							{

								$style = ""; 

								if ($WorkshiftType=='9/8/80 Shift' && $j==6 && $IsEvenFridayExist=="Y" && $OvertimeAllowed !='Y')

								{ 

									$style = "disabled";

								}

								else if ($WorkshiftType=='4/10/40 Shift' && $j==6 && $OvertimeAllowed !='Y') // for all fridays

								{ 

									$style = "disabled"; 

								}

								else if($IsAllowEntry[$j-1]=="N" )

								{

									$style = "disabled"; 

								}

								

								if($style=="")

								$ShiftHoursValue = "";

							}

							else{ $style = "disabled";} 

							

							if($OvertimeAllowed=="Y" && ($j==6||$j==$TotalWeekDays))

							{

								$style="";

							}

					?>	

					<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?>  id = "<?php echo "Hours$i"."_$j"?>" >

						<div class="form-group text-right " >

							<span id = "<?php echo "Span_Hours$i"."_$j"?>" class = "my-span-style" style = "display:none">  </span>							

							<input type="text" id = "<?php echo "Text_Hours$i"."_$j"?>" name = "<?php echo "Text_Hours$i"."_$j"?>" class=" form-control text-right " maxlength="6"  onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onkeypress="return allowNegPosNumber(event);" onblur = "TotalHours(this)" style = "min-width :40px;" <?php  echo $style; ?> value = "<?php echo $ShiftHoursValue; ?>" >

						<!--	<?php if($AliasChildValues!=''){?><br><input type="text" id = "<?php echo "Text_HoursOT$i"."_$j"?>" name = "<?php echo "Text_HoursOT$i"."_$j"?>" class="form-control" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onkeypress="return allowNegPosNumber(event);" onchange = "TotalHours()" style = "min-width :40px;" <?php //echo $style; ?> value = ""><?php } ?> -->						

						</div>

					</td>

					

					<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Status$i"."_$j"?>">

						<div class="form-group">					

							<span id = "<?php echo "span_Status$i"."_$j"?>" class = "my-span-style" style = "font-size:12px; display:none" >  </span>

							<input type="text" id = "<?php echo "Text_Status$i"."_$j"?>" name = "<?php echo "Text_Status$i"."_$j"?>" class="form-control" maxlength="12" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "span_Status$i"."_$j"; ?>',this)" style = "font-weight: bold;min-width : 50px;font-size:12px;" value = "<?php echo $StatusValue; ?>" readonly>

						</div>

					</td>												

					<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Notes$i"."_$j"?>" >

						<div>

							<!--<a href="javascript:ShowPopup('<?php echo$i."_$j"?>')" class="btn btn-primary btn-style-bdronly" > <i class="fa fa-ellipsis-h" aria-hidden="true"></i> </a> -->

							<input type="button" id = "<?php echo "cmdNotes$i"; ?>" name = "<?php echo "cmdNotes$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" onclick = "ShowPopup('<?php echo$i."_$j"?>')" value = "..."  >

							<input type="hidden" id = "<?php echo "h_comment$i"."_$j"; ?>" name = "<?php echo "h_comment$i"."_$j"; ?>" value = "<?php echo $CommentValue; ?>">

						</div>

						

					</td>

					<?php

						}

					?>	

					

					<!-- Part3 -->

					<td>

						<div class="form-group">

							<input type="text" id = "<?php echo "Text_LineTotalHours$i"?>" name = "<?php echo "Text_LineTotalHours$i"?>" class="form-control text-right" readonly style = "min-width :40px;">

						</div>

					</td>					

						

				</tr>

	<?php	

					$i=$i+1;

				}

			}

	?>				

			<!-- one blank row add -->

			

			<tr id = "<?php echo "row$i"; ?>">			

				<td class="check-bx"><!--<input type="checkbox" id="<?php echo "CheckboxInline$i" ?>" value="1" disabled="disabled">--></td>

				<td>

					<div class="form-group">

						<span id = "<?php echo "Span_Task$i"; ?>"> </span>

						<input type="text" id = "<?php echo "Text_Task$i"; ?>" name = "<?php echo "Text_Task$i"; ?>" class="input-sm" onfocus = "SearchPopUp('')" style = "width : 85%;" value = "">	

						<input type="button" id = "<?php echo "cmdTaskDescription$i"; ?>" name = "<?php echo "cmdTaskDescription$i"; ?>" class="btn btn-primary btn-style-bdronly my-link" value = "..." onclick = "TaskDescriptionPopUp(<?php echo $i; ?>)" >				

					</div>

				</td>

				<td <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

					<div class="form-group" <?php if($AliasChildValues==''){ echo "style='display:none'"; } ?>>

						<?php if($AliasChildValues!=''){?><span><select  class="input-sm option_color " id = "Combo_Shift" name = "Combo_Shift" ><?php echo $AliasChildValues; ?></select></span><?php } ?>

					</div>	

				</td>

				<!-- Part2 -->

				<?php	

					

					for($j=1;$j<=$TotalWeekDays;$j++)

					{													

				?>	

				<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?>  id = "<?php echo "Hours$i"."_$j"?>" >

					<div class="form-group">

						<span id = "<?php echo "Span_Hours$i"."_$j"?>" style = "display:none">  </span>

						<input type="text" id = "<?php echo "Text_Hours$i"."_$j"?>" name = "<?php echo "Text_Hours$i"."_$j"?>" class="form-control text-right "  onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onchange = "TotalHours()" onkeypress="return allowNegPosNumber(event);" style = "min-width :40px;">

				<!--		<?php if($AliasChildValues!=''){?><br><input type="text" id = "<?php echo "Text_HoursOT$i"."_$j"?>" name = "<?php echo "Text_HoursOT$i"."_$j"?>" class="form-control"  onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "Span_Hours$i"."_$j"; ?>',this)" onchange = "TotalHours()" onkeypress="return allowNegPosNumber(event);"  style = "min-width :40px;"><?php } ?> -->

					</div>

				</td>

				

				<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Status$i"."_$j"?>">

					<div class="form-group">

						<span id = "<?php echo "span_Status$i"."_$j"?>" style = "display:none">  </span>

						<input  type="text" id = "<?php echo "Text_Status$i"."_$j"?>" name = "<?php echo "Text_Status$i"."_$j"?>" class="form-control " maxlength="12" onkeyup = "EnteredValue('<?php echo $i; ?>','<?php echo "span_Status$i"."_$j"; ?>',this)" style = "font-weight: bold;min-width : 50px;height:100%;font-size: 12px;  " value = ""; readonly>

					</div>

				</td>												

				<td <?php echo ($TotalWeekDaysActual==5)?($j==6||$j==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "Notes$i"."_$j"?>" >

					<div>

						<a href="javascript:void(0)" class="btn btn-primary btn-style-bdronly" > <i class="fa fa-ellipsis-h" aria-hidden="true"></i> </a>

					</div>

					

				</td>

				<?php

					}

				?>	

				

				<!-- Part3 -->

				<td>

					<div class="form-group">

						<input type="text" id = "<?php echo "Text_LineTotalHours$i"?>" name = "<?php echo "Text_LineTotalHours$i"?>" class="form-control text-right" readonly style = "min-width :40px;">

					</div>

				</td>				

					

			</tr>

			

			<tr id = "row-WBSTotal1" >

				<!-- Part1 -->

				<td rowspan="2"></td>

				<td rowspan="2"  <?php if($AliasChildValues!=''){ echo "colspan='2'"; } ?> bgcolor="#337ab7" style = "color: #ffffff;"><b>WBS  Total</b></td>

				

				<!-- Part2 -->

				<?php

					for($i=1;$i<=$TotalWeekDays;$i++)

					{

				?>	

					<td bgcolor="#337ab7" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskHours$i"; ?>">

						<div class="form-group">

							<input type="text" id = "<?php echo "Text_TotalTaskHours$i"?>" name = "<?php echo "Text_TotalTaskHours$i"?>" class="form-control text-right" readonly style = "min-width :40px;">

						</div>

					</td>

					<td bgcolor="#337ab7" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskStatus$i"; ?>" ></td>

					<td bgcolor="#337ab7" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "TotalTaskNotes$i"; ?>" ></td>

				<?php

					}

				?>

				<!-- Part3 -->

				<td rowspan="2" bgcolor="#337ab7" style = "color: #ffffff;">

					<div class="form-group">

						<input type="text" id = "Text_TotalFinal" name = "Text_TotalFinal" class="form-control text-right" readonly style = "min-width :60px;color: #ffffff;" >

					</div>

				</td>				

			</tr>

			<tr id = "row-WBSTotal2" class="cr-user " >

				<!-- Part2 -->

				<?php

					for($i=1;$i<=$TotalWeekDays;$i++)

					{

				?>	

				<td colspan="3" class="submit-tbe approve-btn" <?php echo ($TotalWeekDaysActual==5)?($i==6||$i==$TotalWeekDays)?"style='display:none'":"":""; ?> id = "<?php echo "SubmitForApproval$i"; ?>"> <button type="button" class="btn btn-primary btn-style approve" id = "<?php echo "CmdApproval$i"; ?>" name = "<?php echo "CmdApproval$i"; ?>"> Submit for Approval  </button>

				</td>

				<?php

					} 

				?>

			</tr>

<?php	}

		else 

		{

			if($s2!='') 

			{

				$AliasName = "";

				$AliasId = 0;

				$SelectQuery = "select * FROM cxs_aliases  where $s2 order by ALIAS_NAME ";

				$Result = mysql_query($SelectQuery);

				while($row = mysql_fetch_array($Result))

				{

					$AliasName = $row['ALIAS_NAME'];

					$AliasId = $row['ALIAS_ID'];

				}

			}

			echo $AliasName.$AliasId;

			//$_SESSION['TE_UpdateAliasName'] = $AliasName;

			//$_SESSION['TE_UpdateAliasId'] = $AliasId;

		}

	}

?>



