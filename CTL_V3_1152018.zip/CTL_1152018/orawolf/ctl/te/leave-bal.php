<?php ob_start ();
	 
  include("te-functions.php");
	include("sitename.php");

	check_login();
?>
<?php
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "leave-bal.php";
?>
<script type="text/javascript" >
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Time Management Policy";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys | <?php echo strtoupper($SiteName); ?></title>
<!-- <title>Coexsys | Time Accounting</title> -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">
</head>

<body>
<?php include("header.php"); ?>
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="#"> Time Management Policy </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
        <div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
      <div class="cont-box">
        <div class="pge-hd">
          <h2 class="sec-title"> Time Management Policy </h2>
        </div>
        <div> 
          <!-- <div class="fleft two">
                            <button type="button" class="btn-style btn"> Update Selected </button>
                            <button type="button" class="btn-style btn"> Export </button>
                        </div>-->
          <div class="fright cr-user">
            <a href="create-new-policy.php"><button type="button" class="btn btn-primary btn-style" > <?php echo $s_caption; ?> Policy </button></a>
          </div>
          <div class="data-bx">
            <div class="table-responsive">
              <table class="table table-bordered mar-cont">
                <thead>
                  <tr>
                    <th width="30%"> Policy Profile Name <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a></th>
                    <th width="30%"> Description <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a></th>
                    <th width="25%"> Active Flag <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a> </th>
                    <th width="5%"> </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td><!--<button type="button" class="btn btn-default" data-container="body" data-toggle="popover"  data-placement="left" data-content="Created By:  VAISHNAVR
                      Updated By:  JBOB  Creation Date:  11th March 2017 4:40 PM
                      Last Update Date: 12th March 2017 4:40 PM
                      "  > <i class=" fa fa-eye"></i> </button>-->
                      
                      <button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Dummy content" data-original-title="" title="" aria-describedby="popover894067"> <i class=" fa fa-eye"></i> </button></td>
                  </tr>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td><!--<button type="button" class="btn btn-default" data-container="body" data-toggle="popover"  data-placement="left" data-content="Created By:  VAISHNAVR
                      Updated By:  JBOB  Creation Date:  11th March 2017 4:40 PM
                      Last Update Date: 12th March 2017 4:40 PM
                      "  > <i class=" fa fa-eye"></i> </button>-->
                      
                      <button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Dummy content" data-original-title="" title="" aria-describedby="popover894067"> <i class=" fa fa-eye"></i> </button></td>
                  </tr>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td><!--<button type="button" class="btn btn-default" data-container="body" data-toggle="popover"  data-placement="left" data-content="Created By:  VAISHNAVR
                      Updated By:  JBOB  Creation Date:  11th March 2017 4:40 PM
                      Last Update Date: 12th March 2017 4:40 PM
                      "  > <i class=" fa fa-eye"></i> </button>-->
                      
                      <button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Dummy content" data-original-title="" title="" aria-describedby="popover894067"> <i class=" fa fa-eye"></i> </button></td>
                  </tr>
                  <tr>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td> Dummy Text </td>
                    <td><!--<button type="button" class="btn btn-default" data-container="body" data-toggle="popover"  data-placement="left" data-content="Created By:  VAISHNAVR
                      Updated By:  JBOB  Creation Date:  11th March 2017 4:40 PM
                      Last Update Date: 12th March 2017 4:40 PM
                      "  > <i class=" fa fa-eye"></i> </button>-->
                      
                      <button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Dummy content" data-original-title="" title="" aria-describedby="popover894067"> <i class=" fa fa-eye"></i> </button></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- pagination start-->
          <div class="pagination-bx">
            <div class="bs-example">
              <ul class="pagination">
                <li><a href="#">«</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#">»</a></li>
              </ul>
            </div>
          </div>
          <!-- pagination end --> 
        </div>
      </div>
    </div>
  </div>
</section>
<footer> </footer>
<script type="text/javascript">
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>