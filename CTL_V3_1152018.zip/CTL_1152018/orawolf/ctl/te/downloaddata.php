<?php
	include('../conn.php');

	$r = "";
	$r = $_GET['r'];
	if ($r == "resources-list")
	{
		$filename = "download_resources.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['Resources_Export']);
	}
	else if ($r == "new-resource-address")
	{
		$filename = "download_resource_address.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['NewResourceAddress_Export']);
	}
	else if ($r == "new-resource-contacts")
	{
		$filename = "download_resource_contacts.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['NewResourceContacts_Export']);
	}
	else if ($r == "holiday-calendars")
	{
		$filename = "download_holiday_calendar.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['HolidayCalendar_Export']);
	}
	else if ($r == "accounting-periods")
	{
		$filename = "download_accounting_periods.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['AccountingPeriod_Export']);
	}
	else if ($r == "work-shift")
	{
		$filename = "download_work_shift.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['WorkShift_Export']);
	}
	else if ($r == "resource-export")
	{
		$filename = "download_resource_group.csv";
		$fp = fopen($filename, "w") or die ("couldn't open");
		fwrite($fp, $_SESSION['ResourceGroup_Export']);
	}
	fclose($fp);
?>
<html>
<head>
<title>Coexsys | Download CSV File</title>
</head>
<body>
<script>
	location.href = "<?php echo $filename; ?>";
</script>
</body>
</html>