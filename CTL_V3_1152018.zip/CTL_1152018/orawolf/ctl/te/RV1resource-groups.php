<?php ob_start ();

	include("te-functions.php");    
	include("sitename.php");
	check_login(); 

?>

<?php

	if ($_SESSION['current-user-type'] == "TE-Admin")

	{

		$CREATE_PRIV_ResourceGroup_PERMISSION = "Y";

		$UPDATE_PRIV_ResourceGroup_PERMISSION = "Y";

		$VIEW_PRIV_ResourceGroup_PERMISSION = "Y";

		$ENABLE_AUDIT_ResourceGroup_PERMISSION = "Y";

	}

	else

	{

		$CREATE_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Resource Group',$_SESSION['user_id']);

		$UPDATE_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Resource Group',$_SESSION['user_id']);

		$VIEW_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Resource Group',$_SESSION['user_id']);

		$ENABLE_AUDIT_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Resource Group',$_SESSION['user_id']);

	}		

	if($CREATE_PRIV_ResourceGroup_PERMISSION=='N' && $UPDATE_PRIV_ResourceGroup_PERMISSION=='N' && $VIEW_PRIV_ResourceGroup_PERMISSION=='N' && $ENABLE_AUDIT_ResourceGroup_PERMISSION=='N')

	{

		header('location:te.php');

	}

	

	$LoginUserId = $_SESSION['user_id'];

	$PageName = "resource-groups.php";

	$SiteId = $_SESSION['user-siteid'];

	



	//$qry

	$ComboRoleValues = "<option value=''>- Role -</option>";	

	$qry = "select * from cxs_am_roles where SITE_ID = $SiteId order by ROLE_NAME";

	$result = mysql_query($qry);

	while($row=mysql_fetch_array($result))

	{

		$RoleId = $row['ROLE_ID'];

		$RoleName = $row['ROLE_NAME'];

		$ComboRoleValues .= "<option value='$RoleId' > $RoleName  </option>";

	}											

	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';

	$OrderBY = "";

	$FieldName = "";

	

	$OrderBY = "asc";

	$FieldName = "RESOURCE_GROUP_NAME";

	$Sorts = "";

	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;

	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;

	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	

	$s_Query = str_replace("\\","",$s_Query);

	if ($Sorts == 'asc')

	{

   	 $OrderBY = " desc";

   	 $FieldName = $FileName;

	}

	if ($Sorts == 'desc')

	{

		 $OrderBY = " asc";

		 $FieldName = $FileName;

	}



	$SQueryOrderBy = " order by $FieldName $OrderBY";

	

	$record_per_page=$RecordsPerPage;

	if (isset($_GET["page"]))

	{

		$page  = $_GET["page"];

	}

	else

	{

		$page=1;

	}

	$start_from = ($page-1) *  $record_per_page;

	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;

	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";

	$insArr = array();

	

	if (isset($_POST['cmdAdd'] ))

	{	

		$Text_ResourceGroupName = isset($_POST["Text_ResourceGroupName"] )? $_POST["Text_ResourceGroupName"]: false;

		$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;

		$Combo_TimeManagementPolicy = isset($_POST["Combo_TimeManagementPolicy"] )? $_POST["Combo_TimeManagementPolicy"]: false;

		$Combo_TimeManagementRole = isset($_POST["Combo_TimeManagementRole"] )? $_POST["Combo_TimeManagementRole"]: false;

		$Combo_TimeManagementPreApproval = isset($_POST["Combo_TimeManagementPreApproval"] )? $_POST["Combo_TimeManagementPreApproval"]: false;

		

		$IsDuplicate = isset($_POST["h_duplicate"] )? $_POST["h_duplicate"]: false;

		if($IsDuplicate!='Y')

		{

			unset($inArr);		

			$insArr['RESOURCE_GROUP_NAME'] 	= $Text_ResourceGroupName;

			$insArr['DESCRIPTION'] 			= $Text_Description;

			$insArr['TIME_POLICY_ID'] 		= $Combo_TimeManagementPolicy;

			$insArr['ROLE_ID'] 				= $Combo_TimeManagementRole;

			$insArr['PREAPPROVAL_RULE_ID'] 	= $Combo_TimeManagementPreApproval;

			$insArr['CREATED_BY'] 			= $LoginUserId ;

			$insArr['CREATION_DATE'] 		= date('Y-m-d H:i:s');

			$insArr['LAST_UPDATED_BY'] 		= $LoginUserId;	

			$insArr['SITE_ID'] 				= $SiteId;	

			

			insertdata("cxs_resource_groups",$insArr);	

			

			if($Combo_TimeManagementPreApproval != '')

			{

				$qry = "update cxs_preapp_rules set IN_USE_FLAG = 'Y' where PREAPP_RULE_ID = $Combo_TimeManagementPreApproval and IN_USE_FLAG <> 'Y'";

				mysql_query($qry);

			}

			

		}

	}

	

	if($IsUpdate =='Y' && $TotalRows >0) //when data post with the caption save

	{

		

	//	$TotalRows=1;

		unset($inArr);	

		$msg = "";

		for($i=1;$i<=$TotalRows;$i++)

		{

			$Check_Record = isset( $_POST['CheckboxInline'.$i] )? $_POST['CheckboxInline'.$i]: false;

			$IsDuplicate = isset($_POST["h_duplicate"] )? $_POST["h_duplicate"]: false;

			if($Check_Record==1 && $IsDuplicate != 'Y')			

			{

				$Text_ResourceGroupName = isset($_POST["Text_ResourceGroupName$i"] )? $_POST["Text_ResourceGroupName$i"]: false;

				$Text_Description = isset($_POST["Text_Description$i"] )? $_POST["Text_Description$i"]: false;				

				$Combo_TimeManagementPolicy = isset($_POST["Combo_TimeManagementPolicy$i"] )? $_POST["Combo_TimeManagementPolicy$i"]: false;

				$CheckboxActiveFlag = isset($_POST["CheckboxActiveFlag$i"] )? $_POST["CheckboxActiveFlag$i"]: false;

				$Combo_Role = isset($_POST["Combo_Role$i"] )? $_POST["Combo_Role$i"]: false;

				$Combo_PreApprovalRules = isset($_POST["Combo_PreApprovalRules$i"] )? $_POST["Combo_PreApprovalRules$i"]: false;

				

				

				//Combo_TimeManagementPreApproval

				unset($inArr);

				$Post_ResourceGroupId = isset( $_POST['h_ResourceGroupId'.$i] )? $_POST['h_ResourceGroupId'.$i]: false;				

				$insArr['RESOURCE_GROUP_NAME']	= $Text_ResourceGroupName;

				$insArr['DESCRIPTION'] 			= $Text_Description;

				$insArr['TIME_POLICY_ID'] 			= $Combo_TimeManagementPolicy;

				$insArr['ACTIVE_FLAG'] 			= ($CheckboxActiveFlag==1)?"Y":"N";

				$insArr['LAST_UPDATED_BY'] 		= $LoginUserId;			

			//	$insArr['ROW_NO'] 		= $i;

			

				$insArr['ROLE_ID'] 			= $Combo_Role;

				$insArr['PREAPPROVAL_RULE_ID'] 			= $Combo_PreApprovalRules;

				

				updatedata("cxs_resource_groups",$insArr,"where RESOURCE_GROUP_ID = $Post_ResourceGroupId");					

			}

			else if($IsDuplicate=="Y")

			{

				$msg = "Duplicate Resource Group Not Allowed.";

			}

			if($Combo_PreApprovalRules != '')

			{

				$qry = "update cxs_preapp_rules set IN_USE_FLAG = 'Y' where PREAPP_RULE_ID = $Combo_PreApprovalRules and IN_USE_FLAG <> 'Y'";

				mysql_query($qry);

			}

		}

	}

	$i=1;

	$qry = "Select * from cxs_resource_groups order by RESOURCE_GROUP_NAME ";

	$result = mysql_query($qry);

	while($row = mysql_fetch_array($result))

	{

		${Display_ResourceGroup.$i} = $row['RESOURCE_GROUP_NAME'];		

		${Display_Description.$i} = $row['DESCRIPTION'];		

		//${Display_ActiveFlag.$i} = $row['STATUS'];						

		$i=$i+1;

	}

		

?>

<script type="text/javascript" >

	ISDUPLICATE = "";

	RELATEDPOSITION = "";

	function CheckFavoriteData()

	{	

		KEY = "CheckFavoriteData";			

		var s1 = "Resource Groups";		

		var s2 = "<?php echo $PageName; ?>";				

		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);

	}

	function DataSort(str1,str2)

	{

		var str3;

		document.getElementById('h_field_name').value = str1;

		document.getElementById('h_field_order').value = str2;

		//alert(document.getElementById('h_field_name').value);

		//alert(str2);

		ResourceGroupList.submit();

	}

	

	function checkAll()

	{	

		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;

		var i=1;

		for(i=1;i<=TABLE_ROW;i++)

		{

			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		

		}

		if( $('#cmdUpdateSelected').text()=="Update Selected")

		{

			$("#cmdCancel").attr('disabled',true);

		}

	}   

	

	function checkInline()

	{

		for(i=1;i<=TABLE_ROW;i++)

		{

			if (document.getElementById("CheckboxInline"+i).checked == false)

			{

				document.getElementById('Checkbox_SelectAll').checked = false;

			}

		}

	}

	

	function EditRecord()

	{

		document.getElementById("h_NumRows").value = TABLE_ROW;

		var flag_updaterecord="";

		for(i=1;i<=TABLE_ROW;i++)

		{

			if (document.getElementById("CheckboxInline"+i).checked == true)

			{

				flag_updaterecord = "Y";

				break;

			}

		}

		

		if (flag_updaterecord == "Y")

		{

			var ButtonCaption = document.getElementById("cmdUpdateSelected").innerHTML;

			if (ButtonCaption != "Save")

			{

				document.getElementById("cmdUpdateSelected").innerHTML = "Save";

				$('#Checkbox_SelectAll').hide();

				for(i=1;i<=TABLE_ROW;i++)

				{

					if (document.getElementById("CheckboxInline"+i).checked )

					{

						InputElements(i,"Show");

					}

					else

					{

						$('#CheckboxInline'+i).hide();

					}

				}

				$("#cmdExport").attr('disabled',true);

				$("#cmdCancel").attr('disabled',false);

			}

			else

			{

				var flag_final="";	

				document.getElementById('h_field_update').value = 'Y';

				for(i=1;i<=TABLE_ROW;i++)

				{

					if (document.getElementById("CheckboxInline"+i).checked )

					{

						if(document.getElementById("Text_ResourceGroupName"+i).value == "")

						{

							alert("Pleae Enter Resource Group Name");

							document.getElementById("Text_ResourceGroupName"+i).focus();

							flag_final = "N";

							break;

						}

						CheckDuplicate('Text_ResourceGroupName'+i);

						if (document.getElementById("h_duplicate").value == "Y")

						{

							flag_final = "N";

							//document.getElementById("Text_ResourceGroupName"+RELATEDPOSITION).focus();

							alert("Resource Group Already Exists. Enter Different Name.");

							break;							

						}

						/*else if(document.getElementById("Text_Description"+i).value == "")

						{

							alert("Pleae Enter Description");

							document.getElementById("Text_Description"+i).focus();

							flag_final = "N";

							break;

						}			*/			

					}

				}				

				if (flag_final=="")

				{	

					flag_final = "Y";

					

					if (flag_final == "Y")

					{

						ResourceGroupList.submit();					

					}

				}	

			}

		}

		else

		{

			alert("Please Select Any Record For Update");

			document.getElementById("inlineCheckbox1").focus();

		}

	}

	function InputElements(CurrentRow,jFlag)

	{

		if(jFlag=="Show")

		{

			str1="none";

			str2="block";

		}

		else if(jFlag =="Hide")

		{

			str1="block";

			str2="none";

		}

		//document.getElementById(CurrentRow+"_5").value = "Save";

		document.getElementById("span"+CurrentRow+"_2").style.display = str1;

		document.getElementById("span"+CurrentRow+"_3").style.display = str1;

		document.getElementById("span"+CurrentRow+"_4").style.display = str1;

		document.getElementById("span"+CurrentRow+"_5").style.display = str1;

		document.getElementById("Text_ResourceGroupName"+CurrentRow).style.display = str2;

		document.getElementById("Text_Description"+CurrentRow).style.display = str2;		

		document.getElementById("Combo_TimeManagementPolicy"+CurrentRow).style.display = str2;		

		

		document.getElementById("span"+CurrentRow+"_6").style.display = str1;

		document.getElementById("span"+CurrentRow+"_7").style.display = str1;		

		document.getElementById("Combo_Role"+CurrentRow).style.display = str2;

		document.getElementById("Combo_PreApprovalRules"+CurrentRow).style.display = str2;

		document.getElementById("CheckboxActiveFlag"+CurrentRow).disabled = false;

	}	

	function CheckDuplicate(name)

	{	

		if (name!='')

		{

			KEY = "CheckResourceGroup";

			var regex = /\d+/g;

			var position = name.match(regex);

			RELATEDPOSITION = position; 

		//	var str = document.getElementById('text_accountname'+position).value;															

		//	var s1 = <?php echo (empty($GetAccountId))?'""':$GetAccountId;  ?>;	

			var str;

			if (position==null)

			{

				str = document.getElementById('Text_ResourceGroupName').value;	

			}

			else

			{

				str = document.getElementById('Text_ResourceGroupName'+position).value;															

			}			

			var s1 ="";													

			//makeRequest("ajax-checkduplicate.php","REQUEST=CheckResourceGroup&resourcegroup=" + str+"&selectedid="+s1); 	

			makeRequest("ajax-checkduplicate.php","REQUEST=CheckResourceGroup&resourcegroup=" + str); 			

		}

	}

	

	function ShowReadOnly(Id)

	{

		if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")

		{	

			KEY= "SingleRecord";	

			ReadonlyInputElements(true);

			$('#ModalResourceGroup').modal();		

			var FieldValue = Id;

			var FieldName = "RESOURCE_GROUP_ID";

			var TableName = "cxs_resource_groups";

			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			

		}

	}

	function ReadonlyInputElements(jFlag)

	{	

		$('#Text_ResourceGroupName').val("");				

		$('#Text_Description').val("");						

						

		$('#Text_ResourceGroupName').prop('disabled', jFlag);

		$('#Text_Description').prop('disabled', jFlag);

		$('#Combo_TimeManagementPolicy').prop('disabled', jFlag);		

		$('#Combo_Role').prop('disabled', jFlag);		

		$('#Combo_PreApprovalRules').prop('disabled', jFlag);		

		//$('#cmdAdd').prop('disabled', jFlag);		

		if (jFlag == true)

		{

			$("#ModalResourceGroup").find('.modal-title').text('Resource Group');

			$("#cmdAdd").hide();

		}

		else

		{

			$("#ModalResourceGroup").find('.modal-title').text('Create Resource Group');

			$("#cmdAdd").show();

		}

	}

	function selectedvalue(currentrow,currentvalue)

	{

		document.getElementById("Combo_TimeManagementPolicy"+currentrow).value = currentvalue;

	}

	

	function selectedvalueRole(currentrow,currentvalue)

	{

		document.getElementById("Combo_Role"+currentrow).value = currentvalue;

	}

	function selectedvaluePreApproval(currentrow,currentvalue)

	{

		document.getElementById("Combo_PreApprovalRules"+currentrow).value = currentvalue;

	}

	

	function FindData()

	{	

		KEY = "FindData";

		var formdata = $( "#Find-ResourceGroup-Form" ).serialize();		

		makeRequest("ajax-finddata.php","REQUEST=FindDataResourceGroup&"+formdata);					

	}	

	function RefreshData()

	{

		ResourceGroupList.submit();	

	}

</script>



<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<title>Coexsys | <?php echo strtoupper($SiteName);?></title>
<!-- <title>Coexsys | Time Accounting</title> -->

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<!-- font-awasome-->

<link href="../css/font-awesome.min.css" rel="stylesheet">

<link href="../css/bootstrap.min.css" rel="stylesheet">

<!-- custom-css -->

<link href="../css/style.css" rel="stylesheet">



<style type="text/css">

	.requirefieldcls

	{

		background-color: #fff99c;

	}

</style>

</head>



<body>

  <!-- modals start -->

	<form id = "ResourceGroupForm" name = "ResourceGroupForm" method="post" action="" >

		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalResourceGroup" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		

			<div class="modal-dialog modal-lg cus-modal-lg" role="document">

				<div class="modal-content">

					<div class="modal-header">

						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

						<h4 class="modal-title " id="myModalLabel"> Create Resource Group </h4>

					</div>

					<div class="modal-body"> 

						<!-- field start-->

						<div class="col-sm-12">

							<div class="cus-form-cont">

								<div class="col-sm-4 form-group">

								  <label> Resource Group Name </label> 

								  <input type="text" id = "Text_ResourceGroupName" name = "Text_ResourceGroupName" class="form-control requirefieldcls"  placeholder="" maxlength="50" required  onblur = "CheckDuplicate(this.id)">

								</div>

								<div class="col-sm-4 form-group">

								  <label> Description </label>

								  <input type="text" id = "Text_Description" name = "Text_Description" class="form-control" placeholder="" maxlength="100">

								</div>

								

								<div class="col-sm-4 form-group">

								  <label> Time Management Policy </label>  <!--it comes from Create New Policy page (Policy Profile Name column data) -->

								  

								  <?php

										$ComboPolicyValues = "<option value=''>- Time Management Policy -</option>";

										$qry = "select * from cxs_policy_header where SITE_ID = $SiteId order by NAME";

										$result = mysql_query($qry);

										while($row=mysql_fetch_array($result))

										{

											$PolicyID = $row['POLICY_ID'];

											$PolicyName = $row['NAME'];

											$ComboPolicyValues .= "<option value='$PolicyID' > $PolicyName  </option>";

										}

								  ?>

								  <select id = "Combo_TimeManagementPolicy" name = "Combo_TimeManagementPolicy" class="form-control requirefieldcls" required >

										<?php echo $ComboPolicyValues;  ?>

								  </select>

								  

								</div>

								

								<div class="col-sm-4 form-group">

								  <label> Role </label>  <!--it comes from Create New Policy page (Policy Profile Name column data) -->

								  

								  <?php

									//	$ComboRoleValues = "<option value=''>- Role -</option>";

									//	$ComboRoleValues .= "<option value='Role1'>Role1</option>";

									//	$ComboRoleValues .= "<option value='Role2'>Role2</option>";

										/*$qry = "select * from cxs_policy_header order by NAME";

										$result = mysql_query($qry);

										while($row=mysql_fetch_array($result))

										{

											$PolicyID = $row['POLICY_ID'];

											$PolicyName = $row['NAME'];

											$ComboPolicyValues .= "<option value='$PolicyID' > $PolicyName  </option>";

										}*/

								  ?>

								  <select id = "Combo_TimeManagementRole" name = "Combo_TimeManagementRole" class="form-control">

										<?php echo $ComboRoleValues;  ?>

								  </select>

								  

								</div>

								

								<div class="col-sm-4 form-group">

								  <label> Pre Approval Rules </label>  <!--it comes from Create New Policy page (Policy Profile Name column data) -->

								  

								  <?php 

										$ComboPreApprovalValues = "<option value=''>- Pre Approval Rules -</option>";

										$qry = "select * from cxs_preapp_rules where SITE_ID = $SiteId order by RULE_NAME";

										$result = mysql_query($qry);

										while($row=mysql_fetch_array($result))

										{

											$RuleID = $row['PREAPP_RULE_ID'];

											$RuleName = $row['RULE_NAME'];

											$ComboPreApprovalValues .= "<option value='$RuleID' > $RuleName  </option>";

										}

								  ?>

								  <select id = "Combo_TimeManagementPreApproval" name = "Combo_TimeManagementPreApproval" class="form-control" >

										<?php echo $ComboPreApprovalValues;  ?>

								  </select>

								  

								</div>

								<!--<div class="col-sm-6 form-group cus-form-ico">									

									<div class="checkbox">										

										<label><input type="checkbox" id = "Checkbox_AActive" name = "Checkbox_AActive"  value="1" >  Active </label> 	

									</div>

								</div>-->	

								

							</div>

						</div>

					<!-- end --> 

					</div>

					<div class="clear-both"></div>

					<div class="modal-footer cr-user">

						<button type="submit" id = "cmdAdd"  name = "cmdAdd" class="btn btn-primary btn-style"> Create Resource Group </button>						

					</div>

				</div>

			</div>

		</div>

		<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>

	</form>

	<!-- modals end -->

	

	<!--Search modals start -->

	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">

	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">

		<div class="modal-content">

		  <div class="modal-header">

			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

			<h4 class="modal-title " id="myModalLabel">Find Resource Group </h4>

		  </div>

		  <div class="modal-body"> 

			<!-- field start-->

			<form id="Find-ResourceGroup-Form" id="Find-ResourceGroup-Form">

				<div class="col-sm-12">

				  <div class="cus-form-cont">

					

					<div class="col-sm-6 form-group">

					  <label> Resource Group Name </label> 

					  <input type="text" id = "Text_FindResourceGroupName" name = "Text_FindResourceGroupName" class="form-control "  placeholder="" maxlength="50"   onblur = "CheckDuplicate(this.id)">

					</div>

					

					<div class="col-sm-6 form-group">

					  <label> Time Management Policy </label>  <!--it comes from Create New Policy page (Policy Profile Name column data) -->

					  <select id = "Combo_FindTimeManagementPolicy" name = "Combo_FindTimeManagementPolicy" class="form-control" maxlength="40">

						<option value="">- Time Management Policy -</option>

						<?php

							$qry = "select * from cxs_policy_header where SITE_ID = $SiteId order by NAME";

							$result = mysql_query($qry);

							while($row=mysql_fetch_array($result))

							{

								$TimeManagementName = $row['NAME'];

								$TimeManagementId = $row['POLICY_ID'];

						

								echo "<option value='$TimeManagementId'>$TimeManagementName</option>";

						}					

						?>

					  </select>				  

					</div>

				  </div>

				  

				</div>

			</form>

			<!-- end --> 

		  </div>

		  <div class="clear-both"></div>

		  <div class="modal-footer cr-user">

			<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>

		  </div>

		</div>

	  </div>

	</div>

	<!-- Search Modal  -->

	

	<?php include("header.php"); ?>

	<section class="md-bg">

	  <div class="container-fluid">

		<div class="row"> 

		  <!-- brd crum-->

		  <div class="brd-crmb">

			<ul>

			  <li> <a href="#"> Set Up </a></li>

			  <li> <a href="#"> Resource Groups </a></li>

			</ul>

		  </div>

		  <!-- Dash board -->

		  <div class="dash-strip">

		

			<div class="fright">

			

				<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>

				<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>

			</div>

		  </div>

		  

		  <!-- inner work-->

		  <div class="cont-box">

			<div class="pge-hd">

			  <h2 class="sec-title"> <label id="Label_Title"> Resource Groups </label></h2>

			</div>

			<?php																				

					$selectQuery = "SELECT  RESOURCE_GROUP_NAME,cxs_resource_groups.DESCRIPTION,cxs_policy_header.NAME as PolicyName,cxs_am_roles.ROLE_NAME, cxs_preapp_rules.RULE_NAME as PreApprovalRules ,cxs_resource_groups.ACTIVE_FLAG, cxs_resource_groups.*,cxs_users.USER_NAME as CreatedBy FROM cxs_resource_groups ";

					$selectQuery .= "LEFT JOIN cxs_policy_header on cxs_policy_header.POLICY_ID = cxs_resource_groups.TIME_POLICY_ID LEFT JOIN cxs_preapp_rules ON cxs_preapp_rules.PREAPP_RULE_ID = cxs_resource_groups.PREAPPROVAL_RULE_ID LEFT JOIN cxs_am_roles ON cxs_am_roles.ROLE_ID = cxs_resource_groups.ROLE_ID ";

					$selectQuery .= "inner join cxs_users on cxs_users.USER_ID = cxs_resource_groups.CREATED_BY  WHERE cxs_resource_groups.SITE_ID =$SiteId $s_Query $SQueryOrderBy ";

					$selectQueryForPages  = $selectQuery;

					$selectQuery .= " limit $start_from , $record_per_page";

					

					$ExportQry = $selectQuery;

					

					$RunUserQuery=mysql_query($selectQuery);

					$StdNumRows = mysql_num_rows($RunUserQuery);

					$msg = "";

					if($StdNumRows == 0 )

					{

						$msg = "No Record Found";

					}

			?>	

			<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>	

			<div>			

				<div class="fleft two">	

					<button type="button" class="btn-style btn" id="cmdUpdateSelected" <?php if($UPDATE_PRIV_ResourceGroup_PERMISSION=='Y'){ ?>name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>					

					<button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>

					<button type="button" class="btn-style btn" id="cmdCancel" name="cmdCancel" disabled="disabled"> Cancel</button>

				</div>

				

				<div class="fright cr-user">  

					<button type="button" class="btn btn-primary btn-style"  <?php  $sDisabled = ""; if($CREATE_PRIV_ResourceGroup_PERMISSION=='Y'){ ?> id = "cmdAddResourceGroup" name = "cmdAddResourceGroup"  data-toggle="modal" data-target="#ModalResourceGroup" onclick= 'ReadonlyInputElements(false)' <?php } else {?> disabled="disabled"<?php } ?> >   Create Resource Group</button> 					

				</div>

				

				<form name = "ResourceGroupList" id = "ResourceGroupList" method="post" >

					<div class="data-bx">

						<div class="table-responsive">

							<table id='Table1' class="table table-bordered mar-cont">

								<thead>

									<tr>										

										<th width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>

											<th width="15%">

												<?php if($Sorts == 'desc' && $FileName == 'RESOURCE_GROUP_NAME') { ?>

													  <span style="">

														Name 

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_GROUP_NAME','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Name 

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_GROUP_NAME','desc');"></i>

													  </span>

												<?php } ?>

											</th>



											<th width="15%">

												<?php if($Sorts == 'desc' && $FileName == 'DESCRIPTION') { ?>

													  <span style="">

														Description

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Description

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','desc');"></i>

													  </span>

												<?php } ?>

											</th>

											

											<th width="15%">

												<?php if($Sorts == 'desc' && $FileName == 'RESOURCE_GROUP_NAME') { ?>

													  <span style="">

														Time Management Policy

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_GROUP_NAME','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Time Management Policy

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_GROUP_NAME','desc');"></i>

													  </span>

												<?php } ?>

											</th>

											<th width="15%">

												<?php if($Sorts == 'desc' && $FileName == 'ROLE_NAME') { ?>

													  <span style="">

														Role

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ROLE_NAME','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Role

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ROLE_NAME','desc');"></i>

													  </span>

												<?php } ?>

											</th>

											<th width="15%">												

												<?php if($Sorts == 'desc' && $FileName == 'PreApprovalRules') { ?>

													  <span style="">

														Pre Approval Rules

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PreApprovalRules','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Pre Approval Rules

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PreApprovalRules','desc');"></i>

													  </span>

												<?php } ?>										

											</th>

											<th width="8%">

												<?php if($Sorts == 'desc' && $FileName == 'ACTIVE_FLAG') { ?>

													  <span style="">

														Active Flag

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','asc');"></i>

													  </span>

												<?php } else { ?>

													  <span style="">

														Active Flag

														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','desc');"></i>

													  </span>

												<?php } ?>

											</th>	

											<th width="5%"> </th>

										</tr>

									</thead>

									<tbody>

										<?php

											$i= 1;

											while($rows=mysql_fetch_array($RunUserQuery))

											{

												$Display_ResourceGroupId = $rows['RESOURCE_GROUP_ID'];																								

												$Display_Name	= $rows['RESOURCE_GROUP_NAME'];

												$Display_Description	= $rows['DESCRIPTION'];	

												$Display_ActiveFlag	= $rows['ACTIVE_FLAG'];												

												$Display_CreatedByName	= $rows['CreatedBy'];	

												$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));												

												$UpdatedBy		= $rows['LAST_UPDATED_BY'];

												$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							

												$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));

												$Display_PolicyID = $rows['TIME_POLICY_ID'];

												$Display_TimeManagementPolicy = $rows['PolicyName'];

												$Display_Role = $rows['ROLE_NAME'];

												$Display_RoleId = $rows['ROLE_ID'];

												$Display_PreApprovalRulesId = $rows['PREAPPROVAL_RULE_ID'];

												$Display_PreApprovalRules = $rows['PreApprovalRules'];

												

												

											?>

										<tr ondblclick="ShowReadOnly('<?php echo $Display_ResourceGroupId; ?>')">

											<td class="check-bx ">

												<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()" class="record_chk">

												<input type="hidden" id = <?php echo "h_ResourceGroupId".$i; ?> name = <?php echo "h_ResourceGroupId".$i; ?> value = "<?php echo $Display_ResourceGroupId; ?>">

											</td>

											<td> 

												<span id = "<?php echo "span".$i."_2"; ?>"> <?php echo $Display_Name; ?> </span>

												<input type = "text" class="form-control requirefieldcls" id="<?php echo "Text_ResourceGroupName".$i; ?>" name="<?php echo "Text_ResourceGroupName".$i; ?>" value ="<?php echo $Display_Name; ?>" required style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none" onblur = "CheckDuplicate(this.id)">

											</td>

											<td> 

												<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $Display_Description; ?> </span>

												<input type = "text" class="form-control" id="<?php echo "Text_Description".$i; ?>" name="<?php echo "Text_Description".$i; ?>" value ="<?php echo $Display_Description; ?>" style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">

											</td>

											<td> 

												<span id = "<?php echo "span".$i."_5"; ?>"> <?php echo $Display_TimeManagementPolicy; ?> </span>												

												 <select class="form-control" id = "<?php echo "Combo_TimeManagementPolicy".$i; ?>" name = "<?php echo "Combo_TimeManagementPolicy".$i; ?>"  style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">												 

														<?php echo $ComboPolicyValues;  ?>

												 </select>

												 <script> selectedvalue (<?php echo $i; ?>,<?php echo $Display_PolicyID;?>); </script>

											</td>

												

											<td>

												<span id = "<?php echo "span".$i."_6"; ?>"> <?php echo $Display_Role; ?> </span>

												<select class="form-control" id = "<?php echo "Combo_Role".$i; ?>" name = "<?php echo "Combo_Role".$i; ?>"  style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">

														<?php echo $ComboRoleValues;  ?>

												</select>

												<script> selectedvalueRole (<?php echo $i; ?>,'<?php echo $Display_RoleId;?>'); </script>

											</td>

											<td>

												<span id = "<?php echo "span".$i."_7"; ?>"> <?php echo $Display_PreApprovalRules; ?> </span>

												<select class="form-control" id = "<?php echo "Combo_PreApprovalRules".$i; ?>" name = "<?php echo "Combo_PreApprovalRules".$i; ?>"  style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">

														<?php echo $ComboPreApprovalValues;  ?>

												</select>

												<script> selectedvaluePreApproval (<?php echo $i; ?>,<?php echo $Display_PreApprovalRulesId;?>); </script>

											</td>

											<td class="check-bx "> 

												<span id = "<?php echo "span".$i."_4"; ?>"> <?php //echo $Display_ActiveFlag; ?> </span>	

												<input type="checkbox" id="<?php echo "CheckboxActiveFlag$i"; ?>" name="<?php echo "CheckboxActiveFlag$i"; ?>" value="1" disabled <?php echo ($Display_ActiveFlag=="Y")?"checked":"" ?>>

											</td>

											<td>

												<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="

												Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 

												<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>

											</td>

											

										</tr>

									 <?php   

											$i=$i+1;

											}

										?>

									</tbody>

								</table>

							</div>

						</div>

						<!-- save btn  -->

						

						<!-- pagination start-->

			

							<div class="pagination-bx">

								<div class="bs-example">

								  <ul class="pagination">

									<?php



											//$selectQueryForPages=$selectQueryForPages;

											$RunDepQuery=mysql_query($selectQueryForPages);

											$num_records = mysql_num_rows($RunDepQuery);

											$total_pages= ceil($num_records/$record_per_page);

											if (($page-1)==0){ ?>

												<li class="disabled">

													<!--<a rel="0" href="#"> «</a>-->

													<a rel="0" href="#">&laquo;</a>

												</li>

									  <?php  } else{  ?>

										<li class="">

										<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>

										</li>

										<?php }

									   for($i=1;$i<=$total_pages;$i++){ ?>

											<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>

											<?php }

											 if (($page+1)>$total_pages){   ?>

											<li class="disabled"><a href="#">&raquo;</a></li>

												<?php  }else{    ?>

										   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>

													  <?php } ?>



								  </ul>



								</div>

							</div>

							<!-- pagination end -->

							<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">

							<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	

							<input type="hidden" id="h_field_update" name="h_field_update" value="">

							<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>

							<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>

							<input type="hidden" id="h_query" name="h_query" value=""/>

					</form>	

			  

			 

			</div>

		  </div>

		</div>
<div class="dash-strip">

			

			<div class="fright">

				 <?php

					$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";

					$result=mysql_query	($qry);

					$TotalRecords = mysql_num_rows($result);

					if($TotalRecords == 0)

					{

						$s_Style = "";

					}

					else

					{

						$s_Style = "background-color: #000;";

					}

				?>          

				<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>


			</div>

		  </div>
	  </div>

	</section>

	<footer> </footer>

	<script src="../js/jquery.min.js"></script> 

<script src="../js/bootstrap.min.js"></script> 

<script src="../js/custom.js" type="text/javascript"></script>

	<script type="text/javascript">

		TABLE_ROW = document.getElementById("Table1").rows.length;				

		TABLE_ROW=TABLE_ROW-1;//remove header row from count	

		

		

		function makeRequest(url,data)

		{

				var http_request = false;

				if (window.XMLHttpRequest) { // Mozilla, Safari, ...

					http_request = new XMLHttpRequest();

					if (http_request.overrideMimeType) {

						http_request.overrideMimeType('text/xml');

						// See note below about this line

					}

				} else if (window.ActiveXObject) { // IE

					try {

						http_request = new ActiveXObject("Msxml2.XMLHTTP");

					} catch (e) {

						try {

							http_request = new ActiveXObject("Microsoft.XMLHTTP");

						} catch (e) {}

					}

				}



				if (!http_request) {

					alert('Giving up :( Cannot create an XMLHTTP instance');

					return false;

				}

				http_request.onreadystatechange = function() { alertContents(http_request); };

				http_request.open('POST', url, true);

				http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

				http_request.send(data);

		}



		function alertContents(http_request)

		{

			if (http_request.readyState == 4)

			{

				if (http_request.status == 200)

				{ 

					if(KEY == "CheckFavoriteData")

					{

						var s1 = http_request.responseText;	

						s1=s1.trim();				

						str = s1;

						var n;

						n = str.lastIndexOf("No");					

						if (n>=0)//(s1=="No")

						{

							document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";

							s1 = str.substring(0,n);											

						}

						else

						{

							document.getElementById("cmdFavorites").style.backgroundColor = "#000";						

						}					

						document.getElementById("favorite_list").innerHTML = s1;

					}

					

					else if(KEY == 'CheckResourceGroup')

					{

						var s1 = http_request.responseText;

						s1 = s1.trim();

						if(s1.length > 1)

						{

							document.getElementById("h_duplicate").value = "Y";

							

							if (RELATEDPOSITION!="")

							{

								document.getElementById("Text_ResourceGroupName"+RELATEDPOSITION).focus();

							}

							else

							{

								document.getElementById("Text_ResourceGroupName").focus();

							}

						}

					}					

					else if (KEY == "SingleRecord")

					{

						var JSONObject = JSON.parse(http_request.responseText);						

						$('#Text_ResourceGroupName').val(JSONObject['cxs_resource_groups']["RESOURCE_GROUP_NAME"]);				

						$('#Text_Description').val(JSONObject['cxs_resource_groups']["DESCRIPTION"]);

						$('#Combo_TimeManagementPolicy').val(JSONObject['cxs_resource_groups']["TIME_POLICY_ID"]);

						$('#Combo_TimeManagementRole').val(JSONObject['cxs_resource_groups']["ROLE"]);

						$('#Combo_TimeManagementPreApproval').val(JSONObject['cxs_resource_groups']["PREAPPROVAL_RULE_ID"]);

					}

					else if(KEY == 'FindData')

					{	

						document.getElementById("h_query").value=http_request.responseText;

						ResourceGroupList.submit();

					}

				}

				else

				{

					document.getElementById(KEY).innerHTML = "";

					alert('There was a problem with the request.');

				}

			}

		}

		$("#cmdCancel").click(function()

		{

			var i=1;

			$.each($(".record_chk"),function()

			{

				$(this).prop('checked' , false);

				InputElements(i,'Hide');				

				i=i+1;

			});

			$('#cmdUpdateSelected').text('Update Selected');

			$("#cmdExport").attr('disabled',false);

			$("#cmdCancel").attr('disabled',true);

			$('#Checkbox_SelectAll').prop('checked',false);

			$('#Checkbox_SelectAll').show();

		});

		

	function ExportRecord()

	{

		var exportIds=[];

		var exportTableHeadings = [];

		var SelecteId = "";

		var sql = '<?php echo $ExportQry; ?>';	

		var flag_checked = "";

		var TotalRows = $("#Table1 tr").length-1;

		

		for(i=1;i<=TotalRows;i++)

		{

			if ($("#CheckboxInline"+i).prop("checked")==true)

			{

				flag_checked="Y";

				SelecteId = $("#h_ResourceGroupId"+i).val();

				exportIds.push(SelecteId);

			}

		}

		if(flag_checked=="Y")		

		{

			$('#Table1 thead>tr').each(function () 

			{  

				$('th', this).each(function () 

				{  

					if($(this).text().trim()!='')

					{

						exportTableHeadings.push($(this).text().trim());

					}

				});

			});  

		

			$.ajax({

					url:"../ajax-export.php",				

					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,

						  ExportQryFieldName:'RESOURCE_GROUP_ID', ExportIdList:exportIds,

						  ExportFileName:'_resource-groups.xls', ExportSheetTitle:"Resource Groups"

						 },

					type:"POST",

					success:function(response)

					{

						window.location.href = '../export-records.php';										

					}

				});	

		}

		else

		{

			alert("Please Select Records For Export");

			$("#Checkbox_SelectAll").focus();

		}

	}

	</script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 



</body>

</html>