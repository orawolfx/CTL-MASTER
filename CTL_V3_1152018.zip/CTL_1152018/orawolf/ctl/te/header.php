<?php //ob_start ();

	 

	$LoginUserId = $_SESSION['user_id'];

	$CurrentUserType = "";

	//print_r($_SESSION['user-type']);

	if(HasUserType($_SESSION['user-type'],'TE-Admin'))

	{

		$CurrentUserType = "TE-Admin";

	}

	else if(HasUserType($_SESSION['user-type'],'TE-User'))

	{

		$CurrentUserType = "TE-User ";

	}		

	$_SESSION['current-user-type']=$CurrentUserType;	

	$SiteId1 = $_SESSION['user-siteid'];

	$SiteName = "";

	$qry = "Select * from cxs_sites where SITE_ID = $SiteId1";

	$result = mysql_query($qry);

	while($row = mysql_fetch_array($result))

	{

		$SiteName = "[".$row['SITE_NAME']."]";

	}

	$SiteId = $_SESSION['user-siteid'];
	$sql_ss = "select * from cxs_site_settings where SITE_ID=$SiteId";
	$res_ss = mysql_query($sql_ss);
	$numRow_ss = mysql_num_rows($res_ss);

	if($numRow_ss > 0)
	{
		$row_ss = mysql_fetch_object($res_ss);
		$image = $row_ss->image;
	}
	//print_r($image);die;

	//$qry = "SELECT `MODULE_NAME` FROM `cxs_ta_modules` WHERE `USER_ID` = $LoginUserId AND CREATE_PRIV = 'Y' AND TYPE = 'TE-admin'";
	$qry = "SELECT `MODULE_NAME` FROM `cxs_ta_modules` WHERE `USER_ID` = $LoginUserId AND VIEW_PRIV = 'Y' AND TYPE = 'TE-admin' ORDER BY MODULE_NAME ASC";

                 			$result = mysql_query($qry);
                 			$count = mysql_num_rows($result);
                
               			   $menu =array();
                 			while($row = mysql_fetch_assoc($result))
                 			{
                 				 if($row['MODULE_NAME'] == 'Time Entry'){
                                       $menu['Time_Entry'][] = $row;
                 				 }else {

                 				 	$menu['Other'][] = $row;

                 				 }
                 				 
                 				//echo "<pre>"; print_r($row);echo "</pre>";
                 				 
                 			}

                 			$Other = 0; $Time_Entry=0;
							foreach ($menu['Other'] as $type) {
							    $Other+= count($type);
							}
							foreach ($menu['Time_Entry'] as $type) {
							    $Time_Entry+= count($type);
							}
							//echo $Other;die;
		// for new user
							
                            
                         
                      $RolID_query = mysql_query("SELECT `ROLE_ID` FROM `cxs_users` WHERE `USER_ID` = $LoginUserId");     
                      $row_roleid = mysql_fetch_assoc($RolID_query);
                      $roleID = ($row_roleid['ROLE_ID'] > 0)?$row_roleid['ROLE_ID']:0;

 							
		 $sql =  "SELECT `USER_NAME`, `ROLE_ID` FROM `cxs_users` WHERE `ROLE_ID`= $roleID AND `USER_ID` = $LoginUserId";
		   $result = mysql_query($sql);
		   $array = array();
		   while ($row = mysql_fetch_assoc($result)) {
		   		$array['data'][] = $row;
		   		
			   }
	 
	   //echo $count = mysql_num_rows($result);
							 
		
            



?>

<header>	

  <div class="top-nav-bx">

    <div class="container-fluid">

      <div class="row">

        <div class="col-sm-6 col-md-6 bar-hea" style = "padding-left:2px;padding-right:2px;">

          <div class="logo">
           <a href="te.php"> 
           	<?php  if($image){?>
	          	<div class="logo-de lopu"> <img src="../rbam/uploads/<?php echo $image;?>" title="Site Logo">  </div> 
	            <?php }else{ ?>
	            <div class="logo-de">  <img src="../img/logo.jpg" data-toggle="tooltip" data-placement="bottom" title="Site Logo"></div> 
       		<?php }?>
           	<!-- <img src="../img/logo.jpg" data-toggle="tooltip" data-placement="bottom" title="Coexsys"> --></a> 
           	<span class="ac-manage"> Time & Labor</span>
           	 </div>
			<div class="navbar-heult fleft">
			<div class="navbar-header-ss navbar-default">

                    <button type="button" class="navbar-toggle dropdown" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

						<span class="sr-only"> Toggle navigation </span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

					</button>

                </div> 
                <div id="navbar" class="navbar-collapse dropdown-menu">
					
            <?php
             foreach($array['data'] as $key=> $values)
             {
            	//print_r($values);
            	if($values['ROLE_ID'] > 0){
            		
            	?>
         	        
        		<ul class="nav navbar-nav custom-nav">
	        		<?php if($Other > 0){?>
	         		<li class="dropdown" > <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Set Up <span class="caret"></span></a>
	         			<ul class="dropdown-menu">
	         		 	  <?php foreach ($menu['Other'] as $key=>$values):
	         		 	  	     
	         		 	  			$link = str_replace(" ", "-",$values['MODULE_NAME'] );
	         		 	  	?>
	         		 	 		<li><a href="<?php echo strtolower($link)?>.php"><?php echo $values['MODULE_NAME']; ?></a></li>
	         		 	  <?php  endforeach;?>		

	         		 	 </ul>
	          		 </li>
          		 	<?php }?>
          		 
      		 			<?php foreach($menu['Time_Entry'] as $k=>$values):
								$link = strtolower(str_replace(" ", "-",$values['MODULE_NAME'] ));
          		 				?>
          		 			<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Time Accounting <span class="caret"></span></a>
          		 				<ul class="dropdown-menu">
          		 				 <li><a href="<?php echo $link; ?>.php"><?php echo $values['MODULE_NAME']?></a></li>
          		 				</ul>
          					</li>
          		 			<?php endforeach;?>	 
         	  		</ul>
						<?php }
            	else
            		{

            			?>
            			<ul class="nav navbar-nav custom-nav">
            				<li class="dropdown" > <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Set Up <span class="caret"></span></a>
	         					<ul class="dropdown-menu">
									<li><a href="accounting-periods.php"> Accounting Periods </a></li>
									<li><a href="resource-aliases.php"> Resource Aliases </a></li>
									<li><a href="holiday-calendar.php"> Holiday Calendar </a></li>
									<li><a href="pre-approval-rules.php"> Pre Approval Rules </a></li>
									<li><a href="resource-groups.php"> Resource Groups </a></li>
									<li><a href="resource-management.php"> Resources </a></li>
									<li><a href="time-management-policy.php"> Time Policies </a></li>
									<li><a href="workshifts.php"> Work Shifts </a></li>              
					            </ul>
				        	</li>
				        	<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Time Accounting <span class="caret"></span></a>
           						 <ul class="dropdown-menu">			
			  						<li><a href="time-entry.php"> Time Entry </a></li>
			  			   		</ul>
          					</li>
            			</ul>

            			<?php
            		}
           	 }
            ?>
       

          

		  <!-- li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Time Accounting <span class="caret"></span></a>

            <ul class="dropdown-menu">

			<?php

			if ($CurrentUserType == "TE-Admin")

			{

				$CREATE_PRIV_TimeEntry_PERMISSION = "Y";

				$UPDATE_PRIV_TimeEntry_PERMISSION = "Y";

				$VIEW_PRIV_TimeEntry_PERMISSION = "Y";

				$ENABLE_AUDIT_TimeEntry_PERMISSION = "Y";

			}		

			else

			{		

				$CREATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Entry',$_SESSION['user_id']);

				$UPDATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Entry',$_SESSION['user_id']);

				$VIEW_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Time Entry',$_SESSION['user_id']);

				$ENABLE_AUDIT_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Time Entry',$_SESSION['user_id']);

			}

				$TimeEntry_page_visibility = false;

				if($CREATE_PRIV_TimeEntry_PERMISSION=='Y' || $UPDATE_PRIV_TimeEntry_PERMISSION=='Y' || $VIEW_PRIV_TimeEntry_PERMISSION=='Y' || $ENABLE_AUDIT_TimeEntry_PERMISSION=='Y')

				{

					$TimeEntry_page_visibility = true;

				}

			?>

			  <li><a <?php if($TimeEntry_page_visibility==true){ ?>href="time-entry.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Time Entry </a></li>

              <!--<li><a href="pre-approved-time-entry.php"> Pre-Approval Time Entry </a></li>->

             <?php

			if ($CurrentUserType == "TE-Admin")

			{

				$Notifications_PERMISSION = "Y";				

			}		

			else

			{	

				$Notifications_PERMISSION = getTimeAccountingRulesByUserId('BIZ_MSG_FLAG',$_SESSION['user_id']);				

			}

				$Notifications_page_visibility = false;

				if($Notifications_PERMISSION=='Y')

				{

					$Notifications_page_visibility = true;

				}

			?>

			<!-- <li><a <?php if($Notifications_page_visibility==true){ ?>href="notifications.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Notifications </a></li>	->		 

            </ul>

          </li>

        </ul> -->

                </div>  </div>
                <div class="fleft cr-user desb">
                        <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button></a>
                    </div>
        </div><!--logo-->

        <div class="col-sm-6 col-md-6" style = "padding-left:2px;padding-right:2px;">

			<ul class="top-nav">

				<?php

					$OpenSupportRequest = "";

					if ($CurrentUserType == "TE-Admin")

					{

						$OpenSupportRequest = "Y";

					}

					else

					{

						$qry = "select SUBMIT_CUSTOM from cxs_users left join cxs_am_roles on cxs_am_roles.ROLE_ID = cxs_users.ROLE_ID where cxs_users.USER_ID = $LoginUserId";

						$result=mysql_query	($qry);				

						while($rows = mysql_fetch_array($result))

						{

							$OpenSupportRequest = $rows['SUBMIT_CUSTOM'];

						}				

					}

				if($OpenSupportRequest=="Y"){ ?> 

				 <li class="dropdown botrn"> 

					<a href="te-support.php" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown " role="button" aria-haspopup="true" aria-expanded="false"> <img src="../img/supportw.png" data-placement="left" data-toggle="tooltip" title="Support"></a>

				</li>	

			<?php } ?>

			<!-- 	<li class="dropdown"> <a href="#" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="sm-hide"> Contact Support </span> <b class="fa fa-angle-down"></b></a>

             

				<li class="dropdown"> <a href="#" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-phone"></i> <span class="sm-hide"> Contact Support </span> <b class="fa fa-angle-down"></b></a>

				<ul class="dropdown-menu">

                <li><a href="te.php"> Chat Now </a></li>

                <li><a href="#"> Schedule a Call </a></li>

                <li><a href="#"> Send Message </a></li>

                <li><a href="#"> Call 858-945-8003 </a></li>

                <li><a href="#"> Open a Service request </a></li>

              </ul>

            </li>-->

				<li class="dropdown botrn"> 

                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../img/favorites.png" data-placement="bottom" data-toggle="tooltip" title="Favorites"></a>

				  <ul class="dropdown-menu" id="favorite_list" name="favorite_list">

				   <?php										

						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId order by FEATURE_NAME";

						$result=mysql_query	($qry);						

						while($rows = mysql_fetch_array($result))

						{

							$FEATURE_NAME = $rows['FEATURE_NAME'];

							$PAGE_NAME = $rows['PAGE_NAME'];

							$MODULE_NAME = $rows['MODULE_NAME'];

							if($ModuleName!=$MODULE_NAME)

							{

								if($MODULE_NAME=='Access Management')

								{

									$Link = "../rbam/".$PAGE_NAME;	

									$Link = "../rbam/".$PAGE_NAME."?m=1";

										

								}

								else if($MODULE_NAME=='Time Accounting')

								{

									$Link = "../te/".$PAGE_NAME."?m=1";

								}

							}

							else

							{

								$Link = $PAGE_NAME;

							}

					?>

						<li><a href="<?php  echo $Link; ?>"> <?php echo $FEATURE_NAME; ?></a></li>

				<?php 	} ?>

				  </ul>

				</li>

				<li class="dropdown botrn">  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../img/help.png" data-placement="left" data-toggle="tooltip" title="Help"></a>

				  <ul class="dropdown-menu uerli ">

					<li><a href="#"> Option 1 </a></li>

					<li><a href="#"> Option 2 </a></li>

				  </ul>

				</li>
				<li class="btn-primary" style="padding: 8px;font-size: 16px; cursor: pointer; border-radius: 4px;"><i class="fa fa-refresh" aria-hidden="true" data-toggle="tooltip" data-placement="left" title="Refresh" id="cmdRefresh" name="cmdRefresh" onclick="refreshPage();"></i></li>

				<?php $username = $_SESSION['user_data']['USER_NAME'];  

					include("../uploadphoto.php"); //echo getProfileImg($_SESSION['user_id']);

				?>			

				<li class="dropdown">

					<a href="#" class="dropdown-toggle user-box" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <img class="pro-img-bx" data-toggle="tooltip" title="User Account" data-placement="left" src="<?php echo getProfileImg($_SESSION['user_id']); ?>"/><!--<span class="name-bx2"> <?php //echo $username;?> </span><b class="fa fa-angle-down"></b>--></a>

			
                        <ul class="dropdown-menu uerli" style="top:55px;">
	  						<li><a href="javascript:;"> USERNAME: <?php echo $username;?> </a></li>
	  						
							<li><a href="javascript:uploadProfilePhotoModal();"> Upload Picture </a></li>

						<?php								

							if(isset($_SESSION['access-module']) && ($_SESSION['access-module']=='Both'))

							{?>

								<li><a href="../rbam/rbam.php"> Access Management </a></li>		
								<li><a href="../../SRM7/SRM/wizard/?id=0"> Reports </a></li>

					<?php 	}?>

						<li><a href="../logout.php"> Logout </a></li>

					

					</ul>

				</li>

			</ul>

        </div>

      </div>

    </div>

  </div>

  <!-- navigation  -->

  <?php /*?><nav class="navbar navbar-default custom-navbar">

    <div class="container-fluid">

      <div class="navbar-header">

        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only"> Toggle navigation </span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>

      </div>

      <div id="navbar" class="navbar-collapse collapse">

        

      </div>

      <!--/.nav-collapse --> 

    </div>

  </nav><?php */?>
<script type="text/javascript">
	   	function refreshPage(){
	   		window.location.href='';
	   	}
	   </script>
</header>