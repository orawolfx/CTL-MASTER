<?php ob_start ();
	 
	include("te-functions.php");
	include("sitename.php");
	
	check_login();
?>
<?php		
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_Resources_PERMISSION = "Y";
		$UPDATE_PRIV_Resources_PERMISSION = "Y";
		$VIEW_PRIV_Resources_PERMISSION = "Y";
		$ENABLE_AUDIT_Resources_PERMISSION = "Y";
	}
	else 
	{
		$CREATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Resources',$_SESSION['user_id']);
		$UPDATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Resources',$_SESSION['user_id']);
		$VIEW_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Resources',$_SESSION['user_id']);
		$ENABLE_AUDIT_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Resources',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_Resources_PERMISSION=='N' && $UPDATE_PRIV_Resources_PERMISSION=='N' && $VIEW_PRIV_Resources_PERMISSION=='N' && $ENABLE_AUDIT_Resources_PERMISSION=='N')
	{

		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "resource-management.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "FIRST_NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	
	if ($Sorts == 'asc')
	{
		$OrderBY = " desc";
		$FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";
	
	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page = 1;
	}	
	
	$start_from = ($page-1) *  $RecordsPerPage;
?>
<script type="text/javascript" >
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;
		//alert(document.getElementById('h_field_name').value);
		//alert(str2);
		ResourceList.submit();
	}
	
	var TABLE_ROW = 0;
	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Resource Management";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;		
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("Checkbox_Inline"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
		}
		
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_resourceid"+selectedRow).value;
			location.href="create-new-resource.php?hid="+s;
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}
	}
	function checkAll()
	{
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("Checkbox_Inline"+i).checked = checkboxValue;		
		}
	}   
	function CheckBoxInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("Checkbox_Inline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function ExportRecord1()
	{	
		KEY= "ExportRecord";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("Checkbox_Inline"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_resourceid"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		
		qry1 = '<?php echo $SQueryOrderBy; ?>';					
		//qry1 = 'order by ROW_NO';					
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportResources&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("Checkbox_SelectAll").focus();
		}
	}
	
	function ShowReadOnly(Id)
	{
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{				
			KEY= "SingleRecord";				
			$("#ModalElements :input").prop('disabled', true);
			$('#ModalDisplayPopup').modal();		
			var FieldValue = Id;
			var FieldName = "RESOURCE_ID";
			var TableName = "cxs_resources";
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
	}
	
	
	function ReadonlyInputElements(jFlag)
	{
		
		$('#Text_StartDate').prop('disabled', jFlag);
		$('#Text_EndDate').prop('disabled', jFlag);
		$('#Text_Year').prop('disabled', jFlag);
		$('#Text_PeriodName').prop('disabled', jFlag);
		$('#Combo_Status').prop('disabled', jFlag);
		//$('#cmdAdd').prop('disabled', jFlag);		
		if (jFlag == true)
		{
			$("#ModalAddAccountingPeriod").find('.modal-title').text('Display Record');
			$("#cmdAdd").hide();
		}
		else
		{
			$("#ModalAddAccountingPeriod").find('.modal-title').text('Add New Accounting Periods');
			$("#cmdAdd").show();
		}
	}
	function FindData()
	{	
		KEY = "FindData";
		var formdata = $( "#Find-Resource-Form" ).serialize();		
		makeRequest("ajax-finddata.php","REQUEST=FindDataResourceManagement&"+formdata);			
	}
	/*function RefreshData()
	{
		ResourceList.submit();
	}	*/
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys | <?php echo strtoupper($SiteName);?></title>
<!-- <title>Coexsys | Time Accounting</title> -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<style>
	
</style>
</head>

<body>
<?php include("header.php"); ?>

<!--Search modals start -->
<form id="Find-Resource-Form" >
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document" >
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Find Resource </h4>
		  </div>
		  <div class="modal-body"> 
			<!-- field start-->
			<div class="col-sm-12">
			  <div class="cus-form-cont">
				
				<div class="col-sm-4 form-group">
				  <label> First Name </label>
				  <input type="text" id = "Text_FindFirstName" name = "Text_FindFirstName" value = "<?php echo $Display_FirstName; ?>" class="form-control requirefieldcls" required placeholder="" maxlength="40" autofocus>
				</div>
				
				<div class="col-sm-4 form-group">
				  <label> Last Name </label>
				  <input type="text" id = "Text_FindLastName" name = "Text_FindLastName" value = "<?php echo $Display_LastName; ?>" class="form-control requirefieldcls" required placeholder="" maxlength="40">
				</div>
				
				<div class="col-sm-4 form-group">
				  <label> Supervisor </label>
				  <input type="text" id = "Text_FindSupervisor" name = "Text_FindSupervisor" value = "<?php echo $Display_FirstName; ?>" class="form-control requirefieldcls" required placeholder="" maxlength="40" autofocus>
				</div>
				
				<div class="col-sm-4 form-group">
				  <label> Resource Group </label>					
				  <select id = "Combo_FindResourceGroup" name = "Combo_FindResourceGroup" class="form-control "  maxlength="40">
					<option value="">- Resource Group -</option>
					<?php
						$qry = "select * from cxs_resource_groups where SITE_ID=$SiteId order by RESOURCE_GROUP_NAME";
						$result = mysql_query($qry);
						while($row=mysql_fetch_array($result))
						{
							$ResourceGroupName = $row['RESOURCE_GROUP_NAME'];
							$ResourceGroupId = $row['RESOURCE_GROUP_ID'];
							$IsSelected = "";
							if($Display_ResourceGroup==$ResourceGroupId)
							{
								$IsSelected = "selected";
							}
							echo "<option value='$ResourceGroupId' $IsSelected >$ResourceGroupName</option>";
						}
					?>
				  </select>
				</div>	
				
				<div class="col-sm-4 form-group">
				  <label> Resource Type </label>					
				  <select id = "Combo_FindResourceType" name = "Combo_FindResourceType" class="form-control "  maxlength="40">
					<option value="">- Resource Type -</option>
					<option value="Employee"> Employee</option>
					<option value="Contractor">Contractor</option>
					<option value="External">External or Out of the organization resource</option>
				  </select>
				</div>
				
			  </div>			  
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
		  </div>
		</div>
	  </div>
	</div>
</form>	
	<!-- Search Modal  -->
	
	<!--Display modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ModalDisplayPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " > Resource Management</h4>
		  </div>
		  <div class="modal-body" id = "ModalElements"> 
			<!-- field start-->
			<div class="col-sm-12"  >
				<div class="cus-form-cont">
					
						<div class="manage-bx" > 
          
							  <!-- Nav tabs -->
							<ul class="nav nav-tabs tab-menu-bx" role="tablist">
								<li role="presentation" class="active"><a href="#customer" aria-controls="home" role="tab" data-toggle="tab"> Resource </a></li>
								<li role="presentation"><a href="#addresses" aria-controls="profile" role="tab" data-toggle="tab"> Addresses  </a></li>
								<li role="presentation"><a href="#contacts" aria-controls="messages" role="tab" data-toggle="tab"> Contacts </a></li>
							</ul>
						  
						  <!-- Tab panes -->
						  
							<div class="tab-content" style = "padding-top:0px;">
								<div role="tabpanel" class="tab-pane active in" id="customer">
								  
									<div class="data-bx" style = "padding-top:0px;">
										<div class="col-sm-12">
											<div class="cus-form-cont">
												<div class="col-sm-4 form-group">
												  <label> First Name </label>
												  <input type="text" id = "Text_FirstName" name = "Text_FirstName"  class="form-control " >
												</div>
												<div class="col-sm-4 form-group">
												  <label> Middle Name </label>
												  <input type="text" id = "Text_MiddleName" name = "Text_MiddleName" class="form-control" >
												</div>
												<div class="col-sm-4 form-group">
												  <label> Last Name </label>
												  <input type="text" id = "Text_LastName" name = "Text_LastName" class="form-control "  >
												</div>
											<!--	<br>
												<div class=" col-sm-4 form-group ">
													<label> <input type="checkbox" id = "Check_PreApprove" name = "Check_PreApprove"  value="1" class="mar-tp3" > &nbsp;PreApproval Allowed </label>
												</div>
											-->
												<div class="col-sm-4 form-group">
												  <label> Availability Type </label>
												  <select id = "Combo_AvailbiltyType" name = "Combo_AvailbiltyType" class="form-control option_color" maxlength="20">
													<option class = "option_color" value="" > - Select Availability Type - </option>
													<option class = "option_color" value="Full Time"> Full Time </option>
													<option class = "option_color" value="Part Time"> Part Time </option>													
												  </select>
												</div>
												
												<div class="col-sm-4 form-group">
												  <label> Resource Group </label>					
												  <select id = "Combo_ResourceGroup" name = "Combo_ResourceGroup" class="form-control " >
													<option value="">- Resource Group -</option>
													<?php
														$qry = "select * from cxs_resource_groups order by RESOURCE_GROUP_NAME";
														$result = mysql_query($qry);
														while($row=mysql_fetch_array($result))
														{
															$ResourceGroupName = $row['RESOURCE_GROUP_NAME'];
															$ResourceGroupId = $row['RESOURCE_GROUP_ID'];
															$IsSelected = "";
															if($Display_ResourceGroup==$ResourceGroupId)
															{
																$IsSelected = "selected";
															}
															echo "<option value='$ResourceGroupId' $IsSelected >$ResourceGroupName</option>";
														}													
													?>
												  </select>
												</div>	
												<div class="col-sm-4 form-group">
												  <label> Resource Type </label>					
												  <select id = "Combo_ResourceType" name = "Combo_ResourceType" class="form-control " >
													<option value="">- Resource Type -</option>
													<option value="Employee" <?php echo ($Display_ResourceType=="Employee")?"selected":""; ?> > Employee</option>
													<option value="Contractor" <?php echo ($Display_ResourceType=="Contractor")?"selected":""; ?>  >Contractor</option>
													<option value="External or Out of the organization resource"  <?php echo ($Display_ResourceType=="External or Out of the organization resource")?"selected":""; ?> >External or Out of the organization resource</option>
												  </select>
												</div>
												<div class="col-sm-4 form-group">
												  <label> Contractor Type </label>
												  <select id = "Combo_ContractorType" name = "Combo_ContractorType" class="form-control" disabled maxlength="15">
													<option value="">- Contractor Type -</option>
													<option value="1099" <?php echo ($Display_ContractorType=="1099")?"selected":""; ?>>1099</option>
													<option value="C2C" <?php echo ($Display_ContractorType=="C2C")?"selected":""; ?>>C2C</option>						
												  </select>
												</div>
												
												<div class="col-sm-4 form-group cus-form-ico">
												  <label> Start Date </label>
												  <input type="text" id = "Text_StartDate" name = "Text_StartDate" class="form-control "  disabled maxlength="10" value = "<?php echo $Display_StartDate; ?>" >
												  <span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>
												
												<div class="col-sm-4 form-group cus-form-ico">
												  <label> End Date </label>
												  <input type="text" id = "Text_EndDate" name = "Text_EndDate" class="form-control" disabled maxlength="10" value = "<?php echo $Display_EndDate; ?>">
												  <span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>
												
												<div class="col-sm-4 form-group">  
												  <label> Time Management Policy </label>
												  <select id = "Combo_TimeManagementPolicy" name = "Combo_TimeManagementPolicy" class="form-control" disabled maxlength="40">
													<option value="">- Time Management Policy -</option>
													<?php
														$qry = "select * from CXS_POLICY_HEADER order by NAME";
														$result = mysql_query($qry);
														while($row=mysql_fetch_array($result))
														{
															$TimeManagementName = $row['NAME'];
															$TimeManagementId = $row['POLICY_ID'];
													
															echo "<option value='$TimeManagementId'>$TimeManagementName</option>";
													}
													
													?>
												  </select>
												</div>
												<div class="col-sm-4 form-group">
												  <label> Pre Approval Rules </label>
												  <select id = "Combo_PreApprovalRules" name = "Combo_PreApprovalRules" class="form-control" maxlength="40">
													<option value="">- Pre Approval Rules -</option>
													<?php
														$qry = "select * from cxs_preapp_rules where SITE_ID = $SiteId order by RULE_NAME";
														$result = mysql_query($qry);
														while($row=mysql_fetch_array($result))
														{
															$PreApprovalName = $row['RULE_NAME'];
															$PreApprovalId = $row['PREAPP_RULE_ID'];
															$selectedValue = "";
															if($Display_PreApprovalRules==$PreApprovalId)
															{
																$selectedValue = "selected";
															}
															echo "<option value='$PreApprovalId' $selectedValue>$PreApprovalName</option>";
														}
													?>
												  </select>
												</div>
												
												 <div class="col-sm-4 form-group">
												  <label> Supervisor </label>
												  <input type="text" id = "Text_Supervisor" name = "Text_Supervisor" class="form-control " disabled maxlength="40"   value = "<?php echo $Display_Supervisor; ?>">
												</div>
												
												<div class="col-sm-3 form-group fright">
													
												</div>
														
											</div>							
										</div>
									</div>
									<div class="clear-both"></div> 
								</div>
								<!-- customer end -->
								
								<div role="tabpanel" class="tab-pane" id="addresses">
									<div class="data-bx">
										<div class="table-responsive">											
											<table class="table table-bordered mar-cont" id = "TableAddresses">
												<thead>
													<tr>										
														<th width="10%"> Address 1 </i></a> </th>
														<th width="10%">Address 2 </i></a></th>
														<th width="10%">Address 3 </i></a></th>
														<th width="10%">City </i></a></th>                      
														<th width="10%">State </i></a></th>
														<th width="10%">Country </i></a></th>
														<th width="10%">Postal Code </i></a></th>
														<th width="5%">Primary </i></a></th>
														<th width="5%">Active </i></a></th>
													</tr>
												</thead>
												<tbody>	
												</tbody>	
											</table>		
										</div>
									</div>
								</div>
								<!-- addresses end -->
								<div role="tabpanel" class="tab-pane" id="contacts">									
									<div class="data-bx">
										<div class="table-responsive">											
											<table class="table table-bordered mar-cont" id = "TableContacts">
												<thead>
													<tr>										
														<th width="25%"> Phone </i></a></th>
														<th width="30%">Email Address </i></a></th>
														<th width="10%">Primary </i></a></th>
														<th width="10%">Active </i></a></th>
														<th width="10%">Accept Text </i></a></th>
													</tr>
												</thead>	
												<tbody>	
												</tbody>		
											</table>		
										</div>
									</div>
									<div class="clear-both"></div> 									
								</div>								
							</div>
						</div>				
				</div>
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			
		  </div>
		</div>
		</div>
	</div>
	<!-- Display Modal  -->
	
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="#"> Resource Management </a></li>
        </ul>
      </div>
      <!-- Dash board -->
	  
      <div class="dash-strip">
        
        <div class="fright">
			
			<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
			<!-- <button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button> -->
        </div>
      </div>
      <!-- inner work-->
      <div class="cont-box">
        <div class="pge-hd">
          <h2 class="sec-title"> <label id="Label_Title"> Resource Management </label></h2>
        </div>
        <div>
		<?php 
			$ExportQry = "select a.FIRST_NAME,a.LAST_NAME,a.RESOURCE_TYPE,a.START_DATE_ACTIVE,a.END_DATE_ACTIVE,concat (cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME) as SupervisorName from ( ";
			$ExportQry .= "SELECT FIRST_NAME,LAST_NAME,RESOURCE_TYPE,START_DATE_ACTIVE,END_DATE_ACTIVE,SUPREVISOR_ID  FROM cxs_resources ";
			$ExportQry .= "where cxs_resources.SITE_ID = $SiteId $s_Query $SQueryOrderBy) as a left join cxs_resources on cxs_resources.RESOURCE_ID = a.SUPREVISOR_ID ";	
				
			$selectQuery = "SELECT  cxs_resources.*, cxs_users.USER_NAME as CreatedBy FROM cxs_resources inner join cxs_users on cxs_users.USER_ID = cxs_resources.CREATED_BY WHERE cxs_resources.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";			
			$selectQueryForPages  = $selectQuery;
			$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
		
			$RunUserQuery=mysql_query($selectQuery);
			$StdNumRows = mysql_num_rows($RunUserQuery);
			$msg = "";
			if($StdNumRows == 0 )
			{
				$msg = "No Record Found";
			}
		?>
		<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
		  <br>
		<form class="form" id="ResourceList" name="ResourceList" action="" method="POST">
          <div class="fleft two">
			<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_Resources_PERMISSION=='Y'){ ?>id="cmdUpdateSelected" name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>			
            <button type="button" class="btn-style btn" onclick='ExportRecord()'> Export </button>
			<!--<button type="button" class="btn-style btn" onclick="window.location.href='exportRecords.php'"> Export </button>-->
          </div>
          <div class="fright cr-user">
			<a <?php $sDisabled = ""; if($CREATE_PRIV_Resources_PERMISSION=='Y'){ ?> href="create-new-resource.php" <?php } else $sDisabled ="disabled=disabled"; ?>> 
			<button type="button" class="btn btn-primary btn-style" <?php echo $sDisabled; ?>> Create New Resource </button></a>			
          </div>
          <div class="data-bx">
            <div class="table-responsive">
              <table class="table table-bordered mar-cont" id='Table1'>
                <thead>
                  <tr>
                   <th width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" value="option1" onchange="checkAll()"></th> 				    
                  
					
					<th width="10%">
							<?php if($Sorts == 'desc' && $FileName == 'FIRST_NAME') { ?>
								  <span style="">
									First Name
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('FIRST_NAME','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									First Name 
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('FIRST_NAME','desc');"></i>
								  </span>
							<?php } ?>
						</th>
						
						<th width="10%">
							<?php if($Sorts == 'desc' && $FileName == 'LAST_NAME') { ?>
								  <span style="">
									Last Name
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('LAST_NAME','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Last Name 
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('LAST_NAME','desc');"></i>
								  </span>
							<?php } ?>
						</th>
						
						<th width="12%">
							<?php if($Sorts == 'desc' && $FileName == 'RESOURCE_TYPE') { ?>
								  <span style="">
									Resource Type
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_TYPE','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Resource Type
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_TYPE','desc');"></i>
								  </span>
							<?php } ?>
						</th>	
						
						<th width="18%">
							<?php if($Sorts == 'desc' && $FileName == 'START_DATE_ACTIVE') { ?>
								  <span style="">
									Start Date Active
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('START_DATE_ACTIVE','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									Start Date Active
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('START_DATE_ACTIVE','desc');"></i>
								  </span>
							<?php } ?>
						</th>

						<th width="10%">
							<?php if($Sorts == 'desc' && $FileName == 'END_DATE_ACTIVE') { ?>
								  <span style="">
									End Date Active
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('END_DATE_ACTIVE','asc');"></i>
								  </span>
							<?php } else { ?>
								  <span style="">
									End Date Active
									<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('END_DATE_ACTIVE','desc');"></i>
								  </span>
							<?php } ?>
						</th>

						 <th width="10%"> Supervisor  </th>
					
					

                    <th width="5%"> </th>
                  </tr>
                </thead>
                <tbody>
					<?php
						//$s_data = "";
						//$s_data = "User Name, Resource Name, Resource Id, Start Date Active, End Date Active, Active User  \r\n";
						
						$i= 1;
						while($rows=mysql_fetch_array($RunUserQuery))
						{
							$FirstName = $rows['FIRST_NAME'];
							$LastName = $rows['LAST_NAME'];
							$ResourceType = $rows['RESOURCE_TYPE'];
							$StartDate = "";
							$EndDate = "";
							$OrganizationCode = "";
							if((!is_null($rows['START_DATE_ACTIVE'])) && (($rows['START_DATE_ACTIVE'])!='0000-00-00') )
							{			
								$StartDate = date('m/d/Y', strtotime($rows['START_DATE_ACTIVE']));
							}
							if((!is_null($rows['END_DATE_ACTIVE'])) && (($rows['END_DATE_ACTIVE'])!='0000-00-00') )
							{			
								$EndDate = date('m/d/Y', strtotime($rows['END_DATE_ACTIVE']));
							}
							$SupervisorName = "";
							$SupervisorId = $rows['SUPREVISOR_ID'];
							if($SupervisorId!='')
							{
								$qry1 = "select FIRST_NAME,LAST_NAME from cxs_resources where RESOURCE_ID =  $SupervisorId";
								$result1 = mysql_query($qry1);
								while($row1 = mysql_fetch_array($result1))
								{
									 $SupervisorName = $row1['FIRST_NAME']. ' '.$row1['LAST_NAME'];
								}
							}
							$Display_ResourceID	= $rows['RESOURCE_ID'];	
							$Display_CreatedByName	= $rows['CreatedBy'];	
							$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));							
							$UpdatedBy		= $rows['LAST_UPDATED_BY'];
							$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							
							$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));	
					?>                  
				  <tr  <?php if($VIEW_PRIV_Resources_PERMISSION=='Y') {?> ondblclick="ShowReadOnly('<?php echo $Display_ResourceID; ?>')" <?php } ?>>
                    <td class="check-bx ">
						<input type="checkbox" id="<?php echo "Checkbox_Inline$i"; ?>" name="<?php echo "Checkbox_Inline$i"; ?>  value="1" onchange="CheckBoxInline()">
						<input type="hidden" id = <?php echo "h_resourceid".$i; ?> name = <?php echo "h_resourceid".$i; ?> value = "<?php echo $Display_ResourceID; ?>">
					</td>
                    <td> <?php echo $FirstName; ?> </td>
                    <td> <?php echo $LastName; ?> </td>
                   <!-- <td> <?php //echo $OrganizationCode; ?> </td>-->
                    <td> <?php echo $ResourceType; ?> </td>
                    <td> <?php echo $StartDate; ?></td>
                    <td> <?php echo $EndDate; ?></i></td>
                    <td> <?php echo $SupervisorName; ?> </td>                    
					<td>
						<?php if($VIEW_PRIV_Resources_PERMISSION=='Y') {?>
						<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
						Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
						<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
						<?php } else {?> <button type="button" class="btn btn-default"><i class=" fa fa-eye"></i></button> <?php } ?>
					</td>
                  </tr>
				<?php $i= $i+1;
				}	?>
                </tbody>
              </table>
            </div>
          </div>
          
         <!-- pagination start-->
			<div class="pagination-bx">
				<div class="bs-example">
				  <ul class="pagination">
					<?php

							$selectQueryForPages;
							$RunDepQuery=mysql_query($selectQueryForPages);
							$num_records = mysql_num_rows($RunDepQuery);
							$total_pages= ceil($num_records/$RecordsPerPage);
							if (($page-1)==0){ ?>
								<li class="disabled">
									<!--<a rel="0" href="#"> «</a>-->
									<a rel="0" href="#">&laquo;</a>
								</li>
					  <?php  } else{  ?>
						<li class="">
						<a rel="0" href="?page=<?php echo ($page-1); ?>">&laquo;</a>
						</li>
						<?php }
					   for($i=1;$i<=$total_pages;$i++){ ?>
							<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>"><?php echo $i; ?></a></li>
							<?php }
							 if (($page+1)>$total_pages){   ?>
							<li class="disabled"><a href="#">&raquo;</a></li>
								<?php  }else{    ?>
						   <li class=""><a href="?page=<?php echo ($page+1); ?>">&raquo;</a></li>
									  <?php } ?>

				  </ul>
				</div>
			</div>
			<!-- pagination end -->
			<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
			<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">
			<input type="hidden" id="h_query" name="h_query" value=""/>
		</form>	
        </div>
      </div>
    </div><div class="dash-strip">
        
        <div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
			<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
			
        </div>
      </div>
  </div>
</section>
<script type="text/javascript">
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count	
	
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;						
					//alert(str);
					window.open('downloaddata.php?r=resources-list', '_blank');
				}
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;					
					document.getElementById("h_query").value=s1;					
					s1 = s1.trim();					
					ResourceList.submit();
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText);
					$('#Text_FirstName').val(JSONObject['cxs_resources']["FIRST_NAME"]);
					$('#Text_MiddleName').val(JSONObject['cxs_resources']["MIDDLE_NAME"]);
					$('#Text_LastName').val(JSONObject['cxs_resources']["LAST_NAME"]);
					$('#Combo_AvailbiltyType').val(JSONObject['cxs_resources']["AVAILABILTY_TYPE"]);					
					$('#Combo_ResourceGroup').val(JSONObject['cxs_resources']["RESOURCE_GROUP_ID"]);
					$('#Combo_ResourceType').val(JSONObject['cxs_resources']["RESOURCE_TYPE"]);					
					$('#Combo_ContractorType').val(JSONObject['cxs_resources']["CONTRACTOR_TYPE_FLAG"]);
					$('#Text_StartDate').val(MyDateFormat(JSONObject['cxs_resources']["START_DATE_ACTIVE"]));
					$('#Text_EndDate').val(MyDateFormat(JSONObject['cxs_resources']["END_DATE_ACTIVE"]));
					$('#Combo_TimeManagementPolicy').val(JSONObject['cxs_resources']["TIMEMANAGEMENTPOLICY_ID"]);
					$('#Combo_PreApprovalRules').val(JSONObject['cxs_resources']["PREAPPROVALRULES_ID"]);
					$('#Text_Supervisor').val(JSONObject['SupervisorName']);					
					$('#Combo_JobClassification').val(JSONObject['cxs_resources']["JOB_CLASSIFICATION"]);				
					
					var AddressDetailRows = JSONObject['ADetailRows'];
					var ContactDetailRows = JSONObject['CDetailRows'];
					var i ;
					var check1,check2,check3;
					var check1value,check2value,check3value;
					
					$('#TableAddresses').find('tbody').remove();
					$('#TableContacts').find('tbody').remove();
					
					
					for(i=0;i<AddressDetailRows;i++)
					{
						check1value = (JSONObject[i]['PRIMARY_FLAG']=='Y')?'checked':'' ;
						check1 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						check2value = (JSONObject[i]['ACTIVE_FLAG']=='Y')?'checked':'' ;
						check2 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						$('#TableAddresses').append('<tr><td>'+JSONObject[i]["ADDRESS1"]+'</td><td>'+JSONObject[i]["ADDRESS2"]+'</td><td>'+JSONObject[i]["ADDRESS3"]+'</td><td>'+JSONObject[i]["CITY"]+'</td><td>'+JSONObject[i]["STATE"]+'</td><td>'+JSONObject[i]["COUNTRY"]+'</td><td>'+JSONObject[i]["POSTAL_CODE"]+'</td>'+ check1 + check2 + '</tr>');					
					}			
					
					
					for(i=AddressDetailRows;i<(ContactDetailRows + AddressDetailRows);i++)
					{						
						check1value = (JSONObject[i]['CPRIMARY_FLAG']=='Y')?'checked':'' ;
						check1 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						
						check2value = (JSONObject[i]['CACTIVE_FLAG']=='Y')?'checked':'' ;
						check2 = "<td class='check-bx'><input type='checkbox'" + check2value + " disabled ></td>";
						
						check3value = (JSONObject[i]['CACCEPTS_TEXTS_FLAG']=='Y')?'checked':'' ;
						check3 = "<td class='check-bx'><input type='checkbox'" + check3value + " disabled ></td>";
						
						
						$('#TableContacts').append('<tr><td>'+JSONObject[i]["PHONE_NUMBER"]+'</td><td>'+JSONObject[i]["EMAIL_ADDRESS"]+'</td>'+ check1 + check2 + check3 +'</tr>');
					}
				}
				
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	function MyDateFormat(inputDate)
	{
		var date = new Date(inputDate);
		if (!isNaN(date.getTime())) {
			// Months use 0 index.
			return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear();
		}
		else
		{
			return '';
		}
	}
	
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = "<?php echo $ExportQry; ?>";	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#Checkbox_Inline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_resourceid"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",			
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'RESOURCE_ID', ExportIdList:exportIds,
						  ExportFileName:'resource-management.xls', ExportSheetTitle:"Resource Management"
						  },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>