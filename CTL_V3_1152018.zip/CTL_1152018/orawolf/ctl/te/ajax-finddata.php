<?php
include('../conn.php');
?>
<?php
if($_REQUEST['REQUEST'] == "FindDataAccountPeriod") 
{
	$CalendarName = $_REQUEST['CalendarName'];
	$Year = $_REQUEST['Year'];
	
	$s_query = "";
	
	if($CalendarName!='')
	{
		$s_query .= " and cxs_calendars.CALENDAR_ID = $CalendarName ";
	}
	if($Year!='')
	{
		$s_query .= "and cxs_calendars.PERIOD_YEAR like'%$Year%' ";
	}		
	echo $s_query;
}
if($_REQUEST['REQUEST'] == "FindDataAccountPeriod4Year")
{
	$CalendarId = $_REQUEST['CalendarId'];		
	$sql = "SELECT * from cxs_calendars where CALENDAR_ID = '$CalendarId'";
	$result = mysql_query($sql);	
	while($row=mysql_fetch_array($result))
	{
		echo $row['PERIOD_YEAR'];	
	}
}
if($_REQUEST['REQUEST'] == "FindDataAliases")
{
	$AliasName = $_REQUEST['AliasName'];
	$IsCopy = $_REQUEST['IsCopy'];
	$IsAutoPopulate = $_REQUEST['IsAutoPopulate'];
	$IsActive = $_REQUEST['IsActive'];
	$IsInUse = $_REQUEST['IsInUse'];
	
	$s_query = "";
	
	if($AliasName!='')
	{
		$s_query .= " and cxs_aliases.ALIAS_NAME like'%$AliasName%' ";
	}
	if($IsCopy!='')
	{
		$s_query .= "and cxs_aliases.COPY_ALLOWED ='$IsCopy' ";
	}
	if($IsAutoPopulate!='')
	{
		$s_query .= "and cxs_aliases.AUTOPOPULATE ='$IsAutoPopulate' ";
	}
	if($IsActive!='')
	{
		$s_query .= "and cxs_aliases.ACTIVE_FLAG ='$IsActive' ";
	}
	if($IsInUse!='')
	{
		$s_query .= "and cxs_aliases.ADDINUSE_FLAG ='$IsInUse' ";
	}
		
	echo $s_query;
}


if($_REQUEST['REQUEST'] == "FindDataCopyAlias")
{
	$AliasName = $_REQUEST['AliasName'];	
	$LoginUserId = $_SESSION['user_id']; 
?>
	<table id='TablePopup-CopyAliasHd' class="table table-bordered " width="100%"  >
		<thead>
		  <tr>
			<th width="5%" class="check-bx "><input type="checkbox" id="Copy_Checkbox_SelectAll" onchange="CopyCheckAll()"></th>
			<th width="10%"> User Name </th>
			<th width="15%"> Alias Name </th>
			<th width="35%"> Description </th>
		  </tr>
		</thead>
		<tbody id = "TablePopup-CopyAliasList">
<?php	//if(//$AliasName!='')
	{ 	
		$i=1;
		//and cxs_aliases.CREATED_BY <> $LoginUserId  AND ACTIVE_FLAG = 'Y' and cxs_aliases.ALIAS_NAME  not in (select cxs_aliases.ALIAS_NAME from cxs_aliases where cxs_aliases.CREATED_BY = $LoginUserId)
		$sql = "SELECT cxs_aliases.*,cxs_users.USER_NAME from cxs_aliases  inner join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY where cxs_aliases.ALIAS_CLASS = '' and COPY_ALLOWED = 'Y' and cxs_aliases.ALIAS_NAME like '%$AliasName%' 
		 order by cxs_aliases.ALIAS_NAME";
		$result = mysql_query($sql);	
		while($row=mysql_fetch_array($result))
		{
			$UserName = $row['USER_NAME'];
			$AliasId = $row['ALIAS_ID'];
			$AliasName =  $row['ALIAS_NAME'];
			$Description =  $row['DESCRIPTION'];			
		?>
			<tr style="cursor:pointer"  >
				<td class="check-bx "><input type="checkbox" id="<?php echo "Copy_CheckboxInline$i" ?>" name="<?php echo "Copy_CheckboxInline$i" ?>" onchange="CopyCheckInline()"></th>
				<td><?php echo $UserName; ?>
					<input type="hidden" id = <?php echo "h_AliasId$i"; ?> name = <?php echo "h_AliasId$i "; ?> value = "<?php echo $AliasId; ?>">
				</td> 
				<td><?php echo $AliasName; ?></td> 
				<td><?php echo $Description; ?></td>  				
			</tr>
	<?php	
			$i=$i+1;
		}		
	}?>
		</tbody>
	</table>
<?php }

if($_REQUEST['REQUEST'] == "CopyAliasData")
{
	$AliasId = $_REQUEST['AliasId'];	
	$CurrentUserId = $_SESSION["LogUserId"];
	$CurrentUserId = 1;
	$AlreadyExist = "";
	$SiteId = $_SESSION['user-siteid'];
	if($AliasId!='')
	{	
		do
		{
			$pos = strpos($AliasId,"|");
			$s1 = trim(substr($AliasId, 0, $pos));  //id
			$sQuery = $sQuery."ALIAS_ID=$s1 or ";
			$AliasId = substr($AliasId, $pos+1);
		}while($AliasId.length>0);			
		$sQuery=substr( $sQuery, 0, -3 ); // create query
		
	/*	if ($sQuery!='') // check already exists or not
		{
			$qry = "Select * from cxs_aliases where 1=1 and ($sQuery) and CREATED_BY = $CurrentUserId order by ALIAS_NAME";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$AlreadyExist = $AlreadyExist.$row['ALIAS_NAME'].",";
			}
		}
		
		if ($AlreadyExist!='') 
		{
			$AlreadyExist = substr($AlreadyExist,0,-1);
			echo "You cannot copy your own aliases name - $AlreadyExist";	
		}
		else //when not exists - insert record
		{*/
			
			$qry = "Select * from cxs_aliases where SITE_ID = $SiteId and ($sQuery) order by ALIAS_NAME";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$TempAliasName = $row['ALIAS_NAME']; 
				$s1= $row['ALIAS_NAME']; 
				$strpos = strpos($TempAliasName,"(Copy");
				if ($strpos > 0)
				{
					$s1 = substr($TempAliasName,0,$strpos-1);					
					$TempAliasName =$s1;
				}
				
				$TempAliasName1 = $TempAliasName." (Copy%"; 
				$TotalCount = 0;
				$qry1 = "Select count(*)  as TotalCount  from cxs_aliases where CREATED_BY = $CurrentUserId and (ALIAS_NAME = '$TempAliasName'  OR ALIAS_NAME like '$TempAliasName1') and SITE_ID = $SiteId";
				$result1 = mysql_query($qry1);
				while($row1=mysql_fetch_array($result1))
				{
					$TotalCount = $row1['TotalCount'];
				}
				if($TotalCount>0)
				{	
					$TempAliasName = $s1." (Copy $TotalCount".")";
				}
				$insArr = array();
				$insArr['ALIAS_NAME'] = $TempAliasName;
				$insArr['DESCRIPTION'] =  $row['DESCRIPTION'];
				$insArr['ALIAS_TYPE'] =  $row['ALIAS_TYPE'];
				$insArr['ALIAS_CLASS'] =  $row['ALIAS_CLASS'];
				$insArr['WBS_ID'] =  $row['WBS_ID'];
				$insArr['COPY_ALLOWED'] =  $row['COPY_ALLOWED'];
				$insArr['AUTOPOPULATE'] =  $row['AUTOPOPULATE'];
				$insArr['ACTIVE_FLAG'] =  $row['ACTIVE_FLAG'];
				$insArr['ADDINUSE_FLAG'] =  $row['ADDINUSE_FLAG'];
				$insArr['LAST_UPDATED_BY'] = $CurrentUserId;				
				$insArr['CREATION_DATE']='now()' ;
				$insArr['CREATED_BY']=$CurrentUserId;
				$insArr['SITE_ID']=$SiteId;
				
				$qry1 = "Select * from cxs_aliases where ALIAS_NAME = '$TempAliasName' and SITE_ID = $SiteId";
				$result1 = mysql_query($qry1);
				$noofrecords= mysql_num_rows($result1);
				if($noofrecords == 0)
				{
					insertdata("cxs_aliases",$insArr);
				}
			}
			echo "Records Copied";
		//}
	}
	
}	

if($_REQUEST['REQUEST'] == "FindDataHolidayCalendar")
{
	$CalendarName = $_REQUEST['CalendarName'];
	$PayPeriodYear = $_REQUEST['PayPeriodYear'];
	
	$s_query = "";
	
	if($CalendarName!='')
	{
		$s_query .= " and cxs_holidays.CALENDAR_NAME like'%$CalendarName%' ";
	}
	if($PayPeriodYear!='')
	{
		$s_query .= "and cxs_holidays.PERIOD_YEAR = $PayPeriodYear ";
	}	
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataPreApprovalRule")
{
	$Type = $_REQUEST['Type'];
	$PayPeriodId = $_REQUEST['PayPeriodId'];
	
	$s_query = "";
	
	if($Type!='')
	{
		$s_query .= " and cxs_preapp_rules.PREAPPROVAL_TYPE like'%$Type%' ";
	}
	if($PayPeriodId!='')
	{
		$s_query .= "and cxs_preapp_rules.PERIOD_ID = $PayPeriodId ";
	}	
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataResourceGroup")
{
	$ResourceGroup = $_REQUEST['Text_FindResourceGroupName'];
	$TimeManagementPolicyId = $_REQUEST['Combo_FindTimeManagementPolicy'];	
	$s_query = "";	
	if($ResourceGroup!='')
	{
		$s_query .= " and cxs_resource_groups.RESOURCE_GROUP_NAME like'%$ResourceGroup%' ";
	}
	if($TimeManagementPolicyId!='')
	{
		$s_query .= "and cxs_resource_groups.TIME_POLICY_ID = $TimeManagementPolicyId ";
	}	
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataResourceManagement")
{
	$FirstName = $_REQUEST['Text_FindFirstName'];
	$LastName = $_REQUEST['Text_FindLastName'];	
	$ResourceGroup = $_REQUEST['Combo_FindResourceGroup'];
	$ResourceType = $_REQUEST['Combo_FindResourceType'];	
	$SupervisorName = $_REQUEST['Text_FindSupervisor'];	
	$s_query = "";	
	if($FirstName!='')
	{
		$s_query .= " and cxs_resources.FIRST_NAME like'%$FirstName%' ";
	}
	if($LastName!='')
	{
		$s_query .= "and cxs_resources.LAST_NAME like'%$LastName%' ";
	}	
	if($ResourceGroup!='')
	{
		$s_query .= "and cxs_resources.RESOURCE_GROUP_ID = '$ResourceGroup' ";
	}	
	if($ResourceType!='')
	{
		$s_query .= "and cxs_resources.RESOURCE_TYPE like'%$ResourceType%' ";
	}
	if($SupervisorName!='')
	{
		//$s_query .= "and cxs_resources.RESOURCE_TYPE like'%$SupervisorName%' ";
	}	
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataWorkshift")
{
	$WorkshiftName = $_REQUEST['Text_FindWorkshiftName'];	
	$s_query = "";	
	if($WorkshiftName!='')
	{
		$s_query .= " and cxs_workshifts.NAME like'%$WorkshiftName%' ";
	}		
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataPolicies")
{
	$PolicyName = $_REQUEST['Text_FindPolicyProfileName'];	
	$s_query = "";	
	if($PolicyName!='')
	{
		$s_query .= " and cxs_policy_header.NAME like'%$PolicyName%' ";
	}		
	echo $s_query;
}

if($_REQUEST['REQUEST'] == "FindDataWBS")
{
	$Criteria = $_REQUEST['Text_FindProjectWBS'];
	$SiteId = $_SESSION['user-siteid'];
?>	
	<table id='TablePopupHeading' class="table table-bordered " width="100%" >
		<thead>
			  <tr>
				<?php
					for($i=1;$i<=15;$i++)
					{
				?>		<th> Segment<?php echo $i; ?> </th>
			<?php	} ?>
			  </tr>
			</thead>
			<tbody id = "TablePopupList" >
		
				<?php
					if($Criteria!='')
					{
						//$sql = "SELECT * from cxs_wbs where SEGMENT1 like '%$Criteria%' limit $startnumber, $endnumber";
						$sql = "SELECT * from cxs_wbs where SEGMENT1 like '%$Criteria%' and SITE_ID = $SiteId";
						$result = mysql_query($sql);	
						while($row=mysql_fetch_array($result))
						{
						?>
							<tr style="cursor:pointer"  onClick="SelectedWBSProject(<?php echo $row['WBS_ID']; ?>)">
								<td><?php echo $row['SEGMENT1']; ?></td> 
								<td><?php echo $row['SEGMENT2']; ?></td> 
								<td><?php echo $row['SEGMENT3']; ?> </td> 
								<td> <?php echo $row['SEGMENT4']; ?></td>
								<td> <?php echo $row['SEGMENT5']; ?></td>
								<td> <?php echo $row['SEGMENT6']; ?></td>
								<td> <?php echo $row['SEGMENT7']; ?></td>
								<td> <?php echo $row['SEGMENT8']; ?></td>
								<td> <?php echo $row['SEGMENT9']; ?></td>
								<td> <?php echo $row['SEGMENT10']; ?></td>
								<td> <?php echo $row['SEGMENT11']; ?></td>
								<td> <?php echo $row['SEGMENT12']; ?></td>
								<td> <?php echo $row['SEGMENT13']; ?></td>
								<td> <?php echo $row['SEGMENT14']; ?></td>
								<td> <?php echo $row['SEGMENT15']; ?></td>
							</tr>
					<?php	
						} 
					} ?>
				</tbody>
			</table>
<?php }

if($_REQUEST['REQUEST'] == "SelectedWBS")
{
	$SelectedId = $_REQUEST['Id'];
	$s = "";
	if($SelectedId!='')
	{
		$sql = "SELECT * from cxs_wbs where WBS_ID = $SelectedId";
		$result = mysql_query($sql);	
		while($row=mysql_fetch_array($result))
		{
			if($row['SEGMENT1']!='')
			{
				$s = $row['SEGMENT1'];
			}
			if($row['SEGMENT2']!='')
			{
				$s = $s.".".$row['SEGMENT2'];
			}
			if($row['SEGMENT3']!='')
			{
				$s = $s.".".$row['SEGMENT3'];
			}
			if($row['SEGMENT4']!='')
			{
				$s = $s.".".$row['SEGMENT4'];
			}
			if($row['SEGMENT5']!='')
			{
				$s = $s.".".$row['SEGMENT5'];
			}
			if($row['SEGMENT6']!='')
			{
				$s = $s.".".$row['SEGMENT6'];
			}
			if($row['SEGMENT7']!='')
			{
				$s = $s.".".$row['SEGMENT7'];
			}
			if($row['SEGMENT8']!='')
			{
				$s = $s.".".$row['SEGMENT8'];
			}
			if($row['SEGMENT9']!='')
			{
				$s = $s.".".$row['SEGMENT9'];
			}
			if($row['SEGMENT10']!='')
			{
				$s = $s.".".$row['SEGMENT10'];
			}
			if($row['SEGMENT11']!='')
			{
				$s = $s.".".$row['SEGMENT11'];
			}
			if($row['SEGMENT12']!='')
			{
				$s = $s.".".$row['SEGMENT12'];
			}
			if($row['SEGMENT13']!='')
			{
				$s = $s.".".$row['SEGMENT13'];
			}
			if($row['SEGMENT14']!='')
			{
				$s = $s.".".$row['SEGMENT14'];
			}
			if($row['SEGMENT15']!='')
			{
				$s = $s.".".$row['SEGMENT15'];
			}
		}
	}
	echo $s;
}

if($_REQUEST['REQUEST'] == "FindDataTE-Aliases")
{
	$AliasName = $_REQUEST['AliasName'];
	$AliasClass = $_REQUEST['AliasClass'];
	$IsCheckBoxAllow = $_REQUEST['CheckBoxAllow'];
	$LoginUserId = $_SESSION['user_id'];
	$ResourceId = $_REQUEST['ResourceId'];
	$SiteId = $_SESSION['user-siteid'];
	
	$s_Query = "";
	if ($AliasClass!='')
	{
		if ($AliasClass=='no class')
		{
			$AliasClass = '';
		}
		$s_Query = $s_Query." and cxs_aliases.ALIAS_CLASS ='$AliasClass' ";
	}
	$i=1;
	if($AliasName != '')
	{
		$s_Query = $s_Query." and cxs_aliases.ALIAS_NAME like '%$AliasName%' ";
	}
	if($ResourceId!='')
	{
		$s_Query = $s_Query."and cxs_users.RESOURCE_ID = $ResourceId";
	}
	//and cxs_aliases.CREATED_BY = $LoginUserId
	$sql = "SELECT cxs_aliases.*,cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4 from cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID left join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY where cxs_aliases.ACTIVE_FLAG='Y' and cxs_aliases.SITE_ID = $SiteId $s_Query order by cxs_aliases.ALIAS_NAME";	
	$result = mysql_query($sql);		
	while($row=mysql_fetch_array($result))
	{
		$AliasId = $row['ALIAS_ID'];
		$AliasName =  $row['ALIAS_NAME'];	
		$AliasType =  $row['ALIAS_TYPE'];	
		$Description =  $row['DESCRIPTION'];	
		$IsActive =  $row['ACTIVE_FLAG'];		
		$Segment1 =  $row['SEGMENT1'];	
		$Segment2 =  $row['SEGMENT2'];
		$Segment3 =  $row['SEGMENT3'];
		$Segment4 =  $row['SEGMENT4'];
		$Segment5 =  $row['SEGMENT5'];			
		$WBSValue = "";
		if ($Segment1!="")
		{
			$WBSValue = $Segment1;
			$WBSValue .= ($Segment2!='')?".$Segment2":"";
			$WBSValue .= ($Segment3!='')?".$Segment3":"";
			$WBSValue .= ($Segment4!='')?".$Segment4":"";
		}

	?>
		<tr style="cursor:pointer" <?php if($IsCheckBoxAllow=="N") { ?> onClick="SelectedAlias(<?php echo $AliasId; ?>,'<?php echo $AliasName; ?>')" <?php } ?> >    
			<?php if($IsCheckBoxAllow!="N") { ?>
			<td class="check-bx "><input type="checkbox" id="<?php echo "PopupCheckboxInline$i"?>" onchange="PopupCheckInline()"></td> 
			<?php } ?>
			<td>
				<span id = "<?php echo"Span-AliasName$i"; ?>"><?php echo $AliasName; ?></span>
				<span id = "<?php echo"Span-AliasId$i"; ?>" style = "display : none" ><?php echo $AliasId; ?></span>
			</td> 
			<td><?php echo $AliasType; ?> </td> 
			<td> <?php echo $Description; ?></td>
			<td class="check-bx "> <input type="checkbox" <?php echo ($IsActive=="Y")?"checked":"";?> disabled ></td>
			<td> <?php echo $WBSValue; ?></td>			
		</tr>
<?php	
		$i=$i+1;
	}	
}

?>
<?php
if($_REQUEST['REQUEST'] == "FindData-Policy-Alias")
{
	$AliasName =  $_REQUEST['Text_FindAliasName'];
	$AliasClass = $_REQUEST['h_AliasClass'];	
	//$AliasClass = "Policy";
	$SiteId = $_SESSION['user-siteid'];
	
	$s_Query = "";
	if($AliasClass=='Policy')
	{
		//$s_Query = $s_Query." and (cxs_aliases.ALIAS_CLASS ='Policy' or cxs_aliases.ALIAS_CLASS ='Shift' or cxs_aliases.ALIAS_CLASS ='Overtime') ";
		$s_Query = $s_Query." and cxs_aliases.ALIAS_CLASS ='Policy'  ";
	}
	else 
	{
		$s_Query = $s_Query." and cxs_aliases.ALIAS_CLASS ='$AliasClass'";
	}
	
	$s_Query = $s_Query."and cxs_aliases.ACTIVE_FLAG='Y' and cxs_aliases.SITE_ID = $SiteId";
	
	$i=1;
	if($AliasName != '')
	{
		$s_Query = $s_Query." and cxs_aliases.ALIAS_NAME like '%$AliasName%' ";
	}
?>	
	<table id='TableFindAlias' class="table table-bordered " width="100%" >
		<thead>
			<tr>
				<th width="10%">														
					  <span > Alias Name</span>														
				</th>	
				<th width="20%">														
					  <span > Alias Type</span>														
				</th>
				<th width="30%">														
					  <span > Description</span>														
				</th>	
				<th width="20%">														
					  <span > Alias Class</span>														
				</th>														
				<th width="30%">														
					  <span > Project WBS</span>														
				</th>
			</tr>
		</thead>
		<tbody>
<?php $sql = "SELECT cxs_aliases.*,cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4 from cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where 1=1 $s_Query order by cxs_aliases.ALIAS_NAME";
	$result = mysql_query($sql);		
	while($row=mysql_fetch_array($result))
	{
		$AliasId = $row['ALIAS_ID'];
		$AliasName =  $row['ALIAS_NAME'];	
		$AliasType =  $row['ALIAS_TYPE'];	
		$Description =  $row['DESCRIPTION'];	
		$AliasClass =  $row['ALIAS_CLASS'];
		$Segment1 =  $row['SEGMENT1'];	
		$Segment2 =  $row['SEGMENT2'];
		$Segment3 =  $row['SEGMENT3'];
		$Segment4 =  $row['SEGMENT4'];
		$Segment5 =  $row['SEGMENT5'];			
		$WBSValue = "";
		if ($Segment1!="")
		{
			$WBSValue = $Segment1;
			$WBSValue .= ($Segment2!='')?".$Segment2":"";
			$WBSValue .= ($Segment3!='')?".$Segment3":"";
			$WBSValue .= ($Segment4!='')?".$Segment4":"";
		}
	?>
		<tr style="cursor:pointer" onClick="SelectedAlias(<?php echo $AliasId; ?>)"  >			
			<td>
				<span id = "<?php echo"Span-AliasName$i"; ?>"><?php echo $AliasName; ?></span>
				<span id = "<?php echo"Span-AliasId$i"; ?>" style = "display : none" ><?php echo $AliasId; ?></span>
			</td> 
			<td><?php echo $AliasType; ?> </td> 
			<td> <?php echo $Description; ?></td>
			<td> <?php echo $AliasClass; ?></td>
			<td> <?php echo $WBSValue; ?></td>			
		</tr>
<?php	
		$i=$i+1;
	}?>	
		</tbody>
	</table>
<?php }

?>