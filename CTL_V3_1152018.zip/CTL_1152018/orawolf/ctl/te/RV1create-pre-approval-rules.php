<?php ob_start ();
	 
	include("te-functions.php");
	include("sitename.php");
	
	check_login();
?>
<?php 
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_PreApproval_PERMISSION = "Y";
		$UPDATE_PRIV_PreApproval_PERMISSION = "Y";		
	}
	else
	{
		$CREATE_PRIV_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','PreApproval Rules',$_SESSION['user_id']);
		$UPDATE_PRIV_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','PreApproval Rules',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_PreApproval_PERMISSION=='N' && $UPDATE_PRIV_PreApproval_PERMISSION=='N' )
	{
		header('location:te.php');
	}			
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "create-pre-approval-rules.php";
	$SiteId = $_SESSION['user-siteid'];

	/*foreach($_REQUEST['Text_WBSId'] as $Text_WBSId)
			{ echo $Text_WBSId;
			}
	*/
	$insArr = array();
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];
	//	DisplayRecord($HeaderId);	
	}
	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	$IsDuplicate = isset($_REQUEST['h_duplicate'])?$_REQUEST['h_duplicate']:"";
	
	$msg1="";
	if (isset($_POST['cmdSaveRecord'] ))
	{
		$Text_RuleName = isset($_POST["Text_RuleName"] )? $_POST["Text_RuleName"]: false;	
		$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;
		$Combo_Type = isset($_POST["Combo_Type"] )? $_POST["Combo_Type"]: false;
		$Text_QuotaHours = isset($_POST["Text_QuotaHours"] )? $_POST["Text_QuotaHours"]: false;		
		$Check_InUse = isset($_POST['Check_InUse'] )? $_POST['Check_InUse']: false;
		$Check_Active = isset($_POST['Check_Active'] )? $_POST['Check_Active']: false;
		
		if ($IsDuplicate=="Y")
		{
			$msg1 = "Do not allow duplicate entry.";
			$Display_RuleName = $Text_RuleName;
			$Display_Description = $Text_Description;
			$Display_Type = $Combo_Type;
			$Display_QuotaHours = $Text_QuotaHours;			
			$Display_InUse = ($Check_InUse==1)?"Y":"";
			$Display_Active = ($Check_Active==1)?"Y":"";		
		}
		else
		{
			$insArr['RULE_NAME'] = $Text_RuleName;
			$insArr['DESCRIPTION'] = $Text_Description;
			$insArr['PREAPPROVAL_TYPE'] = $Combo_Type;
			$insArr['QUOTA_HOURS'] = $Text_QuotaHours;		
			$insArr['IN_USE_FLAG'] = ($Check_InUse==1)?"Y":"N";
			$insArr['ACTIVE_FLAG'] = ($Check_Active==1)?"Y":"N";		
			$insArr['LAST_UPDATED_BY'] = $LoginUserId;
			$insArr['SITE_ID'] = $SiteId;
			
			if($HeaderId!='')
			{
				updatedata("cxs_preapp_rules",$insArr,"Where cxs_preapp_rules.PREAPP_RULE_ID = $HeaderId");							
			}	
			else
			{
				$insArr['CREATION_DATE']='now()' ;
				$insArr['CREATED_BY']=$LoginUserId;			
				insertdata("cxs_preapp_rules",$insArr);	
				$HeaderId= mysql_insert_id();						
			}
			if($HeaderId!='')
			{
				$i=1;
				foreach($_POST['Text_AliasId'] as $Text_AliasId)
				{
					if( $Text_AliasId !='')
					{
						$qry = "select * from cxs_preapp_alias where PREAPP_RULE_ID = $HeaderId and ROW_NO = $i";
						$result = mysql_query($qry);
						$noofrecords = mysql_num_rows($result);
						
						$insArr1['PREAPP_RULE_ID']=$HeaderId;					
						$insArr1['ALIAS_ID']=$Text_AliasId;
						$insArr1['LAST_UPDATED_BY']=$LoginUserId;
						$insArr1['ROW_NO']=$i;
						
						if ($noofrecords==0)
						{
							$insArr1['CREATION_DATE']='now()' ;
							$insArr1['CREATED_BY']=$LoginUserId;
							insertdata("cxs_preapp_alias",$insArr1);	
						}
						else
						{
							updatedata("cxs_preapp_alias",$insArr1,"where PREAPP_RULE_ID = $HeaderId and ROW_NO = $i");	
						}					
						$i=$i+1;
					}
				}
			}			
			
			header("Location:pre-approval-rules.php");
			/*echo "<script>";				
			echo "location.href='create-pre-approval-rules.php?hid=$HeaderId'";
			echo "</script>";*/
		}
	}	
	
		
	if($IsUpdate =='Y' && $TotalRows >0)
	{
		/*foreach($_POST['InlineCheckBox'] as $Check_Inline)
		{
					
		}*/
		for($i=1;$i<=$TotalRows;$i++)
		{
			$Check_Record = isset( $_POST['inlineCheckbox'.$i] )? $_POST['inlineCheckbox'.$i]: false;
			if($Check_Record==1)
			{
				unset($insArr1);
				
				$insArr1['PREAPP_RULE_ID']=$HeaderId;					
				$insArr1['WBS_ID']=$_POST['Text_AliasId'][$i-1];								
				$insArr1['LAST_UPDATED_BY']=$LoginUserId;
				$insArr1['ROW_NO']=$i;
				updatedata("cxs_preapp_alias",$insArr1,"where PREAPP_RULE_ID = $HeaderId and ROW_NO = $i");	
			}
		}
	//	echo "Total ".$TotalRows;
	}
	
	if ($HeaderId != '' && $IsDuplicate == '')
	{
		//$qry = "SELECT cxs_preapp_rules.* FROM cxs_preapp_rules Left JOIN cxs_preapp_wbs ON cxs_preapp_wbs.PREAPP_RULE_ID = cxs_preapp_rules.PREAPP_RULE_ID where cxs_preapp_rules.PREAPP_RULE_ID = $HeaderId";		
		/*$qry = "SELECT cxs_preapp_rules.*,cxs_preapp_wbs.WBS_ID,cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4,cxs_wbs.SEGMENT5,cxs_wbs.SEGMENT6,cxs_wbs.SEGMENT7,cxs_wbs.SEGMENT8,cxs_wbs.SEGMENT9,cxs_wbs.SEGMENT10,cxs_wbs.SEGMENT11,cxs_wbs.SEGMENT12 
				FROM cxs_preapp_rules Left JOIN cxs_preapp_wbs ON cxs_preapp_wbs.PREAPP_RULE_ID = cxs_preapp_rules.PREAPP_RULE_ID left join cxs_wbs on cxs_wbs.WBS_ID = cxs_preapp_wbs.WBS_ID where cxs_preapp_rules.PREAPP_RULE_ID = $HeaderId";*/
		$qry = "SELECT cxs_preapp_rules.*FROM cxs_preapp_rules where cxs_preapp_rules.PREAPP_RULE_ID = $HeaderId";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_RuleName = $row['RULE_NAME'];
			$Display_Description = $row['DESCRIPTION'];
			$Display_Type = $row['PREAPPROVAL_TYPE'];
			$Display_QuotaHours = $row['QUOTA_HOURS'];			
			$Display_InUse = $row['IN_USE_FLAG'];
			$Display_Active = $row['ACTIVE_FLAG'];			
		}
	}
	
?>
<script type="text/javascript" >	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create Rules";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}		
	function SearchPopUp(CurrentRow)
	{	
		var form = $("#Find-Alias-Form");
		form.validate().resetForm();      // clear out the validation errors
		form[0].reset();		
		$('#TablePopupList').text('');		
		$('#span_currentRow').text(CurrentRow);
		$('#ModalFindAlias').modal();			
	}
	function RefreshTableList()
	{//alert("refresh");
		document.getElementById("TablePopupList").innerHTML = "";
		if($("#CheckboxPopup_SelectAll").length)
		{
			document.getElementById("CheckboxPopup_SelectAll").checked = false;
		}
	}	
	function FindAliasData()
	{
		var s1 = document.getElementById("Text_FindAliasName").value;		
		var s2 = document.getElementById("Combo_FindAliasClass").value;							
		if( (s1!='' && s2 != '') || (s1=='' && s2 == ''))
		{
			alert("Please Find Either Alias Name Or Alias Class");
			document.getElementById("Text_FindAliasName").focus();
			document.getElementById("TablePopupList").innerHTML="";
			return false;
		}
		
		KEY = "FindAliasData";
		makeRequest("ajax-finddata.php","REQUEST=FindDataTE-Aliases&AliasName="+s1+"&AliasClass="+s2+"&CheckBoxAllow=N");			
	}
	function AddAliasRecord()
	{ 
		
		var Flag_IsSelect = false;
		var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
		var s1="",s2="",j;
	
		
		//var DetailTableRows = document.getElementById("DetailTable").rows.length;
		
			KEY = "AddAliasRecord";
			s1="";
			var TotalWeekDays = 0,LastRowId=0;			
			LastRowId=DetailTableRows-2;
			
			for(i=1;i<=POPUP_TABLE_ROW;i++)
			{
				if (document.getElementById("PopupCheckboxInline"+i).checked == true)
				{
					s1 = s1 + document.getElementById("Span-AliasId"+i).innerHTML + "|";
				}
			}						
			makeRequest("ajax-TE-TableRows.php","REQUEST=Add-AliasRows&AliasId="+s1+"&TotalWeekDays=" + TotalWeekDays+"&LastRowId=" + LastRowId);
		
	}	
	function SelectedAlias(s1,s2)	
	{	
		if(s1!="" && s2 !="")
		{
			//document.getElementById("h_ProjectWBSId").value = s1;
			var CurrentRow = $('#span_currentRow').text();
			var TotalRows = $('#Table_WBS tr').length;
			$('#h_aliasid'+CurrentRow).val(s1);
			$('#Text_AliasName'+CurrentRow).val(s2);
			
			if (CurrentRow==TotalRows-1)
			{
				functionName1 = " onfocus = SearchPopUp("+TotalRows+")";
				//functionName1 = " onfocus = \"SearchPopUp()\" ";
			//	cell1="<td class = 'check-bx'><input type ='checkbox'> </td>";	
				cell1="<td class='check-bx'><input type='checkbox' id='inlineCheckbox"+TotalRows+"' value='1' name='inlineCheckbox"+TotalRows+"' onchange='checkInline()' disabled></td>";
				cell2 = "<td><div class='form-group' style = 'width:100%'> <input type='hidden' id='h_aliasid"+TotalRows+"' name = '<?php echo 'Text_AliasId[]' ?>' value=''> <input type= 'text' id='Text_AliasName"+TotalRows+"' class='form-control ' value=''"+functionName1+" style = 'width:100%' > </div></td>";
				EyeIcon="<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";
				$('#Table_WBS').append('<tr>'+cell1+cell2+EyeIcon+'</tr>');									
			}	
			$("#ModalFindAlias .close").click();					
		}
	}
	function onlyNos(e, t)
	{
		try {
			if (window.event) {
				var charCode = window.event.keyCode;
			}
			else if (e) {
				var charCode = e.which;
			}
			else { return true; }
			if (charCode > 31 && (charCode != 46) &&((charCode < 48 || charCode > 57)))															
			{
				return false;
			}
			return true;
		}
		catch (err) {
			alert(err.Description);
		}
	}
	function chkfld()
	{
		var s1 = $('#Combo_Type').val();
		var TotalRows = $('#Table_WBS tr').length;
		TotalRows = TotalRows-1;		
		if(s1=='Task Base Preapproval')
		{
			if(TotalRows==1)	
			{
				if( $('#h_aliasid1').val()=='')
				{
					alert("Please Fill Atleast One Alias");
					document.getElementById("Text_AliasName1").focus();
					return false;
				}
			}
		}
	}
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		
		for(i=1;i<TABLE_ROW;i++)
		{
			document.getElementById("inlineCheckbox"+i).checked = checkboxValue;		
		}
	}   
	function checkInline()
	{
		for(i=1;i<TABLE_ROW;i++)
		{
			if (document.getElementById("inlineCheckbox"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	function EditRecord()
	{
		document.getElementById("h_NumRows").value = TABLE_ROW;
		var flag_updaterecord="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			//if (document.getElementById("inlineCheckbox"+i).checked == true)
			if ($('#inlineCheckbox'+i).prop("checked"))
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = $('#cmdUpdateSelected').text();			
			if (ButtonCaption != "Save")
			{	
				$('#cmdUpdateSelected').text('Save');
				$('#Checkbox_SelectAll').hide();
				for(i=1;i<=TABLE_ROW;i++)
				{
					if ($('#inlineCheckbox'+i).prop("checked"))
					{
						ShowInputElements(i);
					}					
					else
					{
						$('#CheckboxInline'+i).hide();
					}
				}
			}
			else
			{
				var flag_final="";
				document.getElementById('h_field_update').value = 'Y';
				for(i=1;i<=TABLE_ROW;i++)
				{
					if ($('#inlineCheckbox'+i).prop("checked"))
					{
						if(document.getElementById("Text_AliasName"+i).value == "")
						{
							alert("Pleae Select WBS");
							document.getElementById("Text_AliasName"+i).focus();
							flag_final = "N";
							break;
						}
					}
				}
				if (flag_final=="")
				{	
					Form1.submit();
				}
			}
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("inlineCheckbox1").focus();
		}
	}
	function ShowInputElements(CurrentRow)
	{
		$('#Text_AliasName'+CurrentRow).show();
		$('#span'+CurrentRow).hide();
	}
	
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<title>Coexsys | <?php echo strtoupper($SiteName); ?></title>
<!-- <title>Coexsys | Time Accounting</title> -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>

<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.myAdjustClass
	{
		text-align: right;
	}
	@media (min-width: 992px) 
	{
		.modal-lg
		{
			width: 1280px;
		}		
	}
	
	@media only screen
and (min-device-width : 320px)
and (max-device-width : 480px) 
{
	.myAdjustClass
		{
			text-align: left;
			padding-left:0px;
		}
}
	
</style>
<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
</head>

<body>
<?php include("header.php"); ?>
		<!--  alias pop up start-->
	<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalFindAlias" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
		<div class="modal-dialog modal-lg" role="document">
			<form id="Find-Alias-Form" >
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Find Projects / Tasks</h4>
					</div>
					<div class="modal-body"> 
			<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<span id = 'span_currentRow' style="display:none"></span>
								<div class="col-sm-5 form-group">
								  <label>Alias Name</label>
								  <input type="text" id="Text_FindAliasName" name="Text_FindAliasName" class="form-control "  style = "font-weight: normal" maxlength="100">							 
								</div>
								
								<div class="col-sm-5 form-group">
								<!--	<option value="Shift">Shift</option>
									<option value="Overtime">Overtime</option>-->
								  <label> Alias Class </label>
								  <select id = "Combo_FindAliasClass" name = "Combo_FindAliasClass" class="form-control" maxlength="20" style = "font-weight: normal" onchange="RefreshTableList()">								
									<option value="">- Class -</option>
									<option value="Leave">Leave</option>									
									<option value="Policy">Policy</option>
									<option value="no class">Resource Specific</option>
								  </select>
								</div>
							
								<div class="col-sm-2 form-group">
									<br>
								  <button type="button" id="cmdFindAliasPopup" name="cmdFindAliasPopup" class="btn btn-primary btn-style " onclick="FindAliasData()" >Find</button>
								</div>
								
								<div class="col-sm-12 form-group">
										<div id="span_msg" class="text-center" style = "font-weight:bold"> </div>
										<div class="data-bx">
											<div class="table-responsive">
												<table id='TablePopupHeading' class="table table-bordered " width="100%" >
													<thead>
														<tr>																																							
															<th width="10%">														
																  <span > Alias Name</span>														
															</th>														
															<th width="20%">														
																  <span > Alias Type</span>														
															</th>
															<th width="30%">														
																  <span > Description</span>														
															</th>
															<th width="5%">														
																  <span > Active</span>														
															</th>
															<th width="30%">														
																  <span > Project WBS</span>														
															</th>
														</tr>
													</thead>
													<tbody id = "TablePopupList">
															
													</tbody>
												</table>
											</div>	
										</div>			
								</div>	
								
							</div>
							
							
						</div>
						<!-- end --> 
					  </div>
					<!--<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<button type="button" id="cmdAliasAddItem" name="cmdAliasAddItem" class="btn btn-primary btn-style "  onclick="AddAliasRecord()"  >Add Item(s)	</button>
					</div>					-->
				</div>
			</form>	
		</div>
	</div>
	<!-- end alias pop up -->
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="pre-approval-rules.php"> Preapproval Rules </a></li>
          <li > <a href="#"> <?php echo $s_caption; ?> Rules </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
	
		<div class="cont-box">
			<form class="form" id="Form1" name="Form1" action="" method="POST" onsubmit = "return chkfld()">	<!--  onsubmit = "return chkfld_form1()" -->
			
				<div class="pge-hd">
					<h2 class="sec-title"> 
						<label id="Label_Title"><?php echo $s_caption; ?> Rules</label>
						<label class = "fright" style = "font-size: 12px; margin-right : 40px;"> <input type="checkbox" id="Check_InUse" name="Check_InUse" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled> In Use </label>
					</h2>			  
				</div>
								
				<div class="upp-form row">				
					<!--<div class="cus-form-cont ">-->
						<div class="col-sm-4 form-group">  
							<label> Rule Name </label>
							<input type="text" class="form-control requirefieldcls" required id = "Text_RuleName" name = "Text_RuleName"   maxlength="40" value = <?php echo $Display_RuleName; ?>>
							<span id = "Span_RuleName"><?php echo $msg1; ?></span>
						</div>
					
						<div class="col-sm-4 form-group">
							<label> Description </label>
							<input type="text" class="form-control requirefieldcls" required id = "Text_Description" name = "Text_Description"  maxlength="240" value = <?php echo $Display_Description; ?>>
						</div>
						
						<div class="col-sm-4 form-group">
							<label> Type </label>
							<div>
								<select class="form-control requirefieldcls" required id = "Combo_Type" name = "Combo_Type" >
								<option value=""> - Type - </option>
								<option value="Direct Preapproval" <?php echo ($Display_Type=="Direct Preapproval")?"selected":""; ?>>Direct Preapproval (Solo Time Entry)</option>
								
								<option value="Task Base Preapproval"  <?php echo ($Display_Type=="Task Base Preapproval")?"selected":""; ?>>Task Base Preapproval</option>									  
								</select>
							</div>
						</div>
						<div class="clear-both"></div>		
						<div class="col-sm-4 form-group">
							<label> Quota Hours </label>
							<input type="text" class="form-control" id = "Text_QuotaHours" name = "Text_QuotaHours"  onkeypress="return onlyNos(event,this);" maxlength="10" value = <?php echo $Display_QuotaHours; ?>>
						</div>
						
						
						<div class="col-sm-4 form-group" >
							<div class="checkbox">
								 <br>								
								<label style = "padding-right:10px;"> <input type="checkbox" id = "Check_Active" name = "Check_Active" value = "1" <?php echo ($Display_Active=="Y")?"checked":"";  ?> style = "padding-right:20px;"> Active </label>
							</div>
						</div> 	
				</div>
			
				<div class="detail-form2">
					<div class="upp-form row">	</div>
					<div class="upp-form row">	</div>
					
					<div class="col-sm-12 form-group "  style = "padding-left:0px;">
						<div class = "col-sm-8 fleft two " style = "padding-left:0px;">							
							<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_PreApproval_PERMISSION=='Y' && $Display_InUse != 'Y'){ ?> id = "cmdUpdateSelected" name = "cmdUpdateSelected" onclick= 'EditRecord();' <?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>
						</div>
						
						<div class="col-sm-4 myAdjustClass cr-user" >				   							
							<button <?php if($CREATE_PRIV_PreApproval_PERMISSION=='Y' && $Display_InUse != 'Y'){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style"> Save Record </button>
							<input type="hidden" id="h_IsEditAllowed" <?php if($CREATE_PRIV_PreApproval_PERMISSION=='Y' && $Display_InUse!='Y'){ ?> value = "Y" <?php } else {?> value = "N" <?php } ?> >
						</div>
					</div>
					
					<div class="data-bx" style = "padding-right:15px;">
						<div class="table-responsive"  style = "padding-right:15px;" >									
							<table class="table table-bordered mar-cont" id = "Table_WBS" name = "Table_WBS">
								<thead>
									<tr>												
										<th width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>
										<th>Alias</th>
										<th width="5%"></th>
									</tr>
								</thead>
								<tbody>
									<?php 
										if ($HeaderId =='')
										{
											$i=1;
										}
										else
										{
											$result = mysql_query("select count(*) as expr1 from cxs_preapp_alias where cxs_preapp_alias.PREAPP_RULE_ID = $HeaderId");
											//print_r($result);											
											while($row = mysql_fetch_array($result))
											{
												$i = $row['expr1']+1;
											}
										}
										$BlankRow = "
										<tr>											
											<td class='check-bx'><input type='checkbox' id='inlineCheckbox$i' name = 'inlineCheckbox$i'  value='1' onchange='checkInline()' disabled></td>	
											<td>
												<div class='form-group' style = 'width:100%'> 
													<input type='hidden' id = 'h_aliasid$i' name = 'Text_AliasId[]' value=''> 
													<input type= 'text' id = 'Text_AliasName$i' class='form-control' value='' onfocus = 'SearchPopUp($i)' style = 'width:100%'> 
												</div>
											</td>
											<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>
										</tr>";
										if ($HeaderId=='')
										{
											echo $BlankRow;
										}
										else
										{
											$i=1;
											$qry = "SELECT cxs_preapp_alias.*,cxs_users.USER_NAME AS CreatedBy,cxs_aliases.ALIAS_NAME
														FROM cxs_preapp_alias INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_preapp_alias.CREATED_BY inner JOIN cxs_aliases ON cxs_aliases.ALIAS_ID = cxs_preapp_alias.ALIAS_ID
														where cxs_preapp_alias.PREAPP_RULE_ID = $HeaderId order by ROW_NO";
											$result = mysql_query($qry);
											while($row = mysql_fetch_array($result))
											{
												/*$WBSValue = "";
												if ($row['SEGMENT1']!="")
												{
													$WBSValue = "";
													for($j=1;$j<=15;$j++)
													{
														$value = "SEGMENT$j";															
														$WBSValue .= $row[$value].".";
													}
												}
												if(substr($WBSValue,-1)==".")
												{
													$WBSValue = substr_replace($WBSValue, '', -1);														
												}*/
												$Display_CreatedByName	= $row['CreatedBy'];	
												$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));							
												$UpdatedBy		= $row['LAST_UPDATED_BY'];
												$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");
												$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
										?>
											<tr id = "<?php echo "row$i"."_HDeduct"?>">
													<td class="check-bx "><input type="checkbox" id="<?php echo "inlineCheckbox$i"; ?>" name = '<?php echo "inlineCheckbox$i";?>' value="1" onchange='checkInline()' ></td>													
													<td>
														<div class='form-group'> 
															<input type='hidden' id = '<?php echo 'h_aliasid'.$i; ?>' name = '<?php echo "Text_AliasId[]";?>' value='<?php echo $row['ALIAS_ID']; ?>'> 
															<input type= 'text' id = '<?php echo 'Text_AliasName'.$i; ?>' class='form-control' value='<?php echo $row['ALIAS_NAME']; ?>' onfocus = 'SearchPopUp(<?php echo $i; ?>)' style = "display:none"> 
															<span id = "<?php echo 'span'.$i;?>"><?php  echo $row['ALIAS_NAME']; ?></span>
														</div>
													</td>	
													
													<td class = "check-bx">
														<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
														Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
														<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
													</td>
												</tr>	
									<?php		$i=$i+1; 
											}
											echo $BlankRow;
										}?>
								</tbody>
							</table>		
						</div>
					</div>	
				</div>				
				<input type="hidden" id="h_duplicate" name="h_duplicate" value="<?php echo $IsDuplicate; ?>"/>
				<input type="hidden" id="h_field_update" name="h_field_update" value="">
				<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>
		</form>			
		</div>			
    </div>
  </div>
  
</section>	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.validate.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(
	function() 
	{													
		$(function() 
		{
			Validations();
		});		
		
		$("#Combo_Type").change(function() 
		{
			CheckRuleType(); 
		});
		
		$("#Text_RuleName").blur(function()
		{
			KEY = "CheckDuplicate";
			var TableName = "cxs_preapp_rules";
			var FieldName = "RULE_NAME";
			var FieldValue = $('#Text_RuleName').val();
			var FieldId = "PREAPP_RULE_ID";
			var SelectedId = "<?php echo $HeaderId; ?>";
			makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);					
		});
		
		if ($("#h_IsEditAllowed").val()=="N")		
		{	
			$("#Form1 :input").prop("disabled",true);
		}
	});
	
	TABLE_ROW = $('#Table_WBS tr').length-1;//remove header row from count	
	function Validations()
	{
		CheckRecurringValue();
		CheckRuleType();
	}

	function CheckRuleType()
	{
		TABLE_ROW = $('#Table_WBS tr').length-1;//remove header row from count	
		var s1  = $('#Combo_Type'). val();	
		if(s1=='Direct Preapproval' || s1=='')
		{
			for(var i =1;i<=TABLE_ROW;i++)	
			{
				$("#Text_AliasName"+i).prop("disabled", true);
				$("#Text_AliasName"+i).val('');
			}
		}
		else
		{
			for(var i =1;i<=TABLE_ROW;i++)		
			{
				$("#Text_AliasName"+i).prop("disabled", false);
			}
		}	
	}	
//$("#Table_WBS").DataTable({"searching": false});

var HeaderId = "<?php echo $HeaderId; ?>";
if(HeaderId!='')
{
	$('#Table_WBS').DataTable( 
	{
		'searching': false,
		'order': [[ 1, "asc" ]],
		'aoColumnDefs': [{'bSortable': false,'aTargets': [0,-1] }],
		 'lengthMenu': [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
		 "bInfo" : false //to hide "Showing 1 to 5 of 14 entries" label
	} );
	
	//var table = $('#table_id').DataTable();
	//var table_length = $('#table_id').DataTable().data().count();
	//alert(table_length);
}	

function myFunction()
{
	//$("#TablePopupHeading").DataTable({"searching": false});
}
		
	$('#Find-Alias-Form').keypress(function(e) 
	{
		if (e.which == 13) {
		//e.preventDefault();    
			return false;
		}
  });
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}								
				else if (KEY == 'SelectedWBS')
				{
					var s = http_request.responseText;
					s = s.trim();										
					var TotalRows = $('#Table_WBS tr').length;
					var CurrentRow = $('#span_currentRow').text();
					
					$('#Text_WBSName'+CurrentRow).val(s);
					
					if (CurrentRow==TotalRows-1)
					{
						functionName1 = " onfocus = SearchPopUp("+TotalRows+")";
						//functionName1 = " onfocus = \"SearchPopUp()\" ";
					//	cell1="<td class = 'check-bx'><input type ='checkbox'> </td>";	
						cell1="<td class='check-bx'><input type='checkbox' id='inlineCheckbox"+TotalRows+"' value='1' name='inlineCheckbox"+TotalRows+"' onchange='checkInline()' disabled></td>";
						cell2 = "<td><div class='form-group'> <input type='hidden' id='h_aliasid"+TotalRows+"' name = '<?php echo 'Text_AliasId[]' ?>' value=''> <input type= 'text' id='Text_AliasName"+TotalRows+"' class='form-control ' value=''"+functionName1+"> </div></td>";
						EyeIcon="<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";
						$('#Table_WBS').append('<tr>'+cell1+cell2+EyeIcon+'</tr>');									
					}	
					$("#ModalFindProjectWBS .close").click();					
				}
				else if(KEY=="FindAliasData")
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					
					document.getElementById("TablePopupList").innerHTML = s1;	
					document.getElementById("TablePopupHeading").style.display = "block";	
					//document.getElementById("CheckboxPopup_SelectAll").style=false;	
				
					
					var POPUP_TABLE_ROW = document.getElementById("TablePopupList").rows.length;
					if (POPUP_TABLE_ROW == 0)
					{
						document.getElementById("span_msg").innerHTML = "No Record Found.";
					}
					else
					{
						document.getElementById("span_msg").innerHTML = "";
						//document.getElementById("cmdAliasAddItem").style.visibility = "visible";						
					}
					
					//PopupCheckboxInline2
				}
				else if(KEY == 'CheckDuplicate')
				{
					var s1 = http_request.responseText.trim();					
					if(s1.length > 1)
					{
						document.getElementById("Span_RuleName").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Text_RuleName").focus();					
					}
					else
					{
						document.getElementById("Span_RuleName").innerHTML = "";
						document.getElementById("h_duplicate").value = "";	
					}
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}		
	</script>

</body>
</html>