<?php //ob_start ();

	 

	$LoginUserId = $_SESSION['user_id'];

	$CurrentUserType = "";

	

	if(HasUserType($_SESSION['user-type'],'TE-Admin'))

	{

		$CurrentUserType = "TE-Admin";

	}

	else if(HasUserType($_SESSION['user-type'],'TE-User'))

	{

		$CurrentUserType = "TE-User ";

	}		

	$_SESSION['current-user-type']=$CurrentUserType;	

	$SiteId1 = $_SESSION['user-siteid'];

	$SiteName = "";

	$qry = "Select * from cxs_sites where SITE_ID = $SiteId1";

	$result = mysql_query($qry);

	while($row = mysql_fetch_array($result))

	{

		$SiteName = "[".$row['SITE_NAME']."]";

	}

?>