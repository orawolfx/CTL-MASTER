<?php //ob_start ();

	$LoginUserId = $_SESSION['user_id'];	

	$CurrentUserType = "";		

	if(HasUserType($_SESSION['user-type'],'RBAM-Admin'))

	{ 

		$CurrentUserType = "RBAM-Admin"; 

	}

	else if(HasUserType($_SESSION['user-type'],'RBAM-User'))

	{

		$CurrentUserType = "RBAM-User ";

	}

	$_SESSION['current-user-type']=$CurrentUserType;

	$SiteId1 = $_SESSION['user-siteid'];

	$SiteName = "";

	if($SiteId1!='')

	{

		$qry = "Select * from cxs_sites where SITE_ID = $SiteId1";

		$result = mysql_query($qry);

		while($row = mysql_fetch_array($result))

		{

			$SiteName = "[".$row['SITE_NAME']."]";
			
		}

		
	}
	$SiteId = $_SESSION['user-siteid'];

	$sql_ss = "select * from cxs_site_settings where SITE_ID=$SiteId";

	$res_ss = mysql_query($sql_ss);
	$numRow_ss = mysql_num_rows($res_ss);


	if($numRow_ss > 0)
	{

		$row_ss = mysql_fetch_object($res_ss);
		//echo "<pre>";print_r($row_ss);echo"</pre>";
		$image = $row_ss->image;


	}

	
	

?>

<!--<script src="../js/jquery.min.js"></script> -->

	<header>

		<div class="top-nav-bx">

            <div class="container-fluid">

                <div class="row">

                    <div class="col-sm-6 col-md-6 bar-hea" style = "padding-left:2px;padding-right:2px;">

                        <div class="logo">

                            <a href="rbam.php">
                            	<?php  if($image){?>
					          	<div class="logo-de lopu"> <img src="../rbam/uploads/<?php echo $image;?>" title="Site Logo">  </div> 
					            <?php }else{ ?>
					            <div class="logo-de">  <img src="../img/logo.jpg" data-toggle="tooltip" data-placement="bottom" title="Site Logo"></div> 
				       		<?php }?></a>

                            <span class="ac-manage"> Access Management <?php //echo $SiteName; ?></span>							

                        </div><div class="navbar-heult fleft">
						<div class="navbar-header-ss navbar-default">

		                    <button type="button" class="navbar-toggle dropdown" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

								<span class="sr-only"> Toggle navigation </span>

								<span class="icon-bar"></span>

								<span class="icon-bar"></span>

								<span class="icon-bar"></span>

							</button>

		                </div> 
                <div id="navbar" class="navbar-collapse dropdown-menu">

                    <ul class="nav navbar-nav custom-nav">

                        <li class="dropdown">

                            <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Users and Roles <span class="caret"></span></a>

                            <ul class="dropdown-menu">

							<?php							

							if ($CurrentUserType == "RBAM-Admin")
							{

								$VIEW_PRIV_ss_PERMISSION = "Y";

							}

							else

							{

								$VIEW_PRIV_ss_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Site Settings',$_SESSION['user_id']);

							}

							?>

								<li><a <?php if($VIEW_PRIV_ss_PERMISSION=='Y'){ ?>href="site-settings.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Site Settings</a></li>

							

							<?php

								if ($CurrentUserType == "RBAM-Admin")

								{

									$CREATE_PRIV_ua_PERMISSION = "Y";

									$VIEW_PRIV_ua_PERMISSION = "Y";

									$UPDATE_PRIV_ua_PERMISSION = "Y";

								}

								else

								{

									//$CREATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('CREATE_NEW_USER',$_SESSION['user_id']);

								//	$VIEW_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('VIEW_ONLY',$_SESSION['user_id']);

								//	$UPDATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('UPDATE_ONLY',$_SESSION['user_id']);

								}

							?>	

								<li><a  <?php if($CREATE_PRIV_ua_PERMISSION=='Y' || $VIEW_PRIV_ua_PERMISSION=='Y' || $UPDATE_PRIV_ua_PERMISSION=='Y'){ ?> href="users-administration.php" <?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> User Administration  </a></li>								

							

						<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_alias_PERMISSION = "Y";

								$UPDATE_PRIV_alias_PERMISSION = "Y";

								$VIEW_PRIV_alias_PERMISSION = "Y";

								$ENABLE_AUDIT_alias_PERMISSION = "Y";

							}

							else

							{

							//	$CREATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$UPDATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$VIEW_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$ENABLE_AUDIT_alias_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Global Aliases',$_SESSION['user_id']);

							}

								

							$alias_page_visibility = false;

							if($CREATE_PRIV_alias_PERMISSION=='Y' || $UPDATE_PRIV_alias_PERMISSION=='Y' || $VIEW_PRIV_alias_PERMISSION=='Y' || $ENABLE_AUDIT_alias_PERMISSION=='Y')

							{

								$alias_page_visibility = true;

							}

							?>

							<li><a <?php if($alias_page_visibility==true){ ?> href="aliases-rbam.php" <?php } else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Global Alias </a></li>

								



							<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_wbs_PERMISSION = "Y";

								$UPDATE_PRIV_wbs_PERMISSION = "Y";

								$VIEW_PRIV_wbs_PERMISSION = "Y";

								$ENABLE_AUDIT_wbs_PERMISSION = "Y";

							}

							else

							{

							//	$CREATE_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Create WBS',$_SESSION['user_id']);

							//	$UPDATE_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Create WBS',$_SESSION['user_id']);

							//	$VIEW_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Create WBS',$_SESSION['user_id']);

							//	$ENABLE_AUDIT_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Create WBS',$_SESSION['user_id']);

							}

							

							$WBS_page_visibility = false;

							if($CREATE_PRIV_wbs_PERMISSION=='Y' || $UPDATE_PRIV_wbs_PERMISSION=='Y' || $VIEW_PRIV_wbs_PERMISSION=='Y' || $ENABLE_AUDIT_wbs_PERMISSION=='Y')

							{

								$WBS_page_visibility = true;

							}

							?>

								<li><a <?php if($WBS_page_visibility==true){ ?>href="workbreakdown-structure.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Create WBS </a></li>

								

							<?php						

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_am_PERMISSION = "Y";

								$UPDATE_PRIV_am_PERMISSION = "Y";

								$VIEW_PRIV_am_PERMISSION = "Y";

								$ENABLE_AUDIT_am_PERMISSION = "Y";

							}

							else

							{

								$CREATE_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Access Management',$_SESSION['user_id']);

								$UPDATE_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Access Management',$_SESSION['user_id']);

								$VIEW_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Access Management',$_SESSION['user_id']);

								$ENABLE_AUDIT_am_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Access Management',$_SESSION['user_id']);

							}

							$AM_page_visibility = false;

							if($CREATE_PRIV_am_PERMISSION=='Y' || $UPDATE_PRIV_am_PERMISSION=='Y' || $VIEW_PRIV_am_PERMISSION=='Y' || $ENABLE_AUDIT_am_PERMISSION=='Y')

							{

								$AM_page_visibility = true;

							}

							?>	

								<li><a <?php if($AM_page_visibility==true){ ?> href="access-management.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Access Management </a></li>								

                            </ul>

                        </li>

                      <li class="dropdown">

                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Subscriber Administration <span class="caret"></span></a>

                            <ul class="dropdown-menu">

						<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$VIEW_SUBSCRIBERS_permission = "Y";

								$USAGE_HISTORY_permission = "Y";								

							}

							else

							{

								$VIEW_SUBSCRIBERS_permission = getRoleAccessStatusByUser('VIEW_SUBSCRIBERS',$_SESSION['user_id']);

								$USAGE_HISTORY_permission = getRoleAccessStatusByUser('USAGE_HISTORY',$_SESSION['user_id']);

							}

							$IsEnableAudit = $_SESSION['IsEnableAudit'];

						?>

                               <!-- <li><a <?php if($VIEW_SUBSCRIBERS_permission=='Y'){ ?>href="current-subscriber.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>>Current Subscribers</a></li>-->

                                <li><a <?php if($USAGE_HISTORY_permission=='Y'){ ?>href="usage-history.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Usage History </a></li>

								<li><a <?php $IsEnableAudit;if($IsEnableAudit=='Y'){ ?>href="period-audit.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Period Audit </a></li>

								<li><a <?php if($IsEnableAudit=='Y'){ ?>href="interface-exchange.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Interface Exchange </a></li>

                            </ul>

                        </li> 

                        <li class="dropdown">

                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Billing & Payments <span class="caret"></span></a>

                            <ul class="dropdown-menu">

                                <li> <a href="update-contacts.php"> Update Contacts</a> </li>

                                <li>

                                    <a href="view-bill-payment.php"> View Bill Payment </a>

                                </li>

                                <li> <a href="payment-information.php"> Manage Payment Methods</a> </li>

                            </ul>

                        </li>

                    </ul>

                </div>  </div>
                <div class="fleft cr-user desb">
                        <a href="rbam.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button></a>
                    </div>
                    </div>					

                    <div class="col-sm-6 col-md-6"style = "padding-left:2px;padding-right:2px;">

                        <ul class="top-nav cold-6-nup">

							<?php							

								$OpenSupportRequest = "";

								if ($CurrentUserType == "RBAM-Admin")

								{

									$OpenSupportRequest = "Y";

								}

								else

								{ 

									$qry = "select SUBMIT_CUSTOM from cxs_users left join cxs_am_roles on cxs_am_roles.ROLE_ID = cxs_users.ROLE_ID where cxs_users.USER_ID = $LoginUserId";

									$result=mysql_query	($qry);				

									while($rows = mysql_fetch_array($result))

									{

										$OpenSupportRequest = $rows['SUBMIT_CUSTOM'];

									}

								}

							if($OpenSupportRequest=="Y"){ ?> 

                           

                            <li class="dropdown botrn"> 

                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../img/supportw.png" data-placement="left" data-toggle="tooltip" title="Support"></a>

                            </li>

							<?php } ?> 

                           

							<li class="dropdown botrn"> 

                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../img/favorites.png" data-placement="bottom" data-toggle="tooltip" title="Favorites"></a>

                                <ul class="dropdown-menu" id = "favorite_list" name = "favorite_list">

									<?php										

										$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId order by FEATURE_NAME";

										$result=mysql_query	($qry);

									//	$TotalRecords = mysql_num_rows($result);										

										while($rows = mysql_fetch_array($result))

										{

											$FEATURE_NAME = $rows['FEATURE_NAME'];

											$PAGE_NAME = $rows['PAGE_NAME'];

											$MODULE_NAME = $rows['MODULE_NAME'];

											if($ModuleName!=$MODULE_NAME)

											{

												if($MODULE_NAME=='Access Management')

												{


													$Link = "../rbam/".$PAGE_NAME."?m=1";									

												}

												else if($MODULE_NAME=='Time Accounting')

												{
													
													$Link = "../te/".$PAGE_NAME."?m=1";

												}

											}

											else

											{

												$Link = $PAGE_NAME;

											}

									?>

                                        <li><a href="<?php  echo $Link; ?>"> <?php echo $FEATURE_NAME; ?></a></li>  

								<?php } ?>

                                </ul>

                            </li>

                            <li class="dropdown botrn"> 

                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../img/help.png"  data-placement="left" data-toggle="tooltip" title="Help" alt=""></a>

                                <ul class="dropdown-menu uerli">

                                    <li><a href="#"> Option 1 </a></li>

                                    <li><a href="#"> Option 2 </a></li>

                                </ul>

                            </li>
                            <li class="btn-primary" style="padding: 8px;font-size: 16px; cursor: pointer; border-radius: 4px;"><i class="fa fa-refresh" aria-hidden="true" data-toggle="tooltip" data-placement="left" title="Refresh" id="cmdRefresh" name="cmdRefresh" onclick="refreshPage();"></i></li>
							<?php $username = $_SESSION['user_data']['USER_NAME'];  ?>

							<?php include("../uploadphoto.php"); //echo getProfileImg($_SESSION['user_id']); ?>

                            <li class="dropdown">

                                <a href="#" class="dropdown-toggle user-box" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <img class="pro-img-bx" data-toggle="tooltip" title="User Account" data-placement="left" src="<?php echo getProfileImg($_SESSION['user_id']); ?>"/><!--<span class="name-bx2">  </span><b class="fa fa-angle-down"></b>--></a>

                                <ul class="dropdown-menu uerli" style="top: 52px;">
  									<li><a href="javascript:;"> <?php echo $username;?> </a></li>
                                    <li><a href="javascript:uploadProfilePhotoModal();"> Upload Picture </a></li>

									<?php								

										if(isset($_SESSION['access-module']) && ($_SESSION['access-module']=='Both'))

										{?>

											<li><a href="../te/te.php"> Timekeeping </a></li>		
											<li><a href="../../SRM7/SRM/wizard/?id=0"> Reports </a></li>		

								<?php 	}?>

                                    <li><a href="../logout.php"> Logout </a></li>

								

                                </ul>

                            </li>

                        </ul>

                    </div>

                </div>

            </div>

        </div>		

        <!-- navigation  -->

        <?php /*?><nav class="navbar navbar-default custom-navbar">

            <div class="container-fluid">

                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

						<span class="sr-only"> Toggle navigation </span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

					</button>

                </div>

                <div id="navbar" class="navbar-collapse collapse">

                    <ul class="nav navbar-nav custom-nav">

                        <li class="dropdown">

                            <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Users and Roles <span class="caret"></span></a>

                            <ul class="dropdown-menu">

							<?php							

							if ($CurrentUserType == "RBAM-Admin")

							{

								$VIEW_PRIV_ss_PERMISSION = "Y";

							}

							else

							{

								$VIEW_PRIV_ss_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Site Settings',$_SESSION['user_id']);

							}

							?>

								<li><a <?php if($VIEW_PRIV_ss_PERMISSION=='Y'){ ?>href="site-settings.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Site Settings</a></li>

							

							<?php

								if ($CurrentUserType == "RBAM-Admin")

								{

									$CREATE_PRIV_ua_PERMISSION = "Y";

									$VIEW_PRIV_ua_PERMISSION = "Y";

									$UPDATE_PRIV_ua_PERMISSION = "Y";

								}

								else

								{

									//$CREATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('CREATE_NEW_USER',$_SESSION['user_id']);

								//	$VIEW_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('VIEW_ONLY',$_SESSION['user_id']);

								//	$UPDATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('UPDATE_ONLY',$_SESSION['user_id']);

								}

							?>	

								<li><a  <?php if($CREATE_PRIV_ua_PERMISSION=='Y' || $VIEW_PRIV_ua_PERMISSION=='Y' || $UPDATE_PRIV_ua_PERMISSION=='Y'){ ?> href="users-administration.php" <?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> User Administration  </a></li>								

							

						<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_alias_PERMISSION = "Y";

								$UPDATE_PRIV_alias_PERMISSION = "Y";

								$VIEW_PRIV_alias_PERMISSION = "Y";

								$ENABLE_AUDIT_alias_PERMISSION = "Y";

							}

							else

							{

							//	$CREATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$UPDATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$VIEW_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Global Aliases',$_SESSION['user_id']);

							//	$ENABLE_AUDIT_alias_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Global Aliases',$_SESSION['user_id']);

							}

								

							$alias_page_visibility = false;

							if($CREATE_PRIV_alias_PERMISSION=='Y' || $UPDATE_PRIV_alias_PERMISSION=='Y' || $VIEW_PRIV_alias_PERMISSION=='Y' || $ENABLE_AUDIT_alias_PERMISSION=='Y')

							{

								$alias_page_visibility = true;

							}

							?>

							<li><a <?php if($alias_page_visibility==true){ ?> href="aliases-rbam.php" <?php } else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Global Alias </a></li>

								



							<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_wbs_PERMISSION = "Y";

								$UPDATE_PRIV_wbs_PERMISSION = "Y";

								$VIEW_PRIV_wbs_PERMISSION = "Y";

								$ENABLE_AUDIT_wbs_PERMISSION = "Y";

							}

							else

							{

							//	$CREATE_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Create WBS',$_SESSION['user_id']);

							//	$UPDATE_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Create WBS',$_SESSION['user_id']);

							//	$VIEW_PRIV_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Create WBS',$_SESSION['user_id']);

							//	$ENABLE_AUDIT_wbs_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Create WBS',$_SESSION['user_id']);

							}

							

							$WBS_page_visibility = false;

							if($CREATE_PRIV_wbs_PERMISSION=='Y' || $UPDATE_PRIV_wbs_PERMISSION=='Y' || $VIEW_PRIV_wbs_PERMISSION=='Y' || $ENABLE_AUDIT_wbs_PERMISSION=='Y')

							{

								$WBS_page_visibility = true;

							}

							?>

								<li><a <?php if($WBS_page_visibility==true){ ?>href="workbreakdown-structure.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Create WBS </a></li>

								

							<?php						

							if ($CurrentUserType == "RBAM-Admin")

							{

								$CREATE_PRIV_am_PERMISSION = "Y";

								$UPDATE_PRIV_am_PERMISSION = "Y";

								$VIEW_PRIV_am_PERMISSION = "Y";

								$ENABLE_AUDIT_am_PERMISSION = "Y";

							}

							else

							{

								$CREATE_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('CREATE_PRIV','Access Management',$_SESSION['user_id']);

								$UPDATE_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('UPDATE_PRIV','Access Management',$_SESSION['user_id']);

								$VIEW_PRIV_am_PERMISSION = getTimeAccountingModuleStatusByUser('VIEW_PRIV','Access Management',$_SESSION['user_id']);

								$ENABLE_AUDIT_am_PERMISSION = getTimeAccountingModuleStatusByUser('ENABLE_AUDIT','Access Management',$_SESSION['user_id']);

							}

							$AM_page_visibility = false;

							if($CREATE_PRIV_am_PERMISSION=='Y' || $UPDATE_PRIV_am_PERMISSION=='Y' || $VIEW_PRIV_am_PERMISSION=='Y' || $ENABLE_AUDIT_am_PERMISSION=='Y')

							{

								$AM_page_visibility = true;

							}

							?>	

								<li><a <?php if($AM_page_visibility==true){ ?> href="access-management.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Access Management </a></li>								

                            </ul>

                        </li>

                      <li class="dropdown">

                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Subscriber Administration <span class="caret"></span></a>

                            <ul class="dropdown-menu">

						<?php

							if ($CurrentUserType == "RBAM-Admin")

							{

								$VIEW_SUBSCRIBERS_permission = "Y";

								$USAGE_HISTORY_permission = "Y";								

							}

							else

							{

								$VIEW_SUBSCRIBERS_permission = getRoleAccessStatusByUser('VIEW_SUBSCRIBERS',$_SESSION['user_id']);

								$USAGE_HISTORY_permission = getRoleAccessStatusByUser('USAGE_HISTORY',$_SESSION['user_id']);

							}

							$IsEnableAudit = $_SESSION['IsEnableAudit'];

						?>

                               <!-- <li><a <?php if($VIEW_SUBSCRIBERS_permission=='Y'){ ?>href="current-subscriber.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>>Current Subscribers</a></li>-->

                                <li><a <?php if($USAGE_HISTORY_permission=='Y'){ ?>href="usage-history.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Usage History </a></li>

								<li><a <?php if($IsEnableAudit=='Y'){ ?>href="period-audit.php"<?php }else{ ?>style="color: #e9e9e9; background-color: #ffffff;"<?php } ?>> Period Audit </a></li>

                            </ul>

                        </li> 

                        <li class="dropdown">

                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Billing & Payments <span class="caret"></span></a>

                            <ul class="dropdown-menu">

                                <li> <a href="update-contacts.php"> Update Contacts</a> </li>

                                <li>

                                    <a href="view-bill-payment.php"> View Bill Payment </a>

                                </li>

                                <li> <a href="payment-information.php"> Manage Payment Methods</a> </li>

                            </ul>

                        </li>

                    </ul>

                </div>

                <!--/.nav-collapse -->

            </div>

        </nav><?php */?>

	   <script type="text/javascript">
	   	function refreshPage(){
	   		window.location.href='';
	   	}
	   </script>

    </header>



