<?php //ob_start ();

	$LoginUserId = $_SESSION['user_id'];	

	$CurrentUserType = "";		

	if(HasUserType($_SESSION['user-type'],'RBAM-Admin'))

	{ 

		$CurrentUserType = "RBAM-Admin"; 

	}

	else if(HasUserType($_SESSION['user-type'],'RBAM-User'))

	{

		$CurrentUserType = "RBAM-User ";

	}

	$_SESSION['current-user-type']=$CurrentUserType;

	$SiteId1 = $_SESSION['user-siteid'];

	$SiteName = "";

	if($SiteId1!='')

	{

		$qry = "Select * from cxs_sites where SITE_ID = $SiteId1";

		$result = mysql_query($qry);

		while($row = mysql_fetch_array($result))

		{

			$SiteName = "[".$row['SITE_NAME']."]";
			
		}

		
	}
	

?>