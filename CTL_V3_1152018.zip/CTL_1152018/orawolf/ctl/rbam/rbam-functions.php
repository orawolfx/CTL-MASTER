<?php
//include("../conn.php");
$RecordsPerPage = 25;
$ModuleName = "Access Management";



function getSettingVal($field_name)
{
	$SiteId = $_SESSION['user-siteid'];
	$sql_ss = "select $field_name from cxs_site_settings where SITE_ID='$SiteId'";
	$res_ss = mysql_query($sql_ss);
	$row_ss = mysql_fetch_array($res_ss);	   
	return $row_ss[0];
}

function getRoleAccessStatusByUser($field_name,$user_id)
{
	$sql_ss = "select $field_name from cxs_users,cxs_am_roles where cxs_users.ROLE_ID = cxs_am_roles.ROLE_ID and USER_ID='".$user_id."'";
	$res_ss = mysql_query($sql_ss);
	$row_ss = mysql_fetch_array($res_ss);
	   
	return $row_ss[0];
}

function getTimeAccountingModuleStatusByUser($field_name,$module_name,$user_id)
{
	   $sql_chk="select cxs_resources.RESOURCE_GROUP_ID as RESOURCE_GROUP_ID from cxs_users,cxs_resources where cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID and USER_ID='".$user_id."'";
	   $res_chk=mysql_query($sql_chk);
	   $row_chk=mysql_fetch_array($res_chk);
	   
	   if($row_chk['RESOURCE_GROUP_ID']=='0')
	   {
			 $sql="select $field_name from cxs_ta_modules where USER_ID='".$user_id."' and MODULE_NAME='".$module_name."'";
			 $res = mysql_query($sql);
			 if(mysql_num_rows($res)>0)
			 {
			 	 $row = mysql_fetch_array($res);
			 	 return $row[0];
			 }
			 else
			 {
			 	 return 'N';
			 }	 
	   }
	   else
	   {
			$sql="select $field_name from cxs_ta_modules where RESOURCE_GROUP_ID='".$row_chk['RESOURCE_GROUP_ID']."' and MODULE_NAME='".$module_name."'";
			$res = mysql_query($sql);
			if(mysql_num_rows($res)>0)
			{
			 	$row = mysql_fetch_array($res);
			 	return $row[0];
			}
			else
			{
				return 'N';
			}	
	   }
	   
}

if(isset($_REQUEST['type']))
	  {


$hostname = 'localhost';
$username = 'racyshar_orawolf';
$password = 'HumtumNBT987##';
$dbname = 'racyshar_orawolf';

$conn = mysql_connect("$hostname","$username", "$password") or die("Data not connected".mysql_errno());
mysql_select_db("$dbname",$conn) or die(mysql_error());

	  	$ResourceName = $_REQUEST['ResourceName'];
	  	$exp = explode(' ', $ResourceName);
	  	$FIRST_NAME = $exp[0];
	  	$LAST_NAME = $exp[1];
	  	$payPeriod = $_REQUEST['payPeriod'];
	  	//echo $payPeriod.'=>'.$ResourceName;


	   $sql = "SELECT * FROM `cxs_period_audit` INNER JOIN  cxs_resources On cxs_period_audit.`EMPLOYEE_NUMBER` =  cxs_resources.RESOURCE_ID where cxs_resources.FIRST_NAME LIKE '%".$FIRST_NAME."%' AND cxs_resources.LAST_NAME LIKE '%".$LAST_NAME."%' AND `PERIOD_NAME` = '".$payPeriod."' order by cxs_period_audit.UPDATE_DATE desc";
//echo $sql; die;
	 

	  	$filter =mysql_query($sql,$conn);
	  	 	//echo "<pre>";print_r($filter);echo"</pre>";die;
//	  	$result = mysql_fetch_array($filter);
	  
	  	$array = array();
	  	while($result = mysql_fetch_assoc($filter))
	  	{
	  		//echo"<pre>";print_r($result);echo"</pre>";	
	  		echo "<tr><td>".$result['EMPLOYEE_NUMBER']."</td><td>".$result['FULL_NAME']."</td><td>".$result['PERIOD_NAME']."</td><td>".$result['UPDATE_DATE']."</td><td>".$result['EXP_STATUS']."</td></tr>";
	  	}
	  	//echo"<pre>";print_r($array);echo"</pre>";die;
	  	//echo json_encode($array['data']); 


	  }



?>