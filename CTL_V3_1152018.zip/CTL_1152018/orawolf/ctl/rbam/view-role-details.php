

<?php include("view-role-access-details.php"); ?>
<?php include("view-user-access-details.php"); ?>


<script>
	$('#accordion').css({
    'margin-bottom': '5px'
});
function ViewRole(UserName)
	{
		
		$.ajax({
			type: 'POST',	
			url: 'ajax_userdata.php',        
			data: ({uname:UserName}),
			dataType: 'json',        
			success: function(response)
			{  
			
				var myJSON = JSON.stringify(response);	
				var newArray = JSON.parse(myJSON);							
				clearViewRoleData();
				$('#Modal_ViewRoleDetails').modal();
				
				$('#Modal_ViewRoleDetails').find("#myModalLabel").html(" Role Details - "+UserName);
				if (newArray.CreateUser=="Y")
				{
					document.getElementById("Check_CreateUser").checked = true;
				}	
				if (newArray.ViewOnly=="Y")
				{
					document.getElementById("Check_ViewOnly").checked = true;
				}
				if (newArray.UpdateOnly=="Y")
				{
					document.getElementById("Check_UpdateOnly").checked = true;
				}
				if (newArray.OverideInUse=="Y")
				{
					document.getElementById("Check_OverrideInUse").checked = true;
				}
				if (newArray.ViewSubscribers=="Y")
				{
					document.getElementById("Check_ViewSubscribers").checked = true;
				}	
				if (newArray.SubmitCustom=="Y")
				{
					document.getElementById("Check_SubmitCustomization").checked = true;
				}
				if (newArray.ViewSLA=="Y")
				{
					document.getElementById("Check_ViewSLA").checked = true;
				}
				if (newArray.ExistUserAdmin=="Y")
				{
					document.getElementById("Check_ExistUserAdmin").checked = true;
				}	
				if (newArray.UsageHistory=="Y")
				{
					document.getElementById("Check_UsageHistory").checked = true;
				}
				Value = "Created By:  "+newArray.UACreatedBy+"<br />Updated By : "+newArray.UAUpdatedBy+"<br />Creation Date : "+newArray.UACreationDate+"<br />Last Update Date : "+newArray.UALastUpdateDate;				
				document.getElementById("btn_heading1").setAttribute('data-content',Value);
				
				//Heading 2
			/*	if (newArray.BusinessMessage=="Y")
				{
					document.getElementById("Check_BusinessMessage").checked = true;
				}	
				if (newArray.SetAudit=="Y")
				{
					document.getElementById("Check_SetAudit").checked = true;
				}
				if (newArray.AllowNegativeTimeEntry=="Y")
				{
					document.getElementById("Check_AllowNegativeTimeEntry").checked = true;
				}	
				if (newArray.AdvanceForOvertime=="Y")
				{
					document.getElementById("Check_AdvanceForOvertime").checked = true;
				}
				if (newArray.SubmittedTime=="Y")
				{
					document.getElementById("Check_SubmittedTime").checked = true;
				}	
				if (newArray.PrimaryApprover=="Y")
				{
					document.getElementById("Check_PrimaryApprover").checked = true;
				}	
				document.getElementById("Text_MaxDailyLimit").value = newArray.MaxDailyLimit;
				if (newArray.FlexibleTimeEntry=="Y")
				{
					document.getElementById("Check_FlexibleTimeEntry").checked = true;
				}
				if (newArray.CopyTimesheetEmployees=="Y")
				{
					document.getElementById("Check_CopyTimesheetEmployees").checked = true;
				}
				if (newArray.AllowOverrideWorkshift=="Y")
				{
					document.getElementById("Check_OverrideWorkshift").checked = true;
				}
				*/
				
				document.getElementById("Text_RecentTimecards").value = newArray.RecentTimecards;				
				if (newArray.RetroAdjustments=="Y")
				{
					document.getElementById("Check_RetroAdjustments").checked = true;
				}
				document.getElementById("Text_AllowRetroUpdates").value = newArray.AllowRetroUpdates;
				if (newArray.AllowPreApproval=="Y")
				{
					document.getElementById("Check_AllowPreApproval").checked = true;
				}
				//Value = "Created By:  "+newArray.TARCreatedBy+"&#013;"+"Updated By : "+newArray.TARUpdatedBy+"&#013;Creation Date : "+newArray.TARCreationDate+"&#013;Last Update Date : "+newArray.TARLastUpdateDate;
				Value = "Created By:  "+newArray.TARCreatedBy+"<br />Updated By : "+newArray.TARUpdatedBy+"<br />Creation Date : "+newArray.TARCreationDate+"<br />Last Update Date : "+newArray.TARLastUpdateDate;				
				document.getElementById("btn_heading2").setAttribute('data-content',Value);
				
				//Heading3	
				/*if (newArray.CreateTimeSheet=="Y")
				{
					document.getElementById("Check_CreateTimeSheet").checked = true;
				}	
				if (newArray.ApproveTimeSheet=="Y")
				{
					document.getElementById("Check_ApproveTimeSheet").checked = true;
				}
				if (newArray.CreateTimeSheetTeam=="Y")
				{
					document.getElementById("Check_CreateTimeSheetTeam").checked = true;
				}
				if (newArray.ApproveTimeSheetTeam=="Y")
				{
					document.getElementById("Check_ApproveTimeSheetTeam").checked = true;
				}	
				if (newArray.CreateSupervisorTimeSheet=="Y")
				{
					document.getElementById("Check_CreateSupervisorTimeSheet").checked = true;
				}
				Value = "Created By:  "+newArray.TARCreatedBy+"<br />Updated By : "+newArray.TARUpdatedBy+"<br />Creation Date : "+newArray.TARCreationDate+"<br />Last Update Date : "+newArray.TARLastUpdateDate;				
				document.getElementById("btn_heading3").setAttribute('data-content',Value);
				*/
				//Heading4
				var s1="";
				var s2="";
				var s3="";
				var s4="";
				var j = newArray.TotalRecords1;				
				for(i=1;i<=j;i++)
				{
					s1="";
					s2="";
					s3="";
					s4="";
					
					if (i==1)	{s1=newArray.CreatePriv1; s2=newArray.UpdatePriv1; s3=newArray.ViewPriv1; s4=newArray.EnableAudit1;}
					else if (i==2)	{s1=newArray.CreatePriv2; s2=newArray.UpdatePriv2; s3=newArray.ViewPriv2; s4=newArray.EnableAudit2;}
					else if (i==3)	{s1=newArray.CreatePriv3; s2=newArray.UpdatePriv3; s3=newArray.ViewPriv3; s4=newArray.EnableAudit3;}
					else if (i==4)	{s1=newArray.CreatePriv4; s2=newArray.UpdatePriv4; s3=newArray.ViewPriv4; s4=newArray.EnableAudit4;}
					else if (i==5)	{s1=newArray.CreatePriv5; s2=newArray.UpdatePriv5; s3=newArray.ViewPriv5; s4=newArray.EnableAudit5;}
					else if (i==6)	{s1=newArray.CreatePriv6; s2=newArray.UpdatePriv6; s3=newArray.ViewPriv6; s4=newArray.EnableAudit6;}
					else if (i==7)	{s1=newArray.CreatePriv7; s2=newArray.UpdatePriv7; s3=newArray.ViewPriv7; s4=newArray.EnableAudit7;}
					else if (i==8)	{s1=newArray.CreatePriv8; s2=newArray.UpdatePriv8; s3=newArray.ViewPriv8; s4=newArray.EnableAudit8;}
					else if (i==9)	{s1=newArray.CreatePriv9; s2=newArray.UpdatePriv9; s3=newArray.ViewPriv9; s4=newArray.EnableAudit9;}
					else if (i==10)	{s1=newArray.CreatePriv10; s2=newArray.UpdatePriv10; s3=newArray.ViewPriv10; s4=newArray.EnableAudit10;}
					else if (i==11)	{s1=newArray.CreatePriv11; s2=newArray.UpdatePriv11; s3=newArray.ViewPriv11; s4=newArray.EnableAudit11;}
					else if (i==12)	{s1=newArray.CreatePriv12; s2=newArray.UpdatePriv12; s3=newArray.ViewPriv12; s4=newArray.EnableAudit12;}
					else if (i==13)	{s1=newArray.CreatePriv13; s2=newArray.UpdatePriv13; s3=newArray.ViewPriv13; s4=newArray.EnableAudit13;}					
					else if (i==14)	{s1=newArray.CreatePriv14; s2=newArray.UpdatePriv14; s3=newArray.ViewPriv14; s4=newArray.EnableAudit14;}					
					else if (i==15)	{s1=newArray.CreatePriv15; s2=newArray.UpdatePriv15; s3=newArray.ViewPriv15; s4=newArray.EnableAudit15;}					
					else if (i==16)	{s1=newArray.CreatePriv16; s2=newArray.UpdatePriv16; s3=newArray.ViewPriv16; s4=newArray.EnableAudit16;}
					else if (i==17)	{s1=newArray.CreatePriv17; s2=newArray.UpdatePriv17; s3=newArray.ViewPriv17; s4=newArray.EnableAudit17;}
					else if (i==18)	{s1=newArray.CreatePriv18; s2=newArray.UpdatePriv18; s3=newArray.ViewPriv18; s4=newArray.EnableAudit18;}
					if (s1=="Y")
					{
						document.getElementById("Check_Create"+i).checked = true;
					}	
					if (s2=="Y")
					{
						document.getElementById("Check_Update"+i).checked = true;
					}	
					if (s3=="Y")
					{
						document.getElementById("Check_View"+i).checked = true;
					}	
					if (s4=="Y")
					{
						document.getElementById("Check_Audit"+i).checked = true;
					}
					
					Value = "Created By:  "+newArray.TAMCreatedBy+"<br />Updated By : "+newArray.TAMUpdatedBy+"<br />Creation Date : "+newArray.TAMCreationDate+"<br />Last Update Date : "+newArray.TAMLastUpdateDate;				
					document.getElementById("btn_heading4").setAttribute('data-content',Value);
				
					/*array1.forEach(function(element) {
					  console.log(element);
					});*/
				}
				
				$('#Table_PersonalAliases').find('tbody').remove();
				//heading 5
				TableData = "";
				TableData = newArray.cxs_am_personal_alias;				
				//if(TableData!='')
				if (typeof TableData != "undefined") 
				{
					for(i=0;i<TableData.length;i++)
					{
						sAliasName = (TableData[i]['ALIAS_NAME']);
						sDescription = (TableData[i]['DESCRIPTION']);
						sDepartment = (TableData[i]['DEPARTMENT']);
						sProjectWBS = (TableData[i]['WBS_COMBINATION_ID']);
						sActiveFlag = (TableData[i]['ACTIVE_FLAG']);					
						$('#Table_PersonalAliases').append('<tr><td>'+sAliasName+'</td><td>'+sDescription+'</td><td>'+sDepartment+'</td><td>'+sProjectWBS+'</td><td>'+sActiveFlag+'</td></tr>');										
					}
				}
				
				//heading 6				
				$('#Heading6_Table1').find('tbody').remove();
				TableData = "";
				TableData = newArray.cxs_am_approval_mgmt;
				if (typeof TableData != "undefined") 
				{
					for(i=0;i<TableData.length;i++)
					{
						sApproverName = (TableData[i]['ApproverName']);
						sApproverType = (TableData[i]['ApproverType']);										
						$('#Heading6_Table1').append('<tr><td>'+sApproverName+'</td><td>'+sApproverType+'</td></tr>');
					}
				}
			},
		error: function(ts) { alert(ts.responseText) }
		});
	}
	function clearViewRoleData()
	{
		clearInputFields('collapseOne');			
	}
	function clearInputFields(divElement) 
	{
        var ele = document.getElementById(divElement);    
		 $('#'+divElement).find(':input').each(function () {
			
                switch (this.type) {
                    case 'button':
                    case 'text':
                    case 'submit':
                    case 'password':
                    case 'file':
                    case 'email':
                    case 'date':
                    case 'number':
                        $(this).val('');
                        break;
                    case 'checkbox':
                    case 'radio':
                        this.checked = false;
                        break;
                }
            });			
    }
</script>
