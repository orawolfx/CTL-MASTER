<?php

	if(isset($_POST['CmdSTDDownloadSelected']))
	{
		for($i=0; count($_POST['stdchk'])>$i; $i++)
		{			
			if($_POST['stdchk'][0]=="ShiftDifferential")
			{
				$f1="Shift_Differential.csv";
				$path="csv/Shift_Differential.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
			
			if($_POST['stdchk'][0]=="LeaveBalances")
			{
				$f1="Leave_balances.csv";
				$path="csv/Leave_balances.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
			
			if($_POST['stdchk'][0]=="LeaveInterface")
			{
				$f1="LeaveCLAS.csv";
				$path="csv/LeaveCLAS.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
			
			if($_POST['stdchk'][0]=="PositivePay")
			{
				$f1="PositivePay.csv";
				$path="csv/PositivePay.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
			if($_POST['stdchk'][0]=="Overtime")
			{
				$f1="Overtime.csv";
				$path="csv/Overtime.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
		}	
	}
  
    if(isset($_POST['CmdHumanDownloadSelected']))
	{
		    if($_POST['Humanchk']=="EmployeeInformation")
			{
				$f1="EEI_Extract.csv";
				$path="csv/EEI_Extract.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); 
				readfile($path);	
			}
	}
	if(isset($_POST['CmdProjectDownloadSelected']))
	{
	    for($i=0; count($_POST['prochk'])>$i; $i++)
		{
			if($_POST['prochk'][0]=="ProjectWBS")
			{
				$f1="ProjectsWBS.csv";
				$path="csv/ProjectsWBS.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
			if($_POST['prochk'][0]=="LaborDistribution")
			{
				$f1="LDOutbound.csv";
				$path="csv/LDOutbound.csv";
				header("Content-Type: application-x/force-download");
				header('Content-Type:application/octet-stream');
				header('Content-Description:File Transfer');
				header('Content-Transfer-Encoding:binary');
				header('Content-Disposition: attachment; filename=' .$f1); 
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($path));
				ob_clean();
				flush(); // Flush system output buffer
				readfile($path);	
			}
		}
	}
		
?>