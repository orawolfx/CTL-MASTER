<?php 
ob_start ();
include("conn.php");
 // include ("find.php"); 
?>

<?php
/*if(isset($_POST['cmdFreeTrial'])
{
	
}*/
if(isset($_POST['login']) && $_POST['login']=='login' ){

    $username=isset($_POST['username']) ? $_POST['username'] :'';
    $password=isset($_POST['password']) ? GetPassword($_POST['password']) :'';
	/*$qry="SELECT * FROM cxs_users where USER_NAME='".$username."'";	 
	$result = mysql_query($qry) or die(mysql_error($conn));
	$row_num = mysql_num_rows($result);
	if($row_num>0)
	{
		while($row = mysql_fetch_array($result))
		{
			echo GetPassword($row['ENC_KEY']);
		}
	}
	//exit();*/
	
	$accesibility=isset($_POST['Combo_Accesibility']) ? $_POST['Combo_Accesibility'] :'';
	$AccessModule="";
	$error = "";
    if(empty($username) || empty($password))
	{
        $error="Username and Password required.";
    }	
	else
	{ 
		$qry="SELECT cxs_users.*,cxs_site_settings.MANDATORY_PWD  FROM cxs_users inner join cxs_site_settings on cxs_site_settings.SITE_ID = cxs_users.SITE_ID where USER_NAME='".$username."' && ENC_KEY='".$password."'  limit 0,1";	 
        $result = mysql_query($qry) or die(mysql_error($conn));
        $row_num = mysql_num_rows($result);
        if($row_num>0)
		{   
            $user_arr = mysql_fetch_array($result);
            $now = time(); // or your date as well
			if( !is_null($user_arr['END_DATE']) &&  $user_arr['END_DATE'] != '0000-00-00')
			{ 
				if($user_arr['END_DATE']<date("Y-m-d",$now))
				{ 	
					$date1= date("m/d/Y",strtotime($user_arr['END_DATE']));
					$error = "Your login is expired on $date1";
				}
			}
			if($error=='')
			{
				$psw_reset_date = strtotime($user_arr['PSW_RESET_DATE']);
				$datediff = $now - $psw_reset_date;
				$dtDiff = floor($datediff / (60 * 60 * 24));
				if($user_arr['TEMP_PASSWORD']=='Y' || $dtDiff>=$user_arr['MANDATORY_PWD'])
				{ 
					$AllowResetPassword = "";
					$TempUserId = $user_arr['USER_ID'];
					$qry = "select * from cxs_am_app_admin where USER_ID = $TempUserId";
					$result = mysql_query($qry);	
					$TotalRecords = mysql_num_rows($result);
					if($TotalRecords>0)
					{
						$AllowResetPassword="Y";
					}
					
					if($AllowResetPassword!="Y")
					{
						if($user_arr['ROLE_ID']!=0)		
						{
							$AllowResetPassword = "Y";
						}
						else
						{
							$qry = "select * from cxs_ta_modules where USER_ID = $TempUserId";
							$result=mysql_query($qry);				
							if(mysql_num_rows($result)>0)
							{
								$AllowResetPassword="Y";								
							}
						}
					}
					
					if($AllowResetPassword=="Y")
					{
						$_SESSION['reset-password'] = 'Y';
						$_SESSION['user-email'] = $username;	
						$_SESSION['user-siteid'] = $user_arr['SITE_ID'];	
						header('location:reset-password.php');
					}
					else 
					{
						$error = "You have not to access any module permission. Please contact your administrator.";
					}
				}
				else
				{
					unset($_SESSION['reset-password']);
					unset($_SESSION['user-email']);
					if(!empty($_POST["rememberMe"])) 
					{
						setcookie ("cookie_username",$_POST["username"],time()+ (10 * 365 * 24 * 60 * 60));
						setcookie ("cookie_password",$_POST["password"],time()+ (10 * 365 * 24 * 60 * 60));
					}
					else
					{
						if(isset($_COOKIE["cookie_username"])){setcookie ("cookie_username","");}
						if(isset($_COOKIE["cookie_password"])){setcookie ("cookie_password","");}
					}
					$_SESSION['user_data']=$user_arr;
					$_SESSION['user_id'] = $user_arr['USER_ID'];
					$_SESSION['user-siteid'] = $user_arr['SITE_ID'];
					$TempUserId = $user_arr['USER_ID'];	
					$s1="";
					$s2="";
					$userType = "";
					$IsValid = "";
					$qry = "select * from cxs_am_app_admin where USER_ID = $TempUserId";
					$result = mysql_query($qry);	
					$numofrecords = mysql_num_rows($result);
					if($numofrecords == 0)
					{
						$IsValid = "Y";
					}
					while($row = mysql_fetch_array($result))
					{
						if( !is_null($row['END_DATE_ACTIVE']) &&  $row['END_DATE_ACTIVE'] != '0000-00-00' )
						{ 
							if($row['END_DATE_ACTIVE']>=date("Y-m-d",$now))
							{
								$IsValid = "Y";
							}						
						}
						else
						{
							$IsValid = "Y";						
						}
						
						if($IsValid == "Y")
						{
							
							if($row['APPLICATION_ID']==1 && $IsValid == "Y")	
							{
								$s1 = "RBAM";							
								$userType.="RBAM-Admin ";
							}
							if($row['APPLICATION_ID']==2 && $IsValid == "Y")	
							{
								$s2 = "TE";
								$userType.="TE-Admin ";
							}
						}
					}					
					if(isset($_SESSION['redirect_page']))
					{
						if(isset($_COOKIE["cookie_access-module"])) 
						{
							$_SESSION['access-module'] = $_COOKIE["cookie_access-module"];
							setcookie ("cookie_access-module","");
						}
						header('location:'.$_SESSION['redirect_page']);	
					}
					else
					{	
						if($user_arr['ROLE_ID']!=0 && $s1 == '')	
						{
							if($user_arr['ROLE_END_DATE']!='')
							{
								if($user_arr['ROLE_END_DATE']<=date("Y-m-d",$now))
								{
									$AccessModule="RBAM";
									$s1="RBAM";
									$userType.="RBAM-User "; 
								}
							}
							else
							{
								$AccessModule="RBAM";
								$s1="RBAM";
								$userType.="RBAM-User ";
							}
						}						
						$qry = "select * from cxs_ta_modules where USER_ID = $TempUserId";
						$result=mysql_query($qry);				
						while($row=mysql_fetch_array($result))
						{
							if ($s1=='')
							{
								if( $row['MODULE_NAME']=='Global Aliases'  || $row['MODULE_NAME']=='Site Settings'  || $row['MODULE_NAME']=='Create WBS' || $row['MODULE_NAME']=='Access Management' || $row['MODULE_NAME']=='Billing & Payment' || $row['MODULE_NAME']=='View Bill Payment' || $row['MODULE_NAME']=='Manage Payment Methods')
								{
									if($row['VIEW_PRIV']=="Y")
									{
										$s1 = "RBAM";
										$userType.="RBAM-User ";
									}
								}							
							}						
							if ($s2=='')
							{
								if( $row['MODULE_NAME']=='Time Management Policy'  || $row['MODULE_NAME']=='Holiday Calenders'  || $row['MODULE_NAME']=='Time Entry' || $row['MODULE_NAME']=='Search TimeSheets' || $row['MODULE_NAME']=='Create Personal Aliases' || $row['MODULE_NAME']=='PreApproval Rules' || $row['MODULE_NAME']=='Accounting Period' || $row['MODULE_NAME']=='Resources' || $row['MODULE_NAME']=='Resource Group' || $row['MODULE_NAME']=='Workshift')
								{
									if($row['VIEW_PRIV']=="Y")
									{
										$s2 = "TE";
										$userType.="TE-User ";
									}
								}
							}
						}	
						
						if ($s1!='' && $s2 != '')
						{
							$AccessModule = "Both";
						}
						else if ($s1!='' && $s2 =='')
						{
							$AccessModule = $s1;
						}
						else if ($s1=='' && $s2 !='')
						{
							$AccessModule = $s2;
						}
						else if ($s1=='' && $s2 =='')
						{
							$AccessModule = "";
						}
						$_SESSION['access-module'] = $AccessModule;
						$_SESSION['user-type'] = $userType;
						UpdateLastLogin($user_arr['USER_ID']);
						
						if($AccessModule=="RBAM")
						{
							header("location: ../coexsys/rbam/rbam.php");
						}
						else if($AccessModule=="TE")
						{
							header("Location: ../ctl/te/te.php");
						}
						else if($AccessModule=="Both")
						{
							header("Location:accessibility.php");
						?>
							<!--<script type="text/javascript">							
								document.getElementById('div_signin').style.display = 'none';
								document.getElementById('div_accesibility').style.display = 'show';							
							</script>-->
				<?php	}
						else if($AccessModule=="")
						{
							$error = "You have not to access any module permission. Please contact your administrator.";
						}	
						
					}
				}
			}
      }
	  else
	  {

         $error="Incorrect Username & Password.";
      }
   }
     
}
?>   



<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Coexsys | Login Form</title>  	
	<link rel="stylesheet" href="css/bootstrap1.min.css">
	<link rel="stylesheet" href="css/login_style.css">
	<!--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>-->
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jsfunctions.js"></script>	
    <script src="js/custom.js" type="text/javascript"></script>
  <script>
    function ForgotPasswordPopUp(search_by)
	{	
		$('#ForgotPasswordModal').modal();
		//$('#SearchResourceGroups').find('.srchFld').css('display','none');
		
		//$('#SearchResourceGroups').find('#sec_'+search_by).css('display','block');
		
		//$('#SearchResourceGroups').find('#search_by_field_nm').val(search_by);
	}
	function FreeTrialPopUp(search_by)
	{	
		//$('#FreeTrialModal')[0].reset();
		//	$("#FreeTrialModal").trigger("reset");	
		$('#FreeTrialModal').find('input:text, input:password, select, textarea').val('');	
		$('#FreeTrialModal').modal();	
	}
	
    function sendTempPassword()
    {
        var Text_Email = $.trim($("#Text_Email").val());
        if (Text_Email=='') {
            alert('Please enter your email.');
            $("#Text_Email").val('');
            $("#Text_Email").focus();
        }
        else
        {
            
            var form_data = new FormData();
        	  form_data.append("user_email", Text_Email);
            jQuery.ajax({
                url: "ajax-functions/generateTempPsw.php", // point to server-side PHP script 
                dataType: 'text', // what to expect back from the PHP script
                cache: false,
                contentType: false,
                processData: false,
                async: false,
                data: form_data,
                type: 'POST',
                success: function (response) {
                    var data = response.split('|');
                    alert(data[1]);
                    if (data[0]==1) {
                        $("#ForgotPasswordModal .close").click();
                    }
				
                },
                error: function (response) {
				//$('#fileMsg').html(response); // display error response from the PHP script
                }
        	  });
        }	   
    }
	$(document).ready(function()
	{
		$('#div_accesibility').hide();
		$('#div_signin').show();
	});
	
    
  </script>
  <style>
	.myStyle
	{
		color: #428bca;
		cursor: pointer;
	}
	.myStyle:hover
	{
		color: #2a6496;
		text-decoration: underline;
	}
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	@media (min-width: 768px) 
	{
		.modal-dialog {	width: 400px;}
	}
	</style>
</head>

<body>
    <div class="wrapper">		
    <form class="form-signin" method='post' action=''> 
      <div class='row' > <img style='margin-right:-20px;' class='pull-right' src="img/main_logo.png" /> </div>    
     
		<h2 class="form-signin-heading" >Sign In</h2>
		<?php 
			if($AccessModule==''){ $divStyle = "display:block;"; } 
			else{ $divStyle = "display:none;"; } 
		?>
		<div id="div_signin" style = "<?php echo $divStyle; ?>" >
			<input type="text" class="form-control" name="username" value="<?php if(isset($_COOKIE["cookie_username"])) { echo $_COOKIE["cookie_username"]; } else { echo $_POST['username']; } ?>" placeholder="Email Address" required autofocus />
			<input type="password" class="form-control" value="<?php if(isset($_COOKIE["cookie_password"])) { echo $_COOKIE["cookie_password"]; } else { echo "";} ?>" name="password"  placeholder="Password" required/>
			  
			   
			<?php if(isset($error)){ ?>
				<p align='center' class='text-danger'><?php echo $error; ?></p> 
			<?php } ?>
			
			<label class="checkbox">
				<input type="checkbox" value="remember-me" id="rememberMe" <?php if(isset($_COOKIE["cookie_username"])) { ?> checked <?php } ?>  name="rememberMe">Remember me
			</label>
				
			<div class="clear-both" style = "padding-top:15px;"></div>
			<button class="btn btn-lg btn-primary btn-block" name='login' value='login' type="submit">Login</button> 
			
			<label id='free_trial' class = "myStyle pull-left" onclick="FreeTrialPopUp();" >Free Trial Registration</label>
			<label id='forget_password1' class = "myStyle pull-right"  onclick="ForgotPasswordPopUp();">Forgot Password</label>
			
		</div>
		
		<div id = "div_accesibility" style = "display:none">
			<h2>Accesibility</h2>
			<select id = "Combo_Accesibility" name = "Combo_Accesibility" class="form-control ">
				<option value="RBAM">RBAM</option>
				<option value="TE">Time Entry</option>
			</select>
		</div>
    </form>
  </div>
	<form  method="post" action="" >
	  <div class="modal fade custom-modal" id="ForgotPasswordModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style="display:none">
		<input type="hidden" id="search_by_field_name" value="">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title " id="myModalLabel"> Forget Password </h4>
			</div>
			<div class="modal-body">
			<!-- field start-->
			  <div class="col-sm-12">
				<div class="cus-form-cont">
					
					<div class="col-sm-12 form-group srchFld">
						<label> Please enter your registered email </label>
						<input type="text" id="Text_Email" name="Text_Email" value = "" class="form-control" placeholder="">
					</div>
								
					
				</div>
				
			  </div>
			<!-- end -->
			</div>
			<div class="clear-both"></div>
			<div class="modal-footer cr-user">
			    <button type="button" id="sendTempPsw" name="sendTempPsw" class="btn btn-primary btn-style" onclick="sendTempPassword()"> Reset Password </button>
			</div>
		  </div>
		</div>
	  </div>
	  
	</form>
	
	<form  method="post" action="" id="FreeTrialForm" >
	  <div class="modal fade custom-modal" id="FreeTrialModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style="display:none">
		<input type="hidden" id="search_by_field_name1" value="">
		<div class="modal-dialog " role="document">
		  <div class="modal-content">
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h3 class="modal-title text-center"> Free Trial </h3>
			</div>
			<div class="modal-body">
			<!-- field start-->
			  <div class="col-sm-12">
				<div class="cus-form-cont">
					<div class="col-sm-12 form-group srchFld ">						
					<label >Please complete all fields.</label>
					</div>
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_FirstName" name="Text_FirstName" required value = "" class="form-control requirefieldcls" placeholder="First Name">
						<span id ="span_firstname"></span> 
					</div>
					
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_LastName" name="Text_LastName" required value = "" class="form-control requirefieldcls" placeholder="Last Name">
						<span id ="span_lastname"></span> 
					</div>					
					
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_JobTitle" name="Text_JobTitle" required value = "" class="form-control requirefieldcls" placeholder="Job Title">
						<span id ="span_jobtitle"></span> 
					</div>					
					
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_EmailFreeTrial" name="Text_EmailFreeTrial" required value = "" class="form-control requirefieldcls" placeholder="Email">
						<span id ="span_emailfreetrial"></span> 
					</div>					
					
					<div class="col-sm-12 form-group srchFld">												
						<input type="text" id="Text_Phone" name="Text_Phone" required value = "" class="form-control requirefieldcls" placeholder="Phone">
						<span id ="span_phone"></span> 
					</div>	
					
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_Company" name="Text_Company" required value = "" class="form-control requirefieldcls" placeholder="Company">
						<span id ="span_company"></span> 
					</div>	
					<!--
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_Address1" name="Text_Address1" required value = "" class="form-control requirefieldcls" placeholder="Address">
						<span id ="span_company"></span> 
					</div>
					
					<div class="col-sm-12 form-group srchFld">						
						<span id ="span_company"></span> 
						<input type="text" id="Text_State" name="Text_State" required value = "" class="form-control requirefieldcls" placeholder="Company">
					</div>
					
					<div class="col-sm-12 form-group srchFld">						
						<input type="text" id="Text_Company" name="Text_Company" required value = "" class="form-control requirefieldcls" placeholder="Company">
						<span id ="span_company"></span> 
					</div>
					-->
					<div class="col-sm-12 form-group srchFld">												
						<select id = "Combo_Employees" name = "Combo_Employees" required class="form-control requirefieldcls">
							<option value =''> - Employees -</option>
							<option value = '1 - 45 employees'> 1 - 45 employees</option>
							<option value = '46 - 200 employees'> 46 - 200 employees</option>
							<option value = '201 - 1000 employees'> 201 - 1000 employees</option>
							<option value = '1001 - 4500 employees'> 1001 - 4500 employees</option>
							<option value = '4,501 - 10,000 employees'> 4,501 - 10,000 employees</option>
							<option value = ' 10,001+ employees'> 10,001+ employees</option>
						</select>
						<span id ="span_employees"></span> 
					</div>	
					<button style = "float : left" type="button" id="cmdFreeTrial" name="cmdFreeTrial" class="btn btn-primary btn-style col-sm-12 form-control srchFld"> Set My Free Trial </button>
				</div>
				<div class=" modal-footer	"></div>
			<!-- 	<div class="modal-footer cr-user">
					
				</div>
			  </div>
			<!-- end -->
			</div>
			<!--<div class="clear-both"></div>
			<div class="modal-footer cr-user">
			    <button style = "float : left" type="button" id="sendTempPsw1" name="sendTempPsw1" class="btn btn-primary btn-style col-sm-12 form-control" onclick="sendTempPassword()"> Set My Free Trial </button>
			</div> -->
		  </div>
		</div>
	  </div>
	  
	</form>

<script>
	

	function isEmail(email) 
	{
	  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	  return regex.test(email);
	}
	function isPhone()
	{
		$("#span_phone").text("");
		var s1 = $("#Text_Phone").val().replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing
		
		var number = ""; 
		var s2 = "";
		if(s1!="")
		{
			number = parseInt(s1, 10);
			s2 = number.toString();
		}
		//var Lennumber.toString().length);
		if (s1!="" && s2.length!=10)
		{
			$("#span_phone").text("Please enter valid phone no.");
			$("#Text_Phone").focus();
			return false;
		}
		else
		{
			if(s1!="")
			{
				s1 = "("+s2.substr(0,3)+")"+s2.substr(3,3)+"-"+s2.substr(6,4);
				$("#Text_Phone").val(s1);
				return true;
			}
			else
			{
				$("#span_phone").text("Please enter valid phone no.");
				$("#Text_Phone").focus();
				return false;
			}
		}
	}
	$("#Text_Phone").blur(function()
	{	
		if(isPhone()==false)
		{
			$("#Text_Phone").focus();
			return false;
		}
	});
	
	/*$('#Text_Phone').keyup(function()
	{
		$(this).val($(this).val().replace(/(\d{3})\-?(\d{3})\-?(\d{4})/,'$1-$2-$3'))
	}); */

	$("#Text_Phone").focus(function()
	{
		var s1 = $("#Text_Phone").val().replace(/[^0-9]/gi, ''); // Replace everything that is not a number with nothing
		 $("#Text_Phone").val(s1);
	});
	
	$("#cmdFreeTrial").click(function()
	{
		$("#span_firstname").text("");
		$("#span_lastname").text("");
		$("#span_jobtitle").text("");
		$("#span_emailfreetrial").text("");
		$("#span_phone").text("");
		$("#span_company").text("");
		$("#span_employees").text("");
		
		var Flag_Valid = "";
		if ($("#Text_FirstName").val()=="")
		{
			$("#span_firstname").text("Please enter first name.");
			$("#Text_FirstName").focus();
			Flag_Valid ="N";
		}
			
		if ($("#Text_LastName").val()=="")
		{
			$("#span_lastname").text("Please enter last name.");
			$("#Text_LastName").focus();
			Flag_Valid ="N";
		}
		
		if ($("#Text_JobTitle").val()=="")
		{
			$("#span_jobtitle").text("Please enter job title.");
			$("#Text_JobTitle").focus();
			Flag_Valid ="N";
		}
		
		if ($("#Text_EmailFreeTrial").val()=="")
		{
			$("#span_emailfreetrial").text("Please enter Email Address.");
			$("#Text_EmailFreeTrial").focus();
			Flag_Valid ="N";
		}
		
		if ($("#Text_Phone").val()=="")
		{
			$("#span_phone").text("Please enter phone.");
			$("#Text_Phone").focus();
			Flag_Valid ="N";
		}
		
		if ($("#Text_Company").val()=="")
		{
			$("#span_company").text("Please enter company name.");
			$("#Text_Company").focus();
			Flag_Valid ="N";
		}
		if ($("#Combo_Employees").val()=="")
		{
			$("#span_employees").text("Please select employees.");
			$("#Combo_Employees").focus();
			Flag_Valid ="N";
		}
		
		/*if (Flag_Valid =="N")
		{
			$("#cmdFreeTrial").attr("disabled",false);
			return false;
		}*/
		
		if (!isEmail($("#Text_EmailFreeTrial").val()) )
		{
			$("#span_emailfreetrial").text("Please enter valid Email Address");
			$("#Text_EmailFreeTrial").focus();
		//	$("#cmdFreeTrial").attr("disabled",false);
			return false;
		}
		
		if(isPhone()==false)
		{
			$("#Text_Phone").focus();
			return false;
		}
		$("#cmdFreeTrial").attr("disabled",true);
		$.ajax({ url:"ajax-supervisor.php",method:"POST",
				data:{Request:"FreeTrialRecord",Text_FirstName:$("#Text_FirstName").val(),Text_LastName:$("#Text_LastName").val(),
				Text_JobTitle:$("#Text_JobTitle").val(),Text_EmailFreeTrial:$("#Text_EmailFreeTrial").val(),
				Text_Phone:$("#Text_Phone").val(),Text_Company:$("#Text_Company").val(),Combo_Employees:$("#Combo_Employees").val()
				},   
				success : function(response1)
				{
					//alert(response1);
					$("#cmdFreeTrial").attr("disabled",false);															
					if(response1=='false')
					{	
						alert("Email "+$("#Text_EmailFreeTrial").val()+" is already registered. Please enter another email.");	
						$("#Text_EmailFreeTrial".focus());
					}
					else
					{
						alert("Your free trial up to 30 days has been activated and a temporary password sent to you via email. at "+$("#Text_EmailFreeTrial").val()+".");	
						$("#FreeTrialModal .close").click();
					}
				}
			});
	/*	
		$.ajax({ url:"ajax-supervisor.php",type:"POST",
				data:{Request:"FreeTrialRecord",FormData:data1}, 
                processData: false,                
				success : function(response1)
				{
					alert(response1);alert("j");
				}
			});*/
	});
</script>
</body>

</html>

