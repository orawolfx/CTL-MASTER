<?php
//DGS Employee Time Entry Report by Pay Period,31-Oct-2018 13:28:44
if (! defined("DIRECTACESS")) exit("No direct script access allowed"); 
$file_name = "repDGSEmployeeTimeEntryReportbyPayPeriod";
//  customization settings
$template_title = "";
$category = "DEMO";
$date_created = "31-Oct-2018 13:28:44";
$maintainance_email = "";
$images_path = "images/";
$headers_output_escaping = "Yes";
$default_page_size = "A3";
$output_escaping = "Yes";
$thumnail_max_width = "40";
$thumnail_max_height = "50";
$show_real_size_image = "";
$show_realsize_in_popup = "1";
$chkSearch = "Yes";
//  wizard settings
$language = "en";
$db_extension = "pdo";
$datasource = "table";
$sql = "";
$table = array(
"0" => "cxs_aliases",
"1" => "cxs_periods",
"2" => "cxs_resources",
"3" => "cxs_sites",
"4" => "cxs_te_file",
"5" => "cxs_te_header",
"6" => "cxs_users",
"7" => "cxs_wbs");
$tables_filters = array(
      "filter1" => array(
"sql" => "`cxs_sites`.`SITE_NAME`  <-> LIKE ?",
"param" => "CALIFORNIA",
"type" => "s"));
$relationships = array(
"0" => "`cxs_periods`.`PERIOD_ID` = `cxs_te_header`.`PAY_PERIOD_ID`",
"1" => "`cxs_periods`.`PERIOD_ID` = `cxs_te_file`.`PERIOD_ID`",
"2" => "`cxs_aliases`.`ALIAS_ID` = `cxs_te_file`.`ALIAS_ID`",
"3" => "`cxs_aliases`.`WBS_ID` = `cxs_wbs`.`WBS_ID`",
"4" => "`cxs_wbs`.`WBS_ID` = `cxs_te_file`.`WBS_ID`",
"5" => "`cxs_resources`.`RESOURCE_ID` = `cxs_te_header`.`RESOURCE_ID`",
"6" => "`cxs_resources`.`RESOURCE_ID` = `cxs_te_file`.`RESOURCE_ID`",
"7" => "`cxs_users`.`RESOURCE_ID` = `cxs_resources`.`RESOURCE_ID`",
"8" => "`cxs_te_header`.`TE_ID` = `cxs_te_file`.`TE_ID`",
"9" => "`cxs_sites`.`SITE_ID` = `cxs_te_file`.`SITE_ID`",
"10" => "`cxs_sites`.`SITE_ID` = `cxs_te_header`.`SITE_ID`",
"11" => "`cxs_sites`.`SITE_ID` = `cxs_periods`.`SITE_ID`",
"12" => "`cxs_sites`.`SITE_ID` = `cxs_aliases`.`SITE_ID`",
"13" => "`cxs_sites`.`SITE_ID` = `cxs_resources`.`SITE_ID`",
"14" => "`cxs_sites`.`SITE_ID` = `cxs_users`.`SITE_ID`",
"15" => "`cxs_sites`.`SITE_ID` = `cxs_wbs`.`SITE_ID`");
$affected_column = "";
$function = "";
$groupby_column = "";
$labels = array(
"cxs_sites.SITE_NAME" => "SITE_NAME",
"cxs_aliases.ALIAS_NAME" => "ALIAS_NAME",
"cxs_aliases.PERIOD_NAME" => "PERIOD_NAME",
"cxs_aliases.PROJECT_NUMBER" => "PROJECT_NUMBER",
"cxs_aliases.TASK_NUMBER" => "TASK_NUMBER",
"cxs_resources.FIRST_NAME" => "FIRST_NAME",
"cxs_resources.LAST_NAME" => "LAST_NAME",
"cxs_users.USER_NAME" => "USER_NAME",
"cxs_te_header.TE_NAME" => "TE_NAME",
"cxs_te_file.ENTRY_DATE" => "ENTRY_DATE",
"cxs_te_file.HOURS" => "HOURS",
"cxs_te_file.STATUS_FLAG" => "STATUS_FLAG",
"cxs_te_file.ENTRY_TYPE" => "ENTRY_TYPE");
$cells = array(
"cxs_sites.SITE_NAME" => "value",
"cxs_aliases.ALIAS_NAME" => "value",
"cxs_aliases.PERIOD_NAME" => "value",
"cxs_aliases.PROJECT_NUMBER" => "value",
"cxs_aliases.TASK_NUMBER" => "value",
"cxs_resources.FIRST_NAME" => "value",
"cxs_resources.LAST_NAME" => "value",
"cxs_users.USER_NAME" => "value",
"cxs_te_header.TE_NAME" => "value",
"cxs_te_file.ENTRY_DATE" => "value",
"cxs_te_file.HOURS" => "value",
"cxs_te_file.STATUS_FLAG" => "value",
"cxs_te_file.ENTRY_TYPE" => "value");
$conditional_formating = array(
      "0" => array(
"filter" => "equal",
"column" => "cxs_te_file.STATUS_FLAG",
"filterValue1" => "R",
"color" => "#ff0000"));
$fields = array(
"0" => "cxs_sites.SITE_NAME",
"1" => "cxs_aliases.ALIAS_NAME",
"2" => "cxs_aliases.PERIOD_NAME",
"3" => "cxs_aliases.PROJECT_NUMBER",
"4" => "cxs_aliases.TASK_NUMBER",
"5" => "cxs_resources.FIRST_NAME",
"6" => "cxs_resources.LAST_NAME",
"7" => "cxs_users.USER_NAME",
"8" => "cxs_te_header.TE_NAME",
"9" => "cxs_te_file.ENTRY_DATE",
"10" => "cxs_te_file.HOURS",
"11" => "cxs_te_file.STATUS_FLAG",
"12" => "cxs_te_file.ENTRY_TYPE");
$fields2 = array(
"0" => "cxs_sites.SITE_NAME",
"1" => "cxs_aliases.ALIAS_NAME",
"2" => "cxs_aliases.PERIOD_NAME",
"3" => "cxs_aliases.PROJECT_NUMBER",
"4" => "cxs_aliases.TASK_NUMBER",
"5" => "cxs_resources.FIRST_NAME",
"6" => "cxs_resources.LAST_NAME",
"7" => "cxs_users.USER_NAME",
"8" => "cxs_te_header.TE_NAME",
"9" => "cxs_te_file.ENTRY_DATE",
"10" => "cxs_te_file.HOURS",
"11" => "cxs_te_file.STATUS_FLAG",
"12" => "cxs_te_file.ENTRY_TYPE");
$group_by = array();
$sort_by = array();
$records_per_page = "10";
$layout = "Outline";
$style_name = "grey";
$title = "DGS Employee Time Entry Report by Pay Period";
$header = "";
$footer = "";
$allow_only_admin = "yes";
$sec_Username = "";
$sec_pass = "";
$security = "";
$is_public_access = "no";
$sec_email = "";
$members = "";
$sec_table = "";
$sec_Username_Field = "";
$sec_pass_Field = "";
$sec_email_field = "";
$sec_pass_hash_type = "";
$Forget_password = "enabled";
$is_mobile = "";
