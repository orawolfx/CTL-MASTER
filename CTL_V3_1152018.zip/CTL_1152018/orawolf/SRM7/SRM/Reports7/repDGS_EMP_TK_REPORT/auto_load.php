<?php

/**
 * Smart Report Maker
 * Version 7.0.0
 * Author : StarSoft 
 * All copyrights are preserved to StarSoft
 * URL : http://mysqlreports.com/
 *
 */
if (!defined("DIRECTACESS"))
    exit("No direct script access allowed");
if ($datasource == 'sql') {
    require_once ("../shared/helpers/Model/Report.php");
    require_once ("../shared/helpers/Model/QueryReport.php");
} else {
    require_once ("../shared/helpers/Model/search.php");
    require_once ("../shared/helpers/Model/Report.php");
    require_once ("../shared/helpers/Model/TableReport.php");
}

// require_once ('../shared/pdf/class.ezpdf.php');
if (isset($_GET ["export"]) && ($_GET ["export"] == "pdf" || ($_GET ["export"] == "pdf1" && version_compare(PHP_VERSION, '5.3.0') == -1))) {
    //export all
    require_once("../shared/pdf-old/class.ezpdf.php");
} elseif (isset($_GET ["export"]) && $_GET ["export"] == "pdf1" && version_compare(PHP_VERSION, '5.3.0') >= 0) {
    require_once ("../shared/pdf/dompdf/autoload.inc.php");
}

require_once ("../shared/helpers/functions.php");
require_once ("../shared/helpers/celltypes.php");

require_once ("../shared/helpers/lib.php");
if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
     require_once ("../shared/helpers/export.php");
} else {
       require_once("../shared/helpers/export.old.php");

}

/*
 * #################################################################################################
 * Creating the Report Sql
 * ################################################################################################
 */
if ($datasource == 'sql') {

    $sql = Prepare_QSql();
} else {

    $sql = Prepare_TSql();
}
if ($empty_search_parameters || $possible_attack) {
    // case user send empty search keywords or entered the $Enter_your_search_lang in the search box
    $all_records = array();
    $nRecords = 0;
    $empty_Report = true;
    $numberOfPages = 1;
    $records_per_page = 10;
} else {

    $all_records = query($sql [0], "LayOut : Prepare SQL", $sql [1], $sql [2]);
    $nRecords = count($all_records);
    if ($records_per_page == 0) {
        $records_per_page = 10;
    }

    $numberOfPages = ceil($nRecords / $records_per_page);
    if ($numberOfPages == 0 || $nRecords == 0) {
        $empty_Report = true;
        $numberOfPages = 1;
    } else {
        $empty_Report = false;
    }
}
$levels = count($group_by);
?>