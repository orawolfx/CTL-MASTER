<?php
if (! defined("DIRECTACESS")) exit("No direct script access allowed"); 
$DB_HOST = "localhost";
$DB_USER = "intella1_coexsys";
$DB_PASSWORD = decode( "Y29leEAyMDE4");
$DB_NAME = "intella1_coexsys";
