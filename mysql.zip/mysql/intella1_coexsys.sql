-- MySQL dump 10.13  Distrib 5.6.32-78.1, for Linux (x86_64)
--
-- Host: localhost    Database: intella1_coexsys
-- ------------------------------------------------------
-- Server version	5.6.32-78.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cxs_aliases`
--

DROP TABLE IF EXISTS `cxs_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_aliases` (
  `ALIAS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ALIAS_NAME` varchar(50) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(50) NOT NULL DEFAULT '',
  `PROJECT_NUMBER` varchar(50) NOT NULL DEFAULT '',
  `TASK_NUMBER` varchar(50) NOT NULL DEFAULT '',
  `EXPENDITURE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `EMPLOYEE_NUMBER` varchar(30) NOT NULL DEFAULT '',
  `XXTPAA_COMMENT` varchar(240) NOT NULL DEFAULT '',
  `LAST_UPDATE_LOGIN` bigint(20) NOT NULL DEFAULT '0',
  `ORG_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_STATUS` varchar(50) NOT NULL DEFAULT '',
  `RESOURCE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `CATEGORY` varchar(240) NOT NULL DEFAULT '',
  `SUB_CATEGORY` varchar(240) NOT NULL DEFAULT '',
  `ETRACKER_CCD_NO` varchar(50) NOT NULL DEFAULT '',
  `COPY_ALLOWED` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `AUTOPOPULATE` varchar(1) NOT NULL DEFAULT '',
  `WBS_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALIAS_TYPE` varchar(350) NOT NULL DEFAULT '',
  `ALIAS_CLASS` varchar(50) NOT NULL DEFAULT '',
  `ADDINUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ALIAS_ID`),
  KEY `WBS_ID` (`WBS_ID`),
  KEY `ALIAS_NAME` (`ALIAS_NAME`),
  KEY `PERIOD_NAME` (`PERIOD_NAME`),
  KEY `PROJECT_NUMBER` (`PROJECT_NUMBER`),
  KEY `TASK_NUMBER` (`TASK_NUMBER`),
  KEY `EXPENDITURE_TYPE` (`EXPENDITURE_TYPE`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `EMPLOYEE_NUMBER` (`EMPLOYEE_NUMBER`),
  KEY `XXTPAA_COMMENT` (`XXTPAA_COMMENT`),
  KEY `LAST_UPDATE_LOGIN` (`LAST_UPDATE_LOGIN`),
  KEY `ORG_ID` (`ORG_ID`),
  KEY `ALIAS_STATUS` (`ALIAS_STATUS`),
  KEY `RESOURCE_TYPE` (`RESOURCE_TYPE`),
  KEY `CATEGORY` (`CATEGORY`),
  KEY `SUB_CATEGORY` (`SUB_CATEGORY`),
  KEY `ETRACKER_CCD_NO` (`ETRACKER_CCD_NO`),
  KEY `COPY_ALLOWED` (`COPY_ALLOWED`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `AUTOPOPULATE` (`AUTOPOPULATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `ALIAS_TYPE` (`ALIAS_TYPE`),
  KEY `ALIAS_CLASS` (`ALIAS_CLASS`),
  KEY `ADDINUSE_FLAG` (`ADDINUSE_FLAG`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_aliases`
--

LOCK TABLES `cxs_aliases` WRITE;
/*!40000 ALTER TABLE `cxs_aliases` DISABLE KEYS */;
INSERT INTO `cxs_aliases` (`ALIAS_ID`, `ALIAS_NAME`, `PERIOD_NAME`, `PROJECT_NUMBER`, `TASK_NUMBER`, `EXPENDITURE_TYPE`, `DESCRIPTION`, `EMPLOYEE_NUMBER`, `XXTPAA_COMMENT`, `LAST_UPDATE_LOGIN`, `ORG_ID`, `ALIAS_STATUS`, `RESOURCE_TYPE`, `CATEGORY`, `SUB_CATEGORY`, `ETRACKER_CCD_NO`, `COPY_ALLOWED`, `ACTIVE_FLAG`, `AUTOPOPULATE`, `WBS_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ALIAS_TYPE`, `ALIAS_CLASS`, `ADDINUSE_FLAG`, `SITE_ID`) VALUES (1,'GALIAS','','','','','GALIASd','','',0,0,'','','','','','Y','Y','Y',4,35,'2018-08-05 10:52:05',35,'2018-08-05 18:27:06','PTO-Personal Time Off','Policy','Y',18),(2,'PALIAS','','','','','AD','','',0,0,'','','','','','N','N','N',4,35,'2018-08-05 10:58:21',35,'2018-08-05 16:58:21','RES-Resource Specific Alias','','',18),(3,'NEWLEAVE','','','','','leavw','','',0,0,'','','','','','Y','Y','Y',0,35,'2018-08-05 12:27:33',35,'2018-08-05 18:27:50','PTO-Personal Time Off','Leave','Y',18),(4,'GALIAS','','','','','GALIASd','','',0,0,'','','','','','Y','Y','Y',4,36,'2018-08-05 15:26:27',36,'2018-08-05 21:26:27','PTO-Personal Time Off','Policy','Y',18),(5,'NEWLEAVE','','','','','leavw','','',0,0,'','','','','','Y','Y','Y',0,36,'2018-08-05 15:26:27',36,'2018-08-05 21:26:27','PTO-Personal Time Off','Leave','Y',18),(6,'PALIAS2','','','','','2018','','',0,0,'','','','','','N','N','N',6,35,'2018-08-05 15:40:04',35,'2018-08-05 21:40:04','RES-Resource Specific Alias','','',18),(7,'PALIAS','','','','','PALIAS','','',0,0,'','','','','','N','Y','Y',4,37,'2018-08-08 22:49:27',37,'2018-08-09 04:49:35','RES-Resource Specific Alias','','',18),(8,'GLEAVE','','','','','GLOBAL LEAVE','','',0,0,'','','','','','N','Y','N',0,39,'2018-08-14 10:15:10',39,'2018-08-14 17:11:23','PTO-Personal Time Off','Leave','Y',21),(9,'WO-141340','','','','','DGS000000141340','','',0,0,'','','','','','N','Y','Y',8,39,'2018-08-14 11:01:07',39,'2018-08-14 17:11:09','RES-Resource Specific Alias','Policy','Y',21),(10,'MYALIAS','','','','','MY ALIAS','','',0,0,'','','','','','N','Y','Y',11,40,'2018-08-14 17:07:06',40,'2018-08-14 23:07:06','RES-Resource Specific Alias','','',21),(11,'WO-999999','','','','','99 WO','','',0,0,'','','','','','Y','Y','Y',11,39,'2018-08-15 10:20:35',39,'2018-08-16 16:47:21','RES-Resource Specific Alias','Policy','Y',21),(12,'WOALIAS','','','','','WOALIAS','','',0,0,'','','','','','Y','Y','Y',11,42,'2018-08-15 17:09:48',42,'2018-08-15 23:09:48','RES-Resource Specific Alias','','',21),(13,'RESOURCEALIAS1','','','','','resource description','','',0,0,'','','','','','Y','Y','Y',12,34,'2018-08-18 01:32:23',34,'2018-08-31 15:27:57','RES-Resource Specific Alias','','',19),(14,'GLOBALALIAS1','','','','','g description','','',0,0,'','','','','','Y','Y','Y',7,34,'2018-08-18 01:35:08',34,'2018-08-18 07:37:28','ITO-Informal Time Off','Policy','Y',19),(15,'ACTTIVEFLAG','','','','','DF','','',0,0,'','','','','','N','N','N',0,39,'2018-08-20 14:24:48',39,'2018-08-20 20:24:48','PTO-Personal Time Off','Leave','',21),(16,'EASTEND','','','','','EASTEND SERVICES','','',0,0,'','','','','','N','Y','Y',14,39,'2018-09-17 22:51:30',39,'2018-09-18 04:57:13','RES-Resource Specific Alias','Policy','Y',21),(17,'CAPITOL','','','','','CAPITOL BUILDING PROJECT','','',0,0,'','','','','','N','Y','Y',15,39,'2018-09-17 22:52:40',39,'2018-09-18 04:57:13','RES-Resource Specific Alias','Policy','Y',21);
/*!40000 ALTER TABLE `cxs_aliases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_am_app_admin`
--

DROP TABLE IF EXISTS `cxs_am_app_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_am_app_admin` (
  `APP_ADM_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `APPLICATION_ID` bigint(20) NOT NULL,
  `START_DATE_ACTIVE` date DEFAULT NULL,
  `END_DATE_ACTIVE` date DEFAULT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`APP_ADM_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `APPLICATION_ID` (`APPLICATION_ID`),
  KEY `START_DATE_ACTIVE` (`START_DATE_ACTIVE`),
  KEY `END_DATE_ACTIVE` (`END_DATE_ACTIVE`),
  KEY `ROWNO` (`ROWNO`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_am_app_admin`
--

LOCK TABLES `cxs_am_app_admin` WRITE;
/*!40000 ALTER TABLE `cxs_am_app_admin` DISABLE KEYS */;
INSERT INTO `cxs_am_app_admin` (`APP_ADM_ID`, `USER_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `APPLICATION_ID`, `START_DATE_ACTIVE`, `END_DATE_ACTIVE`, `ROWNO`, `RESOURCE_GROUP_ID`, `SITE_ID`) VALUES (36,34,0,'2018-08-03 23:14:06',34,'2018-08-04 05:14:06',2,'2018-08-03',NULL,0,0,19),(35,34,0,'2018-08-03 23:14:06',34,'2018-08-04 05:14:06',1,'2018-08-03',NULL,0,0,19),(37,35,0,'2018-08-05 10:41:33',35,'2018-08-05 16:41:33',1,'2018-08-05',NULL,0,0,18),(38,35,0,'2018-08-05 10:41:33',35,'2018-08-05 16:41:33',2,'2018-08-05',NULL,0,0,18),(39,37,35,'2018-08-07 23:15:44',35,'2018-08-08 05:15:44',2,'2018-08-01','0000-00-00',0,0,0),(40,37,35,'2018-08-07 23:17:42',35,'2018-08-08 05:17:42',1,'2018-08-01','0000-00-00',0,0,0),(41,39,0,'2018-08-14 09:57:15',39,'2018-08-14 15:57:15',1,'2018-08-14',NULL,0,0,21),(42,39,0,'2018-08-14 09:57:15',39,'2018-08-14 15:57:15',2,'2018-08-14',NULL,0,0,21),(43,40,39,'2018-08-14 16:56:27',39,'2018-08-14 22:56:27',2,'0000-00-00','0000-00-00',0,0,0),(44,41,39,'2018-08-14 16:56:39',39,'2018-08-14 22:56:39',2,'0000-00-00','0000-00-00',0,0,0),(45,42,39,'2018-08-15 15:33:08',39,'2018-08-15 21:33:08',2,'2018-08-01','0000-00-00',0,0,0),(46,43,39,'2018-08-16 11:11:50',39,'2018-08-16 17:11:50',2,'2018-08-01','0000-00-00',0,0,0),(47,44,39,'2018-08-20 12:04:44',39,'2018-08-20 18:04:44',2,'0000-00-00','0000-00-00',0,0,0),(48,46,39,'2018-08-20 12:39:53',39,'2018-08-20 18:39:53',2,'0000-00-00','0000-00-00',0,0,0),(49,47,0,'2018-08-27 15:40:41',47,'2018-08-27 21:40:41',1,'2018-08-27',NULL,0,0,20),(50,47,0,'2018-08-27 15:40:41',47,'2018-08-27 21:40:41',2,'2018-08-27',NULL,0,0,20),(51,48,0,'2018-09-06 14:49:57',48,'2018-09-06 20:49:57',1,'2018-09-06',NULL,0,0,22),(52,48,0,'2018-09-06 14:49:57',48,'2018-09-06 20:49:57',2,'2018-09-06',NULL,0,0,22),(60,52,0,'2018-09-17 22:11:02',52,'2018-09-18 04:11:02',2,'2018-09-17',NULL,0,0,26),(59,52,0,'2018-09-17 22:11:02',52,'2018-09-18 04:11:02',1,'2018-09-17',NULL,0,0,26),(57,51,0,'2018-09-17 22:03:46',51,'2018-09-18 04:03:46',1,'2018-09-17',NULL,0,0,25),(58,51,0,'2018-09-17 22:03:46',51,'2018-09-18 04:03:46',2,'2018-09-17',NULL,0,0,25),(61,53,39,'2018-09-17 23:14:50',39,'2018-09-18 05:14:50',2,'0000-00-00','0000-00-00',0,0,0);
/*!40000 ALTER TABLE `cxs_am_app_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_am_approval_mgmt`
--

DROP TABLE IF EXISTS `cxs_am_approval_mgmt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_am_approval_mgmt` (
  `USER_ID` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `REFERENCE_APPROVER_ID` bigint(20) NOT NULL,
  `APPROVER_TYPE` varchar(40) NOT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `USER_ID` (`USER_ID`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `REFERENCE_APPROVER_ID` (`REFERENCE_APPROVER_ID`),
  KEY `APPROVER_TYPE` (`APPROVER_TYPE`),
  KEY `ROWNO` (`ROWNO`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_am_approval_mgmt`
--

LOCK TABLES `cxs_am_approval_mgmt` WRITE;
/*!40000 ALTER TABLE `cxs_am_approval_mgmt` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_am_approval_mgmt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_am_personal_alias`
--

DROP TABLE IF EXISTS `cxs_am_personal_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_am_personal_alias` (
  `USER_ID` bigint(20) DEFAULT NULL,
  `CREATED_BY` bigint(20) DEFAULT NULL,
  `CREATION_DATE` date DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(20) DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALIAS_ID` bigint(20) DEFAULT NULL,
  `ALIAS_NAME` varchar(40) DEFAULT NULL,
  `DESCRIPTION` varchar(240) DEFAULT NULL,
  `DEPARTMENT` varchar(40) DEFAULT NULL,
  `WBS_COMBINATION_ID` bigint(20) DEFAULT NULL,
  `ACTIVE_FLAG` varchar(1) DEFAULT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `USER_ID` (`USER_ID`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `ALIAS_NAME` (`ALIAS_NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `DEPARTMENT` (`DEPARTMENT`),
  KEY `WBS_COMBINATION_ID` (`WBS_COMBINATION_ID`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_am_personal_alias`
--

LOCK TABLES `cxs_am_personal_alias` WRITE;
/*!40000 ALTER TABLE `cxs_am_personal_alias` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_am_personal_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_am_roles`
--

DROP TABLE IF EXISTS `cxs_am_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_am_roles` (
  `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(40) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `CREATED_BY` int(11) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` int(11) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATE_NEW_USER` varchar(1) NOT NULL,
  `VIEW_ONLY` varchar(1) NOT NULL,
  `UPDATE_ONLY` varchar(1) NOT NULL,
  `VIEW_SUBSCRIBERS` varchar(1) NOT NULL,
  `SUBMIT_CUSTOM` varchar(1) NOT NULL,
  `ALLOW_CHAT` varchar(1) NOT NULL,
  `VIEW_SLA` varchar(1) NOT NULL,
  `EXISTING_USER` varchar(1) NOT NULL,
  `REMOVE_ACCESS` varchar(1) NOT NULL,
  `USAGE_HISTORY` varchar(1) NOT NULL,
  `TEMPORARY_APPROVER_ID` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_SITE_CONTACTS` varchar(1) NOT NULL,
  `OVERRIDE_INUSE` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ROLE_ID`),
  KEY `ROLE_NAME` (`ROLE_NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `CREATE_NEW_USER` (`CREATE_NEW_USER`),
  KEY `VIEW_ONLY` (`VIEW_ONLY`),
  KEY `UPDATE_ONLY` (`UPDATE_ONLY`),
  KEY `VIEW_SUBSCRIBERS` (`VIEW_SUBSCRIBERS`),
  KEY `SUBMIT_CUSTOM` (`SUBMIT_CUSTOM`),
  KEY `ALLOW_CHAT` (`ALLOW_CHAT`),
  KEY `OVERRIDE_INUSE` (`OVERRIDE_INUSE`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_am_roles`
--

LOCK TABLES `cxs_am_roles` WRITE;
/*!40000 ALTER TABLE `cxs_am_roles` DISABLE KEYS */;
INSERT INTO `cxs_am_roles` (`ROLE_ID`, `ROLE_NAME`, `DESCRIPTION`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `CREATE_NEW_USER`, `VIEW_ONLY`, `UPDATE_ONLY`, `VIEW_SUBSCRIBERS`, `SUBMIT_CUSTOM`, `ALLOW_CHAT`, `VIEW_SLA`, `EXISTING_USER`, `REMOVE_ACCESS`, `USAGE_HISTORY`, `TEMPORARY_APPROVER_ID`, `SITE_ID`, `UPDATE_SITE_CONTACTS`, `OVERRIDE_INUSE`) VALUES (1,'TEST ROLE','TEOST ROLLE 2',35,'2018-08-05 13:01:00',35,'2018-08-10 04:09:40','Y','Y','Y','N','N','','N','Y','N','N',0,18,'N','Y'),(2,'aa','AAA',34,'2018-08-06 04:32:08',34,'2018-08-06 10:32:24','N','Y','Y','N','Y','','N','N','N','N',0,19,'N','N'),(3,'role 1234','ROLE DESCRIPTION',34,'2018-08-06 04:36:08',34,'2018-08-06 10:36:15','N','Y','Y','N','N','','N','Y','N','N',0,19,'N','N'),(4,'MAINROLE','MAIN ROLE',39,'2018-08-14 16:34:34',39,'2018-08-16 23:15:42','N','Y','Y','N','Y','','Y','N','N','Y',0,21,'Y','Y');
/*!40000 ALTER TABLE `cxs_am_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_am_ta_rules`
--

DROP TABLE IF EXISTS `cxs_am_ta_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_am_ta_rules` (
  `USER_ID` bigint(11) NOT NULL DEFAULT '0',
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `BIZ_MSG_FLAG` varchar(1) NOT NULL,
  `AUDIT_FLAG` varchar(1) NOT NULL,
  `ALLOW_NEGATIVE` varchar(1) NOT NULL,
  `ADVANCE_FOR_OVERTIME` varchar(1) NOT NULL,
  `UPDATE_SUBMITTED` varchar(1) NOT NULL,
  `OVERRIDE_PRIMARY` varchar(1) NOT NULL,
  `RECENT_TIMECARDS` double NOT NULL,
  `RETRO_ADJUST` varchar(1) NOT NULL,
  `MAX_DAILY_LIMIT` double NOT NULL,
  `AFT_ENTRY` varchar(1) NOT NULL,
  `RETRO_PERIOD_NUM` double NOT NULL,
  `ALLOW_COPY` varchar(1) NOT NULL,
  `COPY_ANYONE_TS_FLAG` varchar(1) NOT NULL,
  `APPROVE_ANYONE_TS` varchar(1) NOT NULL,
  `CREATE_ANYONE_TS` varchar(1) NOT NULL,
  `APPROVE_ANYONE_TS_TEAM` varchar(1) NOT NULL,
  `ALLOW_SUP_TS` varchar(1) NOT NULL,
  `ALLOW_PREAPPROVAL` varchar(1) NOT NULL,
  `CREATED_BY` bigint(11) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(11) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ALLOW_OVERRIDE_WORKSHIFT` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `USER_ID` (`USER_ID`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `BIZ_MSG_FLAG` (`BIZ_MSG_FLAG`),
  KEY `AUDIT_FLAG` (`AUDIT_FLAG`),
  KEY `ALLOW_NEGATIVE` (`ALLOW_NEGATIVE`),
  KEY `ADVANCE_FOR_OVERTIME` (`ADVANCE_FOR_OVERTIME`),
  KEY `UPDATE_SUBMITTED` (`UPDATE_SUBMITTED`),
  KEY `OVERRIDE_PRIMARY` (`OVERRIDE_PRIMARY`),
  KEY `RECENT_TIMECARDS` (`RECENT_TIMECARDS`),
  KEY `RETRO_ADJUST` (`RETRO_ADJUST`),
  KEY `MAX_DAILY_LIMIT` (`MAX_DAILY_LIMIT`),
  KEY `AFT_ENTRY` (`AFT_ENTRY`),
  KEY `RETRO_PERIOD_NUM` (`RETRO_PERIOD_NUM`),
  KEY `ALLOW_COPY` (`ALLOW_COPY`),
  KEY `COPY_ANYONE_TS_FLAG` (`COPY_ANYONE_TS_FLAG`),
  KEY `APPROVE_ANYONE_TS` (`APPROVE_ANYONE_TS`),
  KEY `CREATE_ANYONE_TS` (`CREATE_ANYONE_TS`),
  KEY `APPROVE_ANYONE_TS_TEAM` (`APPROVE_ANYONE_TS_TEAM`),
  KEY `ALLOW_SUP_TS` (`ALLOW_SUP_TS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_am_ta_rules`
--

LOCK TABLES `cxs_am_ta_rules` WRITE;
/*!40000 ALTER TABLE `cxs_am_ta_rules` DISABLE KEYS */;
INSERT INTO `cxs_am_ta_rules` (`USER_ID`, `RESOURCE_GROUP_ID`, `BIZ_MSG_FLAG`, `AUDIT_FLAG`, `ALLOW_NEGATIVE`, `ADVANCE_FOR_OVERTIME`, `UPDATE_SUBMITTED`, `OVERRIDE_PRIMARY`, `RECENT_TIMECARDS`, `RETRO_ADJUST`, `MAX_DAILY_LIMIT`, `AFT_ENTRY`, `RETRO_PERIOD_NUM`, `ALLOW_COPY`, `COPY_ANYONE_TS_FLAG`, `APPROVE_ANYONE_TS`, `CREATE_ANYONE_TS`, `APPROVE_ANYONE_TS_TEAM`, `ALLOW_SUP_TS`, `ALLOW_PREAPPROVAL`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ALLOW_OVERRIDE_WORKSHIFT`, `SITE_ID`) VALUES (7,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',15,'2018-07-23 00:00:00',15,'2018-07-23 21:21:26','N',0),(15,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21','N',14),(35,0,'','','','','','',0,'Y',0,'',3,'','N','N','N','N','N','N',35,'2018-08-05 13:08:15',35,'2018-08-05 21:14:16','N',18),(36,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',35,'2018-08-05 15:25:54',35,'2018-08-05 21:25:54','N',18),(42,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',39,'2018-08-16 15:12:05',39,'2018-08-16 21:12:05','N',21),(44,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',39,'2018-08-17 10:39:40',39,'2018-08-17 16:39:40','N',21),(54,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',39,'2018-09-17 23:13:36',39,'2018-09-18 05:13:36','N',21),(55,0,'','','','','','',0,'N',0,'',0,'','N','N','N','N','N','N',39,'2018-09-17 23:14:13',39,'2018-09-18 05:14:13','N',21);
/*!40000 ALTER TABLE `cxs_am_ta_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_application_assignments`
--

DROP TABLE IF EXISTS `cxs_application_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_application_assignments` (
  `ASSIGNMENT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `APPLICATION_ROLE_ID` bigint(20) NOT NULL,
  `ROLE_START_DATE` date DEFAULT NULL,
  `ROLE_END_DATE` date DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ASSIGNMENT_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `CXS_APPLICATION_ASSIGNMENTS_U1` (`ASSIGNMENT_ID`),
  KEY `APPLICATION_ROLE_ID` (`APPLICATION_ROLE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `ROLE_START_DATE` (`ROLE_START_DATE`),
  KEY `ROLE_END_DATE` (`ROLE_END_DATE`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_application_assignments`
--

LOCK TABLES `cxs_application_assignments` WRITE;
/*!40000 ALTER TABLE `cxs_application_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_application_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_application_roles`
--

DROP TABLE IF EXISTS `cxs_application_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_application_roles` (
  `APPLICATION_ROLE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(40) DEFAULT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`APPLICATION_ROLE_ID`),
  KEY `ROLE_NAME` (`ROLE_NAME`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_application_roles`
--

LOCK TABLES `cxs_application_roles` WRITE;
/*!40000 ALTER TABLE `cxs_application_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_application_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_calendars`
--

DROP TABLE IF EXISTS `cxs_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_calendars` (
  `CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `DESCR` varchar(240) NOT NULL DEFAULT '',
  `PERIOD_YEAR` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_TYPE` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FLAG_SYSTEMCREATED` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CALENDAR_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `NAME` (`NAME`),
  KEY `DESCR` (`DESCR`),
  KEY `PERIOD_YEAR` (`PERIOD_YEAR`),
  KEY `PERIOD_TYPE` (`PERIOD_TYPE`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_calendars`
--

LOCK TABLES `cxs_calendars` WRITE;
/*!40000 ALTER TABLE `cxs_calendars` DISABLE KEYS */;
INSERT INTO `cxs_calendars` (`CALENDAR_ID`, `NAME`, `DESCR`, `PERIOD_YEAR`, `PERIOD_TYPE`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `FLAG_SYSTEMCREATED`, `SITE_ID`) VALUES (1,'2018FY-2018-2019','2018','2018-2019','Monthly',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',18),(2,'aa-2018-2019','','2018-2019','Monthly',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',19),(3,'2018 Monthly-2018-2019','','2018-2019','Monthly',40,'2018-08-14 17:03:14',44,'2018-09-03 04:46:32','N',21);
/*!40000 ALTER TABLE `cxs_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_common_words`
--

DROP TABLE IF EXISTS `cxs_common_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_common_words` (
  `COMMON_WORD_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `WORD_NAME` varchar(240) DEFAULT '',
  `ACTIVE_FLAG` varchar(1) DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`COMMON_WORD_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `WORD_NAME` (`WORD_NAME`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_common_words`
--

LOCK TABLES `cxs_common_words` WRITE;
/*!40000 ALTER TABLE `cxs_common_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_common_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_daily_audit`
--

DROP TABLE IF EXISTS `cxs_daily_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_daily_audit` (
  `AUDIT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `EMPLOYEE_NUMBER` varchar(40) NOT NULL DEFAULT '',
  `EMPLOYEE_NAME` varchar(40) NOT NULL DEFAULT '',
  `CREATEDBY_EMPNO` bigint(20) NOT NULL DEFAULT '0',
  `UPDATEDBY_EMPNO` bigint(20) NOT NULL DEFAULT '0',
  `CREATEDBY_ENAME` varchar(40) NOT NULL DEFAULT '',
  `UPDATEDBY_ENAME` varchar(40) NOT NULL DEFAULT '',
  `EI_NORM_ID` bigint(20) NOT NULL,
  `EI_DNORM_ID` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `EXPENDITURE_QTY` double NOT NULL,
  `STATUS_FLAG` varchar(40) NOT NULL DEFAULT '',
  `EXPENDITURE_DATE` date NOT NULL,
  `LAST_UPDATE` datetime DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`AUDIT_ID`),
  KEY `EMPLOYEE_NUMBER` (`EMPLOYEE_NUMBER`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_daily_audit`
--

LOCK TABLES `cxs_daily_audit` WRITE;
/*!40000 ALTER TABLE `cxs_daily_audit` DISABLE KEYS */;
INSERT INTO `cxs_daily_audit` (`AUDIT_ID`, `EMPLOYEE_NUMBER`, `EMPLOYEE_NAME`, `CREATEDBY_EMPNO`, `UPDATEDBY_EMPNO`, `CREATEDBY_ENAME`, `UPDATEDBY_ENAME`, `EI_NORM_ID`, `EI_DNORM_ID`, `CREATION_DATE`, `EXPENDITURE_QTY`, `STATUS_FLAG`, `EXPENDITURE_DATE`, `LAST_UPDATE`, `SITE_ID`, `ROW_NO`) VALUES (1,'10','Applisoft Technologies',10,10,'','',11,32,'2018-08-18 01:41:11',0,'SAVED','2018-08-13','2018-08-18 01:41:11',19,1),(2,'10','Applisoft Technologies',10,10,'','',11,33,'2018-08-18 01:41:11',0,'SAVED','2018-08-14','2018-08-18 01:41:11',19,1),(3,'10','Applisoft Technologies',10,10,'','',11,34,'2018-08-18 01:41:11',0,'SAVED','2018-08-15','2018-08-18 01:41:11',19,1),(4,'10','Applisoft Technologies',10,10,'','',11,32,'2018-08-18 01:41:11',2,'SAVED','2018-08-13','2018-08-18 01:43:57',19,1),(5,'10','Applisoft Technologies',10,10,'','',11,33,'2018-08-18 01:41:11',3,'SAVED','2018-08-14','2018-08-18 01:43:57',19,1),(6,'10','Applisoft Technologies',10,10,'','',11,34,'2018-08-18 01:41:11',4,'SAVED','2018-08-15','2018-08-18 01:43:57',19,1),(7,'9','ALDE BOB',9,9,'','',6,41,'2018-08-24 11:39:00',8,'SAVED','2018-08-22','2018-08-24 11:39:06',21,1),(8,'9','ALDE BOB',9,9,'','',6,42,'2018-08-24 11:39:00',8,'SAVED','2018-08-23','2018-08-24 11:39:06',21,2),(9,'9','ALDE BOB',9,9,'','',6,37,'2018-08-24 11:39:00',8,'PreApproved','2018-08-20','2018-08-24 11:39:09',21,3),(10,'9','ALDE BOB',9,9,'','',6,38,'2018-08-24 11:39:00',8,'PreApproved','2018-08-20','2018-08-24 11:39:09',21,4),(11,'9','ALDE BOB',9,9,'','',6,39,'2018-08-24 11:39:00',8,'PreApproved','2018-08-21','2018-08-24 11:39:09',21,3),(12,'9','ALDE BOB',9,9,'','',6,40,'2018-08-24 11:39:00',8,'PreApproved','2018-08-21','2018-08-24 11:39:09',21,4),(13,'9','ALDE BOB',9,9,'','',6,41,'2018-08-24 11:39:00',8,'PreApproved','2018-08-22','2018-08-24 11:39:09',21,1),(14,'9','ALDE BOB',9,9,'','',6,42,'2018-08-24 11:39:00',8,'PreApproved','2018-08-23','2018-08-24 11:39:09',21,2),(15,'10','Applisoft Technologies',10,10,'','',11,35,'2018-08-21 23:43:47',1,'SAVED','2018-08-20','2018-08-27 11:28:57',19,1),(16,'10','Applisoft Technologies',10,10,'','',11,43,'2018-08-27 11:29:26',0,'SAVED','2018-08-20','2018-08-27 11:29:26',19,2),(17,'10','Applisoft Technologies',10,10,'','',11,44,'2018-08-27 11:29:26',0,'SAVED','2018-08-21','2018-08-27 11:29:26',19,2),(18,'9','ALDE BOB',9,9,'','',6,47,'2018-08-27 12:14:23',8,'SUBMITTED','2018-08-27','2018-08-27 12:14:27',21,1),(19,'9','ALDE BOB',9,9,'','',6,48,'2018-08-27 12:14:23',8,'SUBMITTED','2018-08-28','2018-08-27 12:14:27',21,1),(20,'10','Applisoft Technologies',10,10,'','',11,50,'2018-08-31 04:09:43',0,'SAVED','2018-08-27','2018-08-31 04:09:43',19,2),(21,'10','Applisoft Technologies',10,10,'','',11,51,'2018-08-31 04:09:43',0,'SAVED','2018-08-28','2018-08-31 04:09:43',19,2),(29,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',4,'SAVED','2018-09-03','2018-09-06 16:29:14',19,3),(28,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,62,'2018-09-03 06:54:59',10,'SAVED','2018-09-05','2018-09-04 22:08:41',19,2),(27,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,61,'2018-09-03 06:54:59',10,'SAVED','2018-09-04','2018-09-04 22:08:41',19,1),(26,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',3,'SAVED','2018-09-03','2018-09-04 22:08:41',19,3),(30,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,61,'2018-09-03 06:54:59',10,'SAVED','2018-09-04','2018-09-06 16:29:14',19,1),(31,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,62,'2018-09-03 06:54:59',10,'SAVED','2018-09-05','2018-09-06 16:29:14',19,2),(32,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',5,'SAVED','2018-09-03','2018-09-06 16:29:34',19,3),(33,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',6,'SAVED','2018-09-03','2018-09-06 16:29:45',19,3),(34,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',7,'SAVED','2018-09-03','2018-09-06 16:30:02',19,3),(35,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',8,'SAVED','2018-09-03','2018-09-06 16:30:24',19,3),(36,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',9,'SAVED','2018-09-03','2018-09-06 16:30:30',19,3),(37,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',10,'SAVED','2018-09-03','2018-09-06 16:30:37',19,3),(38,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',11,'SAVED','2018-09-03','2018-09-06 16:30:42',19,3),(39,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',12,'SAVED','2018-09-03','2018-09-06 16:30:48',19,3),(40,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',13,'SAVED','2018-09-03','2018-09-06 16:30:54',19,3),(41,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',14,'SAVED','2018-09-03','2018-09-06 16:31:02',19,3),(42,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,60,'2018-09-03 06:54:59',15,'SUBMITTED','2018-09-03','2018-09-06 16:31:54',19,3),(43,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,61,'2018-09-03 06:54:59',10,'SAVED','2018-09-04','2018-09-06 16:44:24',19,1),(44,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,62,'2018-09-03 06:54:59',10,'SAVED','2018-09-05','2018-09-06 16:44:24',19,2),(45,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,63,'2018-09-06 16:44:24',0,'SAVED','2018-09-06','2018-09-06 16:44:24',19,4),(46,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,64,'2018-09-07 12:14:56',0,'SAVED','2018-09-03','2018-09-07 12:14:56',19,4),(47,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,61,'2018-09-03 06:54:59',10,'SAVED','2018-09-04','2018-09-07 12:14:56',19,1),(48,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,65,'2018-09-07 12:14:56',0,'SAVED','2018-09-04','2018-09-07 12:14:56',19,4),(49,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,62,'2018-09-03 06:54:59',10,'SAVED','2018-09-05','2018-09-07 12:14:56',19,2),(50,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,64,'2018-09-07 12:14:56',2,'SAVED','2018-09-03','2018-09-07 12:15:56',19,4),(51,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,61,'2018-09-03 06:54:59',10,'SAVED','2018-09-04','2018-09-07 12:17:25',19,1),(52,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,62,'2018-09-03 06:54:59',10,'SAVED','2018-09-05','2018-09-07 12:17:25',19,2),(53,'10','Applisoft Technologies',10,10,'Applisoft Technologies','Applisoft Technologies',11,66,'2018-09-07 12:17:25',0,'SAVED','2018-09-05','2018-09-07 12:17:25',19,4),(54,'15','BOB TABAKA',15,15,'BOB TABAKA','BOB TABAKA',13,67,'2018-09-17 23:21:19',7,'SAVED','2018-09-17','2018-09-17 23:21:19',21,1),(55,'15','BOB TABAKA',15,15,'BOB TABAKA','BOB TABAKA',13,68,'2018-09-17 23:21:19',1,'SAVED','2018-09-17','2018-09-17 23:21:19',21,2),(56,'15','BOB TABAKA',15,15,'BOB TABAKA','BOB TABAKA',13,67,'2018-09-17 23:21:19',7,'SUBMITTED','2018-09-17','2018-09-17 23:21:35',21,1),(57,'15','BOB TABAKA',15,15,'BOB TABAKA','BOB TABAKA',13,68,'2018-09-17 23:21:19',1,'SUBMITTED','2018-09-17','2018-09-17 23:21:35',21,2);
/*!40000 ALTER TABLE `cxs_daily_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_flex_schedule`
--

DROP TABLE IF EXISTS `cxs_flex_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_flex_schedule` (
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `SCHEDULE_TYPE` varchar(40) NOT NULL DEFAULT '',
  `SCHEDULE_START_DATE` date DEFAULT NULL,
  `SCHEDULE_END_DATE` date DEFAULT NULL,
  `DAYS_IN_MONTH1` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH2` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH3` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH4` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH5` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH6` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH7` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH8` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH9` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH10` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH11` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH12` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH13` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH14` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH15` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH16` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH17` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH18` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH19` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH20` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH21` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH22` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH23` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH24` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH25` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH26` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH27` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH28` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH29` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH30` varchar(1) NOT NULL DEFAULT '',
  `DAYS_IN_MONTH31` varchar(1) NOT NULL DEFAULT '',
  `SUNDAY` varchar(1) NOT NULL DEFAULT '',
  `MONDAY` varchar(1) NOT NULL DEFAULT '',
  `TUESDAY` varchar(1) NOT NULL DEFAULT '',
  `WEDNESDAY` varchar(1) NOT NULL DEFAULT '',
  `THURSDAY` varchar(1) NOT NULL DEFAULT '',
  `FRIDAY` varchar(1) NOT NULL DEFAULT '',
  `SATURDAY` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATED` (`LAST_UPDATED`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `SCHEDULE_TYPE` (`SCHEDULE_TYPE`),
  KEY `SCHEDULE_START_DATE` (`SCHEDULE_START_DATE`),
  KEY `SCHEDULE_END_DATE` (`SCHEDULE_END_DATE`),
  KEY `DAYS_IN_MONTH1` (`DAYS_IN_MONTH1`),
  KEY `DAYS_IN_MONTH2` (`DAYS_IN_MONTH2`),
  KEY `DAYS_IN_MONTH3` (`DAYS_IN_MONTH3`),
  KEY `DAYS_IN_MONTH4` (`DAYS_IN_MONTH4`),
  KEY `DAYS_IN_MONTH5` (`DAYS_IN_MONTH5`),
  KEY `DAYS_IN_MONTH6` (`DAYS_IN_MONTH6`),
  KEY `DAYS_IN_MONTH7` (`DAYS_IN_MONTH7`),
  KEY `DAYS_IN_MONTH8` (`DAYS_IN_MONTH8`),
  KEY `DAYS_IN_MONTH9` (`DAYS_IN_MONTH9`),
  KEY `DAYS_IN_MONTH10` (`DAYS_IN_MONTH10`),
  KEY `DAYS_IN_MONTH11` (`DAYS_IN_MONTH11`),
  KEY `DAYS_IN_MONTH12` (`DAYS_IN_MONTH12`),
  KEY `DAYS_IN_MONTH13` (`DAYS_IN_MONTH13`),
  KEY `DAYS_IN_MONTH14` (`DAYS_IN_MONTH14`),
  KEY `DAYS_IN_MONTH15` (`DAYS_IN_MONTH15`),
  KEY `DAYS_IN_MONTH16` (`DAYS_IN_MONTH16`),
  KEY `DAYS_IN_MONTH17` (`DAYS_IN_MONTH17`),
  KEY `DAYS_IN_MONTH18` (`DAYS_IN_MONTH18`),
  KEY `DAYS_IN_MONTH19` (`DAYS_IN_MONTH19`),
  KEY `DAYS_IN_MONTH20` (`DAYS_IN_MONTH20`),
  KEY `DAYS_IN_MONTH21` (`DAYS_IN_MONTH21`),
  KEY `DAYS_IN_MONTH22` (`DAYS_IN_MONTH22`),
  KEY `DAYS_IN_MONTH23` (`DAYS_IN_MONTH23`),
  KEY `DAYS_IN_MONTH24` (`DAYS_IN_MONTH24`),
  KEY `DAYS_IN_MONTH25` (`DAYS_IN_MONTH25`),
  KEY `DAYS_IN_MONTH26` (`DAYS_IN_MONTH26`),
  KEY `DAYS_IN_MONTH27` (`DAYS_IN_MONTH27`),
  KEY `DAYS_IN_MONTH28` (`DAYS_IN_MONTH28`),
  KEY `DAYS_IN_MONTH29` (`DAYS_IN_MONTH29`),
  KEY `DAYS_IN_MONTH30` (`DAYS_IN_MONTH30`),
  KEY `DAYS_IN_MONTH31` (`DAYS_IN_MONTH31`),
  KEY `SUNDAY` (`SUNDAY`),
  KEY `MONDAY` (`MONDAY`),
  KEY `TUESDAY` (`TUESDAY`),
  KEY `WEDNESDAY` (`WEDNESDAY`),
  KEY `THURSDAY` (`THURSDAY`),
  KEY `FRIDAY` (`FRIDAY`),
  KEY `SATURDAY` (`SATURDAY`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_flex_schedule`
--

LOCK TABLES `cxs_flex_schedule` WRITE;
/*!40000 ALTER TABLE `cxs_flex_schedule` DISABLE KEYS */;
INSERT INTO `cxs_flex_schedule` (`WORKSHIFT_ID`, `SCHEDULE_TYPE`, `SCHEDULE_START_DATE`, `SCHEDULE_END_DATE`, `DAYS_IN_MONTH1`, `DAYS_IN_MONTH2`, `DAYS_IN_MONTH3`, `DAYS_IN_MONTH4`, `DAYS_IN_MONTH5`, `DAYS_IN_MONTH6`, `DAYS_IN_MONTH7`, `DAYS_IN_MONTH8`, `DAYS_IN_MONTH9`, `DAYS_IN_MONTH10`, `DAYS_IN_MONTH11`, `DAYS_IN_MONTH12`, `DAYS_IN_MONTH13`, `DAYS_IN_MONTH14`, `DAYS_IN_MONTH15`, `DAYS_IN_MONTH16`, `DAYS_IN_MONTH17`, `DAYS_IN_MONTH18`, `DAYS_IN_MONTH19`, `DAYS_IN_MONTH20`, `DAYS_IN_MONTH21`, `DAYS_IN_MONTH22`, `DAYS_IN_MONTH23`, `DAYS_IN_MONTH24`, `DAYS_IN_MONTH25`, `DAYS_IN_MONTH26`, `DAYS_IN_MONTH27`, `DAYS_IN_MONTH28`, `DAYS_IN_MONTH29`, `DAYS_IN_MONTH30`, `DAYS_IN_MONTH31`, `SUNDAY`, `MONDAY`, `TUESDAY`, `WEDNESDAY`, `THURSDAY`, `FRIDAY`, `SATURDAY`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATED`, `SITE_ID`) VALUES (1,'DAYS_IN_MONTH',NULL,NULL,'','X','','','','','','','','','','','','','','','','','','','','','','','X','X','','','','','','','','','','','','',7,'2018-07-17 05:31:40',7,'2018-07-17 11:31:40',0);
/*!40000 ALTER TABLE `cxs_flex_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_holiday_calendar`
--

DROP TABLE IF EXISTS `cxs_holiday_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_holiday_calendar` (
  `CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `HOLIDAY_CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `HOLIDAY_TAG_NAME` varchar(40) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `HOLIDAY_START_DATE` date DEFAULT NULL,
  `HOLIDAY_END_DATE` date DEFAULT NULL,
  `INUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ENFORCE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `RECESS_ALLOWED` varchar(1) NOT NULL DEFAULT '',
  `ENABLED_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CALENDAR_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `HOLIDAY_CALENDAR_ID` (`HOLIDAY_CALENDAR_ID`),
  KEY `HOLIDAY_TAG_NAME` (`HOLIDAY_TAG_NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `HOLIDAY_START_DATE` (`HOLIDAY_START_DATE`),
  KEY `HOLIDAY_END_DATE` (`HOLIDAY_END_DATE`),
  KEY `INUSE_FLAG` (`INUSE_FLAG`),
  KEY `ENFORCE_FLAG` (`ENFORCE_FLAG`),
  KEY `RECESS_ALLOWED` (`RECESS_ALLOWED`),
  KEY `ENABLED_FLAG` (`ENABLED_FLAG`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_holiday_calendar`
--

LOCK TABLES `cxs_holiday_calendar` WRITE;
/*!40000 ALTER TABLE `cxs_holiday_calendar` DISABLE KEYS */;
INSERT INTO `cxs_holiday_calendar` (`CALENDAR_ID`, `HOLIDAY_CALENDAR_ID`, `HOLIDAY_TAG_NAME`, `DESCRIPTION`, `HOLIDAY_START_DATE`, `HOLIDAY_END_DATE`, `INUSE_FLAG`, `ENFORCE_FLAG`, `RECESS_ALLOWED`, `ENABLED_FLAG`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,1,'August6 Holiday','Aug 6 Holiday','2018-08-06','2018-08-06','','Y','N','Y','',35,'2018-08-05 10:47:46',35,'2018-08-05 16:47:46',18),(2,2,'15TH AUGUST ','','2018-08-15','2018-08-15','','Y','N','Y','',40,'2018-08-14 17:05:46',40,'2018-08-14 23:05:46',21),(3,2,'22TH AUGUAST','','2018-08-22','2018-08-22','','Y','N','Y','',39,'2018-08-20 11:35:38',39,'2018-08-20 17:35:38',21),(4,2,'23RD AUGUST','','2018-08-23','2018-08-23','','N','N','Y','',44,'2018-08-20 12:09:46',44,'2018-08-20 18:09:46',21),(5,3,'d','dd','2018-09-04','2018-09-05','','N','N','Y','',34,'2018-09-02 18:42:47',34,'2018-09-03 00:42:47',19);
/*!40000 ALTER TABLE `cxs_holiday_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_holidays`
--

DROP TABLE IF EXISTS `cxs_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_holidays` (
  `HOLIDAY_CALENDAR_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CALENDAR_NAME` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_YEAR` varchar(10) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`HOLIDAY_CALENDAR_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `CALENDAR_NAME` (`CALENDAR_NAME`),
  KEY `PERIOD_YEAR` (`PERIOD_YEAR`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_holidays`
--

LOCK TABLES `cxs_holidays` WRITE;
/*!40000 ALTER TABLE `cxs_holidays` DISABLE KEYS */;
INSERT INTO `cxs_holidays` (`HOLIDAY_CALENDAR_ID`, `CALENDAR_NAME`, `PERIOD_YEAR`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,'2018FY','2018-2019',35,'2018-08-05 10:47:46',35,'2018-08-05 16:47:46',18),(2,'2018 holidays','2018-2019',40,'2018-08-14 17:05:46',44,'2018-08-20 18:09:46',21),(3,'2018-19 hol','2018-2019',34,'2018-09-02 18:42:47',34,'2018-09-03 00:42:47',19);
/*!40000 ALTER TABLE `cxs_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_hours_deduction`
--

DROP TABLE IF EXISTS `cxs_hours_deduction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_hours_deduction` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALLOW_PAID_BREAK` varchar(1) NOT NULL DEFAULT '',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `REQUIRED_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `BREAK_HOURS` double NOT NULL DEFAULT '0',
  `BREAK_START_TIME` datetime DEFAULT NULL,
  `BREAK_END_TIME` datetime DEFAULT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `POLICY_ID` (`POLICY_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `ALLOW_PAID_BREAK` (`ALLOW_PAID_BREAK`),
  KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  KEY `REQUIRED_HOURS` (`REQUIRED_HOURS`),
  KEY `BREAK_HOURS` (`BREAK_HOURS`),
  KEY `BREAK_START_TIME` (`BREAK_START_TIME`),
  KEY `BREAK_END_TIME` (`BREAK_END_TIME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_hours_deduction`
--

LOCK TABLES `cxs_hours_deduction` WRITE;
/*!40000 ALTER TABLE `cxs_hours_deduction` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_hours_deduction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_page_list`
--

DROP TABLE IF EXISTS `cxs_page_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_page_list` (
  `PAGE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UI_VALUES` varchar(40) NOT NULL,
  `DB_VALUES` varchar(40) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PAGE_ID`),
  KEY `UI_VALUES` (`UI_VALUES`),
  KEY `DB_VALUES` (`DB_VALUES`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_page_list`
--

LOCK TABLES `cxs_page_list` WRITE;
/*!40000 ALTER TABLE `cxs_page_list` DISABLE KEYS */;
INSERT INTO `cxs_page_list` (`PAGE_ID`, `UI_VALUES`, `DB_VALUES`, `LAST_UPDATE_DATE`) VALUES (1,'Contact Support Page','CS','2018-07-31 11:12:48'),(2,'Login Issues','LI','2018-07-31 11:12:48'),(3,'Performance','PF','2018-07-31 11:12:48'),(4,'Access Management','AM','2018-07-31 11:12:48'),(5,'Global Alias','GA','2018-07-31 11:12:48'),(6,'Work Shift','WS','2018-07-31 11:12:48'),(7,'Employee Alias','EA','2018-07-31 11:12:48'),(8,'Resource Groups','RG','2018-07-31 11:12:48'),(9,'Resources','RS','2018-07-31 11:12:48'),(10,'Time Entry Page','TE','2018-07-31 11:12:48'),(11,'Dashboard','DB','2018-07-31 11:12:48'),(12,'Accounting Periods','AP','2018-07-31 11:12:48'),(13,'Holiday Calendar','HC','2018-07-31 11:12:48'),(14,'Time Policy','TP','2018-07-31 11:12:48'),(15,'Submit Customization Request','SC','2018-08-06 10:19:11');
/*!40000 ALTER TABLE `cxs_page_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_password_reuse`
--

DROP TABLE IF EXISTS `cxs_password_reuse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_password_reuse` (
  `USER_ID` int(11) NOT NULL,
  `LAST_UPDATE_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(15) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `CREATED_BY` bigint(15) NOT NULL,
  `XXT_PASSWORD` varchar(100) NOT NULL,
  `KOUNTER` int(11) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `XXT_PASSWORD` (`XXT_PASSWORD`),
  KEY `KOUNTER` (`KOUNTER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_password_reuse`
--

LOCK TABLES `cxs_password_reuse` WRITE;
/*!40000 ALTER TABLE `cxs_password_reuse` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_password_reuse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_period_audit`
--

DROP TABLE IF EXISTS `cxs_period_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_period_audit` (
  `SORT_DATE` datetime DEFAULT NULL,
  `EI_NORM_ID` bigint(20) NOT NULL DEFAULT '0',
  `EXP_STATUS` varchar(12) NOT NULL DEFAULT '',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `FULL_NAME` varchar(240) NOT NULL DEFAULT '',
  `EMPLOYEE_NUMBER` varchar(30) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(35) NOT NULL DEFAULT '',
  `USER_NAME` varchar(40) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_period_audit`
--

LOCK TABLES `cxs_period_audit` WRITE;
/*!40000 ALTER TABLE `cxs_period_audit` DISABLE KEYS */;
INSERT INTO `cxs_period_audit` (`SORT_DATE`, `EI_NORM_ID`, `EXP_STATUS`, `UPDATE_DATE`, `FULL_NAME`, `EMPLOYEE_NUMBER`, `PERIOD_NAME`, `USER_NAME`, `SITE_ID`) VALUES ('2018-08-18 01:41:11',5,'SAVED','2018-08-18 01:41:11','Applisoft Technologies','10','AUG-2018','APPLISOFT4U@GMAIL.COM',19),('2018-08-18 01:41:11',5,'SAVED','2018-08-18 01:43:57','Applisoft Technologies','10','AUG-2018','APPLISOFT4U@GMAIL.COM',19),('2018-08-24 11:39:00',6,'SAVED','2018-08-24 11:39:06','ALDE BOB','9','AUG-2018','BOB@AOL.COM',21),('2018-08-24 11:39:00',6,'PreApproved','2018-08-24 11:39:09','ALDE BOB','9','AUG-2018','BOB@AOL.COM',21),('2018-08-21 23:43:47',5,'SAVED','2018-08-27 11:28:57','Applisoft Technologies','10','AUG-2018','APPLISOFT4U@GMAIL.COM',19),('2018-08-27 11:29:26',5,'SAVED','2018-08-27 11:29:26','Applisoft Technologies','10','AUG-2018','APPLISOFT4U@GMAIL.COM',19),('2018-08-27 12:14:23',6,'SUBMITTED','2018-08-27 12:14:27','ALDE BOB','9','AUG-2018','BOB@AOL.COM',21),('2018-08-31 04:09:43',5,'SAVED','2018-08-31 04:09:43','Applisoft Technologies','10','AUG-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:39:06',7,'SAVED','2018-09-03 06:39:45','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:41:00',7,'SAVED','2018-09-03 06:41:00','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-04 22:08:41','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:29:14','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:29:34','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:29:45','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:02','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:24','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:30','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:37','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:42','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:48','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:30:54','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:31:02','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SUBMITTED','2018-09-06 16:31:54','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-06 16:44:24','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-07 12:14:56',7,'SAVED','2018-09-07 12:14:56','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-07 12:14:56',7,'SAVED','2018-09-07 12:15:56','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-03 06:54:59',7,'SAVED','2018-09-07 12:17:25','Applisoft Technologies','10','SEP-2018','APPLISOFT4U@GMAIL.COM',19),('2018-09-17 23:21:19',9,'SAVED','2018-09-17 23:21:19','BOB TABAKA','15','SEP-2018','BOB.TABAKA@DSS.CA.GOV',21),('2018-09-17 23:21:19',9,'SUBMITTED','2018-09-17 23:21:35','BOB TABAKA','15','SEP-2018','BOB.TABAKA@DSS.CA.GOV',21);
/*!40000 ALTER TABLE `cxs_period_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_periods`
--

DROP TABLE IF EXISTS `cxs_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_periods` (
  `PERIOD_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FROM_PERIOD_DATE` date NOT NULL,
  `TO_PERIOD_DATE` date NOT NULL,
  `PERIOD_YEAR` varchar(40) NOT NULL DEFAULT '',
  `PERIOD_NAME` varchar(50) NOT NULL DEFAULT '',
  `STATUS` varchar(50) NOT NULL DEFAULT 'N',
  `ENTITY_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `FLAG_INUSE` varchar(1) NOT NULL DEFAULT '',
  `CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PERIOD_ID`),
  KEY `ENTITY_ID` (`ENTITY_ID`),
  KEY `CALENDAR_ID` (`CALENDAR_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `FROM_PERIOD_DATE` (`FROM_PERIOD_DATE`),
  KEY `TO_PERIOD_DATE` (`TO_PERIOD_DATE`),
  KEY `PERIOD_YEAR` (`PERIOD_YEAR`),
  KEY `PERIOD_NAME` (`PERIOD_NAME`),
  KEY `STATUS` (`STATUS`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `FLAG_INUSE` (`FLAG_INUSE`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_periods`
--

LOCK TABLES `cxs_periods` WRITE;
/*!40000 ALTER TABLE `cxs_periods` DISABLE KEYS */;
INSERT INTO `cxs_periods` (`PERIOD_ID`, `FROM_PERIOD_DATE`, `TO_PERIOD_DATE`, `PERIOD_YEAR`, `PERIOD_NAME`, `STATUS`, `ENTITY_ID`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `FLAG_INUSE`, `CALENDAR_ID`, `SITE_ID`) VALUES (1,'2018-08-01','2018-08-31','2018-2019','AUG-2018','Open',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:46:29','N',1,18),(2,'2018-09-01','2018-09-30','2018-2019','SEP-2018','Open',0,'',35,'2018-08-05 10:44:58',35,'2018-09-03 00:51:03','N',1,18),(3,'2018-10-01','2018-10-31','2018-2019','OCT-2018','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(4,'2018-11-01','2018-11-30','2018-2019','NOV-2018','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(5,'2018-12-01','2018-12-31','2018-2019','DEC-2018','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(6,'2019-01-01','2019-01-31','2018-2019','JAN-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(7,'2019-02-01','2019-02-28','2018-2019','FEB-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(8,'2019-03-01','2019-03-31','2018-2019','MAR-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(9,'2019-04-01','2019-04-30','2018-2019','APR-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(10,'2019-05-01','2019-05-31','2018-2019','MAY-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(11,'2019-06-01','2019-06-30','2018-2019','JUN-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(12,'2019-07-01','2019-07-31','2018-2019','JUL-2019','Never Opened',0,'',35,'2018-08-05 10:44:58',35,'2018-08-05 16:44:58','N',1,18),(13,'2018-08-01','2018-08-31','2018-2019','AUG-2018','Open',0,'',34,'2018-08-06 05:06:25',34,'2018-08-18 07:29:13','N',2,19),(14,'2018-09-01','2018-09-30','2018-2019','SEP-2018','Open',0,'',34,'2018-08-06 05:06:25',34,'2018-09-03 00:41:25','N',2,19),(15,'2018-10-01','2018-10-31','2018-2019','OCT-2018','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(16,'2018-11-01','2018-11-30','2018-2019','NOV-2018','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(17,'2018-12-01','2018-12-31','2018-2019','DEC-2018','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(18,'2019-01-01','2019-01-31','2018-2019','JAN-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(19,'2019-02-01','2019-02-28','2018-2019','FEB-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(20,'2019-03-01','2019-03-31','2018-2019','MAR-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(21,'2019-04-01','2019-04-30','2018-2019','APR-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(22,'2019-05-01','2019-05-31','2018-2019','MAY-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(23,'2019-06-01','2019-06-30','2018-2019','JUN-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(24,'2019-07-01','2019-07-31','2018-2019','JUL-2019','Never Opened',0,'',34,'2018-08-06 05:06:25',34,'2018-08-06 11:06:25','N',2,19),(25,'2018-08-01','2018-08-31','2018-2019','AUG-2018','Open',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:34','N',3,21),(26,'2018-09-01','2018-09-30','2018-2019','SEP-2018','Open',0,'',40,'2018-08-14 17:03:14',44,'2018-09-03 04:46:32','N',3,21),(27,'2018-10-01','2018-10-31','2018-2019','OCT-2018','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(28,'2018-11-01','2018-11-30','2018-2019','NOV-2018','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(29,'2018-12-01','2018-12-31','2018-2019','DEC-2018','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(30,'2019-01-01','2019-01-31','2018-2019','JAN-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(31,'2019-02-01','2019-02-28','2018-2019','FEB-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(32,'2019-03-01','2019-03-31','2018-2019','MAR-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(33,'2019-04-01','2019-04-30','2018-2019','APR-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(34,'2019-05-01','2019-05-31','2018-2019','MAY-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(35,'2019-06-01','2019-06-30','2018-2019','JUN-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21),(36,'2019-07-01','2019-07-31','2018-2019','JUL-2019','Never Opened',0,'',40,'2018-08-14 17:03:14',40,'2018-08-14 23:03:14','N',3,21);
/*!40000 ALTER TABLE `cxs_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_policy_general`
--

DROP TABLE IF EXISTS `cxs_policy_general`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_policy_general` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `EXCESS_HOURS_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `HOLIDAY_EARN_CREDIT` varchar(1) NOT NULL DEFAULT 'N',
  `CTO_OVERTIME` varchar(1) NOT NULL DEFAULT 'N',
  `OVERTIME_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `POLICY_ID` (`POLICY_ID`),
  KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `ROW_NO` (`ROW_NO`),
  KEY `EXCESS_HOURS_ALLOWED` (`EXCESS_HOURS_ALLOWED`),
  KEY `HOLIDAY_EARN_CREDIT` (`HOLIDAY_EARN_CREDIT`),
  KEY `CTO_OVERTIME` (`CTO_OVERTIME`),
  KEY `OVERTIME_ALLOWED` (`OVERTIME_ALLOWED`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_policy_general`
--

LOCK TABLES `cxs_policy_general` WRITE;
/*!40000 ALTER TABLE `cxs_policy_general` DISABLE KEYS */;
INSERT INTO `cxs_policy_general` (`POLICY_ID`, `WORKSHIFT_ID`, `ALIAS_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`, `EXCESS_HOURS_ALLOWED`, `HOLIDAY_EARN_CREDIT`, `CTO_OVERTIME`, `OVERTIME_ALLOWED`) VALUES (1,1,3,7,'2018-07-17 05:55:36',7,'2018-07-17 11:55:36',1,'N','N','N','N'),(2,2,5,15,'2018-07-29 21:21:08',15,'2018-07-30 03:21:08',1,'N','N','N','N'),(3,3,1,35,'2018-08-05 12:27:06',35,'2018-08-05 18:27:06',1,'N','N','N','N'),(4,3,1,35,'2018-08-05 15:40:51',35,'2018-08-06 05:26:51',1,'Y','Y','N','N'),(5,3,1,35,'2018-08-05 23:30:20',35,'2018-08-07 19:55:33',1,'Y','N','N','N'),(6,3,4,35,'2018-08-07 13:56:13',35,'2018-08-07 19:56:13',1,'N','N','N','N'),(7,4,9,39,'2018-08-14 11:11:09',39,'2018-08-14 17:11:09',1,'Y','N','N','N'),(8,4,9,39,'2018-08-16 10:47:21',39,'2018-08-16 16:47:21',1,'N','N','N','N'),(8,4,11,39,'2018-08-16 10:47:21',39,'2018-08-16 16:47:21',2,'N','N','N','N'),(9,4,9,39,'2018-08-17 10:27:48',44,'2018-08-20 18:22:19',1,'N','Y','N','Y'),(9,4,11,39,'2018-08-17 10:27:48',44,'2018-08-20 18:22:19',2,'N','Y','N','Y'),(10,5,14,34,'2018-08-18 01:37:28',34,'2018-08-18 07:37:28',1,'N','Y','N','N'),(11,6,9,44,'2018-08-20 12:36:46',46,'2018-08-20 18:41:26',1,'Y','N','N','N'),(11,6,11,44,'2018-08-20 12:36:46',46,'2018-08-20 18:41:26',2,'Y','N','N','N'),(12,4,9,39,'2018-08-20 14:26:08',39,'2018-08-20 20:26:08',1,'N','N','N','N'),(13,7,17,39,'2018-09-17 22:57:13',39,'2018-09-18 04:57:13',1,'N','N','N','Y'),(13,7,16,39,'2018-09-17 22:57:13',39,'2018-09-18 04:57:13',2,'N','N','N','Y');
/*!40000 ALTER TABLE `cxs_policy_general` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_policy_header`
--

DROP TABLE IF EXISTS `cxs_policy_header`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_policy_header` (
  `POLICY_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(240) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ADDINUSE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`POLICY_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `NAME` (`NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ADDINUSE_FLAG` (`ADDINUSE_FLAG`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_policy_header`
--

LOCK TABLES `cxs_policy_header` WRITE;
/*!40000 ALTER TABLE `cxs_policy_header` DISABLE KEYS */;
INSERT INTO `cxs_policy_header` (`POLICY_ID`, `NAME`, `DESCRIPTION`, `ACTIVE_FLAG`, `ADDINUSE_FLAG`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,'Policy1','policy 1 description','Y','',7,'2018-07-17 05:55:36',7,'2018-07-17 11:55:36',7),(2,'AAAA','','Y','',15,'2018-07-29 21:21:08',15,'2018-07-30 03:21:08',14),(3,'asdf','asdf','Y','',35,'2018-08-05 12:27:06',35,'2018-08-05 18:27:06',18),(4,'newpolicy','new','N','',35,'2018-08-05 15:40:51',35,'2018-08-05 21:40:51',18),(5,'anotherpolicy','another desc','Y','',35,'2018-08-05 23:30:20',35,'2018-08-06 05:30:20',18),(6,'DEFINE POLICY','','Y','Y',35,'2018-08-07 13:56:13',35,'2018-08-08 15:12:15',18),(7,'PREAPPROVAL POLICY','PREAPPROVAL POLICY','Y','Y',39,'2018-08-14 11:11:09',39,'2018-08-14 23:08:58',21),(8,'MAIN APPROVAL POLICY','','Y','Y',39,'2018-08-16 10:47:21',39,'2018-08-16 17:13:39',21),(9,'HOLIDAY EARN CREDIT POLICY','HOLIDAY EARN CREDIT POLICY','Y','Y',39,'2018-08-17 10:27:48',39,'2018-08-24 17:39:00',21),(10,'policy1','yyy','Y','Y',34,'2018-08-18 01:37:28',34,'2018-08-18 07:41:11',19),(11,'AWW POLICY','','N','',44,'2018-08-20 12:36:46',44,'2018-08-20 18:36:46',21),(12,'ACTIVE TEST','','N','',39,'2018-08-20 14:26:08',39,'2018-08-20 20:26:08',21),(13,'DSS REGULAR SHIFT POLICY','DSS REGULAR SHIFT POLICY','Y','Y',39,'2018-09-17 22:57:13',39,'2018-09-18 05:21:19',21);
/*!40000 ALTER TABLE `cxs_policy_header` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_policy_time_earned1`
--

DROP TABLE IF EXISTS `cxs_policy_time_earned1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_policy_time_earned1` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `EXCESS_HOURS_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `HOLIDAY_EARN_CREDIT` varchar(1) NOT NULL DEFAULT 'N',
  `SHIFT_DIFFERENTIAL` varchar(1) NOT NULL DEFAULT 'N',
  `OVERTIME_ALLOWED` varchar(1) NOT NULL DEFAULT 'N',
  `REQUIRED_HOURS` double NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `EARN_TYPE` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  `CTO_OVERTIME` varchar(1) NOT NULL DEFAULT 'N',
  KEY `POLICY_ID` (`POLICY_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_policy_time_earned1`
--

LOCK TABLES `cxs_policy_time_earned1` WRITE;
/*!40000 ALTER TABLE `cxs_policy_time_earned1` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_policy_time_earned1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_policy_time_off`
--

DROP TABLE IF EXISTS `cxs_policy_time_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_policy_time_off` (
  `POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `MAXIMUM_HOURS_ALLOWED` double DEFAULT NULL,
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(10) DEFAULT NULL,
  KEY `POLICY_ID` (`POLICY_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  KEY `MAXIMUM_HOURS_ALLOWED` (`MAXIMUM_HOURS_ALLOWED`),
  KEY `PERIOD_ID` (`PERIOD_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_policy_time_off`
--

LOCK TABLES `cxs_policy_time_off` WRITE;
/*!40000 ALTER TABLE `cxs_policy_time_off` DISABLE KEYS */;
INSERT INTO `cxs_policy_time_off` (`POLICY_ID`, `ALIAS_ID`, `WORKSHIFT_ID`, `MAXIMUM_HOURS_ALLOWED`, `PERIOD_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`) VALUES (1,2,1,0,0,7,'2018-07-17 05:56:16',7,'2018-07-17 11:56:16',1),(3,3,3,0,0,35,'2018-08-05 12:27:50',35,'2018-08-05 18:27:50',1),(4,3,3,0,0,35,'2018-08-05 15:40:59',35,'2018-08-05 21:40:59',1),(7,8,4,0,0,39,'2018-08-14 11:11:23',39,'2018-08-14 17:11:23',1),(8,8,4,0,0,39,'2018-08-16 10:47:29',39,'2018-08-16 16:47:29',1),(9,8,4,0,0,39,'2018-08-17 10:27:58',39,'2018-08-17 16:27:58',1),(11,8,6,0,0,44,'2018-08-20 12:36:54',44,'2018-08-20 18:36:54',1),(13,8,7,0,0,39,'2018-09-17 22:57:23',39,'2018-09-18 04:57:23',1);
/*!40000 ALTER TABLE `cxs_policy_time_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_preapp_alias`
--

DROP TABLE IF EXISTS `cxs_preapp_alias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_preapp_alias` (
  `PREAPP_RULE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROW_NO` int(11) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `WBS_ID` (`ALIAS_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `PREAPP_RULE_ID` (`PREAPP_RULE_ID`),
  KEY `ROW_NO` (`ROW_NO`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_preapp_alias`
--

LOCK TABLES `cxs_preapp_alias` WRITE;
/*!40000 ALTER TABLE `cxs_preapp_alias` DISABLE KEYS */;
INSERT INTO `cxs_preapp_alias` (`PREAPP_RULE_ID`, `ALIAS_ID`, `ROW_NO`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `LAST_SESSION_ID`, `SITE_ID`) VALUES (3,5,1,15,'2018-07-29 21:17:22',15,'2018-07-30 03:17:22','',0),(5,1,1,35,'2018-08-05 13:34:21',35,'2018-08-05 19:34:21','',0),(7,9,1,39,'2018-08-14 11:16:46',40,'2018-08-15 16:13:08','',0),(7,11,2,40,'2018-08-15 14:17:25',40,'2018-08-15 20:17:25','',0);
/*!40000 ALTER TABLE `cxs_preapp_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_preapp_rules`
--

DROP TABLE IF EXISTS `cxs_preapp_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_preapp_rules` (
  `PREAPP_RULE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PREAPPROVAL_TYPE` varchar(100) NOT NULL DEFAULT '',
  `QUOTA_HOURS` double NOT NULL DEFAULT '0',
  `CHARGE_TYPE` varchar(10) NOT NULL DEFAULT '',
  `BUDGET_HOURS` double NOT NULL DEFAULT '0',
  `TOLERANCE` double NOT NULL DEFAULT '0',
  `RECURRING_FLAG` varchar(1) NOT NULL DEFAULT '',
  `WEEKEND_HOURS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CALENDAR_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RULE_NAME` varchar(40) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT 'N',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT 'Y',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`PREAPP_RULE_ID`),
  KEY `CALENDAR_ID` (`CALENDAR_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `PREAPPROVAL_TYPE` (`PREAPPROVAL_TYPE`),
  KEY `QUOTA_HOURS` (`QUOTA_HOURS`),
  KEY `CHARGE_TYPE` (`CHARGE_TYPE`),
  KEY `BUDGET_HOURS` (`BUDGET_HOURS`),
  KEY `RECURRING_FLAG` (`RECURRING_FLAG`),
  KEY `TOLERANCE` (`TOLERANCE`),
  KEY `WEEKEND_HOURS_FLAG` (`WEEKEND_HOURS_FLAG`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `RULE_NAME` (`RULE_NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `IN_USE_FLAG` (`IN_USE_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_preapp_rules`
--

LOCK TABLES `cxs_preapp_rules` WRITE;
/*!40000 ALTER TABLE `cxs_preapp_rules` DISABLE KEYS */;
INSERT INTO `cxs_preapp_rules` (`PREAPP_RULE_ID`, `PREAPPROVAL_TYPE`, `QUOTA_HOURS`, `CHARGE_TYPE`, `BUDGET_HOURS`, `TOLERANCE`, `RECURRING_FLAG`, `WEEKEND_HOURS_FLAG`, `CALENDAR_ID`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `RULE_NAME`, `DESCRIPTION`, `IN_USE_FLAG`, `ACTIVE_FLAG`, `SITE_ID`) VALUES (1,'Direct Preapproval',222,'',0,0,'','',0,'',15,'2018-07-23 21:49:55',15,'2018-07-24 03:49:55','Quota Based','Quota Based','N','Y',14),(2,'Direct Preapproval',0,'',0,0,'','',0,'',15,'2018-07-29 21:16:29',15,'2018-07-30 03:22:43','aaa','2018','Y','N',14),(3,'Task Base Preapproval',222,'',0,0,'','',0,'',15,'2018-07-29 21:17:22',15,'2018-07-30 03:17:22','aaa1','2018','N','Y',14),(4,'Direct Preapproval',121,'',0,0,'','',0,'',35,'2018-08-05 13:33:17',35,'2018-08-05 19:36:07','Just6','just','N','Y',18),(5,'Task Base Preapproval',13423,'',0,0,'','',0,'',35,'2018-08-05 13:34:21',35,'2018-08-05 20:01:54','Just Preapprove3','preaprove2','Y','N',18),(6,'Direct Preapproval',50,'',0,0,'','',0,'',39,'2018-08-14 11:14:52',39,'2018-08-14 17:17:17','DIRECT PREAPPROVAL RULE ','PREAPPROVAL RULE','Y','Y',21),(7,'Task Base Preapproval',20,'',0,0,'','',0,'',39,'2018-08-14 11:16:46',40,'2018-08-15 21:29:34','PROJCT','PROJECT','Y','Y',21),(8,'Direct Preapproval',0,'',0,0,'','',0,'',46,'2018-08-20 12:47:54',46,'2018-08-20 18:47:54','ACTIVE TEST RULE','ACTR','N','N',21);
/*!40000 ALTER TABLE `cxs_preapp_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_resource_address`
--

DROP TABLE IF EXISTS `cxs_resource_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_resource_address` (
  `ADDRESS_RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `ADDRESS1` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS2` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS3` varchar(100) NOT NULL DEFAULT '',
  `CITY` varchar(100) NOT NULL DEFAULT '',
  `STATE` varchar(100) NOT NULL DEFAULT '',
  `COUNTRY` varchar(100) NOT NULL DEFAULT '',
  `POSTAL_CODE` varchar(50) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ADDRESS_RESOURCE_ID`),
  KEY `RESOURCE_ID` (`RESOURCE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `ADDRESS1` (`ADDRESS1`),
  KEY `ADDRESS2` (`ADDRESS2`),
  KEY `ADDRESS3` (`ADDRESS3`),
  KEY `CITY` (`CITY`),
  KEY `STATE` (`STATE`),
  KEY `COUNTRY` (`COUNTRY`),
  KEY `POSTAL_CODE` (`POSTAL_CODE`),
  KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `ROW_NO` (`ROW_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_resource_address`
--

LOCK TABLES `cxs_resource_address` WRITE;
/*!40000 ALTER TABLE `cxs_resource_address` DISABLE KEYS */;
INSERT INTO `cxs_resource_address` (`ADDRESS_RESOURCE_ID`, `RESOURCE_ID`, `ADDRESS1`, `ADDRESS2`, `ADDRESS3`, `CITY`, `STATE`, `COUNTRY`, `POSTAL_CODE`, `PRIMARY_FLAG`, `ACTIVE_FLAG`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`, `SITE_ID`) VALUES (1,1,'a street','b street','c street','San Diego','CA-CALIFORNIA','United States','92126','Y','N','',35,'2018-08-05 13:05:49',35,'2018-08-05 19:05:49',1,18),(2,2,'a street','b street','c street','San Diego','CA-CALIFORNIA','United States','92126','Y','Y','',35,'2018-08-05 13:06:30',35,'2018-08-05 19:06:30',1,18),(3,4,'A STREEET','B STREET','C STREET','A CITY','CA-CALIFORNIA','A COUNTRY','98121','Y','N','',35,'2018-08-07 13:53:05',35,'2018-08-07 19:53:05',1,18),(4,5,'A STREET','B STREET','C STREET','SAN DIEGO','CA-CALIFORNIA','US','92127','Y','N','',39,'2018-08-14 11:17:43',39,'2018-08-14 17:17:43',1,21),(5,6,'ASTREET','BSTREET','CSTREET','SAN DIEGO','CA-CALIFORNIA','US','92127','Y','Y','',39,'2018-08-14 11:19:28',39,'2018-08-14 17:19:28',1,21),(6,7,'A STREET','B STREET','C STREET','A CITY','CA-CALIFORNIA','A COUNTRY','92127','Y','Y','',39,'2018-08-15 15:29:58',39,'2018-08-15 21:29:58',1,21),(7,8,'ADDRESS1','ADRESS2','ADR3','SAN DIEGO','CA-CALIFORNIA','US','92127','Y','Y','',39,'2018-08-16 10:48:44',39,'2018-08-16 16:48:44',1,21),(8,9,'ABC','DEF','GHI','JKL','CA-CALIFORNIA','MN','9127','Y','Y','',39,'2018-08-17 10:29:43',39,'2018-08-17 16:29:43',1,21),(9,12,'CXDSF','','SDFS','','AZ-ARIZONA','','SAFD','Y','Y','',44,'2018-08-20 12:37:55',44,'2018-08-20 18:37:55',1,21),(10,13,'11440 West Bernardo Ct','b street','','San Diego','CA-CALIFORNIA','United States','92127','Y','Y','',39,'2018-09-17 23:02:01',39,'2018-09-18 05:02:01',1,21),(11,14,'11440 West Bernardo Ct','b street','','San Diego','CA-CALIFORNIA','United States','92127','Y','Y','',39,'2018-09-17 23:03:32',39,'2018-09-18 05:03:32',1,21),(12,15,'11440 West Bernardo Ct','b street','','San Diego','CA-CALIFORNIA','United States','92127','Y','Y','',39,'2018-09-17 23:04:42',39,'2018-09-18 05:04:42',1,21);
/*!40000 ALTER TABLE `cxs_resource_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_resource_contact`
--

DROP TABLE IF EXISTS `cxs_resource_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_resource_contact` (
  `CONTACT_RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `PHONE_NUMBER` varchar(100) NOT NULL DEFAULT '',
  `EMAIL_ADDRESS` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACCEPTS_TEXTS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `SOCIAL_URL` varchar(100) NOT NULL DEFAULT '',
  `SOCIAL_URL_LABEL` varchar(240) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CONTACT_RESOURCE_ID`),
  KEY `RESOURCE_ID` (`RESOURCE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `PHONE_NUMBER` (`PHONE_NUMBER`),
  KEY `EMAIL_ADDRESS` (`EMAIL_ADDRESS`),
  KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ACCEPTS_TEXTS_FLAG` (`ACCEPTS_TEXTS_FLAG`),
  KEY `SOCIAL_URL` (`SOCIAL_URL`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `SOCIAL_URL_LABEL` (`SOCIAL_URL_LABEL`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_resource_contact`
--

LOCK TABLES `cxs_resource_contact` WRITE;
/*!40000 ALTER TABLE `cxs_resource_contact` DISABLE KEYS */;
INSERT INTO `cxs_resource_contact` (`CONTACT_RESOURCE_ID`, `RESOURCE_ID`, `PHONE_NUMBER`, `EMAIL_ADDRESS`, `PRIMARY_FLAG`, `ACTIVE_FLAG`, `ACCEPTS_TEXTS_FLAG`, `SOCIAL_URL`, `SOCIAL_URL_LABEL`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`, `SITE_ID`) VALUES (1,1,'1111111111','ADC@ADC.COM','Y','Y','Y','','','',35,'2018-08-05 13:05:59',35,'2018-08-05 19:05:59',1,0),(2,2,'ASDF','','Y','Y','Y','','','',35,'2018-08-05 13:06:39',35,'2018-08-05 19:06:39',1,0),(3,4,'8888888888','abc@abc.com','Y','N','N','','','',35,'2018-08-07 13:53:17',35,'2018-08-07 19:53:17',1,0),(4,5,'8588888888','try@try.com','Y','N','N','','','',39,'2018-08-14 11:18:16',39,'2018-08-14 17:18:16',1,0),(5,6,'8888888888','try@try.com','Y','Y','N','','','',39,'2018-08-14 11:19:55',39,'2018-08-14 17:20:06',1,21),(6,7,'8888888888','try@try.com','Y','Y','Y','','','',39,'2018-08-15 15:30:13',39,'2018-08-15 21:30:13',1,0),(7,8,'8589458003','ptaka@aol.com','Y','Y','Y','','','',39,'2018-08-16 10:49:11',39,'2018-08-16 16:49:11',1,0),(8,9,'8888888888','def@def.com','Y','Y','Y','','','',39,'2018-08-17 10:29:56',39,'2018-08-17 16:29:56',1,0),(9,12,'S324234234','23@23.COM','Y','Y','Y','','','',44,'2018-08-20 12:38:08',44,'2018-08-20 18:38:08',1,0),(10,13,'1111111111','ADC@ADC.COM','Y','Y','N','','','',39,'2018-09-17 23:02:16',39,'2018-09-18 05:02:16',1,0),(11,14,'1111111111','ADF@ADF.COM','Y','Y','N','','','',39,'2018-09-17 23:03:53',39,'2018-09-18 05:03:53',1,0),(12,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:02',39,'2018-09-18 05:05:03',1,0),(13,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:03',2,0),(14,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:03',3,0),(15,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:03',4,0),(16,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:03',5,0),(17,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:03',6,0),(18,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:03',39,'2018-09-18 05:05:04',7,0),(19,15,'1111111111','ADC@ADC.COM','N','Y','N','','','',39,'2018-09-17 23:05:04',39,'2018-09-18 05:05:04',8,0),(20,15,'1111111111','ADC@ADC.COM','Y','Y','N','','','',39,'2018-09-17 23:05:04',39,'2018-09-18 05:05:04',9,0);
/*!40000 ALTER TABLE `cxs_resource_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_resource_groups`
--

DROP TABLE IF EXISTS `cxs_resource_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_resource_groups` (
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `RESOURCE_GROUP_NAME` varchar(40) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT 'Y',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TIME_POLICY_ID` bigint(20) NOT NULL DEFAULT '0',
  `ROLE_ID` bigint(50) NOT NULL DEFAULT '0',
  `PREAPPROVAL_RULE_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`RESOURCE_GROUP_ID`),
  KEY `TIME_POLICY_ID` (`TIME_POLICY_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `RESOURCE_GROUP_NAME` (`RESOURCE_GROUP_NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ROLE` (`ROLE_ID`),
  KEY `PREAPPROVAL_RULE_ID` (`PREAPPROVAL_RULE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_resource_groups`
--

LOCK TABLES `cxs_resource_groups` WRITE;
/*!40000 ALTER TABLE `cxs_resource_groups` DISABLE KEYS */;
INSERT INTO `cxs_resource_groups` (`RESOURCE_GROUP_ID`, `RESOURCE_GROUP_NAME`, `DESCRIPTION`, `ACTIVE_FLAG`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `TIME_POLICY_ID`, `ROLE_ID`, `PREAPPROVAL_RULE_ID`, `SITE_ID`) VALUES (1,'AG','','Y',15,'2018-07-29 21:22:43',15,'2018-07-30 03:22:43',2,0,2,14),(2,'test','','Y',35,'2018-08-06 06:00:08',35,'2018-08-06 12:00:08',5,0,5,18),(3,'RRG','RRGD','Y',35,'2018-08-07 13:46:34',35,'2018-08-07 19:46:34',4,1,5,18);
/*!40000 ALTER TABLE `cxs_resource_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_resources`
--

DROP TABLE IF EXISTS `cxs_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_resources` (
  `RESOURCE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` varchar(240) NOT NULL DEFAULT '',
  `MIDDLE_NAME` varchar(240) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(240) NOT NULL DEFAULT '',
  `RESOURCE_TYPE` varchar(100) NOT NULL,
  `CONTRACTOR_TYPE_FLAG` varchar(100) NOT NULL DEFAULT '',
  `START_DATE_ACTIVE` date DEFAULT NULL,
  `END_DATE_ACTIVE` date DEFAULT NULL,
  `TIMEMANAGEMENTPOLICY_ID` bigint(20) NOT NULL,
  `PREAPPROVALRULES_ID` bigint(20) NOT NULL,
  `SUPREVISOR_ID` bigint(20) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `ENTITY_ID` bigint(20) NOT NULL,
  `RBAC_ID` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LAST_SESSION_ID` bigint(20) NOT NULL DEFAULT '0',
  `AVAILABILTY_TYPE` varchar(40) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT 'N',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`RESOURCE_ID`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `FIRST_NAME` (`FIRST_NAME`),
  KEY `MIDDLE_NAME` (`MIDDLE_NAME`),
  KEY `LAST_NAME` (`LAST_NAME`),
  KEY `RESOURCE_TYPE` (`RESOURCE_TYPE`),
  KEY `CONTRACTOR_TYPE_FLAG` (`CONTRACTOR_TYPE_FLAG`),
  KEY `START_DATE_ACTIVE` (`START_DATE_ACTIVE`),
  KEY `END_DATE_ACTIVE` (`END_DATE_ACTIVE`),
  KEY `TIMEMANAGEMENTPOLICY_ID` (`TIMEMANAGEMENTPOLICY_ID`),
  KEY `PREAPPROVALRULES_ID` (`PREAPPROVALRULES_ID`),
  KEY `SUPREVISOR_ID` (`SUPREVISOR_ID`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `ENTITY_ID` (`ENTITY_ID`),
  KEY `RBAC_ID` (`RBAC_ID`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `AVAILABILTY_TYPE` (`AVAILABILTY_TYPE`),
  KEY `IN_USE_FLAG` (`IN_USE_FLAG`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_resources`
--

LOCK TABLES `cxs_resources` WRITE;
/*!40000 ALTER TABLE `cxs_resources` DISABLE KEYS */;
INSERT INTO `cxs_resources` (`RESOURCE_ID`, `FIRST_NAME`, `MIDDLE_NAME`, `LAST_NAME`, `RESOURCE_TYPE`, `CONTRACTOR_TYPE_FLAG`, `START_DATE_ACTIVE`, `END_DATE_ACTIVE`, `TIMEMANAGEMENTPOLICY_ID`, `PREAPPROVALRULES_ID`, `SUPREVISOR_ID`, `DESCRIPTION`, `ENTITY_ID`, `RBAC_ID`, `RESOURCE_GROUP_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `LAST_SESSION_ID`, `AVAILABILTY_TYPE`, `IN_USE_FLAG`, `SITE_ID`) VALUES (1,'A NAME','','test','Employee','','2018-08-01','0000-00-00',3,0,0,'',0,0,0,35,'2018-08-05 13:05:41',35,'2018-08-05 19:07:34',0,'Full Time','Y',18),(2,'ADSF','','ASDF','Employee','','2018-08-01','0000-00-00',3,0,4,'',0,0,0,35,'2018-08-05 13:06:25',35,'2018-08-10 04:10:38',0,'Full Time','Y',18),(3,'RUCHIR','S','VAISHNAV','Employee','','2018-08-05','0000-00-00',6,5,1,'',0,0,0,35,'2018-08-05 14:01:54',35,'2018-08-08 07:59:47',0,'Full Time','Y',18),(4,'HAREVY','B','BLAKE','Employee','','2018-08-07','2018-08-07',4,5,3,'',0,0,3,35,'2018-08-07 13:52:31',35,'2018-08-07 19:59:03',0,'Full Time','Y',18),(5,'WELLS','','FARGO','Employee','','2018-08-01','0000-00-00',7,6,6,'',0,0,0,39,'2018-08-14 11:17:17',39,'2018-08-14 22:28:28',0,'Full Time','Y',21),(6,'SUPER WELLS','','FARGO','Employee','','2018-08-01','0000-00-00',7,6,5,'',0,0,0,39,'2018-08-14 11:18:56',39,'2018-08-14 22:28:50',0,'Full Time','Y',21),(7,'ORAWOLF','X','CTLA','Employee','','2018-08-01','0000-00-00',7,7,6,'',0,0,0,39,'2018-08-15 15:29:34',39,'2018-08-15 21:32:04',0,'Full Time','Y',21),(8,'PAUL ','','TAMAKA','Employee','','2018-08-01','0000-00-00',8,0,6,'',0,0,0,39,'2018-08-16 10:48:14',39,'2018-08-16 16:50:25',0,'Full Time','Y',21),(9,'ALDE','','BOB','Employee','','2018-08-01','0000-00-00',9,6,6,'',0,0,0,39,'2018-08-17 10:29:24',39,'2018-08-17 16:34:40',0,'Full Time','Y',21),(10,'Applisoft','','Technologies','Contractor','','2018-08-18','0000-00-00',10,0,11,'',0,0,0,34,'2018-08-18 01:38:21',34,'2018-08-18 07:40:18',0,'','Y',19),(11,'Resource1','','test data','Employee','','2018-08-01','0000-00-00',10,0,10,'',0,0,0,34,'2018-08-18 01:39:14',34,'2018-08-18 07:48:59',0,'Full Time','Y',19),(12,'AWW','','RESOURCE','Employee','','2018-08-01','0000-00-00',11,0,6,'',0,0,0,44,'2018-08-20 12:37:42',44,'2018-08-20 18:39:29',0,'Full Time','Y',21),(13,'JEFF','','STRICKLER','Employee','','2018-09-17','0000-00-00',13,0,9,'',0,0,0,39,'2018-09-17 23:00:26',39,'2018-09-18 05:08:53',0,'Full Time','Y',21),(14,'JOHN','','SMITH','Employee','','2018-09-17','0000-00-00',13,0,13,'',0,0,0,39,'2018-09-17 23:03:21',39,'2018-09-18 05:10:25',0,'Full Time','Y',21),(15,'BOB','','TABAKA','Employee','','2018-09-17','0000-00-00',13,0,13,'',0,0,0,39,'2018-09-17 23:04:30',39,'2018-09-18 05:09:32',0,'','Y',21);
/*!40000 ALTER TABLE `cxs_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_site_address`
--

DROP TABLE IF EXISTS `cxs_site_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_site_address` (
  `ADDRESS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SITE_ID` bigint(20) NOT NULL,
  `ADDRESS1` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS2` varchar(100) NOT NULL DEFAULT '',
  `ADDRESS3` varchar(100) NOT NULL DEFAULT '',
  `CITY` varchar(100) NOT NULL DEFAULT '',
  `POSTAL_CODE` varchar(50) NOT NULL DEFAULT '',
  `STATE` varchar(100) NOT NULL DEFAULT '',
  `COUNTRY` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ADDRESS_ID`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `ADDRESS1` (`ADDRESS1`),
  KEY `ADDRESS2` (`ADDRESS2`),
  KEY `ADDRESS3` (`ADDRESS3`),
  KEY `CITY` (`CITY`),
  KEY `STATE` (`STATE`),
  KEY `COUNTRY` (`COUNTRY`),
  KEY `ZIP_CODE` (`POSTAL_CODE`),
  KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ROW_NO` (`ROW_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_site_address`
--

LOCK TABLES `cxs_site_address` WRITE;
/*!40000 ALTER TABLE `cxs_site_address` DISABLE KEYS */;
INSERT INTO `cxs_site_address` (`ADDRESS_ID`, `SITE_ID`, `ADDRESS1`, `ADDRESS2`, `ADDRESS3`, `CITY`, `POSTAL_CODE`, `STATE`, `COUNTRY`, `PRIMARY_FLAG`, `ACTIVE_FLAG`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`) VALUES (1,18,'SFDG','FDSG','FDSG','FDSG','DFG','AL-ALABAMA','S','Y','N',35,'2018-08-07 14:03:15',35,'2018-08-07 20:03:15',1);
/*!40000 ALTER TABLE `cxs_site_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_site_contacts`
--

DROP TABLE IF EXISTS `cxs_site_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_site_contacts` (
  `CONTACT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SITE_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(100) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(100) NOT NULL DEFAULT '',
  `PHONE` varchar(100) NOT NULL DEFAULT '',
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `PHONE_TYPE` varchar(50) NOT NULL DEFAULT '',
  `TITLE` varchar(100) NOT NULL DEFAULT '',
  `PRIMARY_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`CONTACT_ID`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `FIRST_NAME` (`FIRST_NAME`),
  KEY `LAST_NAME` (`LAST_NAME`),
  KEY `PHONE` (`PHONE`),
  KEY `EMAIL` (`EMAIL`),
  KEY `PHONE_TYPE` (`PHONE_TYPE`),
  KEY `TITLE` (`TITLE`),
  KEY `PRIMARY_FLAG` (`PRIMARY_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ROW_NO` (`ROW_NO`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_site_contacts`
--

LOCK TABLES `cxs_site_contacts` WRITE;
/*!40000 ALTER TABLE `cxs_site_contacts` DISABLE KEYS */;
INSERT INTO `cxs_site_contacts` (`CONTACT_ID`, `SITE_ID`, `FIRST_NAME`, `LAST_NAME`, `PHONE`, `EMAIL`, `PHONE_TYPE`, `TITLE`, `PRIMARY_FLAG`, `ACTIVE_FLAG`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROW_NO`) VALUES (1,18,'SDGF','FDSG','DSFG','SFDG@SDF.COM','','SGFD','Y','N',35,'2018-08-07 14:03:31',35,'2018-08-07 20:03:31',1);
/*!40000 ALTER TABLE `cxs_site_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_site_settings`
--

DROP TABLE IF EXISTS `cxs_site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_site_settings` (
  `SITE_SETTINGS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `MANDATORY_PWD` bigint(20) NOT NULL,
  `INCORRECT_ATTEMPT` bigint(20) NOT NULL,
  `IDLE_SESSION` bigint(20) NOT NULL,
  `MINIMUM_ALLOWED` bigint(20) NOT NULL,
  `MAXIMUM_ALLOWED` bigint(20) NOT NULL,
  `DEFAULT_DATE_FORMAT` varchar(20) DEFAULT '',
  `DEFAULT_NUMBER_FORMAT` varchar(1) DEFAULT '',
  `DEFAULT_TIMEZONE` varchar(20) DEFAULT '',
  `ENFORCE_RECENT` varchar(1) DEFAULT '',
  `NUMBER_OF_RECENT` int(1) DEFAULT NULL,
  `ALLOW_SPECIALS` varchar(1) DEFAULT '',
  `ALLOW_UPPERCASE` varchar(1) DEFAULT '',
  `ALLOW_TIME_ENTRY` varchar(1) DEFAULT NULL,
  `ALLOW_LOWERCASE` varchar(1) DEFAULT '',
  `ALLOW_NUMERIC` varchar(1) DEFAULT '',
  `ENABLE_COMMON` varchar(1) DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ENABLE_AUDIT` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`SITE_SETTINGS_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `MANDATORY_PWD` (`MANDATORY_PWD`),
  KEY `INCORRECT_ATTEMPT` (`INCORRECT_ATTEMPT`),
  KEY `IDLE_SESSION` (`IDLE_SESSION`),
  KEY `MINIMUM_ALLOWED` (`MINIMUM_ALLOWED`),
  KEY `MAXIMUM_ALLOWED` (`MAXIMUM_ALLOWED`),
  KEY `DEFAULT_DATE_FORMAT` (`DEFAULT_DATE_FORMAT`),
  KEY `DEFAULT_NUMBER_FORMAT` (`DEFAULT_NUMBER_FORMAT`),
  KEY `DEFAULT_TIMEZONE` (`DEFAULT_TIMEZONE`),
  KEY `ENFORCE_RECENT` (`ENFORCE_RECENT`),
  KEY `NUMBER_OF_RECENT` (`NUMBER_OF_RECENT`),
  KEY `ALLOW_SPECIALS` (`ALLOW_SPECIALS`),
  KEY `ALLOW_UPPERCASE` (`ALLOW_UPPERCASE`),
  KEY `ALLOW_TIME_ENTRY` (`ALLOW_TIME_ENTRY`),
  KEY `ALLOW_LOWERCASE` (`ALLOW_LOWERCASE`),
  KEY `ALLOW_NUMERIC` (`ALLOW_NUMERIC`),
  KEY `ENABLE_COMMON` (`ENABLE_COMMON`),
  KEY `ENABLE_AUDIT` (`ENABLE_AUDIT`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_site_settings`
--

LOCK TABLES `cxs_site_settings` WRITE;
/*!40000 ALTER TABLE `cxs_site_settings` DISABLE KEYS */;
INSERT INTO `cxs_site_settings` (`SITE_SETTINGS_ID`, `MANDATORY_PWD`, `INCORRECT_ATTEMPT`, `IDLE_SESSION`, `MINIMUM_ALLOWED`, `MAXIMUM_ALLOWED`, `DEFAULT_DATE_FORMAT`, `DEFAULT_NUMBER_FORMAT`, `DEFAULT_TIMEZONE`, `ENFORCE_RECENT`, `NUMBER_OF_RECENT`, `ALLOW_SPECIALS`, `ALLOW_UPPERCASE`, `ALLOW_TIME_ENTRY`, `ALLOW_LOWERCASE`, `ALLOW_NUMERIC`, `ENABLE_COMMON`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`, `ENABLE_AUDIT`) VALUES (1,10,25,1243,9,0,'d-M-Y','','Eastern','Y',5,'Y','Y','Y','Y','Y','Y',1,'2018-07-11',1,'2018-07-17 11:28:54',7,'N'),(2,10,25,1243,9,0,'d-M-Y','','Eastern','Y',5,'Y','Y','Y','Y','Y','Y',1,'2018-07-11',1,'2018-07-18 05:00:54',9,'N'),(3,10,25,1243,9,0,'d-M-Y','','Eastern','Y',5,'Y','Y','Y','Y','Y','Y',14,'2018-07-18',14,'2018-07-18 09:37:20',13,'N'),(4,10,25,1243,9,0,'d-M-Y','','Eastern','Y',5,'Y','Y','Y','Y','Y','Y',15,'2018-07-18',15,'2018-07-19 04:40:43',14,'N'),(5,10,25,1243,9,0,'d-M-Y','','Eastern','Y',5,'Y','Y','Y','Y','Y','Y',16,'2018-07-19',16,'2018-07-19 07:40:18',15,'N'),(6,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',31,'2018-07-30',31,'2018-07-30 10:45:51',16,'N'),(7,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',32,'2018-07-30',32,'2018-07-30 10:45:51',17,'N'),(8,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',34,'2018-08-03',34,'2018-08-27 16:50:37',19,'Y'),(9,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',35,'2018-08-05',35,'2018-08-05 16:41:33',18,'N'),(10,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',39,'2018-08-14',39,'2018-08-22 17:52:29',21,'Y'),(11,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',47,'2018-08-27',47,'2018-08-27 21:40:41',20,'N'),(12,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',48,'2018-09-06',48,'2018-09-06 20:49:57',22,'N'),(13,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',49,'2018-09-07',49,'2018-09-08 04:36:23',23,'N'),(14,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',50,'2018-09-17',50,'2018-09-18 03:41:44',24,'N'),(15,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',51,'2018-09-17',51,'2018-09-18 04:03:46',25,'N'),(16,30,25,1243,9,0,'','','','Y',5,'Y','Y','Y','Y','Y','Y',52,'2018-09-17',52,'2018-09-18 04:11:02',26,'N');
/*!40000 ALTER TABLE `cxs_site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_sites`
--

DROP TABLE IF EXISTS `cxs_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_sites` (
  `SITE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` varchar(240) NOT NULL DEFAULT '',
  `LAST_NAME` varchar(240) NOT NULL DEFAULT '',
  `JOB_TITLE` varchar(240) NOT NULL DEFAULT '',
  `EMAIL` varchar(240) NOT NULL DEFAULT '',
  `PHONE` varchar(40) NOT NULL DEFAULT '',
  `SITE_NAME` varchar(240) NOT NULL DEFAULT '',
  `SITE_CODE` varchar(100) NOT NULL DEFAULT '',
  `EMPLOYEE_BREAK` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL DEFAULT '0',
  `CREATION_DATE` date DEFAULT NULL,
  `UPDATED_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IS_APPROVAL` varchar(1) NOT NULL DEFAULT 'N',
  `SYSTEM_PASSWORD` varchar(240) NOT NULL DEFAULT '',
  `DATE_ACTIVATED` date DEFAULT NULL,
  PRIMARY KEY (`SITE_ID`),
  KEY `FIRST_NAME` (`FIRST_NAME`),
  KEY `LAST_NAME` (`LAST_NAME`),
  KEY `JOB_TITLE` (`JOB_TITLE`),
  KEY `EMAIL` (`EMAIL`),
  KEY `PHONE` (`PHONE`),
  KEY `SITE_NAME` (`SITE_NAME`),
  KEY `SITE_CODE` (`SITE_CODE`),
  KEY `EMPLOYEE_BREAK` (`EMPLOYEE_BREAK`),
  KEY `IS_APPROVAL` (`IS_APPROVAL`),
  KEY `SYSTEM_PASSWORD` (`SYSTEM_PASSWORD`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `UPDATED_DATE` (`UPDATED_DATE`),
  KEY `DATE_ACTIVATED` (`DATE_ACTIVATED`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_sites`
--

LOCK TABLES `cxs_sites` WRITE;
/*!40000 ALTER TABLE `cxs_sites` DISABLE KEYS */;
INSERT INTO `cxs_sites` (`SITE_ID`, `FIRST_NAME`, `LAST_NAME`, `JOB_TITLE`, `EMAIL`, `PHONE`, `SITE_NAME`, `SITE_CODE`, `EMPLOYEE_BREAK`, `CREATED_BY`, `CREATION_DATE`, `UPDATED_DATE`, `IS_APPROVAL`, `SYSTEM_PASSWORD`, `DATE_ACTIVATED`) VALUES (19,'applisoft','technologies','j','APPLISOFT4U@GMAIL.COM','(123)456-7890','applisoft','appli2','1 - 45 employees',0,'2018-08-03','2018-08-04 05:14:06','Y','áÇÍß×¬óÞ','2018-08-03'),(18,'ABC','DEF','GHI','ORAWOLFX@GMAIL.COM','(888)888-8888','aco','aco1','1 - 45 employees',0,'2018-08-03','2018-08-05 16:41:33','Y','Ðé÷¼ÙØ¬ô','2018-08-05'),(20,'abcx','abc','def','SERVICE@COEXSYS.COM','(888)888-8888','coexsys','coexs3','1 - 45 employees',0,'2018-08-05','2018-08-27 21:40:41','Y','Øèý¬ÔÁê«','2018-08-27'),(21,'AUTOADMIN','AUTOADMIN','AUTOADMIN','PARTHIVI.V@GMAIL.COM','(888)888-8888','CALIFORNIA DEPARTMENT OF SOCIAL SERVICES','DEPAR4','1001 - 4500 employees',0,'2018-08-14','2018-09-18 04:26:37','Y','ÙÔÍÞ¯Úëü','2018-08-14'),(22,'Kyle','White','Mr','KYLEMWHITE@GMAIL.COM','(916)572-8697','','5','1 - 45 employees',0,'2018-09-06','2018-09-06 20:49:57','Y','ýñÝ é÷´Á','2018-09-06'),(26,'RUCHIR','VAISHNAV','ANALYST','RUCHIR.VAISHNAV@GMAIL.COM','(858)945-8003','CALIFORNIA DEPARTMENT OF SOCIAL SERVICES','CALIF7','1001 - 4500 employees',0,'2018-09-17','2018-09-18 04:11:02','Y','óÔêá¡Ãþò','2018-09-17'),(25,'AUTOINSTALL','AUTOINSTALL','AUTOINSTALL','AFFILIATE@COEXSYS.COM','(858)945-8003','DEPARTMENT OF SOCIAL SERVICES','DEPAR7','1001 - 4500 employees',0,'2018-09-17','2018-09-18 04:03:46','Y',' ©ð¸Öêö±','2018-09-17');
/*!40000 ALTER TABLE `cxs_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_subscribers`
--

DROP TABLE IF EXISTS `cxs_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_subscribers` (
  `SUBSCRIBER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_ID` bigint(20) NOT NULL,
  `FIRST_NAME` varchar(240) NOT NULL,
  `MIDDLE_INITIAL` varchar(40) NOT NULL,
  `LAST_NAME` varchar(240) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SUBSCRIBER_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `FIRST_NAME` (`FIRST_NAME`),
  KEY `MIDDLE_INITIAL` (`MIDDLE_INITIAL`),
  KEY `LAST_NAME` (`LAST_NAME`),
  KEY `START_DATE` (`START_DATE`),
  KEY `END_DATE` (`END_DATE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_subscribers`
--

LOCK TABLES `cxs_subscribers` WRITE;
/*!40000 ALTER TABLE `cxs_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_support_history`
--

DROP TABLE IF EXISTS `cxs_support_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_support_history` (
  `SUPPORT_HISTORY_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SUPPORT_REQUEST_ID` bigint(20) NOT NULL,
  `UPDATE_COUNTER` bigint(20) NOT NULL DEFAULT '0',
  `UPDATE_STMT` varchar(2000) NOT NULL DEFAULT '',
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `PAGE_TYPE_ID` int(11) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SUPPORT_HISTORY_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `SUPPORT_REQUEST_ID` (`SUPPORT_REQUEST_ID`),
  KEY `UPDATE_COUNTER` (`UPDATE_COUNTER`),
  KEY `UPDATE_STMT` (`UPDATE_STMT`(1000)),
  KEY `PAGE_TYPE_ID` (`PAGE_TYPE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_support_history`
--

LOCK TABLES `cxs_support_history` WRITE;
/*!40000 ALTER TABLE `cxs_support_history` DISABLE KEYS */;
INSERT INTO `cxs_support_history` (`SUPPORT_HISTORY_ID`, `SUPPORT_REQUEST_ID`, `UPDATE_COUNTER`, `UPDATE_STMT`, `CREATION_DATE`, `LAST_UPDATE_DATE`, `CREATED_BY`, `LAST_UPDATED_BY`, `PAGE_TYPE_ID`, `SITE_ID`) VALUES (1,1,1,'','2018-07-31','2018-07-31 11:13:17',7,7,0,0),(2,1,2,'changes','2018-07-31','2018-07-31 11:13:30',7,7,0,0),(3,2,1,'','2018-07-31','2018-07-31 11:14:17',7,7,0,0),(4,3,1,'THAT IS NOT WORKING','2018-08-05','2018-08-05 18:08:09',35,35,0,0),(5,3,2,'PLEASE TRY NOW','2018-08-05','2018-08-05 18:09:20',35,35,0,0);
/*!40000 ALTER TABLE `cxs_support_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_support_request`
--

DROP TABLE IF EXISTS `cxs_support_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_support_request` (
  `SUPPORT_REQUEST_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SR_NUMBER` varchar(40) NOT NULL DEFAULT '',
  `ISSUE_STMT` varchar(40) NOT NULL DEFAULT '',
  `PAGE_TYPE_ID` int(11) NOT NULL DEFAULT '0',
  `ISSUE_DESCRIPTION` varchar(2000) NOT NULL DEFAULT '',
  `MULTI_USER_FLAG` varchar(1) NOT NULL DEFAULT '',
  `WORKAROUND_FLAG` varchar(1) NOT NULL DEFAULT '',
  `IMPACT_STMT` varchar(100) NOT NULL DEFAULT '',
  `SR_STATUS` varchar(20) NOT NULL DEFAULT '',
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` double NOT NULL,
  `LAST_UPDATED_BY` double NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `CUSTOMIZATION_REQUEST` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`SUPPORT_REQUEST_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `SR_NUMBER` (`SR_NUMBER`),
  KEY `ISSUE_STMT` (`ISSUE_STMT`),
  KEY `PAGE_TYPE_ID` (`PAGE_TYPE_ID`),
  KEY `ISSUE_DESCRIPTION` (`ISSUE_DESCRIPTION`(1000)),
  KEY `MULTI_USER_FLAG` (`MULTI_USER_FLAG`),
  KEY `WORKAROUND_FLAG` (`WORKAROUND_FLAG`),
  KEY `IMPACT_STMT` (`IMPACT_STMT`),
  KEY `SR_STATUS` (`SR_STATUS`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_support_request`
--

LOCK TABLES `cxs_support_request` WRITE;
/*!40000 ALTER TABLE `cxs_support_request` DISABLE KEYS */;
INSERT INTO `cxs_support_request` (`SUPPORT_REQUEST_ID`, `SR_NUMBER`, `ISSUE_STMT`, `PAGE_TYPE_ID`, `ISSUE_DESCRIPTION`, `MULTI_USER_FLAG`, `WORKAROUND_FLAG`, `IMPACT_STMT`, `SR_STATUS`, `CREATION_DATE`, `LAST_UPDATE_DATE`, `CREATED_BY`, `LAST_UPDATED_BY`, `SITE_ID`, `CUSTOMIZATION_REQUEST`) VALUES (1,'1','ff',12,'','Y','Y','Cannot Enter Time','In Progress','2018-07-31','2018-07-31 11:13:30',7,7,0,''),(2,'2','rbam error issues',13,'','Y','Y','Cannot Enter Time','Open','2018-07-31','2018-07-31 11:14:17',7,7,0,''),(3,'3','THIS IS NOT WORKING',4,'THAT IS NOT WORKING','Y','Y','Cannot Enter Time','Close','2018-08-05','2018-08-05 18:11:08',35,35,0,'');
/*!40000 ALTER TABLE `cxs_support_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_ta_modules`
--

DROP TABLE IF EXISTS `cxs_ta_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_ta_modules` (
  `RESOURCE_GROUP_ID` bigint(20) DEFAULT NULL,
  `USER_ID` bigint(20) DEFAULT NULL,
  `MODULE_NAME` varchar(40) DEFAULT NULL,
  `CREATE_PRIV` varchar(1) DEFAULT NULL,
  `UPDATE_PRIV` varchar(1) DEFAULT NULL,
  `VIEW_PRIV` varchar(1) DEFAULT NULL,
  `ENABLE_AUDIT` varchar(1) DEFAULT NULL,
  `CREATED_BY` bigint(20) DEFAULT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROWNO` bigint(20) DEFAULT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `USER_ID` (`USER_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`),
  KEY `MODULE_NAME` (`MODULE_NAME`),
  KEY `CREATE_PRIV` (`CREATE_PRIV`),
  KEY `UPDATE_PRIV` (`UPDATE_PRIV`),
  KEY `VIEW_PRIV` (`VIEW_PRIV`),
  KEY `ENABLE_AUDIT` (`ENABLE_AUDIT`),
  KEY `ROWNO` (`ROWNO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_ta_modules`
--

LOCK TABLES `cxs_ta_modules` WRITE;
/*!40000 ALTER TABLE `cxs_ta_modules` DISABLE KEYS */;
INSERT INTO `cxs_ta_modules` (`RESOURCE_GROUP_ID`, `USER_ID`, `MODULE_NAME`, `CREATE_PRIV`, `UPDATE_PRIV`, `VIEW_PRIV`, `ENABLE_AUDIT`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `ROWNO`, `SITE_ID`) VALUES (0,7,'Time Management Policy','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',1,0),(0,7,'Holiday Calenders','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',2,0),(0,7,'Time Entry','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',3,0),(0,7,'Global Aliases','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',4,0),(0,7,'Create Personal Aliases','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',6,0),(0,7,'Create WBS','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',10,0),(0,7,'Billing & Payment','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',13,0),(0,7,'Manage Payment Methods','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',15,0),(0,7,'Resources','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',16,0),(0,7,'Workshift','N','N','N','N',15,'2018-07-23 15:18:08',15,'2018-07-23 21:21:26',18,0),(0,15,'Time Management Policy','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',1,14),(0,15,'Holiday Calenders','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',2,14),(0,15,'Time Entry','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',3,14),(0,15,'Global Aliases','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',4,14),(0,15,'Create Personal Aliases','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',6,14),(0,15,'PreApproval Rules','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',7,14),(0,15,'Accounting Period','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',8,14),(0,15,'Site Settings','N','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',9,14),(0,15,'Create WBS','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',10,14),(0,15,'Access Management','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',11,14),(0,15,'Subscriber Admin','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',12,14),(0,15,'Billing & Payment','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',13,14),(0,15,'View Bill Payment','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',14,14),(0,15,'Manage Payment Methods','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',15,14),(0,15,'Resources','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',16,14),(0,15,'Resource Group','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',17,14),(0,15,'Workshift','Y','Y','Y','N',15,'2018-07-31 14:14:21',15,'2018-07-31 20:14:21',18,14),(0,35,'Time Management Policy','Y','N','Y','N',35,'2018-08-05 13:08:15',35,'2018-08-05 19:08:15',1,18),(0,35,'Holiday Calenders','Y','N','Y','N',35,'2018-08-05 13:08:15',35,'2018-08-05 19:08:15',2,18),(0,35,'Time Entry','Y','N','Y','N',35,'2018-08-05 13:08:15',35,'2018-08-05 19:08:15',3,18),(0,36,'Time Management Policy','Y','Y','Y','N',35,'2018-08-05 15:25:54',35,'2018-08-05 21:25:54',1,18),(0,36,'Holiday Calenders','Y','Y','Y','N',35,'2018-08-05 15:25:54',35,'2018-08-05 21:25:54',2,18),(0,36,'Time Entry','Y','Y','Y','N',35,'2018-08-05 15:25:54',35,'2018-08-05 21:25:54',3,18),(0,36,'Global Aliases','Y','Y','Y','N',35,'2018-08-05 15:25:54',35,'2018-08-05 21:25:54',4,18),(0,42,'Time Management Policy','N','N','Y','N',39,'2018-08-16 15:12:05',39,'2018-08-16 21:12:05',1,21),(0,42,'Access Management','Y','Y','Y','N',39,'2018-08-16 15:57:04',39,'2018-08-16 22:22:43',11,21),(0,42,'Create WBS','Y','Y','Y','N',39,'2018-08-16 16:22:43',39,'2018-08-16 23:02:56',10,21),(0,42,'Site Settings','N','N','Y','N',39,'2018-08-16 17:02:56',39,'2018-08-16 23:02:56',9,21),(0,44,'Time Management Policy','Y','Y','Y','N',39,'2018-08-17 10:39:40',39,'2018-08-17 18:36:01',1,21),(0,44,'Holiday Calenders','N','N','Y','N',39,'2018-08-17 12:36:01',39,'2018-08-17 18:36:01',2,21),(0,44,'Time Entry','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',3,21),(0,44,'Global Aliases','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',4,21),(0,44,'Search TimeSheets','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',5,21),(0,44,'Create Personal Aliases','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',6,21),(0,44,'PreApproval Rules','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',7,21),(0,44,'Accounting Period','N','Y','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 20:13:14',8,21),(0,44,'Site Settings','N','N','Y','N',39,'2018-08-17 12:36:32',39,'2018-08-17 18:36:32',9,21),(0,44,'Resources','N','N','Y','N',39,'2018-08-17 14:13:14',39,'2018-08-17 20:13:14',16,21),(0,44,'Resource Group','N','N','Y','N',39,'2018-08-17 14:13:14',39,'2018-08-17 20:13:14',17,21),(0,44,'Workshift','N','N','Y','N',39,'2018-08-17 14:13:14',39,'2018-08-17 20:13:14',18,21),(0,54,'Time Entry','Y','Y','Y','N',39,'2018-09-17 23:13:36',39,'2018-09-18 05:13:36',3,21),(0,55,'Time Entry','Y','Y','Y','N',39,'2018-09-17 23:14:13',39,'2018-09-18 05:14:13',3,21);
/*!40000 ALTER TABLE `cxs_ta_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_te_approved`
--

DROP TABLE IF EXISTS `cxs_te_approved`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_te_approved` (
  `EI_APPROVAL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TE_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ADJUSTED_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `TIME_STATUS` varchar(1) NOT NULL DEFAULT '',
  `INTERFACE_STATUS` varchar(1) NOT NULL DEFAULT '',
  `ACTUAL_HOURS` float NOT NULL DEFAULT '0',
  `BUDGETED_HOURS` float NOT NULL DEFAULT '0',
  `COMMENT` varchar(250) NOT NULL DEFAULT '',
  `ENTRY_DATE` date NOT NULL,
  `APPROVAL_DATE` date NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`EI_APPROVAL_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `TE_ID` (`TE_ID`),
  KEY `RESOURCE_ID` (`RESOURCE_ID`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `ADJUSTED_HOURS` (`ADJUSTED_HOURS`),
  KEY `TIME_STATUS` (`TIME_STATUS`),
  KEY `INTERFACE_STATUS` (`INTERFACE_STATUS`),
  KEY `ACTUAL_HOURS` (`ACTUAL_HOURS`),
  KEY `BUDGETED_HOURS` (`BUDGETED_HOURS`),
  KEY `COMMENT` (`COMMENT`),
  KEY `ENTRY_DATE` (`ENTRY_DATE`),
  KEY `APPROVAL_DATE` (`APPROVAL_DATE`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_te_approved`
--

LOCK TABLES `cxs_te_approved` WRITE;
/*!40000 ALTER TABLE `cxs_te_approved` DISABLE KEYS */;
INSERT INTO `cxs_te_approved` (`EI_APPROVAL_ID`, `TE_ID`, `RESOURCE_ID`, `ALIAS_ID`, `ADJUSTED_HOURS`, `TIME_STATUS`, `INTERFACE_STATUS`, `ACTUAL_HOURS`, `BUDGETED_HOURS`, `COMMENT`, `ENTRY_DATE`, `APPROVAL_DATE`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,1,3,7,0,'','',8,0,'','2018-08-09','2018-08-14',38,'2018-08-14 09:37:30',38,'2018-08-14 15:37:30',0),(2,1,3,7,0,'','',8,0,'','2018-08-09','2018-08-14',38,'2018-08-14 09:37:30',38,'2018-08-14 15:37:30',0),(3,1,3,7,0,'','',8,0,'Approved. ','2018-08-08','2018-08-14',38,'2018-08-14 09:37:47',38,'2018-08-14 15:37:47',0),(4,1,3,7,0,'','',8,0,'Approved. ','2018-08-08','2018-08-14',38,'2018-08-14 09:37:47',38,'2018-08-14 15:37:47',0),(5,1,3,0,0,'','',8,0,'','2018-08-06','2018-08-14',38,'2018-08-14 09:38:59',38,'2018-08-14 15:38:59',0),(6,1,3,0,0,'','',8,0,'','2018-08-06','2018-08-14',38,'2018-08-14 09:38:59',38,'2018-08-14 15:38:59',0),(7,1,3,0,0,'','',8,0,'','2018-08-06','2018-08-14',38,'2018-08-14 09:39:00',38,'2018-08-14 15:39:00',0),(8,1,3,0,0,'','',8,0,'','2018-08-06','2018-08-14',38,'2018-08-14 09:39:00',38,'2018-08-14 15:39:00',0),(9,2,5,9,0,'','',8,0,'','2018-08-17','2018-08-15',41,'2018-08-15 11:28:06',41,'2018-08-15 17:28:06',0),(10,2,5,10,0,'','',8,0,'','2018-08-16','2018-08-15',41,'2018-08-15 11:28:09',41,'2018-08-15 17:28:09',0),(11,2,5,9,0,'','',8,0,'','2018-08-16','2018-08-15',41,'2018-08-15 11:28:23',41,'2018-08-15 17:28:23',0),(12,3,7,9,0,'','',8,0,'','2018-08-16','2018-08-15',41,'2018-08-15 17:13:31',41,'2018-08-15 23:13:31',0),(13,3,7,12,0,'','',8,0,'','2018-08-16','2018-08-15',41,'2018-08-15 17:13:34',41,'2018-08-15 23:13:34',0),(14,3,7,0,0,'','',8,0,'','2018-08-15','2018-08-15',41,'2018-08-15 17:13:39',41,'2018-08-15 23:13:39',0),(15,3,7,9,0,'','',8,0,'','2018-08-14','2018-08-15',41,'2018-08-15 17:13:40',41,'2018-08-15 23:13:40',0),(16,3,7,12,0,'','',8,0,'','2018-08-14','2018-08-15',41,'2018-08-15 17:13:41',41,'2018-08-15 23:13:41',0),(17,3,7,12,0,'','',8,0,'','2018-08-13','2018-08-15',41,'2018-08-15 17:13:42',41,'2018-08-15 23:13:42',0),(18,4,8,9,0,'','',8,0,'ABC','2018-08-17','2018-08-16',41,'2018-08-16 11:18:16',41,'2018-08-16 17:18:16',0),(19,4,8,9,0,'','',8,0,'DEF','2018-08-16','2018-08-16',41,'2018-08-16 11:18:18',41,'2018-08-16 17:18:18',0),(20,4,8,0,0,'','',8,0,'GHI','2018-08-15','2018-08-16',41,'2018-08-16 11:18:21',41,'2018-08-16 17:18:21',0),(21,4,8,9,0,'','',8,0,'LMN','2018-08-15','2018-08-16',41,'2018-08-16 11:18:22',41,'2018-08-16 17:18:22',0),(22,4,8,11,0,'','',8,0,'OPE','2018-08-15','2018-08-16',41,'2018-08-16 11:18:22',41,'2018-08-16 17:18:22',0),(23,4,8,9,0,'','',8,0,'SAFFASFD','2018-08-14','2018-08-16',41,'2018-08-16 11:18:23',41,'2018-08-16 17:18:23',0),(24,4,8,11,0,'','',8,0,'SFDSAFSAF','2018-08-14','2018-08-16',41,'2018-08-16 11:18:23',41,'2018-08-16 17:18:23',0),(25,4,8,9,0,'','',8,0,'AFDAFSA','2018-08-13','2018-08-16',41,'2018-08-16 11:18:24',41,'2018-08-16 17:18:24',0),(26,4,8,11,0,'','',2,0,'ASFAFA','2018-08-13','2018-08-16',41,'2018-08-16 11:18:25',41,'2018-08-16 17:18:25',0),(27,9,15,17,0,'','',7,0,'','2018-09-17','2018-09-18',53,'2018-09-18 16:01:47',53,'2018-09-18 22:01:47',0);
/*!40000 ALTER TABLE `cxs_te_approved` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_te_file`
--

DROP TABLE IF EXISTS `cxs_te_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_te_file` (
  `DETAIL_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TE_ID` bigint(20) NOT NULL DEFAULT '0',
  `APPROVAL_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `WBS_ID` bigint(20) NOT NULL DEFAULT '0',
  `ALIAS_ID` bigint(20) NOT NULL DEFAULT '0',
  `SEED_ALIAS` varchar(240) NOT NULL,
  `PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `ENTRY_DATE` date DEFAULT NULL,
  `HOURS` float DEFAULT NULL,
  `STATUS_FLAG` varchar(1) NOT NULL DEFAULT '',
  `COMMENT` varchar(250) NOT NULL DEFAULT '',
  `ENTRY_TYPE` varchar(1) NOT NULL DEFAULT '',
  `ROW_NO` bigint(20) NOT NULL DEFAULT '0',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED_LOGIN` bigint(10) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SHIFT` varchar(100) NOT NULL DEFAULT '',
  `APPROVER_COMMENT` varchar(100) NOT NULL DEFAULT '',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`DETAIL_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `TE_ID` (`TE_ID`),
  KEY `APPROVAL_ID` (`APPROVAL_ID`),
  KEY `RESOURCE_ID` (`RESOURCE_ID`),
  KEY `WBS_ID` (`WBS_ID`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `SEED_ALIAS` (`SEED_ALIAS`),
  KEY `PERIOD_ID` (`PERIOD_ID`),
  KEY `ENTRY_DATE` (`ENTRY_DATE`),
  KEY `HOURS` (`HOURS`),
  KEY `STATUS_FLAG` (`STATUS_FLAG`),
  KEY `COMMENT` (`COMMENT`),
  KEY `ENTRY_TYPE` (`ENTRY_TYPE`),
  KEY `ROW_NO` (`ROW_NO`),
  KEY `LAST_UPDATED_LOGIN` (`LAST_UPDATED_LOGIN`),
  KEY `SHIFT` (`SHIFT`),
  KEY `APPROVER_COMMENT` (`APPROVER_COMMENT`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_te_file`
--

LOCK TABLES `cxs_te_file` WRITE;
/*!40000 ALTER TABLE `cxs_te_file` DISABLE KEYS */;
INSERT INTO `cxs_te_file` (`DETAIL_ID`, `TE_ID`, `APPROVAL_ID`, `RESOURCE_ID`, `WBS_ID`, `ALIAS_ID`, `SEED_ALIAS`, `PERIOD_ID`, `ENTRY_DATE`, `HOURS`, `STATUS_FLAG`, `COMMENT`, `ENTRY_TYPE`, `ROW_NO`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATED_LOGIN`, `LAST_UPDATE_DATE`, `SHIFT`, `APPROVER_COMMENT`, `SITE_ID`) VALUES (1,1,1,3,0,0,'HOL-August6 Holiday',1,'2018-08-06',8,'R','','A',1,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:39:00','','',18),(2,1,1,3,4,7,'',1,'2018-08-07',8,'R','','A',2,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:38:34','STD - Straight Time /Day','',18),(3,1,1,3,4,7,'',1,'2018-08-07',8,'R','','A',3,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:38:34','STD - Straight Time /Day','',18),(4,1,1,3,4,7,'',1,'2018-08-08',8,'A','','A',2,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:37:47','STD - Straight Time /Day','Approved. ',18),(5,1,1,3,4,7,'',1,'2018-08-08',8,'A','','A',3,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:37:47','STD - Straight Time /Day','Approved. ',18),(6,1,1,3,4,7,'',1,'2018-08-09',8,'A','','A',2,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:37:30','STD - Straight Time /Day','',18),(7,1,1,3,4,7,'',1,'2018-08-09',8,'A','','A',3,37,'2018-08-12 12:18:23',38,0,'2018-08-14 15:37:30','STD - Straight Time /Day','',18),(8,2,6,5,8,9,'',25,'2018-08-13',8,'A','','A',2,40,'2018-08-14 17:08:58',40,0,'2018-08-14 23:12:14','STD - Straight Time /Day','',21),(9,2,6,5,11,10,'',25,'2018-08-13',8,'A','','A',3,40,'2018-08-14 17:08:58',40,0,'2018-08-14 23:12:14','STD - Straight Time /Day','',21),(10,2,6,5,8,9,'',25,'2018-08-14',8,'A','','A',2,40,'2018-08-14 17:08:58',40,0,'2018-08-14 23:12:14','STD - Straight Time /Day','',21),(11,2,6,5,11,10,'',25,'2018-08-14',8,'A','','A',3,40,'2018-08-14 17:08:58',40,0,'2018-08-14 23:12:14','STD - Straight Time /Day','',21),(12,2,6,5,0,0,'HOL-15TH AUGUST  ',25,'2018-08-15',8,'A','','A',1,40,'2018-08-14 17:08:58',40,0,'2018-08-14 23:12:14','','',21),(13,2,6,5,8,9,'',25,'2018-08-16',8,'A','','A',2,40,'2018-08-14 17:08:58',41,0,'2018-08-15 17:28:23','STD - Straight Time /Day','',21),(14,2,6,5,11,10,'',25,'2018-08-16',8,'A','','A',3,40,'2018-08-14 17:08:58',41,0,'2018-08-15 17:28:09','STD - Straight Time /Day','',21),(15,2,6,5,8,9,'',25,'2018-08-17',8,'A','','A',2,40,'2018-08-14 17:08:58',41,0,'2018-08-15 17:28:06','STD - Straight Time /Day','',21),(16,3,6,7,8,9,'',25,'2018-08-13',8,'A','','A',2,42,'2018-08-15 17:11:56',42,0,'2018-08-15 23:12:08','STD - Straight Time /Day','',21),(17,3,6,7,11,12,'',25,'2018-08-13',8,'A','','A',3,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:42','STD - Straight Time /Day','',21),(18,3,6,7,8,9,'',25,'2018-08-14',8,'A','','A',2,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:40','STD - Straight Time /Day','',21),(19,3,6,7,11,12,'',25,'2018-08-14',8,'A','','A',3,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:41','STD - Straight Time /Day','',21),(20,3,6,7,0,0,'HOL-15TH AUGUST ',25,'2018-08-15',8,'A','','A',1,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:39','','',21),(21,3,6,7,8,9,'',25,'2018-08-16',8,'A','','A',2,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:31','STD - Straight Time /Day','',21),(22,3,6,7,11,12,'',25,'2018-08-16',8,'A','','A',3,42,'2018-08-15 17:11:56',41,0,'2018-08-15 23:13:34','STD - Straight Time /Day','',21),(23,4,6,8,8,9,'',25,'2018-08-13',8,'A','','A',2,43,'2018-08-16 11:13:39',41,0,'2018-08-16 17:18:24','STD - Straight Time /Day','AFDAFSA',21),(24,4,6,8,11,11,'',25,'2018-08-13',2,'A','','A',3,43,'2018-08-16 11:13:39',41,0,'2018-08-16 17:18:25','STD - Straight Time /Day','ASFAFA',21),(25,4,6,8,8,9,'',25,'2018-08-14',8,'A','','A',2,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:23','STD - Straight Time /Day','SAFFASFD',21),(26,4,6,8,11,11,'',25,'2018-08-14',8,'A','','A',3,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:23','STD - Straight Time /Day','SFDSAFSAF',21),(27,4,6,8,0,0,'HOL-15TH AUGUST ',25,'2018-08-15',8,'A','','A',1,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:21','','GHI',21),(28,4,6,8,8,9,'',25,'2018-08-15',8,'A','','A',2,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:22','STD - Straight Time /Day','LMN',21),(29,4,6,8,11,11,'',25,'2018-08-15',8,'A','','A',3,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:22','STD - Straight Time /Day','OPE',21),(30,4,6,8,8,9,'',25,'2018-08-16',8,'A','','A',2,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:18','STD - Straight Time /Day','DEF',21),(31,4,6,8,8,9,'',25,'2018-08-17',8,'A','','A',2,43,'2018-08-16 11:15:45',41,0,'2018-08-16 17:18:16','STD - Straight Time /Day','ABC',21),(32,5,11,10,7,14,'',13,'2018-08-13',2,'W','test','A',1,34,'2018-08-18 01:41:11',34,0,'2018-08-22 05:36:48','STD - Straight Time /Day','',19),(33,5,11,10,7,14,'',13,'2018-08-14',1,'W','','A',1,34,'2018-08-18 01:41:11',34,0,'2018-08-22 05:36:42','STD - Straight Time /Day','',19),(34,5,11,10,7,14,'',13,'2018-08-15',4,'W','','A',1,34,'2018-08-18 01:41:11',34,0,'2018-08-18 07:43:57','STD - Straight Time /Day','',19),(35,5,11,10,7,14,'',13,'2018-08-20',2,'W','','A',1,34,'2018-08-21 23:43:47',34,0,'2018-08-27 17:28:57','STD - Straight Time /Day','',19),(36,5,11,10,7,14,'',13,'2018-08-21',2,'W','','A',1,34,'2018-08-21 23:43:47',34,0,'2018-08-22 05:43:47','STD - Straight Time /Day','',19),(37,6,6,9,8,9,'',25,'2018-08-20',8,'A','','A',3,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','STD - Straight Time /Day','',21),(38,6,6,9,11,11,'',25,'2018-08-20',8,'A','','A',4,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','STD - Straight Time /Day','',21),(39,6,6,9,8,9,'',25,'2018-08-21',8,'A','','A',3,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','STD - Straight Time /Day','',21),(40,6,6,9,11,11,'',25,'2018-08-21',8,'A','','A',4,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','STD - Straight Time /Day','',21),(41,6,6,9,0,0,'HOL-22TH AUGUAST',25,'2018-08-22',8,'A','','A',1,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','','',21),(42,6,6,9,0,0,'HOL-23RD AUGUST',25,'2018-08-23',8,'A','','A',2,44,'2018-08-24 11:39:00',44,0,'2018-08-24 17:39:09','','',21),(43,5,11,10,7,13,'',13,'2018-08-20',3,'W','','A',2,34,'2018-08-27 11:29:26',34,0,'2018-08-27 17:29:26','STE - Straight Time /Evening','',19),(44,5,11,10,7,13,'',13,'2018-08-21',3,'W','','A',2,34,'2018-08-27 11:29:26',34,0,'2018-08-27 17:29:26','STE - Straight Time /Evening','',19),(45,6,6,9,8,9,'',25,'2018-08-20',8,'W','','A',1,44,'2018-08-27 12:13:46',44,0,'2018-08-27 18:13:46','STD - Straight Time /Day','',21),(46,6,6,9,11,11,'',25,'2018-08-20',8,'W','','A',2,44,'2018-08-27 12:13:46',44,0,'2018-08-27 18:13:46','STD - Straight Time /Day','',21),(47,6,6,9,8,9,'',25,'2018-08-27',8,'S','','A',1,44,'2018-08-27 12:14:23',44,0,'2018-08-27 18:14:27','STE - Straight Time /Evening','',21),(48,6,6,9,8,9,'',25,'2018-08-28',8,'S','','A',1,44,'2018-08-27 12:14:23',44,0,'2018-08-27 18:14:27','STE - Straight Time /Evening','',21),(49,5,11,10,7,14,'',13,'2018-08-27',2,'W','','A',1,34,'2018-08-28 18:26:36',34,0,'2018-08-29 00:26:36','STD - Straight Time /Day','',19),(50,5,11,10,7,13,'',13,'2018-08-27',3,'W','','A',2,34,'2018-08-31 04:09:43',34,0,'2018-08-31 10:09:43','STD - Straight Time /Day','',19),(51,5,11,10,7,13,'',13,'2018-08-28',2,'W','','A',2,34,'2018-08-31 04:09:43',34,0,'2018-08-31 10:09:43','STD - Straight Time /Day','',19),(52,8,6,9,8,9,'',26,'2018-09-03',8,'W','','A',1,44,'2018-09-02 22:47:59',44,0,'2018-09-03 04:47:59','STD - Straight Time /Day','',21),(53,8,6,9,11,11,'',26,'2018-09-03',2,'W','','A',2,44,'2018-09-02 22:47:59',44,0,'2018-09-03 04:47:59','STD - Straight Time /Day','',21),(54,8,6,9,8,9,'',26,'2018-09-04',8,'W','','A',1,44,'2018-09-02 22:47:59',44,0,'2018-09-03 04:47:59','STD - Straight Time /Day','',21),(55,8,6,9,11,11,'',26,'2018-09-04',2,'W','','A',2,44,'2018-09-02 22:47:59',44,0,'2018-09-03 04:47:59','STD - Straight Time /Day','',21),(63,7,11,10,7,14,'',14,'2018-09-06',8,'W','','A',4,34,'2018-09-06 16:44:24',34,0,'2018-09-06 22:44:24','STD - Straight Time /Day','',19),(62,7,11,10,0,0,'HOL-d     ',14,'2018-09-05',10,'W','','A',2,34,'2018-09-03 06:54:59',34,0,'2018-09-07 18:17:25','','',19),(61,7,11,10,0,0,'HOL-d     ',14,'2018-09-04',10,'W','','A',1,34,'2018-09-03 06:54:59',34,0,'2018-09-07 18:17:25','','',19),(60,7,11,10,7,14,'',14,'2018-09-03',15,'S','','A',3,34,'2018-09-03 06:54:59',34,0,'2018-09-06 22:31:54','STD - Straight Time /Day','',19),(64,7,11,10,7,14,'',14,'2018-09-03',3,'W','','A',4,34,'2018-09-07 12:14:56',34,0,'2018-09-07 18:15:56','STD - Straight Time /Day','',19),(65,7,11,10,7,14,'',14,'2018-09-04',2,'W','','A',4,34,'2018-09-07 12:14:56',34,0,'2018-09-07 18:14:56','STD - Straight Time /Day','',19),(66,7,11,10,7,14,'',14,'2018-09-05',4,'W','','A',4,34,'2018-09-07 12:17:25',34,0,'2018-09-07 18:17:25','STD - Straight Time /Day','',19),(67,9,13,15,15,17,'',26,'2018-09-17',7,'A','','A',1,54,'2018-09-17 23:21:19',53,0,'2018-09-18 22:01:47','STD - Straight Time /Day','',21),(68,9,13,15,14,16,'',26,'2018-09-17',1,'S','','A',2,54,'2018-09-17 23:21:19',54,0,'2018-09-18 05:21:35','STD - Straight Time /Day','',21);
/*!40000 ALTER TABLE `cxs_te_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_te_header`
--

DROP TABLE IF EXISTS `cxs_te_header`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_te_header` (
  `TE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TE_NAME` varchar(40) NOT NULL,
  `TE_PREFIX` varchar(20) NOT NULL,
  `TE_DESCR` varchar(240) NOT NULL DEFAULT 'Y',
  `PAY_PERIOD_ID` bigint(20) NOT NULL DEFAULT '0',
  `RESOURCE_ID` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID2` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID3` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID4` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID5` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID6` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID7` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID8` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID9` bigint(20) NOT NULL DEFAULT '0',
  `SUPERVISOR_ID10` bigint(20) NOT NULL DEFAULT '0',
  `TEMPORARY_SUPERVISOR` bigint(20) NOT NULL DEFAULT '0',
  `STATUS` varchar(40) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATE_LOGIN` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TE_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `TE_NAME` (`TE_NAME`),
  KEY `TE_PREFIX` (`TE_PREFIX`),
  KEY `TE_DESCR` (`TE_DESCR`),
  KEY `PAY_PERIOD_ID` (`PAY_PERIOD_ID`),
  KEY `RESOURCE_ID` (`RESOURCE_ID`),
  KEY `SUPERVISOR_ID` (`SUPERVISOR_ID`),
  KEY `SUPERVISOR_ID2` (`SUPERVISOR_ID2`),
  KEY `SUPERVISOR_ID3` (`SUPERVISOR_ID3`),
  KEY `SUPERVISOR_ID4` (`SUPERVISOR_ID4`),
  KEY `STATUS` (`STATUS`),
  KEY `LAST_UPDATE_LOGIN` (`LAST_UPDATE_LOGIN`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_te_header`
--

LOCK TABLES `cxs_te_header` WRITE;
/*!40000 ALTER TABLE `cxs_te_header` DISABLE KEYS */;
INSERT INTO `cxs_te_header` (`TE_ID`, `TE_NAME`, `TE_PREFIX`, `TE_DESCR`, `PAY_PERIOD_ID`, `RESOURCE_ID`, `SUPERVISOR_ID`, `SUPERVISOR_ID2`, `SUPERVISOR_ID3`, `SUPERVISOR_ID4`, `SUPERVISOR_ID5`, `SUPERVISOR_ID6`, `SUPERVISOR_ID7`, `SUPERVISOR_ID8`, `SUPERVISOR_ID9`, `SUPERVISOR_ID10`, `TEMPORARY_SUPERVISOR`, `STATUS`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_LOGIN`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,'RVAISHNAV- AUG-2018 ','TETEST1','',1,3,1,0,0,0,0,0,0,0,0,0,0,'Open',37,'2018-08-08 09:10:37',37,0,'2018-08-08 15:10:37',0),(2,'WFARGO- AUG-2018 ','AUG','',25,5,6,0,0,0,0,0,0,0,0,0,0,'Open',40,'2018-08-14 17:07:27',40,0,'2018-08-14 23:07:27',21),(3,'OCTLA- AUG-2018 ','ORAWOLF','TIME ENTRY FOR AUGUST 2018',25,7,6,0,0,0,0,0,0,0,0,0,0,'Open',42,'2018-08-15 16:50:05',42,0,'2018-08-15 22:50:05',21),(4,'PTAMAKA- AUG-2018 ','PTAMAMKA','',25,8,6,0,0,0,0,0,0,0,0,0,0,'Open',43,'2018-08-16 11:13:11',43,0,'2018-08-16 17:13:11',21),(5,'ATechnologies- AUG-2018 ','TESTENTRY','',13,10,11,0,0,0,0,0,0,0,0,0,0,'Open',34,'2018-08-18 01:40:54',34,0,'2018-08-18 07:40:54',19),(6,'ABOB- AUG-2018 ','BOB','',25,9,6,0,0,0,0,0,0,0,0,0,0,'Open',44,'2018-08-20 12:08:06',44,0,'2018-08-20 18:08:06',21),(7,'ATechnologies- SEP-2018 ','FF','',14,10,11,0,0,0,0,0,0,0,0,0,0,'Open',34,'2018-09-02 18:42:54',34,0,'2018-09-03 00:42:54',19),(8,'ABOB- SEP-2018 ','SEP','',26,9,6,0,0,0,0,0,0,0,0,0,0,'Open',44,'2018-09-02 22:46:44',44,0,'2018-09-03 04:46:44',21),(9,'BTABAKA- SEP-2018 ','SEP','',26,15,13,0,0,0,0,0,0,0,0,0,0,'Open',54,'2018-09-17 23:20:22',54,0,'2018-09-18 05:20:22',21);
/*!40000 ALTER TABLE `cxs_te_header` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_temp_approver`
--

DROP TABLE IF EXISTS `cxs_temp_approver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_temp_approver` (
  `USER_ID` bigint(20) NOT NULL,
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PERIOD_ID` bigint(20) NOT NULL,
  `ALIAS_ID` bigint(20) NOT NULL,
  `ACTIVE_FLAG` varchar(1) NOT NULL,
  `ROWNO` bigint(20) NOT NULL,
  `RESOURCE_GROUP_ID` bigint(20) NOT NULL DEFAULT '0',
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  KEY `USER_ID` (`USER_ID`),
  KEY `PERIOD_ID` (`PERIOD_ID`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `ALIAS_ID` (`ALIAS_ID`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `ROWNO` (`ROWNO`),
  KEY `RESOURCE_GROUP_ID` (`RESOURCE_GROUP_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_temp_approver`
--

LOCK TABLES `cxs_temp_approver` WRITE;
/*!40000 ALTER TABLE `cxs_temp_approver` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_temp_approver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_users`
--

DROP TABLE IF EXISTS `cxs_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_users` (
  `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(40) DEFAULT NULL,
  `ENC_KEY` varchar(240) DEFAULT NULL,
  `TEMP_PASSWORD` varchar(1) DEFAULT NULL,
  `RESET_DAYS` bigint(20) DEFAULT NULL,
  `PSW_RESET_DATE` date NOT NULL,
  `RESOURCE_ID` bigint(20) NOT NULL,
  `ROLE_ID` bigint(20) NOT NULL,
  `ROLE_START_DATE` date NOT NULL,
  `ROLE_END_DATE` date NOT NULL,
  `PHOTO` varchar(255) NOT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date NOT NULL,
  `PWD_RULE_CODE` varchar(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  `LAST_LOGIN_TIME` datetime NOT NULL,
  `LAST_LOGOUT_TIME` datetime NOT NULL,
  PRIMARY KEY (`USER_ID`,`RESOURCE_ID`),
  KEY `CXS_USERS_U1` (`USER_ID`),
  KEY `USER_NAME` (`USER_NAME`),
  KEY `ENC_KEY` (`ENC_KEY`),
  KEY `TEMP_PASSWORD` (`TEMP_PASSWORD`),
  KEY `RESET_DAYS` (`RESET_DAYS`),
  KEY `PSW_RESET_DATE` (`PSW_RESET_DATE`),
  KEY `ROLE_ID` (`ROLE_ID`),
  KEY `ROLE_START_DATE` (`ROLE_START_DATE`),
  KEY `ROLE_END_DATE` (`ROLE_END_DATE`),
  KEY `PHOTO` (`PHOTO`),
  KEY `START_DATE` (`START_DATE`),
  KEY `END_DATE` (`END_DATE`),
  KEY `PWD_RULE_CODE` (`PWD_RULE_CODE`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `LAST_LOGIN_TIME` (`LAST_LOGIN_TIME`),
  KEY `LAST_LOGOUT_TIME` (`LAST_LOGOUT_TIME`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_users`
--

LOCK TABLES `cxs_users` WRITE;
/*!40000 ALTER TABLE `cxs_users` DISABLE KEYS */;
INSERT INTO `cxs_users` (`USER_ID`, `USER_NAME`, `ENC_KEY`, `TEMP_PASSWORD`, `RESET_DAYS`, `PSW_RESET_DATE`, `RESOURCE_ID`, `ROLE_ID`, `ROLE_START_DATE`, `ROLE_END_DATE`, `PHOTO`, `START_DATE`, `END_DATE`, `PWD_RULE_CODE`, `CREATION_DATE`, `LAST_UPDATE_DATE`, `CREATED_BY`, `LAST_UPDATED_BY`, `SITE_ID`, `LAST_LOGIN_TIME`, `LAST_LOGOUT_TIME`) VALUES (34,'APPLISOFT4U@GMAIL.COM','×øíðö÷øõ½¨','N',NULL,'2018-09-07',10,0,'0000-00-00','0000-00-00','','2018-08-03','0000-00-00','','2018-08-03 23:14:06','2018-09-19 10:34:11',0,34,19,'2018-09-19 04:34:11','2018-09-17 20:50:51'),(33,'A@C.COM','×øíðö÷øõ½¨',NULL,NULL,'0000-00-00',0,0,'0000-00-00','0000-00-00','','2018-07-30','0000-00-00','','2018-07-30 04:53:43','2018-08-08 07:58:57',7,7,7,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(35,'ORAWOLFX@GMAIL.COM','ßªôðõà¨«íñëüü½','N',NULL,'2018-08-07',4,1,'2018-08-01','0000-00-00','8822logo.jpg','2018-08-05','0000-00-00','','2018-08-05 10:41:33','2018-09-03 00:58:16',0,35,18,'2018-09-02 18:52:27','2018-09-02 18:58:16'),(36,'XYZ@XYZ1.COM','ßªôðõà¨«ßðïü½','N',NULL,'2018-08-05',2,1,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-05 13:09:25','2018-08-05 21:30:56',35,35,18,'2018-08-05 15:26:06','2018-08-05 15:30:56'),(37,'RUCHIR.VAISHNAV@GMAIL.COM','íþô¤ÿßéº','Y',NULL,'2018-09-07',3,1,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-07 23:14:48','2018-09-18 04:14:21',35,35,18,'2018-09-07 22:37:04','2018-09-07 23:24:35'),(38,'RUCHIR.VAISHNAV@DGS.CA.GOV','ßªôðõà¨«íñëüü½','N',NULL,'2018-08-14',1,1,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-14 09:35:50','2018-09-03 00:58:57',37,37,18,'2018-09-02 18:58:39','2018-09-02 18:58:57'),(39,'PARTHIVI.V@GMAIL.COM','ßªôðõà¨«íñëüü½','N',NULL,'2018-09-17',0,0,'0000-00-00','0000-00-00','testpic2.JPG','2018-08-14','0000-00-00','','2018-08-14 09:57:15','2018-09-19 16:34:44',0,0,21,'2018-09-19 10:34:44','2018-09-17 23:14:57'),(40,'RUCHIR.VAISHNAV@COEXSYS.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-14',5,4,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-14 16:28:28','2018-08-15 20:21:45',39,39,21,'2018-08-15 14:21:45','2018-08-15 14:21:28'),(41,'SERVICE@COEXSYS.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-15',6,0,'0000-00-00','0000-00-00','','2018-08-01','0000-00-00','','2018-08-14 16:28:50','2018-08-16 17:18:42',39,39,21,'2018-08-16 11:16:46','2018-08-16 11:18:42'),(42,'ORAWOLFX1@AOL.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-15',7,4,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-15 15:32:04','2018-08-20 17:22:28',39,39,21,'2018-08-20 11:21:51','2018-08-20 11:22:28'),(43,'PTAMAKA@AOL.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-16',8,4,'2018-08-01','0000-00-00','','2018-08-01','0000-00-00','','2018-08-16 10:50:25','2018-08-16 17:51:34',39,39,21,'2018-08-16 11:48:24','2018-08-16 11:51:34'),(44,'BOB@AOL.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-17',9,0,'0000-00-00','0000-00-00','','2018-08-01','0000-00-00','','2018-08-17 10:34:40','2018-09-07 15:52:36',39,39,21,'2018-09-07 09:52:36','2018-09-04 22:06:15'),(45,'TEST@TEST.COM','×øíðö÷øõ½¨',NULL,NULL,'0000-00-00',11,0,'0000-00-00','0000-00-00','','2018-08-18','0000-00-00','','2018-08-18 01:48:59','2018-08-18 07:48:59',34,34,19,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(46,'AWW@AWW.COM','×øíð©÷øõ¨½','N',NULL,'2018-08-20',12,0,'0000-00-00','0000-00-00','','2018-08-01','0000-00-00','','2018-08-20 12:39:29','2018-08-20 18:41:06',39,39,21,'2018-08-20 12:41:06','0000-00-00 00:00:00'),(47,'SERVICE@COEXSYS.COM','Øèý¬ÔÁê«',NULL,NULL,'0000-00-00',0,0,'0000-00-00','0000-00-00','','2018-08-27','0000-00-00','','2018-08-27 15:40:41','2018-08-27 21:40:41',0,0,20,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(48,'KYLEMWHITE@GMAIL.COM','ÿËãÍíô­¯ûÙÝêÛÀà¯¼ºË ¯','N',NULL,'2018-09-06',0,0,'0000-00-00','0000-00-00','','2018-09-06','0000-00-00','','2018-09-06 14:49:57','2018-09-06 20:51:08',0,0,22,'2018-09-06 14:51:08','0000-00-00 00:00:00'),(52,'RUCHIR.VAISHNAV@GMAIL.COM','óÔêá¡Ãþò',NULL,NULL,'0000-00-00',0,0,'0000-00-00','0000-00-00','','2018-09-17','0000-00-00','','2018-09-17 22:11:02','2018-09-18 04:11:02',0,0,26,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(51,'AFFILIATE@COEXSYS.COM','òÀÛ«­¯¬á','Y',NULL,'0000-00-00',0,0,'0000-00-00','0000-00-00','','2018-09-17','0000-00-00','','2018-09-17 22:03:46','2018-09-18 04:05:34',0,0,25,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(53,'JEFF.STRICKLER@DSS.CA.GOV','Úøõðÿöë÷ðø¨½','N',NULL,'2018-09-17',13,4,'2018-09-17','0000-00-00','jeff.jpg','2018-09-17','0000-00-00','','2018-09-17 23:08:53','2018-09-18 22:07:24',39,39,21,'2018-09-18 16:07:13','2018-09-18 16:07:24'),(54,'BOB.TABAKA@DSS.CA.GOV','Úøõðÿöë÷ðø¨½','N',NULL,'2018-09-17',15,0,'0000-00-00','0000-00-00','bob.jpg','2018-09-17','0000-00-00','','2018-09-17 23:09:32','2018-09-20 00:57:49',39,39,21,'2018-09-19 18:57:49','2018-09-19 09:05:53'),(55,'JOHN.SMITH@DSS.CA.GOV','Úøõðÿöë÷ðø¨½','N',NULL,'2018-09-17',14,0,'0000-00-00','0000-00-00','john.jpg','2018-09-17','0000-00-00','','2018-09-17 23:10:25','2018-09-18 05:24:35',39,39,21,'2018-09-17 23:24:02','2018-09-17 23:24:35');
/*!40000 ALTER TABLE `cxs_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_users_favorites`
--

DROP TABLE IF EXISTS `cxs_users_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_users_favorites` (
  `USER_ID` bigint(20) NOT NULL,
  `FEATURE_NAME` varchar(40) NOT NULL,
  `PAGE_NAME` varchar(40) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MODULE_NAME` varchar(50) NOT NULL DEFAULT '',
  KEY `USER_ID` (`USER_ID`),
  KEY `FEATURE_NAME` (`FEATURE_NAME`),
  KEY `PAGE_NAME` (`PAGE_NAME`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `MODULE_NAME` (`MODULE_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_users_favorites`
--

LOCK TABLES `cxs_users_favorites` WRITE;
/*!40000 ALTER TABLE `cxs_users_favorites` DISABLE KEYS */;
INSERT INTO `cxs_users_favorites` (`USER_ID`, `FEATURE_NAME`, `PAGE_NAME`, `LAST_UPDATE_DATE`, `MODULE_NAME`) VALUES (35,'Time Entry','time-entry.php','2018-08-05 17:59:57','Time Accounting'),(35,'Usage History','usage-history.php','2018-08-06 04:57:10','Access Management'),(35,'Dashboard','rbam.php','2018-08-07 19:35:24','Access Management'),(35,'Update Contacts','update-contacts.php','2018-08-07 19:35:40','Access Management'),(35,'Resource Management','resource-management.php','2018-08-07 19:59:22','Time Accounting'),(37,'Dashboard','rbam.php','2018-08-10 04:35:29','Access Management'),(37,'Time Entry','time-entry.php','2018-08-10 04:35:36','Time Accounting'),(37,'Create New Resource','create-new-resource.php','2018-08-14 15:29:56','Time Accounting'),(39,'Access Management','access-management.php','2018-08-14 17:01:40','Access Management'),(39,'Resource Management','resource-management.php','2018-08-17 16:32:08','Time Accounting');
/*!40000 ALTER TABLE `cxs_users_favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_wbs`
--

DROP TABLE IF EXISTS `cxs_wbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_wbs` (
  `WBS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SEQUENCE` bigint(20) NOT NULL DEFAULT '0',
  `SEGMENT1` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT2` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT3` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT4` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT5` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT6` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT7` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT8` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT9` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT10` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT11` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT12` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT13` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT14` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT15` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION1` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION2` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION3` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION4` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION5` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION6` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION7` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION8` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION9` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION10` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION11` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION12` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION13` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION14` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION15` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG1` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG2` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG3` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG4` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG5` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG6` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG7` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG8` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG9` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG10` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG11` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG12` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG13` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG14` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG15` varchar(100) NOT NULL DEFAULT '',
  `IN_USE1` varchar(100) NOT NULL DEFAULT '',
  `IN_USE2` varchar(100) NOT NULL DEFAULT '',
  `IN_USE3` varchar(100) NOT NULL DEFAULT '',
  `IN_USE4` varchar(100) NOT NULL DEFAULT '',
  `IN_USE5` varchar(100) NOT NULL DEFAULT '',
  `IN_USE6` varchar(100) NOT NULL DEFAULT '',
  `IN_USE7` varchar(100) NOT NULL DEFAULT '',
  `IN_USE8` varchar(100) NOT NULL DEFAULT '',
  `IN_USE9` varchar(100) NOT NULL DEFAULT '',
  `IN_USE10` varchar(100) NOT NULL DEFAULT '',
  `IN_USE11` varchar(100) NOT NULL DEFAULT '',
  `IN_USE12` varchar(100) NOT NULL DEFAULT '',
  `IN_USE13` varchar(100) NOT NULL DEFAULT '',
  `IN_USE14` varchar(100) NOT NULL DEFAULT '',
  `IN_USE15` varchar(100) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`WBS_ID`),
  KEY `SEQUENCE` (`SEQUENCE`),
  KEY `SEGMENT1` (`SEGMENT1`),
  KEY `SEGMENT2` (`SEGMENT2`),
  KEY `SEGMENT3` (`SEGMENT3`),
  KEY `SEGMENT4` (`SEGMENT4`),
  KEY `SEGMENT5` (`SEGMENT5`),
  KEY `SEGMENT7` (`SEGMENT7`),
  KEY `SEGMENT6` (`SEGMENT6`),
  KEY `SEGMENT8` (`SEGMENT8`),
  KEY `SEGMENT9` (`SEGMENT9`),
  KEY `SEGMENT10` (`SEGMENT10`),
  KEY `SEGMENT11` (`SEGMENT11`),
  KEY `SEGMENT12` (`SEGMENT12`),
  KEY `SEGMENT13` (`SEGMENT13`),
  KEY `SEGMENT14` (`SEGMENT14`),
  KEY `SEGMENT15` (`SEGMENT15`),
  KEY `DESCRIPTION1` (`DESCRIPTION1`),
  KEY `DESCRIPTION2` (`DESCRIPTION2`),
  KEY `DESCRIPTION3` (`DESCRIPTION3`),
  KEY `DESCRIPTION4` (`DESCRIPTION4`),
  KEY `DESCRIPTION5` (`DESCRIPTION5`),
  KEY `DESCRIPTION6` (`DESCRIPTION6`),
  KEY `DESCRIPTION7` (`DESCRIPTION7`),
  KEY `DESCRIPTION8` (`DESCRIPTION8`),
  KEY `DESCRIPTION9` (`DESCRIPTION9`),
  KEY `DESCRIPTION10` (`DESCRIPTION10`),
  KEY `DESCRIPTION11` (`DESCRIPTION11`),
  KEY `DESCRIPTION12` (`DESCRIPTION12`),
  KEY `DESCRIPTION13` (`DESCRIPTION13`),
  KEY `DESCRIPTION14` (`DESCRIPTION14`),
  KEY `DESCRIPTION15` (`DESCRIPTION15`),
  KEY `ACTIVE_FLAG1` (`ACTIVE_FLAG1`),
  KEY `ACTIVE_FLAG2` (`ACTIVE_FLAG2`),
  KEY `ACTIVE_FLAG5` (`ACTIVE_FLAG5`),
  KEY `ACTIVE_FLAG6` (`ACTIVE_FLAG6`),
  KEY `ACTIVE_FLAG9` (`ACTIVE_FLAG9`),
  KEY `ACTIVE_FLAG10` (`ACTIVE_FLAG10`),
  KEY `ACTIVE_FLAG11` (`ACTIVE_FLAG11`),
  KEY `ACTIVE_FLAG12` (`ACTIVE_FLAG12`),
  KEY `ACTIVE_FLAG13` (`ACTIVE_FLAG13`),
  KEY `ACTIVE_FLAG14` (`ACTIVE_FLAG14`),
  KEY `ACTIVE_FLAG15` (`ACTIVE_FLAG15`),
  KEY `IN_USE1` (`IN_USE1`),
  KEY `IN_USE2` (`IN_USE2`),
  KEY `IN_USE3` (`IN_USE3`),
  KEY `SITE_ID` (`SITE_ID`),
  KEY `LAST_UPDATE_DATE` (`LAST_UPDATE_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `IN_USE15` (`IN_USE15`),
  KEY `IN_USE14` (`IN_USE14`),
  KEY `IN_USE13` (`IN_USE13`),
  KEY `IN_USE12` (`IN_USE12`),
  KEY `IN_USE11` (`IN_USE11`),
  KEY `IN_USE10` (`IN_USE10`),
  KEY `IN_USE9` (`IN_USE9`),
  KEY `IN_USE8` (`IN_USE8`),
  KEY `IN_USE7` (`IN_USE7`),
  KEY `IN_USE6` (`IN_USE6`),
  KEY `IN_USE5` (`IN_USE5`),
  KEY `IN_USE4` (`IN_USE4`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_wbs`
--

LOCK TABLES `cxs_wbs` WRITE;
/*!40000 ALTER TABLE `cxs_wbs` DISABLE KEYS */;
INSERT INTO `cxs_wbs` (`WBS_ID`, `SEQUENCE`, `SEGMENT1`, `SEGMENT2`, `SEGMENT3`, `SEGMENT4`, `SEGMENT5`, `SEGMENT6`, `SEGMENT7`, `SEGMENT8`, `SEGMENT9`, `SEGMENT10`, `SEGMENT11`, `SEGMENT12`, `SEGMENT13`, `SEGMENT14`, `SEGMENT15`, `DESCRIPTION1`, `DESCRIPTION2`, `DESCRIPTION3`, `DESCRIPTION4`, `DESCRIPTION5`, `DESCRIPTION6`, `DESCRIPTION7`, `DESCRIPTION8`, `DESCRIPTION9`, `DESCRIPTION10`, `DESCRIPTION11`, `DESCRIPTION12`, `DESCRIPTION13`, `DESCRIPTION14`, `DESCRIPTION15`, `ACTIVE_FLAG1`, `ACTIVE_FLAG2`, `ACTIVE_FLAG3`, `ACTIVE_FLAG4`, `ACTIVE_FLAG5`, `ACTIVE_FLAG6`, `ACTIVE_FLAG7`, `ACTIVE_FLAG8`, `ACTIVE_FLAG9`, `ACTIVE_FLAG10`, `ACTIVE_FLAG11`, `ACTIVE_FLAG12`, `ACTIVE_FLAG13`, `ACTIVE_FLAG14`, `ACTIVE_FLAG15`, `IN_USE1`, `IN_USE2`, `IN_USE3`, `IN_USE4`, `IN_USE5`, `IN_USE6`, `IN_USE7`, `IN_USE8`, `IN_USE9`, `IN_USE10`, `IN_USE11`, `IN_USE12`, `IN_USE13`, `IN_USE14`, `IN_USE15`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATE_DATE`, `SITE_ID`) VALUES (1,0,'test','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N',7,'2018-07-17 00:00:00',7,'2018-07-17 11:50:19',7),(2,0,'DGS000000100504','MT','OP','57000','51000','','','','','','','','','','','','','','','','','','','','','','','','','','Y','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N',15,'2018-07-23 00:00:00',15,'2018-07-23 18:29:06',14),(3,0,'DGS000000100505','MT','OP','57000','51000','','','','','','','','','','','','','','','','','','','','','','','','','','Y','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N',15,'2018-07-23 00:00:00',15,'2018-07-23 18:29:59',14),(4,0,'DGS00001','ACTIVITY0001','CATG001','SUBCATG01','','','','','','','','','','','','A DESCR','AN ACTIVITY','A CATG','A SUBCAT','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',35,'2018-08-05 10:56:27',35,'2018-08-05 16:56:27',18),(5,0,'DGS00001','ACTIVITY0001','CATG001','','','','','','','','','','','','','','','','','','','','','','','','','','','','Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',35,'2018-08-05 15:33:45',35,'2018-08-05 21:33:45',18),(6,0,'DGS00001','ACTIVITY0002','CATG003','','','','','','','','','','','','','','','','','','','','','','','','','','','','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',35,'2018-08-05 15:37:35',35,'2018-08-05 21:37:35',18),(7,0,'ss','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','N','N','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',34,'2018-08-13 06:35:50',34,'2018-08-13 12:35:50',19),(8,0,'DGS000000141340','RT','49004','99999','','','','','','','','','','','','151109-MIL-Sale-Yreka','Review Transaction','Review Transaction','General','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-08-14 10:19:06',39,'2018-08-14 16:19:06',21),(9,0,'DGS000000141340','RT','49004','99999','','','','','','','','','','','','151109-MIL-Sale-Yreka','Review Transaction','Appraisal Review','General','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-08-14 10:20:45',39,'2018-08-14 16:20:45',21),(10,0,'DGS000000141645','PT','49004','99999','','','','','','','','','','','','*160125, DGS, AppRvw','Project Transaction','Appraisal Review','General','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-08-14 10:29:09',39,'2018-08-14 16:29:09',21),(11,0,'DGS000000126009','PT','49002','99999','','','','','','','','','','','','*080103 CDF San Marcos surplus','Project Transaction','Appraisal','General','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-08-14 10:30:15',39,'2018-08-14 16:32:49',21),(12,0,'abc','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',34,'2018-08-31 09:27:35',34,'2018-08-31 15:27:35',19),(13,0,'FISE Maintenence','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','Y','N','N','N','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',48,'2018-09-06 14:52:45',48,'2018-09-06 20:52:45',22),(14,0,'DSS000014100','OP','57000','52000','','','','','','','','','','','','DSS000014100','OPERATIONS','57000','52000','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-09-17 22:47:18',39,'2018-09-18 04:47:18',21),(15,0,'DSS000015100','MT','57000','52000','','','','','','','','','','','','DSS000015100','MAINTENANCE','57000','52000','','','','','','','','','','','','Y','Y','Y','Y','N','N','N','N','N','N','N','N','N','N','N','','','','','','','','','','','','','','','',39,'2018-09-17 22:47:57',39,'2018-09-18 04:47:57',21);
/*!40000 ALTER TABLE `cxs_wbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_wbs123`
--

DROP TABLE IF EXISTS `cxs_wbs123`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_wbs123` (
  `WBS_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SEQUENCE` bigint(20) NOT NULL DEFAULT '0',
  `SEGMENT1` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT2` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT3` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT4` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT5` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT6` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT7` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT8` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT9` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT10` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT11` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT12` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT13` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT14` varchar(100) NOT NULL DEFAULT '',
  `SEGMENT15` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE1` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE2` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE3` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE4` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE5` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE6` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE7` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE8` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE9` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE10` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE11` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE12` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE13` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE14` varchar(100) NOT NULL DEFAULT '',
  `DISPLAY_VALUE15` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION1` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION2` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION3` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION4` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION5` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION6` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION7` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION8` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION9` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION10` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION11` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION12` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION13` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION14` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION15` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP1` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP2` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP3` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP4` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP5` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP6` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP7` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP8` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP9` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP10` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP11` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP12` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP13` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP14` varchar(100) NOT NULL DEFAULT '',
  `ROLLUP15` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG1` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG2` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG3` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG4` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG5` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG6` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG7` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG8` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG9` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG10` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG11` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG12` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG13` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG14` varchar(100) NOT NULL DEFAULT '',
  `ACTIVE_FLAG15` varchar(100) NOT NULL DEFAULT '',
  `IN_USE1` varchar(100) NOT NULL DEFAULT '',
  `IN_USE2` varchar(100) NOT NULL DEFAULT '',
  `IN_USE3` varchar(100) NOT NULL DEFAULT '',
  `IN_USE4` varchar(100) NOT NULL DEFAULT '',
  `IN_USE5` varchar(100) NOT NULL DEFAULT '',
  `IN_USE6` varchar(100) NOT NULL DEFAULT '',
  `IN_USE7` varchar(100) NOT NULL DEFAULT '',
  `IN_USE8` varchar(100) NOT NULL DEFAULT '',
  `IN_USE9` varchar(100) NOT NULL DEFAULT '',
  `IN_USE10` varchar(100) NOT NULL DEFAULT '',
  `IN_USE11` varchar(100) NOT NULL DEFAULT '',
  `IN_USE12` varchar(100) NOT NULL DEFAULT '',
  `IN_USE13` varchar(100) NOT NULL DEFAULT '',
  `IN_USE14` varchar(100) NOT NULL DEFAULT '',
  `IN_USE15` varchar(100) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` date NOT NULL,
  `LAST_UPDATED_BY` bigint(20) NOT NULL,
  `LAST_UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`WBS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_wbs123`
--

LOCK TABLES `cxs_wbs123` WRITE;
/*!40000 ALTER TABLE `cxs_wbs123` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxs_wbs123` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_workshifts`
--

DROP TABLE IF EXISTS `cxs_workshifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_workshifts` (
  `WORKSHIFT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(240) NOT NULL DEFAULT '',
  `TIMEZONE` varchar(240) NOT NULL DEFAULT '',
  `WORKSHIFT_TYPE` varchar(40) NOT NULL DEFAULT '',
  `PART_TIME` varchar(100) NOT NULL DEFAULT '',
  `IN_USE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `ACTIVE_FLAG` varchar(1) NOT NULL DEFAULT '',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SITE_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`WORKSHIFT_ID`),
  KEY `NAME` (`NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `TIMEZONE` (`TIMEZONE`),
  KEY `WORKSHIFT_TYPE` (`WORKSHIFT_TYPE`),
  KEY `PART_TIME` (`PART_TIME`),
  KEY `IN_USE_FLAG` (`IN_USE_FLAG`),
  KEY `ACTIVE_FLAG` (`ACTIVE_FLAG`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATED` (`LAST_UPDATED`),
  KEY `SITE_ID` (`SITE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_workshifts`
--

LOCK TABLES `cxs_workshifts` WRITE;
/*!40000 ALTER TABLE `cxs_workshifts` DISABLE KEYS */;
INSERT INTO `cxs_workshifts` (`WORKSHIFT_ID`, `NAME`, `DESCRIPTION`, `TIMEZONE`, `WORKSHIFT_TYPE`, `PART_TIME`, `IN_USE_FLAG`, `ACTIVE_FLAG`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATED`, `SITE_ID`) VALUES (1,'Shift1','Test Shift','PDT','Flexible Shift','','','N','',7,'2018-07-17 05:31:33',7,'2018-07-17 11:31:42',7),(2,'aSHIFT','2018','PDT','9/8/80 Shift','','','Y','',15,'2018-07-29 21:19:50',15,'2018-07-30 03:19:50',14),(3,'aSHIFTd','2018','CDT','Regular 40Hours Shift','','','Y','',35,'2018-08-05 10:50:26',35,'2018-08-05 20:16:57',18),(4,'PREAPPROVAL SHIFT','PREAPPROVAL SHIFT','HAST','Regular 40Hours Shift','','','Y','',39,'2018-08-14 11:10:11',39,'2018-08-14 17:10:21',21),(5,'workshift1','description workshift','PDT','4/10/40 Shift','','','Y','',34,'2018-08-18 01:36:37',34,'2018-08-18 07:36:37',19),(6,'AWW SHIFT','AWW','HAST','9/8/80 Shift','','','N','',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',21),(7,'DSS REGULAR SHIFT','DSS REGULAR SHIFT','PDT','Regular 40Hours Shift','','','N','',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',21);
/*!40000 ALTER TABLE `cxs_workshifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxs_workshifts_detail`
--

DROP TABLE IF EXISTS `cxs_workshifts_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxs_workshifts_detail` (
  `WORKSHIFT_ID` bigint(20) NOT NULL DEFAULT '0',
  `BEGIN_WORKDAY` varchar(40) NOT NULL DEFAULT '',
  `DAILY_WORK_HOURS` bigint(20) NOT NULL DEFAULT '0',
  `LAST_SESSION_ID` varchar(240) NOT NULL DEFAULT '',
  `CREATED_BY` bigint(20) NOT NULL,
  `CREATION_DATE` datetime DEFAULT NULL,
  `LAST_UPDATED_BY` bigint(10) NOT NULL,
  `LAST_UPDATED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ROW_NO` int(11) NOT NULL DEFAULT '0',
  `SHIFT_HOURS` float NOT NULL DEFAULT '0',
  KEY `WORKSHIFT_ID` (`WORKSHIFT_ID`),
  KEY `BEGIN_WORKDAY` (`BEGIN_WORKDAY`),
  KEY `DAILY_WORK_HOURS` (`DAILY_WORK_HOURS`),
  KEY `LAST_SESSION_ID` (`LAST_SESSION_ID`),
  KEY `CREATED_BY` (`CREATED_BY`),
  KEY `CREATION_DATE` (`CREATION_DATE`),
  KEY `LAST_UPDATED_BY` (`LAST_UPDATED_BY`),
  KEY `LAST_UPDATED` (`LAST_UPDATED`),
  KEY `ROW_NO` (`ROW_NO`),
  KEY `SHIFT_HOURS` (`SHIFT_HOURS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxs_workshifts_detail`
--

LOCK TABLES `cxs_workshifts_detail` WRITE;
/*!40000 ALTER TABLE `cxs_workshifts_detail` DISABLE KEYS */;
INSERT INTO `cxs_workshifts_detail` (`WORKSHIFT_ID`, `BEGIN_WORKDAY`, `DAILY_WORK_HOURS`, `LAST_SESSION_ID`, `CREATED_BY`, `CREATION_DATE`, `LAST_UPDATED_BY`, `LAST_UPDATED`, `ROW_NO`, `SHIFT_HOURS`) VALUES (2,'',0,'',15,'2018-07-29 21:19:51',15,'2018-07-30 03:19:51',1,9),(2,'',0,'',15,'2018-07-29 21:19:51',15,'2018-07-30 03:19:51',2,9),(2,'',0,'',15,'2018-07-29 21:19:51',15,'2018-07-30 03:19:51',3,9),(2,'',0,'',15,'2018-07-29 21:19:51',15,'2018-07-30 03:19:51',4,9),(2,'',0,'',15,'2018-07-29 21:19:51',15,'2018-07-30 03:19:51',5,8),(3,'',0,'',35,'2018-08-05 10:50:26',35,'2018-08-05 16:50:26',1,8),(3,'',0,'',35,'2018-08-05 10:50:26',35,'2018-08-05 16:50:26',2,8),(3,'',0,'',35,'2018-08-05 10:50:26',35,'2018-08-05 16:50:26',3,8),(3,'',0,'',35,'2018-08-05 10:50:26',35,'2018-08-05 16:50:26',4,8),(3,'',0,'',35,'2018-08-05 10:50:26',35,'2018-08-05 16:50:26',5,8),(4,'',0,'',39,'2018-08-14 11:10:12',39,'2018-08-14 17:10:12',1,8),(4,'',0,'',39,'2018-08-14 11:10:12',39,'2018-08-14 17:10:12',2,8),(4,'',0,'',39,'2018-08-14 11:10:12',39,'2018-08-14 17:10:12',3,8),(4,'',0,'',39,'2018-08-14 11:10:12',39,'2018-08-14 17:10:12',4,8),(4,'',0,'',39,'2018-08-14 11:10:12',39,'2018-08-14 17:10:12',5,8),(5,'',0,'',34,'2018-08-18 01:36:37',34,'2018-08-18 07:36:37',1,10),(5,'',0,'',34,'2018-08-18 01:36:37',34,'2018-08-18 07:36:37',2,10),(5,'',0,'',34,'2018-08-18 01:36:37',34,'2018-08-18 07:36:37',3,10),(5,'',0,'',34,'2018-08-18 01:36:37',34,'2018-08-18 07:36:37',4,10),(6,'',0,'',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',1,9),(6,'',0,'',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',2,9),(6,'',0,'',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',3,9),(6,'',0,'',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',4,9),(6,'',0,'',44,'2018-08-20 12:36:07',39,'2018-08-20 20:16:19',5,8),(7,'',0,'',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',1,8),(7,'',0,'',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',2,8),(7,'',0,'',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',3,8),(7,'',0,'',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',4,8),(7,'',0,'',39,'2018-09-17 22:54:24',39,'2018-09-18 04:54:24',5,8);
/*!40000 ALTER TABLE `cxs_workshifts_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_applications`
--

DROP TABLE IF EXISTS `sys_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_applications` (
  `APPLICATION_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(240) NOT NULL,
  `DESCRIPTION` varchar(240) NOT NULL,
  `DATE_ENABLED` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`APPLICATION_ID`),
  KEY `NAME` (`NAME`),
  KEY `DESCRIPTION` (`DESCRIPTION`),
  KEY `DATE_ENABLED` (`DATE_ENABLED`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_applications`
--

LOCK TABLES `sys_applications` WRITE;
/*!40000 ALTER TABLE `sys_applications` DISABLE KEYS */;
INSERT INTO `sys_applications` (`APPLICATION_ID`, `NAME`, `DESCRIPTION`, `DATE_ENABLED`) VALUES (1,'RBAM','','2018-08-01 07:35:27'),(2,'Time Accounting','','2018-08-08 10:38:16');
/*!40000 ALTER TABLE `sys_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'intella1_coexsys'
--

--
-- Dumping routines for database 'intella1_coexsys'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-20  2:10:22
