<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">   Sales Management   </a></li>
                        <li> <a href="#"> Trail Period Management </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Trail Period Management </h2>
                    </div>
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="form-group cus-form-ico">
                                <label for="inputEmail3" class="col-sm-2 control-label pd-tb33"> Universal Trial Period  </label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="" maxlength="3">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="clear-both"></div>
                    <div>
                        <h2 class="sec-subtitle"> Customer Specific Trial Period </h2>
                    </div>

                    <!-- find bx-->
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Number </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>

                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-2 form-group cus-form-ico">
                                <label> Days </label>
                                <input type="text" class="form-control" placeholder="" maxlength="3">

                            </div>
                            <div class="col-sm-2 form-group cus-form-ico">
                                <label> Trial Start </label>
                                <input type="text" class="form-control" placeholder="End Date" maxlength="20">
                                <span class="inp-icons"><i class="fa fa-calendar"></i></span>
                            </div>

                            <div class="col-sm-2 form-group cus-form-ico">
                                <label> Trial End Date </label>
                                <input type="text" class="form-control" placeholder="End Date" maxlength="20">
                                <span class="inp-icons"><i class="fa fa-calendar"></i></span>
                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> User Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="15">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Password </label>
                                <input type="password" class="form-control" placeholder="" maxlength="20">

                            </div>

                            <div class="col-sm-3 form-group">
                                <button type="button" class="btn btn-primary btn-style2 mar-tp22"> Save </button>
                            </div>
                        </div>
                    </div>



                    <div>

                    </div>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th> Customer Number
                                            <a href="#" class="sort-bx"> </a>
                                        </th>
                                        <th> Customer Name
                                            <a href="#" class="sort-bx"> </a>
                                        </th>
                                        <th> Days
                                            <a href="#" class="sort-bx"> </a>
                                        </th>
                                        <th> Trial Start Date </th>
                                        <th> Trial End Date </th>
                                        <th> User Name </th>
                                        <th> Password </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>

                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>

                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>

                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>

                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>



                                </tbody>
                            </table>
                        </div>
                    </div>


                    <!-- pagination -->
                    <div class="pagination-bx">
                        <div class="bs-example">
                            <ul class="pagination">
                                <li><a href="#">«</a></li>
                                <li><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li><a href="#">5</a></li>
                                <li><a href="#">»</a></li>
                            </ul>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>

</html>