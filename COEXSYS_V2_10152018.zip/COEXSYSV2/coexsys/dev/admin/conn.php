<?php
session_start();
/*$hostname = 'localhost';
$username = 'root';
$password = '';
$dbname = 'rbam2';*/

$hostname = 'localhost';
$username = 'racyshar_orawolf';
$password = 'HumtumNBT987##';
$dbname = 'racyshar_orawolf';

$user_session_id = session_id();
$ipaddress = getenv('REMOTE_ADDR');

//$conn = mysql_connect("$db1_host", "$db1_user", "$db1_pass") or die(mysql_error()) ;
$conn = mysql_connect("$hostname","$username", "$password") or die("Data not connected".mysql_errno());
mysql_select_db("$dbname",$conn) or die(mysql_error());

//$ModuleName = "Access Management";

function add_security($val)		// RETURN VALUE WITH SECURITY
{
	return mysql_real_escape_string($val);
}
function insertdata($table,$data)	// FUNCTION TO INSERT NEW RECORD IN SPECIFIED TABLE
{
	$qry="INSERT INTO ".$table." set ";
	foreach($data as $fld=>$val)
	{
		if($val=='now()')
		{
			//$qry.= $fld."=now(),";
			$qry.= $fld."=".add_security($val).",";
		}
		else
		{
			$qry.= $fld."='".add_security($val)."',";
		}
	}
	$qry=substr($qry,0,-1);
	//echo $qry;
	$result_insert = mysql_query($qry);
}

function updatedata($table,$data, $wherecondition)	// FUNCTION TO UPDATE RECORD IN SPECIFIED TABLE
{
	$qry="Update ".$table." set ";
	foreach($data as $fld=>$val)
	{
		$qry.= $fld."='".add_security($val)."',";
	}
	$qry=substr($qry,0,-1);
	$qry = $qry . $wherecondition;	
	//echo $qry;
	$result_insert = mysql_query($qry);
}
function getvalue($table,$fieldname, $wherecondition)	// FUNCTION TO GET RECORD IN SPECIFIED TABLE
{	
	$qry="Select $fieldname from ".$table." ".$wherecondition;
	$result = mysql_query($qry) or die(mysql_error($conn));
	while($linedetail=mysql_fetch_array($result))
	{
		$valueResult = $linedetail[$fieldname];			
	}		
	return $valueResult;
}
function getProfileImg($id)	// FUNCTION TO GET RECORD IN SPECIFIED TABLE
{	
	$qry="Select PHOTO from cxs_users where USER_ID=".$id;
	$result = mysql_query($qry) or die(mysql_error($conn));
	while($linedetail=mysql_fetch_array($result))
	{
			 if($linedetail['PHOTO']=='')
			 {
				    $valueResult = "../img/default_profile_img.jpg";
			 }
			 else
			 {	
				    $valueResult = "../img/uploads/user_images/".$id."/".$linedetail['PHOTO'];					
				    if (!file_exists($valueResult)) 
					{
						$valueResult = "../img/default_profile_img.jpg";
				    }
			 }
	}		
	return $valueResult;
}
function GetPassword($s)
{
	$l = strlen($s);
	$s1 = "";
	$s2 = "";
	$s3 = "";
	$s4 = "";
	for ($i=0; $i <= $l-1; $i++ )
	{
		$s1 = substr($s, $i, 1);
		$s2 = ord($s1);
		$s3 = ($s2 ^ 153);
		$s4 = $s4 . chr($s3);
	}
	return "$s4";
}

if(isset($_COOKIE["LogUserId"]))	
{
	$_SESSION["LogUserId"] = $_COOKIE["LogUserId"];
	$_SESSION["LogUserName"] = $_COOKIE["LogUserName"]; 
	
}
//$UserLoginId = $_SESSION['CustomerId'];

	function check_login()
	{
		if($_SESSION['reset-password']=='Y')
		{
			 header('location:reset-password.php');
		}					
		if(!isset($_SESSION['user_data']) || !isset($_SESSION['user_id']))
		{	 
			$_SESSION['redirect_page']=$_SERVER['REQUEST_URI'];		
			header('location:../index.php');
			exit();
		}
	}

	function HasUserType($FromString,$FindString)
	{
		if (strpos($FromString, $FindString) !== false)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}	
	
	function CreateSystemGenerateUser($LastInsertedSite)
	{
		$qry1 = "select * from cxs_users where SITE_ID = $LastInsertedSite";
		$result1 = mysql_query($qry1);	
		$noofrecords = mysql_num_rows($result1);
		if($noofrecords==0)
		{
			$qry = "select * from cxs_sites where SITE_ID = $LastInsertedSite";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$SiteId = $row['SITE_ID'];
				$insArr['USER_NAME'] = $row["EMAIL"];
				$insArr['ENC_KEY'] = $row["SYSTEM_PASSWORD"];
				$insArr['START_DATE'] = 'now()';				
				$insArr['CREATION_DATE']='now()' ;	
				$insArr['SITE_ID']=$SiteId ;
				
				insertdata("cxs_users",$insArr);			
				$LastInsertedId = mysql_insert_id();
			}
			
			
			//insert data into site settings table
			unset($insArr);		
			$insArr['MANDATORY_PWD'] = "30";
			$insArr['INCORRECT_ATTEMPT'] = "25";
			$insArr['IDLE_SESSION'] = "1243";
			$insArr['MINIMUM_ALLOWED'] = '9';			
			$insArr['ENFORCE_RECENT'] = 'Y';
			$insArr['NUMBER_OF_RECENT'] = '5';
			$insArr['ALLOW_SPECIALS'] = 'Y';
			$insArr['ALLOW_UPPERCASE'] = 'Y';
			$insArr['ALLOW_TIME_ENTRY'] = 'Y';
			$insArr['ALLOW_LOWERCASE'] = 'Y';
			$insArr['ALLOW_NUMERIC'] = 'Y';
			$insArr['ENABLE_COMMON'] = 'Y';
			$insArr['CREATED_BY'] = $LastInsertedId;
			$insArr['LAST_UPDATED_BY'] = $LastInsertedId;		
			$insArr['CREATION_DATE']='now()' ;	
			$insArr['SITE_ID']=$LastInsertedSite ;		
			insertdata("cxs_site_settings",$insArr);
				
			//mysql_query("update cxs_users set CREATED_BY = $LastInsertedId where USER_ID = $LastInsertedId");
			//mysql_query("update cxs_sites set IS_APPROVAL = 'Y', CREATED_BY = $LastInsertedId where SITE_ID = $LastInsertedSite");
		//	mysql_query("update cxs_sites set IS_APPROVAL = 'Y', DATE_ACTIVATED = now(),USER_ID=$LastInsertedId where SITE_ID = $LastInsertedSite");
			mysql_query("update cxs_sites set IS_APPROVAL = 'Y', DATE_ACTIVATED = now() where SITE_ID = $LastInsertedSite");
			SetUserAccessibility($LastInsertedId,$LastInsertedSite);
		}
	}
	function SetUserAccessibility($UserId,$TempSiteId)
	{
		for($i=1;$i<=2;$i++)
		{
			$insArr['USER_ID']= trim($UserId);
			//$insArr['CREATED_BY']= trim($UserId);
			$insArr['LAST_UPDATED_BY']= $UserId;
			$insArr['CREATION_DATE']= 'now()';
			$insArr['APPLICATION_ID']= $i;//for RBAM
			$insArr['START_DATE_ACTIVE']= 'now()';
			$insArr['SITE_ID']= $TempSiteId;
			//$insArr['END_DATE_ACTIVE']= $END_DATE_ACTIVE;	
			insertdata("cxs_am_app_admin",$insArr);
		}
	}
?>