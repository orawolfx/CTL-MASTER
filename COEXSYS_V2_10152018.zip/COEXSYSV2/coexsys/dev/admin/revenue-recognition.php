<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">   Sales Management   </a></li>
                        <li> <a href="#"> Revenue Recognition </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>

                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Revenue Recognition </h2>
                    </div>
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-3 form-group cus-form-ico">

                                <select class="form-control" maxlength="50">
                                    <option value="">  Period ID </option>
                                    <option value=""> ----</option>
                                    <option value=""> ----</option>
                                    <option value=""> ---- </option>
                                    </select>
                            </div>

                            <div class="col-sm-3 form-group">
                                <a href="#" class="btn btn-primary btn-style2"> Run Biling </a>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="data-bx">
                            <div class="table-responsive">
                                <table class="table table-bordered mar-cont">
                                    <thead>
                                        <tr>
                                            <th class="check-bx"> <input type="checkbox" id="inlineCheckbox1" value="option1"> </th>
                                            <th width="12%"> Bill ID <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Billing Period <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Start Date <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> End Date <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Bill Sent Date <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Due Date <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Bill Status <i class="fa fa-sort"></i> </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                        <tr>
                                            <td class="check-bx"> <input type="checkbox" id="" value="option1"> </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- button -->
                        <div class="cr-user fright">
                            <a href="#" class="btn btn-primary btn-style"> Distribute </a>
                        </div>
                        <!-- button end -->


                        <!-- pagination start-->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- pagination end -->

                    </div>
                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>

</html>