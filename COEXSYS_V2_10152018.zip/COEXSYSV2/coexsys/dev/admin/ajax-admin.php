<?php
	include ("conn.php");
	if($_POST['Request']=='Site Activate')
	{
		$ArrayIds = isset($_POST['Ids'])?$_POST['Ids']:'';
		//mysql_query("update cxs_sites set IS_APPROVAL = 'Y' where 1=1SITE_ID = 1 ")
		/*if(sizeof($ArrayIds)>0)
		{
			$query_1="where ";
			foreach($ArrayIds as $id )
			{
				$query_1 .= "SITE_ID = $id or ";
			}
			$query_1 = substr($query_1,0,-3);
		}*/		
		//mysql_query("update cxs_sites set IS_APPROVAL = 'Y' $query_1 ");
		
		//CreateSystemGenerateUser($LastInsertedSite);
		if(sizeof($ArrayIds)>0)
		{
			foreach($ArrayIds as $id )
			{
				CreateSystemGenerateUser($id);
			}
		}
	}
?>