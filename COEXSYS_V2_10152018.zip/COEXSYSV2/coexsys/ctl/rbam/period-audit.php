<?php ob_start ();	 
	include("../conn.php");
	include("rbam-functions.php");
	check_login();
?>
<?php 
	if($_SESSION['IsEnableAudit']!='Y')
	{
		header('location:rbam.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "period-audit.php";	
	$SiteId = $_SESSION['user-siteid'];
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
   	 $OrderBY = " desc";
   	 $FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}
	$SQueryOrderBy = " order by $FieldName $OrderBY";

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	//	$record_per_page=$RecordsPerPage;
	// $start_from = ($page-1) *  $record_per_page;
	$start_from = ($page-1) *  $RecordsPerPage;			
?>
<script type="text/javascript" >
	var TABLE_ROW;
	var RELATEDPOSITION = "";
	var KEY="";
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Period Audit";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;		
		AccountingPeriodList.submit();
	}
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		
		}
	}   
	
	function checkInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function FindData()
	{
		KEY = "FindData";
		var str1 = document.getElementById("Combo_FindCalendarName").value;		
		var str2 = document.getElementById("Text_FindYear").value;					
		makeRequest("ajax-finddata.php","REQUEST=FindDataAccountPeriod&CalendarName=" +str1+"&Year="+str2);
	}
	
	function RefreshData()
	{
		AccountingPeriodList.submit();
	}
	
	function ShowReadOnly(Id)
	{	
	/*	if ($('#cmdUpdateSelected').length) {}	*/
		KEY= "SingleRecord";								
		$("#ModalElements :input").prop('disabled', true);			
		$('#ModalDisplayAccountingPeriod').modal();		
		var FieldValue = Id;
		var FieldName = "CALENDAR_ID";
		var TableName = "cxs_calendars";
		makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);		
	}
	
</script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	
	
	<script src="../datepicker/jquery.js"></script>
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />
	
	<script src="../js/jsfunctions.js"></script>
	<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
	
</head>

<body>
<?php include("header.php"); ?>	
	
	<!--Search modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title " id="myModalLabel">Find Period Audit </h4>
			  </div>
			  <div class="modal-body"> 
				<!-- field start-->
				<div class="col-sm-12">
				  <div class="cus-form-cont">
					
					<div class="col-sm-6 form-group ">
						<label>Resource Name</label>						
						<select class="selectpicker form-control" id="Combo_FindCalendarName" name="Combo_FindCalendarName" data-show-subtext="true" data-live-search="true" onchange="SetCalendarYear()" >
						<option value=""> - Resource Name - </option>
						<?php 
							$query = "SELECT * FROM cxs_resources where SITE_ID = $SiteId order by FIRST_NAME,MIDDLE_NAME,LAST_NAME";
							$result=mysql_query($query);
							while($rows = mysql_fetch_array($result))
							{	$ResourceName = $rows['FIRST_NAME']." ".$rows['LAST_NAME']; 
							?>
							<option value="<?php echo $rows['RESOURCE_ID']; ?>"><?php echo $ResourceName; ?></option>
						<?php } ?>
						</select>
					</div>
					
				
				<div class="col-sm-6 form-group ">
						<label>Supervisor Name</label>
						<select class="selectpicker form-control" id="Combo_FindCalendarName" name="Combo_FindCalendarName" data-show-subtext="true" data-live-search="true" onchange="SetCalendarYear()" >
						<option value=""> - Supervisor Name - </option>
						<?php 						
							$query = "SELECT * FROM cxs_resources WHERE cxs_resources.SITE_ID = $SiteId AND cxs_resources.RESOURCE_ID  IN ( SELECT cxs_resources.SUPREVISOR_ID FROM cxs_resources where SUPREVISOR_ID <> '' ) order by FIRST_NAME,MIDDLE_NAME,LAST_NAME ";
							$result=mysql_query($query);
							while($rows = mysql_fetch_array($result))
							{	$SupervisorName = $rows['FIRST_NAME']." ".$rows['LAST_NAME']; 
							?>
							<option value="<?php echo $rows['RESOURCE_ID']; ?>"><?php echo $SupervisorName; ?></option>
						<?php } ?>
						</select>
					</div>
					
					<div class="col-sm-6 form-group ">
						<label>Pay Period</label>
						<select class="selectpicker form-control" id="Combo_FindCalendarName" name="Combo_FindCalendarName" data-show-subtext="true" data-live-search="true" onchange="SetCalendarYear()" >
						<option value=""> - Pay Period - </option>
						<?php 
							$query = "select PERIOD_NAME, PERIOD_ID from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID 
										where cxs_periods.status = 'Open' and cxs_periods.SITE_ID = $SiteId order by cxs_calendars.NAME, cxs_periods.PERIOD_ID desc ";
							$result = mysql_query($query);								
							while($rows = mysql_fetch_array($result))
							{	
							?>
							<option class = 'option_color' value = "<?php echo  $rows['PERIOD_ID']?>" > <?php echo $rows['PERIOD_NAME']?> </option>
						<?php } ?>
						</select>
					</div>
					
					<div class="col-sm-6 form-group">
					  <label>Year</label>
					  <input type="text" id="Text_FindYear" name="Text_FindYear" class="form-control" placeholder="" maxlength="100">
					</div>
						
				  </div>
				  
				
				</div>
				<!-- end --> 
			  </div>
			  <div class="clear-both"></div>
			  <div class="modal-footer cr-user">
				<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
			  </div>
			</div>
		</div>
	</div>
	<!-- Search Modal  -->
	
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <!-- brd crum-->
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#"> Subscriber Administration  </a></li>
                        <li> <a href="#"> Period Audit </a></li>
                    </ul>
                </div>
                <!-- Dash board -->
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="rbam.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> 
                    </div>
                    <div class="fright">
				<?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						}
				?>          
						<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
						<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
						<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>
					</div>
                </div>
                <!-- inner work-->
                <div class="cont-box">
                    <div class="pge-hd">                        
						<h2 class="sec-title"  > <label id="Label_Title">Period Audit</label>  </h2>
                    </div>
					
					<?php
						
						$ExportQry = "SELECT cxs_calendars.NAME,DESCR,PERIOD_YEAR,PERIOD_TYPE FROM cxs_calendars WHERE cxs_calendars.SITE_ID = $SiteId $s_Query  $SQueryOrderBy  limit $start_from , $RecordsPerPage";
						
						$selectQuery = "SELECT  cxs_calendars.*,cxs_users.USER_NAME as CreatedBy,
						(Select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_calendars.LAST_UPDATED_BY) as UpdatedBy FROM cxs_calendars inner join cxs_users on cxs_users.USER_ID = cxs_calendars.CREATED_BY  WHERE cxs_calendars.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";
						$selectQueryForPages  = $selectQuery;
						$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
						$RunUserQuery=mysql_query($selectQuery);
						$StdNumRows = mysql_num_rows($RunUserQuery);
						$msg = "";
						if($StdNumRows == 0 )
						{
							$msg = "No Record Found";
						}
					?>
					<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
					<br>
					<div class="fleft two">					  					  
					  <button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>
					</div>					
					
					
					<form name = "AccountingPeriodList" id = "AccountingPeriodList" method="post" >
						<div class="data-bx">
							<div class="table-responsive">							
								
								<table id='Table1' class="table table-bordered mar-cont">
									<thead>
										<tr>
											<th>
												<?php if($Sorts == 'desc' && $FileName == 'CalendarName') { ?>
													  <span style="">
														Employee Number
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CalendarName','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Employee Number
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CalendarName','desc');"></i>
													  </span>
												<?php } ?>
											</th>
											<th>
												<?php if($Sorts == 'desc' && $FileName == 'PERIOD_YEAR') { ?>
													  <span style="">
														Employee Name
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_YEAR','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Employee Name
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_YEAR','desc');"></i>
													  </span>
												<?php } ?>
											</th>
											
											
											<th>
												<?php if($Sorts == 'desc' && $FileName == 'PERIOD_YEAR') { ?>
													  <span style="">
														Supervisor Name
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_YEAR','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Supervisor Name
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_YEAR','desc');"></i>
													  </span>
												<?php } ?>
											</th>
											

											<th>
												<?php if($Sorts == 'desc' && $FileName == 'PERIOD_NAME') { ?>
													  <span style="">
														Pay Period
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_NAME','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Pay Period
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('PERIOD_NAME','desc');"></i>
													  </span>
												<?php } ?>
											</th>
											
											<th> Update Date </th>
										</tr>
									</thead>
									<tbody>
										<?php
											$i= 1;
											/*$qry = "select distinct cxs_te_file.DETAIL_ID, EMPLOYEE_NUMBER,EMPLOYEE_NAME,cxs_te_header.SUPERVISOR_ID,";
											$qry .="(concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME)) as Supervisorname,cxs_resources.RESOURCE_ID,";
											$qry .="cxs_periods.PERIOD_NAME,cxs_te_file.LAST_UPDATE_DATE from cxs_te_file left join cxs_daily_audit on cxs_daily_audit.EI_DNORM_ID = cxs_te_file.DETAIL_ID ";
											$qry .="left join cxs_te_header on cxs_te_header.TE_ID = cxs_te_file.TE_ID ";
											$qry .="left join cxs_resources on cxs_resources.RESOURCE_ID = cxs_te_header.SUPERVISOR_ID ";
											$qry .="left join cxs_periods on cxs_periods.PERIOD_ID = cxs_te_file.PERIOD_ID ";
											$qry .="where cxs_daily_audit.EMPLOYEE_NUMBER is not null";*/
											$qry = "SELECT EMPLOYEE_NUMBER, FULL_NAME,PERIOD_NAME,cxs_period_audit.EI_NORM_ID,(concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME)) as Supervisorname,";
											$qry .="cxs_period_audit.UPDATE_DATE from cxs_period_audit inner JOIN cxs_te_header ON cxs_te_header.TE_ID = cxs_period_audit.EI_NORM_ID ";
											$qry .="left join cxs_resources on cxs_resources.RESOURCE_ID = cxs_te_header.SUPERVISOR_ID group by cxs_period_audit.EI_NORM_ID order by cxs_period_audit.UPDATE_DATE desc ";
											$result = mysql_query($qry);
											while($rows=mysql_fetch_array($result))
											{
										?>
										<tr>											
											<td> 
												<?php echo $rows['EMPLOYEE_NUMBER']; ?> 												
											</td>
											<td> 
												<?php echo $rows['FULL_NAME']; ?>												
											</td>
											<td> 
												<?php echo $rows['Supervisorname']; ?>												
											</td>	
											<td> 
												<?php echo $rows['PERIOD_NAME']; ?>												
											</td>
											<td> 
												<?php echo date('m/d/Y h:i:sa', strtotime($rows['UPDATE_DATE'])); ?>												
											</td>
										</tr>
									 <?php 
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
						<!-- save btn  -->
						
						<!-- pagination start-->
			
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php

											//$selectQueryForPages=$selectQueryForPages;
											$RunDepQuery=mysql_query($selectQueryForPages);
											$num_records = mysql_num_rows($RunDepQuery);
											$total_pages= ceil($num_records/$RecordsPerPage);
											if (($page-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pages;$i++){ ?>
											<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($page+1)>$total_pages){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
													  <?php } ?>

								  </ul>
								</div>
							</div>
							<!-- pagination end -->
							<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
							<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	
							<input type="hidden" id="h_field_update" name="h_field_update" value="">
							<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>
							<input type="hidden" id="h_duplicate1" name="h_duplicate1" value=""/>
							<input type="hidden" id="h_query" name="h_query" value=""/>
					</form>	
                   
                </div>
            </div>
        </div>
        </div>
    </section>
    <footer> </footer>
	
	

<script type="text/javascript">	
	
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count	
	$('.form_datetime').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});		
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				
				else if(KEY == 'CheckAccountingPeriod')
				{
					
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)
					{
						//alert(s1);
						//span_periodname
						document.getElementById("span_periodname").innerHTML = s1;
						if (RELATEDPOSITION!="")
						{
							document.getElementById("h_duplicate1").value = "Y";
							document.getElementById("Text_PeriodName"+RELATEDPOSITION).focus();
						}
						else
						{
							document.getElementById("h_duplicate").value = "Y";							
							document.getElementById("Text_PeriodName").focus();
						}
						
					}
					else
					{
						if (RELATEDPOSITION!="")
						{
							document.getElementById("h_duplicate1").value = "";
						}
						else
						{
							document.getElementById("h_duplicate").value = "";
						}
						document.getElementById("span_periodname").innerHTML = "";
					}
				}
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;
					document.getElementById("h_query").value=s1;					
					s1 = s1.trim();					
					AccountingPeriodList.submit();
				}
				else if (KEY == "FindDataForYear")
				{
					var s1 = http_request.responseText;
					document.getElementById("Text_FindYear").value=s1;
				}
				
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText); 					
					//alert(JSON.stringify(JSONObject));
					
					$('#Text_CalendarName').val(JSONObject['cxs_calendars']["NAME"]);
					$('#Text_Description').val(JSONObject['cxs_calendars']["DESCR"]);
					$('#Text_PeriodYear').val(JSONObject['cxs_calendars']["PERIOD_YEAR"]);
					$('#Combo_PeriodType').val(JSONObject['cxs_calendars']["PERIOD_TYPE"]);	
					
					var DetailRows = JSONObject['DetailRows'];
					$('#Table2').find('tbody').remove();
					var check1='',check1value='';

					for(i=0;i<DetailRows;i++)
					{
						startdate = MyDateFormat(JSONObject[i]["FROM_PERIOD_DATE"]);
						enddate = MyDateFormat(JSONObject[i]["TO_PERIOD_DATE"]);
						check1value = (JSONObject[i]['FLAG_INUSE']=='Y')?'checked':'' ;
						check1 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						SelectedId = "<td style = 'display:none'>"+JSONObject[i]['PERIOD_ID']+"</td>";
						$('#Table2').append('<tr><td>'+startdate+'</td><td>'+enddate+'</td><td>'+JSONObject[i]["PERIOD_YEAR"]+'</td><td>'+JSONObject[i]["PERIOD_NAME"]+'</td><td>'+JSONObject[i]["STATUS"]+'</td>'+check1+SelectedId+'</tr>');					
					}	 
					var table = $("#Table2").DataTable({
						"searching": false,
						'order': [[ 6, "asc" ]],
						destroy: true,
						'lengthMenu': [[12, 24, 48, -1], [12, 24, 48, "All"]],
						//'columnDefs': [{"targets": [-1],"visible": false}]
						});											
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = '<?php echo $ExportQry; ?>';	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#CheckboxInline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_PeriodId"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'CALENDAR_ID', ExportIdList:exportIds,
						  ExportFileName:'_accounting-periods.xls', ExportSheetTitle:"Accounting Periods"
						  },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	</script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) kuparmar@yahoo.com -->
<script src="../livesearch/bootstrap-select.min.js"></script>  
  <script src="../js/jquery.min.js"></script>
   <script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/dataTables.bootstrap.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>

</html>