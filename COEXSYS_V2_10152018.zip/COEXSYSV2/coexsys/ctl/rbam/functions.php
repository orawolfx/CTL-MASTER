<?php	
	function DisplayRecords($FieldName,$FieldValue)	 
	{
		//global $BusinessMessage,$SetAudit,$AllowNegativeTimeEntry;
		global $AdvanceForOvertime,$SubmittedTime,$PrimaryApprover,$RecentTimecards,$RetroAdjustments,$AllowRetroUpdates,$MaxDailyLimit;
		global $FlexibleTimeEntry,$CopyTimesheetEmployees;		
		global $CreateTimeSheet,$ApproveTimeSheet,$CreateTimeSheetTeam,$ApproveTimeSheetTeam,$CreateSupervisorTimeSheet,$AllowPreApproval,$ApproverType,$AllowOverrideWorkshift;				
		global $TARCreatedBy,$TARUpdatedBy,$TARCreationDate,$TARLastUpdateDate;				
		global $ApproverTableRow,$ExistingApprovers,$resource_group_id,$Text_ResourceGroup,$s_qry1235;		
		global $h_userid,$Text_FirstName,$Text_LastName,$qry1;
		if($FieldName=="USER_ID")
		{
		/*	$qry = "SELECT RESOURCE_GROUP_NAME from cxs_users.*,cxs_resources.* from cxs_users, cxs_resources where cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID
			and cxs_users.USER_ID = '$FieldValue'";	*/			
			$qry = "SELECT cxs_resource_groups.RESOURCE_GROUP_NAME,cxs_resource_groups.RESOURCE_GROUP_ID,cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME from cxs_users inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID
					left join cxs_resource_groups on cxs_resource_groups.RESOURCE_GROUP_ID = cxs_resources.RESOURCE_GROUP_ID where cxs_users.USER_ID = '$FieldValue'";
			$result = mysql_query($qry);		
			$row=mysql_fetch_array($result); 
		
			$Text_ResourceGroup = $row['RESOURCE_GROUP_NAME'];
			$resource_group_id	= $row['RESOURCE_GROUP_ID'];
			$Text_FirstName = $row['FIRST_NAME'];
			$Text_LastName = $row['LAST_NAME'];
			$h_userid = $FieldValue;
		}
		else if($FieldName=="RESOURCE_GROUP_ID")
		{
			 $resource_group_id = $FieldValue;
		}
		
		$SiteId = $_SESSION['user-siteid'];
		$qry1 = "select * from cxs_am_ta_rules where cxs_am_ta_rules.$FieldName = '$FieldValue' and SITE_ID = $SiteId";
		$qry = "select * from cxs_ta_modules where cxs_ta_modules.$FieldName = '$FieldValue' and SITE_ID = $SiteId order by ROWNO";	
		$qry2 = "select * from cxs_am_approval_mgmt where cxs_am_approval_mgmt.$FieldName = '$FieldValue' and SITE_ID = $SiteId order by ROWNO";
		
		$result1 = mysql_query($qry1);
		$TotalRecords1 = mysql_num_rows($result1);
		while($row = mysql_fetch_array($result1))
		{
			/**************** Time Approval Rules ************/
	//		$BusinessMessage 	= $row['BIZ_MSG_FLAG'];
	//		$SetAudit 			= $row['AUDIT_FLAG'];
	//		$AllowNegativeTimeEntry = $row['ALLOW_NEGATIVE'];			
	//		$AdvanceForOvertime 	= $row['ADVANCE_FOR_OVERTIME'];
	//		$SubmittedTime 		= $row['UPDATE_SUBMITTED'];
	//		$PrimaryApprover 	= $row['OVERRIDE_PRIMARY'];					
	//		$MaxDailyLimit 		= $row['MAX_DAILY_LIMIT'];
	//		$FlexibleTimeEntry 	= $row['AFT_ENTRY'];			
	//		$CopyTimesheetEmployees = $row['ALLOW_COPY'];
	//		$AllowOverrideWorkshift 		= $row['ALLOW_OVERRIDE_WORKSHIFT'];	
			$RecentTimecards 	= $row['RECENT_TIMECARDS'];
			$RetroAdjustments 	= $row['RETRO_ADJUST'];	
			$AllowRetroUpdates 	= $row['RETRO_PERIOD_NUM'];
			$AllowPreApproval 	= $row['ALLOW_PREAPPROVAL'];
			
			/**************** Time Approval Rules ************/
		/*	$CreateTimeSheet 	= $row['COPY_ANYONE_TS_FLAG'];
			$ApproveTimeSheet 	= $row['APPROVE_ANYONE_TS'];
			$CreateTimeSheetTeam = $row['CREATE_ANYONE_TS'];
			$ApproveTimeSheetTeam = $row['APPROVE_ANYONE_TS_TEAM'];
			$CreateSupervisorTimeSheet = $row['ALLOW_SUP_TS'];										
		*/
			
			if((!is_null($row['CREATION_DATE'])) && (($row['CREATION_DATE'])!='0000-00-00') )
			{
				$TARCreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));	
			}
			if(!is_null($row['LAST_UPDATE_DATE']))
			{
				$TARLastUpdateDate = date('m/d/Y  h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
			}
			$TARCreatedBy   = $row['CREATED_BY']; 
			$TARUpdatedBy 	= $row['LAST_UPDATED_BY'];
			
			$TARCreatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TARCreatedBy");
			$TARUpdatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TARUpdatedBy");	
		}
	
		$result = mysql_query($qry);
		$TotalRecords = mysql_num_rows($result);
		while($row = mysql_fetch_array($result))
		{
			$DBRowNo = $row['ROWNO'];
			global ${ModuleName.$DBRowNo};
			global ${CreatePriv.$DBRowNo};
			global ${UpdatePriv.$DBRowNo};
			global ${ViewPriv.$DBRowNo} ;
			global ${EnableAudit.$DBRowNo};			
			global $TAMCreatedBy;
			global $TAMUpdatedBy;
			global $TAMCreationDate;
			global $TAMLastUpdateDate;
			
			${ModuleName.$DBRowNo} = $row['MODULE_NAME'];
			${CreatePriv.$DBRowNo} = $row['CREATE_PRIV'];			
			${UpdatePriv.$DBRowNo} = $row['UPDATE_PRIV'];
			${ViewPriv.$DBRowNo} = $row['VIEW_PRIV'];
			${EnableAudit.$DBRowNo} = $row['ENABLE_AUDIT'];
			
			$TAMCreatedBy  		= $row['CREATED_BY'];
			$TAMUpdatedBy 		= $row['LAST_UPDATED_BY'];			
			
			if((!is_null($row['CREATION_DATE'])) && (($row['CREATION_DATE'])!='0000-00-00 00:00:00') )
			{
				$TAMCreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));	
				$TAMCreatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TAMCreatedBy");
			}
			if(!is_null($row['LAST_UPDATE_DATE']))
			{
				$TAMLastUpdateDate = date('m/d/Y h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
				$TAMUpdatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TAMUpdatedBy");
			}				
		}
		
		/**************** Approval Management****** ************/
		$s_qry1235=$qry2;
		$ApproverTableRow = "";
		$ExistingApprovers=0;
		$result2 = mysql_query($qry2);
		$TotalRecords2 = mysql_num_rows($result2);	
		if($TotalRecords2==0)
		{
			if($FieldName=="USER_ID")	
			{	
				$s_qry = "select cxs_resources.SUPREVISOR_ID as sId,
				(select concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME)  from cxs_resources where cxs_resources.RESOURCE_ID = sId) as ApproverName,
				(SELECT cxs_resources.RESOURCE_TYPE FROM cxs_resources WHERE cxs_resources.RESOURCE_ID = sId) AS ApproverType
				from cxs_users inner join  cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID  where cxs_users.USER_ID = '$FieldValue' and cxs_resources.SUPREVISOR_ID!=0";
				$s_result = mysql_query($s_qry);
				while($row=mysql_fetch_array($s_result))
				{
					$data1=$row['ApproverName'];
					$data2=$row['ApproverType'];
					$data3=$row['sId'];
					$ApproverTableRow="<tr><td><span>$data1</span><input type='hidden' id = 'Text_ApproverId1' name = 'Text_ApproverId[]' value = '$data3'>  </td><td> $data2 </td></tr>";
					$ExistingApprovers=$ExistingApprovers+1;
					
				}
				
				//$s_qry1235=$s_qry;
			}
			
			else if($FieldName=="RESOURCE_GROUP_ID")	
			{
				
			}
			
		}
		else
		{
			$i=1;
			$s_qry = "SELECT cxs_am_approval_mgmt.REFERENCE_APPROVER_ID,CONCAT(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as ApproverName,cxs_resources.RESOURCE_TYPE as ApproverType,
			(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_am_approval_mgmt.CREATED_BY) as CreatedBy,
			(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_am_approval_mgmt.LAST_UPDATED_BY) as UpdatedBy,cxs_am_approval_mgmt.CREATION_DATE,cxs_am_approval_mgmt.LAST_UPDATE_DATE
			FROM cxs_resources inner join cxs_am_approval_mgmt on cxs_am_approval_mgmt.REFERENCE_APPROVER_ID = cxs_resources.RESOURCE_ID
			where cxs_am_approval_mgmt.USER_ID = '$FieldValue' order by ROWNO";
		//	$s_qry1235=$s_qry;
			$s_result = mysql_query($s_qry);			
			while($row = mysql_fetch_array($s_result))
			{
				$data1=$row['ApproverName'];
				$data2=$row['ApproverType'];
				$data3=$row['REFERENCE_APPROVER_ID'];
				
				$CreatedByName = $row['CreatedBy'];
				$UpdatedByName = $row['UpdatedBy'];
				$CreationDate =$row['CREATION_DATE'];
				$LastUpdateDate = $row['LAST_UPDATE_DATE'];
				$data4="<td class='check-bx'><button type='button' class='btn btn-default' data-container='body'   data-toggle='popover' data-html='true' data-placement='left' 
				data-content='Created By:  $CreatedByName <br>
				Updated By:  $UpdatedByName <br>
				Creation Date: $CreationDate <br>
				Last Update Date: $LastUpdateDate'> 
				<i class='fa fa-eye'></i> </button></td>";				
				$ApproverTableRow.="<tr><td><span>$data1</span><input type='hidden' id = 'Text_ApproverId$i' name = 'Text_ApproverId[]' value = '$data3'>  </td><td> $data2 </td>$data4</tr>";
				$i=$i+1;
				$ExistingApprovers=$ExistingApprovers+1;
			}
		}
		
		if ($TotalRecords==0)
		{
			$msg = "No Record Found";
		}	
		if ($TotalRecords1==0)
		{
			$msg = "No Record Found";
		}	
	}
	
	function DisplayRoleDetails($Text_RoleName1)	
	{	
		global $Text_RoleName,$Text_RoleDescription,$CreateUser,$ViewOnly,$UpdateOnly,$ViewSubscribers,$SubmitCustom;
		global $AllowChat,$ViewSLA,$ExistUserAdmin,$RemoveAccess,$UsageHistory,$UACreatedBy;
		global $UACreationDate,$UAUpdatedBy,$UALastUpdateDate,$UpdateSiteContacts,$OverrideInUse;	
		$SiteId = $_SESSION['user-siteid'];	
		$qry = "SELECT * from cxs_am_roles where ROLE_NAME='".$Text_RoleName1."' and SITE_ID = $SiteId";		
		$result = mysql_query($qry);
		$TotalRecords = mysql_num_rows($result);
		while($row=mysql_fetch_array($result))
		{
			$Text_RoleName = $row['ROLE_NAME'];
			$Text_RoleDescription = $row['DESCRIPTION'];
			/******User Administration******/
			$CreateUser 	 = $row['CREATE_NEW_USER'];
			$ViewOnly 		 = $row['VIEW_ONLY'];
			$UpdateOnly 	 = $row['UPDATE_ONLY'];
			$OverrideInUse 	 = $row['OVERRIDE_INUSE'];
			/******Billing Administration******/
			$ViewSubscribers = $row['VIEW_SUBSCRIBERS'];
			$SubmitCustom	 = $row['SUBMIT_CUSTOM'];			
			$ViewSLA		 = $row['VIEW_SLA'];
			$ExistUserAdmin  = $row['EXISTING_USER'];
			$RemoveAccess	 = $row['REMOVE_ACCESS'];
			$UsageHistory	 = $row['USAGE_HISTORY'];
			$UACreatedBy  	 = $row['CREATED_BY']; 
			$UAUpdatedBy 	 = $row['LAST_UPDATED_BY'];
			$UpdateSiteContacts	= $row['UPDATE_SITE_CONTACTS'];
			
			if((!is_null($row['CREATION_DATE'])) && (($row['CREATION_DATE'])!='0000-00-00') )
			{
				$UACreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));	
			}
			if(!is_null($row['LAST_UPDATE_DATE']))
			{
				$UALastUpdateDate = date('m/d/Y  h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
			}
		}
	}