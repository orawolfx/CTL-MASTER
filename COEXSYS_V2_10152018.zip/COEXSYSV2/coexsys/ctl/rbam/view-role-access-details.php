<?php
	$Isdisabled1 = "";	
	if($Text_RoleName==''){$Isdisabled1="disabled";} 	
?>
<script>
	$(document).ready(function()
	{ 
		var IsDisable1 = '<?php echo $Isdisabled1; ?>';
		if(IsDisable1!='')
		{
			//$("#accordion1 :input").prop("disabled", true);
			$("#collapseOne :input").prop("disabled", true);			
			$('#cmdSaveRolePermission').prop('disabled',true);
		}
	});
	
	/*$('#Check_CreateUser').change(function() 
	{
		alert("hu");
	}*/
	
	 $(function () {
        $("#Check_CreateUser").click(function () {			
            if ($(this).is(":checked")) 
			{
                $('#Check_ViewOnly').prop('checked',true);
            } 
        });
		
		
		$("#Check_UpdateOnly").click(function () {
            if ($(this).is(":checked")) 
			{
                $('#Check_ViewOnly').prop('checked',true);
            } 
        });
		
		
		$("#Check_ViewOnly").click(function () {
			
			if (!$(this).is (":checked")) 
			{
				if ($('#Check_CreateUser').is(":checked") || $('#Check_UpdateOnly').is(":checked"))	
				{
					$('#Check_ViewOnly').prop('checked',true);
				}
            } 
        });
		
    });
</script>
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true" >
	
	<div class="panel panel-default">						
		<div class="panel-heading" role="tab" id="headingOne">
			<span id="myspan"> </span>
			<h4 class="panel-title"> 
				<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> User Administration <i class="fa fa-plus"></i> </a> 
				<span class="over-eyecont">
				<?php										
					//$CreatedByName = "";
					$UpdatedByName = "";
					//if($UACreatedBy!='') $CreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UACreatedBy");
					if($UAUpdatedBy!='') $UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UAUpdatedBy");
				?>
				  <button type="button" id = "btn_heading1" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover"  data-html="true"  data-placement="left" data-content="Created By:  <?php  echo $CreatedByName; ?><br>Updated By:  <?php  echo $UpdatedByName; ?><br>Creation Date: <?php  echo $UACreationDate; ?><br>Last Update Date: <?php  echo $UALastUpdateDate; ?>"> <i class=" fa fa-eye"></i> </button>
				</span> 
			</h4>
		</div>
		<div id="collapseOne" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingOne">
			<div class="panel-body">
				<div class="col-md-12"><h2 class="f-sec-hd"> User Administration </h2></div>
				<div class="col-md-12">
					<div class="row">
						<div class="checkbox col-md-3">
							<label><input type="checkbox" id="Check_CreateUser" name="Check_CreateUser" <?php if($CreateUser == "Y"){ ?> checked="checked" <?php } ?>  value="1">Create New Users </label>
						</div>
											
						<div class="checkbox col-md-3">
							<label><input type="checkbox" id="Check_ViewOnly" name="Check_ViewOnly" <?php if($ViewOnly == "Y"){ ?> checked="checked" <?php } ?> value="1">View Only </label>
						</div>
										
						<div class="checkbox col-md-3">
							<label><input type="checkbox" id="Check_UpdateOnly" name="Check_UpdateOnly" <?php if($UpdateOnly == "Y"){ ?> checked="checked" <?php } ?> value="1">Update Only </label>
						</div>
						
						<div class="checkbox col-md-3">
							<label><input type="checkbox" id="Check_OverrideInUse" name="Check_OverrideInUse" <?php if($OverrideInUse == "Y"){ ?> checked="checked" <?php } ?> value="1">Override In Use</label>
						</div>
						
					</div>
				</div>
									<!-- -->
				<div class="col-md-12"><h2 class="f-sec-hd"> Billing Administration </h2></div>
				<div class="col-md-12">
					  <div class="row">
					<!--	<div class="checkbox col-md-3">
						  <label><input type="checkbox" id="Check_ViewSubscribers" name="Check_ViewSubscribers" <?php if($ViewSubscribers == "Y"){ ?> checked="checked" <?php } ?> value="1">View Subscribers </label>
						</div> -->
											
						<div class="checkbox col-md-3">
						  <label><input type="checkbox" id="Check_SubmitCustomization" name="Check_SubmitCustomization" <?php if($SubmitCustom == "Y"){ ?> checked="checked" <?php } ?> value="1">Open Support Requests </label>
						</div>											
						<div class="checkbox col-md-3">
							  <label><input type="checkbox" id="Check_ViewSLA" name="Check_ViewSLA" <?php if($ViewSLA == "Y"){ ?> checked="checked" <?php } ?> value="1">View SLA </label>
						</div>
											
						<div class="checkbox col-md-3">
						  <label><input type="checkbox" id="Check_ExistUserAdmin" name="Check_ExistUserAdmin" <?php if($ExistUserAdmin == "Y"){ ?> checked="checked" <?php } ?> value="1">Existing User Admin </label>
						</div>											
						<div class="checkbox col-md-3">
						  <label><input type="checkbox" id="Check_UsageHistory" name="Check_UsageHistory" <?php if($UsageHistory == "Y"){ ?> checked="checked" <?php } ?> value="1">Usage History </label>
						</div>
						<div class="checkbox col-md-3">
						  <label><input type="checkbox" id="Check_UpdateSiteContacts" name="Check_UpdateSiteContacts" <?php if($UpdateSiteContacts == "Y"){ ?> checked="checked" <?php } ?> value="1">Update Site Contacts </label>
						</div>
					  </div>
				</div>
			</div>
		</div>
	</div>
					  
</div>			
			