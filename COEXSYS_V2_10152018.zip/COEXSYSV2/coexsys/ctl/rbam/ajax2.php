<?php ob_start (); 
include('../conn.php');

if($_REQUEST['REQUEST'] == "FetchRecords")
{
	$TableName = $_REQUEST['TableName'];
	$FieldName = $_REQUEST['FieldName'];
	$FieldValue = $_REQUEST['FieldValue'];
	$JoinTable = $_REQUEST['JoinTable'];
	if($JoinTable == "cxs_resources")
	{
		$qry = "Select $TableName.*,cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME,cxs_resource_groups.RESOURCE_GROUP_NAME,cxs_resource_groups.RESOURCE_GROUP_ID  from $TableName
		inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID
		left join cxs_resource_groups on cxs_resource_groups.RESOURCE_GROUP_ID = cxs_resources.RESOURCE_GROUP_ID
		Where $TableName.$FieldName='$FieldValue'";
	}
	else 
	{
		$qry = "Select * from $TableName Where $FieldName='$FieldValue'";
	}

	$result = mysql_query($qry);
	while($row=mysql_fetch_array($result))
	{
	   $data[$TableName] = $row;		
	}
	echo json_encode($data);
}

else if($_REQUEST['REQUEST'] == "SearchSupervisor")
{
	$FirstName = $_REQUEST['FirstName'];
	$MiddleName = $_REQUEST['MiddleName'];
	$LastName = $_REQUEST['LastName'];
	$ResourceId  = $_REQUEST['ResourceId'];
	$userid = $_REQUEST['userid'];
	$form = $_REQUEST['form'];
	$SiteId = $_SESSION['user-siteid'];
	
	$s_query = "";	
	$s_query1 = "";	
	if($FirstName!='')
	{
		$s_query .= "and cxs_resources.FIRST_NAME like'%$FirstName%' ";
		$s_query1 .= "and cxs_resources.FIRST_NAME like'%$FirstName%' ";
	}
	if($MiddleName!='')
	{
		$s_query .= " and cxs_resources.MIDDLE_NAME like'%$MiddleName%' ";
		$s_query1 .= " and cxs_resources.MIDDLE_NAME like'%$MiddleName%' ";
	}
	if($LastName!='')
	{
		$s_query .= "and cxs_resources.LAST_NAME like'%$LastName%' ";
		$s_query1 .= "and cxs_resources.LAST_NAME like'%$LastName%' ";
	}	
	if($ResourceId!='')
	{
		$s_query .= "and cxs_resources.RESOURCE_ID <> $ResourceId ";		
		$s_query1 .= "or cxs_resources.RESOURCE_ID = $ResourceId ";
	}		
	if($form=='' && $userid!='')
	{
		$s_query .= "and cxs_resources.RESOURCE_ID in(SELECT cxs_resources.SUPREVISOR_ID from cxs_resources) ";//and ACTIVE_FLAG = 'Y'
		$qry = "Select * from cxs_users where USER_ID = $userid";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$r1 = $row['RESOURCE_ID'];
		}		
		if ($r1!=''){ $s_query .= " and cxs_resources.RESOURCE_ID <> $r1 ";}		
		/*MUST BE SETUP in Time Approval Rule Tab with AT LEAST ONE permission checked*/
		$s_query .= "and cxs_resources.RESOURCE_ID IN (select  cxs_users.RESOURCE_ID from cxs_am_ta_rules 
					inner join cxs_users on cxs_users.USER_ID = cxs_am_ta_rules.USER_ID
					where (cxs_am_ta_rules.COPY_ANYONE_TS_FLAG = 'Y' or cxs_am_ta_rules.APPROVE_ANYONE_TS = 'Y' or cxs_am_ta_rules.CREATE_ANYONE_TS = 'Y' 
						or cxs_am_ta_rules.APPROVE_ANYONE_TS_TEAM = 'Y' or cxs_am_ta_rules.ALLOW_SUP_TS = 'Y'))";
		
		$sql = "SELECT * FROM cxs_resources where cxs_resources.SITE_ID = $SiteId  $s_query order by FIRST_NAME";
	}
	else if($form!='')
	{
		$sql = "select * from cxs_resources where cxs_resources.SITE_ID = $SiteId and cxs_resources.RESOURCE_ID not in (select cxs_users.RESOURCE_ID from cxs_users) $s_query1 order by FIRST_NAME ";
	} 
?>
	<table class="table table-bordered " width="100%" id = "divTable">
		  <thead>
			<tr>
			<?php if($form == 'users-administration') 
				{ ?>	
				<th><span> Resource Id </span></th>
		<?php 	} ?>	
			  <th><span> First Name </span></th>
			  <th><span> Middle Name </span></th>
			  <th><span> Last Name </span></th>
			</tr>
		  </thead>
		  <tbody id='ListSupervisor'>
<?php	
	if($sql!='')
	{
		$result = mysql_query($sql);		
		while($row=mysql_fetch_array($result))
		{
			$SearchResourceId 	  =  $row['RESOURCE_ID'];		
			$SearchFirstName  =  $row['FIRST_NAME'];	
			$SearchMiddleName	  =  $row['MIDDLE_NAME'];				
			$SearchLastName   =  $row['LAST_NAME'];	
			$today = date("Y-m-d");
			$flag_show="";
			
			if( (!is_null($row['START_DATE_ACTIVE']) && ($row['START_DATE_ACTIVE'])!='0000-00-00')  && (!is_null($row['END_DATE_ACTIVE']) && ($row['END_DATE_ACTIVE'])!='0000-00-00') )	 
			{
				if($today >= $row['START_DATE_ACTIVE'] && $today <= $row['END_DATE_ACTIVE'])
				{
					$flag_show="Y";
				}			
			}
			else if( (!is_null($row['START_DATE_ACTIVE']) && ($row['START_DATE_ACTIVE'])!='0000-00-00')  && (is_null($row['END_DATE_ACTIVE']) || ($row['END_DATE_ACTIVE'])=='0000-00-00') )	 
			{
				if($today >= $row['START_DATE_ACTIVE'] )
				{
					$flag_show="Y";
				}			
			}
			
			if($flag_show=="Y")
			{	
		?>
				<!--<tr style="cursor:pointer"  onClick="SelectedSupervisor('<?php echo $SearchFirstName; ?>','<?php echo $SearchLastName; ?>',<?php echo $SearchResourceId; ?>);">-->
				<tr style="cursor:pointer"  onClick="SelectedSupervisor(<?php echo $SearchResourceId; ?>);">
				<?php if($form == 'users-administration') 
				{ ?>	
				<th><?php echo $row['RESOURCE_ID']; ?></th>
		<?php 	} ?>	
				<td><?php echo $SearchFirstName; ?></td> 
				<td><?php echo $SearchMiddleName; ?> </td> 
				<td> <?php echo $SearchLastName; ?>  </td></tr>
	<?php	}
		}
	}?>	
		  </tbody>
	</table>
<?php }	

else if($_REQUEST['REQUEST'] == "FindDataAliases")
{
	$AliasName = $_REQUEST['AliasName'];
	$AliasClass = $_REQUEST['AliasClass'];
	$IsCopy = $_REQUEST['IsCopy'];
	$IsAutoPopulate = $_REQUEST['IsAutoPopulate'];
	$IsActive = $_REQUEST['IsActive'];
	$IsInUse = $_REQUEST['IsInUse'];
	
	$s_query = "";
	
	if($AliasName!='')
	{
		$s_query .= " and cxs_aliases.ALIAS_NAME like'%$AliasName%' ";
	}
	if($AliasClass!='')
	{
		$s_query .= " and cxs_aliases.ALIAS_CLASS ='$AliasClass' ";
	}
	if($IsCopy!='N')
	{
		$s_query .= "and cxs_aliases.COPY_ALLOWED ='$IsCopy' ";
	}
	if($IsAutoPopulate!='N')
	{
		$s_query .= "and cxs_aliases.AUTOPOPULATE ='$IsAutoPopulate' ";
	}
	if($IsActive!='N')
	{
		$s_query .= "and cxs_aliases.ACTIVE_FLAG ='$IsActive' ";
	}
	if($IsInUse!='N')
	{
		$s_query .= "and cxs_aliases.ADDINUSE_FLAG ='$IsInUse' ";
	}
		
	echo $s_query;
}
else if($_REQUEST['REQUEST'] == "IsExistiRoleName")
{
	$RoleName = $_REQUEST['RoleName'];
	$SiteId = $_SESSION['user-siteid'];
	$qry = "SELECT * from cxs_am_roles where ROLE_NAME='".$RoleName."' and SITE_ID = $SiteId";		
	$result = mysql_query($qry);
	$TotalRecords = mysql_num_rows($result);
	if($TotalRecords==0)
	{
		echo "false";
	}
	else
	{
		echo "true";
	}
}
else 
{
	$LoginUserId = $_SESSION['user_id'];
	$Text_AliasName = isset($_POST["Text_AliasName"] )? $_POST["Text_AliasName"]: false;
	$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;
	$Combo_AliasType = isset($_POST["Combo_AliasType"] )? $_POST["Combo_AliasType"]: false;
	$Combo_AliasClass = isset($_POST["Combo_AliasClass"] )? $_POST["Combo_AliasClass"]: false;
	$Check_CopyAllowed = isset($_POST['Check_CopyAllowed'] )? $_POST['Check_CopyAllowed']: false;
	$Check_AutoPopulate = isset($_POST['Check_AutoPopulate'] )? $_POST['Check_AutoPopulate']: false;
	$Check_Active = isset($_POST['Check_Active'] )? $_POST['Check_Active']: false;
//	$Check_AddInUse = isset($_POST['Check_AddInUse'] )? $_POST['Check_AddInUse']: false;
	$WBSProjectId = isset($_POST['h_ProjectWBSId'] )? $_POST['h_ProjectWBSId']: false;
	$HeaderId = isset($_POST['h_headerid'] )? $_POST['h_headerid']: false;
	$SiteId = $_SESSION['user-siteid'];
	
	$IsAllow="true";
	//$AliasType = substr($Combo_AliasType,0,3);
	//if ($AliasType == 'OTD'||$AliasType == 'OTE'||$AliasType == 'OTS'||$AliasType == 'CTH'||$AliasType == 'CTS')
	{
		//$qry = "select * from cxs_aliases where ALIAS_TYPE = '$Combo_AliasType'";
		$query1="";
		if($HeaderId!='')
		{
			$query1 = "and  ALIAS_ID <> $HeaderId ";
		}
		if($WBSProjectId!='')
		{
			$query1 .= "and WBS_ID = $WBSProjectId ";
		}
		$qry = "select * from cxs_aliases where ALIAS_NAME = '$Text_AliasName' and ALIAS_TYPE = '$Combo_AliasType' and SITE_ID = $SiteId $query1";
		$result=mysql_query($qry);
		if(mysql_fetch_array($result) > 0)
		{
			$IsAllow="false";
		}
	}
	if($IsAllow=="true")
	{
		$insArr['ALIAS_NAME'] = $Text_AliasName;
		$insArr['DESCRIPTION'] = $Text_Description;
		$insArr['ALIAS_TYPE'] = $Combo_AliasType;
		$insArr['ALIAS_CLASS'] = $Combo_AliasClass;
		$insArr['WBS_ID'] = $WBSProjectId;
		$insArr['COPY_ALLOWED'] = ($Check_CopyAllowed==1)?"Y":"N";
		$insArr['AUTOPOPULATE'] = ($Check_AutoPopulate==1)?"Y":"N";
		$insArr['ACTIVE_FLAG'] = ($Check_Active==1)?"Y":"N";
	//	$insArr['ADDINUSE_FLAG'] = ($Check_AddInUse==1)?"Y":"N";
		$insArr['LAST_UPDATED_BY'] = $LoginUserId;
		$insArr['SITE_ID'] = $SiteId;
		
		if($HeaderId!='')
		{
			updatedata("cxs_aliases",$insArr,"Where cxs_aliases.ALIAS_ID = $HeaderId");		
		}	
		else
		{
			$insArr['CREATION_DATE']='now()';
			$insArr['CREATED_BY']=$LoginUserId;			
			insertdata("cxs_aliases",$insArr);	
		}
		echo "success";
	}
	else
	{
		//echo "Alias Type $Combo_AliasType is already exist. You cannot enter multiple entry of it.";
		echo "Combination of Alias Name , Type and WBS should not be repeat.";
	}
}


?>