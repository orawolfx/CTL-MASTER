<?php ob_start ();
 
include("../conn.php");
include("rbam-functions.php");
check_login();
include ("find.php");	

?>
<?php
	if ($_SESSION['current-user-type'] == "RBAM-Admin")
	{
		$CREATE_PRIV_ua_PERMISSION = "Y";
		$VIEW_PRIV_ua_PERMISSION = "Y";
		$UPDATE_PRIV_ua_PERMISSION = "Y";	 	
	}
	else
	{
		$CREATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('CREATE_NEW_USER',$_SESSION['user_id']);
		$VIEW_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('VIEW_ONLY',$_SESSION['user_id']);
		$UPDATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('UPDATE_ONLY',$_SESSION['user_id']);
	}							
	if($CREATE_PRIV_ua_PERMISSION!='Y' && $VIEW_PRIV_ua_PERMISSION!='Y' &&  $UPDATE_PRIV_ua_PERMISSION!='Y' )
	{
		header('location:rbam.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "users-administration.php";
	$SiteId = $_SESSION['user-siteid'];


	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "USER_NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	//$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	if ($Sorts == 'asc')
	{
   	 $OrderBY = " desc";
   	 $FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";
	$record_per_page=$RecordsPerPage;	
	
	//$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;

   if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	$start_from = ($page-1) *  $record_per_page;
	//if (isset($_POST['cmdUpdateSelected'] ))
	
	
	if (isset($_POST['cmdResetPassword'] ))
	{
	   
	    $user_id = $_POST['rsPsw_userId'];
		$user_name = getvalue("cxs_users","USER_NAME", "where USER_ID = $user_id and SITE_ID = $SiteId");
		
		$Text_NewPassword  = isset($_POST['Text_NewPassword'] )? $_POST['Text_NewPassword']: false;
		unset ($insArr);
		$Pass = GetPassword($_POST['Text_NewPassword']);
		$insArr['ENC_KEY']=$Pass;
		$insArr['LAST_UPDATED_BY']=$LoginUserId;
		updatedata("cxs_users",$insArr, " where USER_ID = $user_id and SITE_ID = $SiteId");
		
		/**************** Code for sending email *****************/
		$from_name='Coexsys Time Accounting'; //Website Name
		//$from_email='admin@testrbam.com'; //Admin Email
		$from_email='info@synchronwebservices.com'; //Admin Email
		$to=$user_name;
		$subject = "Welcome to ".$from_name;
		$cc="";
		include "email/passwordChanged.php"; //email design with content included		
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: $from_name < $from_email >\r\n";		
	    mail($to, $subject, $message, $headers);
		/*********************************************************/
	}
	
	/***** Password rules *****/
	$password_rules = array();
	if(getSettingVal('ALLOW_NUMERIC')=='Y')
	{
	   array_push($password_rules,"At least one numeric value.");
	}
	if(getSettingVal('ALLOW_UPPERCASE')=='Y')
	{
	   array_push($password_rules,"At least one upper case character.");
	}
	if(getSettingVal('ALLOW_LOWERCASE')=='Y')
	{
	   array_push($password_rules,"At least one lower case character.");
	}
	if(getSettingVal('ALLOW_SPECIALS')=='Y')
	{
	   array_push($password_rules,"At least one special character.");
	}
	array_push($password_rules,"No Spaces Allowed.");
	$miniCharacters = "";
	$miniCharacters = getSettingVal('MINIMUM_ALLOWED');
	if($miniCharacters!='')
	{
		array_push($password_rules,"At least $miniCharacters character/s.");
	}
	if(getSettingVal('ENABLE_COMMON')=='Y')
	{
	   array_push($password_rules,"Must not use commonly used words.");
	}
	array_push($password_rules,"Must not use any UniCode or Asian Characters.");	
?>

<script type="text/javascript" >
	$(document).ready(function() 
	{													
	   $('.record_chk').change(function() 
	   {
			if ($('.record_chk:checked').length == 0)
			{
				document.getElementById("cmdUpdateSelected").innerHTML = "Update selected";
			//	$("#cmdCancel").attr('disabled',true);
				$("#cmdExport").attr('disabled',false);
				//flag_checked="N";
				flag_updaterecord = "N";
			}
	   });
	});

	var GridCurrentRow;
	GridCurrentRow = 0;
	var IsGridDateValid;
	IsGridDateValid = "";
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;
		AdministrationList.submit();
	}	
	function checkAll123(ele)
	{
		 var checkboxes = document.getElementsByTagName('input');
		 if (ele.checked) 
		 {
			 for (var i = 0; i < checkboxes.length; i++) {
				 if (checkboxes[i].type == 'checkbox') {
					 checkboxes[i].checked = true;
				 }
			 }
		 } 
		 else 
		 {
			  $('.record_chk').each(function () {
				    $(this).prop('checked' , false);
				    HideDatePicker($(this).val());
				    for(i=5;i<=7;i++)
				    {
						  document.getElementById($(this).val()+"_"+i).style.borderColor  = "";
						  document.getElementById($(this).val()+"_"+i).style.backgroundColor = "";
				    }
			 });
			 if ($('.record_chk:checked').length == 0)
			 {
				    document.getElementById("cmdUpdateSelected").innerHTML = "Update selected";
				 //   $("#cmdCancel").attr('disabled',true);
				    $("#cmdExport").attr('disabled',false);
				    $("#selectall").prop('checked' , false);
				    //flag_checked="N";
				    flag_updaterecord = "N";
			 }			 
		 }
	}
	
	function checkAll(ele)
	{
		 var checkboxes = document.getElementsByTagName('input');
		 if (ele.checked) {
			 for (var i = 0; i < checkboxes.length; i++) {
				 if (checkboxes[i].type == 'checkbox') {
					 checkboxes[i].checked = true;
				 }
			 }
		 } else {
			 
			 /**********/
			 
			  for (var i = 0; i < checkboxes.length; i++) {
				 if (checkboxes[i].type == 'checkbox') {
					 checkboxes[i].checked = false;
				 }
			 }
			/* $('.record_chk').each(function () {
				    $(this).prop('checked' , false);
				    HideDatePicker($(this).val());
				    for(i=5;i<=7;i++)
				    {
						  document.getElementById($(this).val()+"_"+i).style.borderColor  = "";
						  document.getElementById($(this).val()+"_"+i).style.backgroundColor = "";
				    }
			 });*/
			 if ($('.record_chk:checked').length == 0){
				    document.getElementById("cmdUpdateSelected").innerHTML = "Update selected";
				//    $("#cmdCancel").attr('disabled',true);
				    $("#cmdExport").attr('disabled',false);
				    $("#selectall").prop('checked' , false);
				    //flag_checked="N";
				    flag_updaterecord = "N";
			 }
			 /*********/
		 }
	}
	
	function checkAll1()
	{
		//var checkboxes = document.getElementsByTagName('input');
		var checkboxes = $(".record_chk");
		for (var i = 0; i < checkboxes.length; i++)
		{
			if (checkboxes[i].type == 'checkbox')
			{
				if(checkboxes[i].checked == false)
				{
					document.getElementById("selectall").checked =false;
					break;
				}
			}
		}
	}	
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;
		for(i=1;i<=TotalRows;i++)
		{
			if (document.getElementById("Check_Record"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
		}
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_userid"+selectedRow).value;
			location.href="users-administration-create.php?hid="+s;						   
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}
	}

	function TableRowFunction(UserId)
	{
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{	
			KEY= "SingleRecord";
			$("#ModalUserBody :input").prop('disabled', true);	
			//$("DTPicker_StartDate").removeClass("form_datetime");
			$("#ModalUserDetail").find('.modal-title').text('User Administration');	
			$("#cmdCreateUser").hide();
			$("#crtFrmPswRules").hide();
			$("#new_psw_err_tooltip").empty();			
			$('#ModalUserDetail').modal();					
			var TableName = "cxs_users";
			var FieldName = "USER_ID";
			var FieldValue = UserId;			
			//makeRequest("ajax.php","REQUEST=SingleUserRecord&UserId=" + str);						
			makeRequest("ajax-DisplayRecord-rbam.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
	}
	
	
	
	function SearchResourceName()
	{
		KEY= "SearchResourceNameData";			
		var str = document.getElementById("Text_ResourceName").value;		
		makeRequest("ajax.php","REQUEST=SearchResourceNameData&ResourceName=" + str);
	}
	function SelectedResourceName(s1,s2)
	{
		document.getElementById("Text_ResourceName").value = s1;		
		document.getElementById("Text_ResourceId").value = s2;		
		document.getElementById("ListResourceResult").style.display = 'none';				
	}
	function ResetResourceDiv()
	{
		document.getElementById("ListResourceResult").style.display = 'block';
		document.getElementById("ListResourceResult").innerHTML = "";
		document.getElementById("Text_ResourceName").value = "";
		document.getElementById("Text_ResourceId").value = "";
	}
	
	function CheckDate(currentRow)
	{
		var date1 = document.getElementById("Date_Start"+currentRow).value;
		var date2 = document.getElementById("Date_End"+currentRow).value;
		var IsActive = document.getElementById("Combo_ActiveUser"+currentRow).value;
		if (IsActive=="Inactive" && date2=='')
		{
			alert("Please Select End Date");
			document.getElementById("Date_End"+currentRow).focus();
		}
		
		if (date1!='' && date2!='') //
		{
			date1 = new Date($('#Date_Start'+currentRow).val());
			date2 = new Date($('#Date_End'+currentRow).val());			
			
			if (date1 > date2)
			{
				alert("Start Date Must Be Greater Than End Date");
				document.getElementById("Date_End"+currentRow).focus();				
			}			
		}
		
	}
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "User Administration";		
		var s2 = "users-administration.php";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function RefreshData()
	{
		AdministrationList.submit();
	}	
</script>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">	
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title> Coexsys Time Accounting </title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	
	<script src="../datepicker/jquery.js"></script>
	<!--<script src="js1/jquery.js"></script>-->
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<script src="../js/jsfunctions.js"></script>
	<script type="text/javascript" ><?php //include 'find.php'; ?></script>
<style type="text/css">
.requirefieldcls{ background-color: #fff99c;	}
.AttachOnMouseOverText{ color: black;	}
.myclass{ padding-top : 3px; padding-bottom : 3px; }
.datepicker { font-size: 9px; }
.not-valid-tip{ color: #ff0000; }
.bootstrap-datetimepicker-widget td.day { width: 200px;line-height: 10px;font-size: 10px; }
#new_psw_err_tooltip,#reset_psw_err_tooltip { position: absolute; z-index: 999; background: #ededed; }
#new_psw_err_tooltip span,#reset_psw_err_tooltip span{ display: block; padding: 12px 12px 0 12px; }
#new_psw_err_tooltip span:last-child,#reset_psw_err_tooltip span:last-child{ padding-bottom: 26px; }
#new_psw_err_tooltip br,#reset_psw_err_tooltip br{ height: 10px; }
</style>

</head>
<body>
    <!-- modals start -->
    <!--<form method="post" action="" onsubmit = "return chkfld(document.getElementById('Text_Password').value , document.getElementById('Combo_PasswordSecurityRules').value),''">-->
	<form id = "form1" method="post" action="" onsubmit = "return chkfld('CreateUser')" enctype="multipart/form-data">
		<div class="modal fade bs-example-modal-lg custom-modal createUserModal" id="ModalUserDetail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Create User</h4>
					</div>
					<div class="modal-body"  id = "ModalUserBody">
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-6 form-group">
									<label> Email Address  (Your Email Address is your User Name) </label>
									<input type="text"  id="Text_UserName" name = "Text_UserName" required class="form-control requirefieldcls" placeholder=""  onkeypress = 'return UserNameValidation(event);' oninput="this.value=this.value.toUpperCase()" onblur = "DuplicateUserName(this.value)"> <!--onkeyup="this.value=this.value.toUpperCase()" oninput='UserNameValidation(this.value);' -->
								</div>
								<div class="col-sm-6 form-group">
									<label> Password </label>
									<input type="password" id="Text_Password" name="Text_Password" required class="form-control requirefieldcls" placeholder="" maxlength="240">
								     <span id="new_psw_err_tooltip" style="color: #ff0000"></span>
								</div>
								<div class="col-sm-6 form-group">
									<label> Reset Password Days </label>
									<input type="text" id="Text_ResetPasswordDays" name="Text_ResetPasswordDays" required class="form-control requirefieldcls" value = "30"  placeholder="" maxlength="3" onkeypress = 'return ResetPasswordDaysValidation(event);'>
								</div>
								<div class="col-sm-6 form-group">
									<label> Resource Name </label>									
									<?php									
										$qry = "select cxs_resources.*, concat( cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as RESOURCE_NAME from cxs_resources order by RESOURCE_NAME";
										$result = mysql_query($qry);
										echo '<select id = "Combo_ResourceName" name = "Combo_ResourceName" class="form-control requirefieldcls"  required>';
										echo "<option value=''>- Assign Resource Name -</option>";
										while($row=mysql_fetch_array($result))
										{?>
											<option value='<?php echo$row['RESOURCE_ID'];?>'<?php echo ($row['RESOURCE_ID']==$Display_ResourceId)?' selected':'';?>><?php echo $row['RESOURCE_NAME'];?></option>;
									<?php
										}
									?>
									</select>
								</div>
								<div class="col-sm-6 form-group cus-form-ico">
									<label> Start Date </label>
									<input type="text" id="DTPicker_StartDate" name="DTPicker_StartDate" class="form-control requirefieldcls " placeholder="" maxlength="25" required onchange = chk_validdate();>
									<span class="inp-icons"><i class="fa fa-calendar"></i></span>
								</div>
								<div class="col-sm-6 form-group cus-form-ico">
									<label> End Date </label>
									<input type="text" id="DTPicker_EndDate" name="DTPicker_EndDate" class="form-control" placeholder="" maxlength="25" onchange = chk_validdate();>
									<span class="inp-icons"><i class="fa fa-calendar"></i></span>
								</div>
								
								<div class="col-sm-12">
									<div class="row">
										<div class="bdr-btn">
											<h2 class="f-hd"> Application Roles</h2>
											<span></span>
										</div>
										<div class="col-sm-4 form-group">
										<?php
											//$qry = "select * from cxs_application_roles order by ROLE_NAME";
											$qry = "select * from cxs_am_roles where SITE_ID = $SiteId order by ROLE_NAME";
											
											$result = mysql_query($qry);
											echo '<select id = "Combo_ApplicationRoles" name = "Combo_ApplicationRoles" class="form-control "  >';
											echo "<option value=''>- Assign Application Role -</option>";
											while($row=mysql_fetch_array($result))
											{
										?>
												<option value='<?php echo$row['ROLE_ID'];?>'<?php echo ($row['ROLE_ID']==$Display_ApplicationRoleId)?' selected':'';?>><?php echo $row['ROLE_NAME'];?></option>
										<?php
											}
										?>
											</select>

										</div>
										<div class="col-sm-4 form-group cus-form-ico">
											<input type="text" id="DTPicker_RoleStartDate" name="DTPicker_RoleStartDate" class="form-control" onchange = chk_validdate() placeholder="Start Date">
											<span class="inp-icons"><i class="fa fa-calendar"></i></span>
										</div>
										<div class="col-sm-4 form-group cus-form-ico">
											<input type="text" id="DTPicker_RoleEndDate" name="DTPicker_RoleEndDate" class="form-control" onchange = chk_validdate() placeholder="End Date">
											<span class="inp-icons"><i class="fa fa-calendar"></i></span>
										</div>
									</div>
								</div>
							</div>
						</div>
					<!-- end -->
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
							<div class="col-sm-8" style="text-align: left;">
									<div id="crtFrmPswRules">
										New Password must have:
										<ol>
										<?php foreach($password_rules as $rl){ ?>
										<li><?php echo $rl; ?></li>
										<?php } ?>
										</ol>
								  </div>
								  </div>
					 <div class="col-sm-4">					 
						<button type="submit" id="cmdCreateUser" name="cmdCreateUser" class="btn btn-primary btn-style" disabled="disabled">Create User</button>
						</div>
					</div>
				</div>
			</div>
		</div>
    <!-- modals end -->
	</form>
    <!-- modals end -->


	<!--Password Reset modals start -->
	<form method="post" action="" onsubmit="return resetPasswordFormValidation()"><!--onsubmit = "return chkfld('ResetPsw')"-->
	   <input type="hidden" id="reset_psw_used_common_word" name="reset_psw_used_common_word" value="0">
		<div class="modal fade custom-modal" id = "ModalResetPassword" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Reset Password </h4>
					</div>
					<div class="modal-body">
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">

								<div class="col-sm-6 form-group">
									
									<label> New Password </label>
									<input type="password" id="Text_NewPassword" name="Text_NewPassword" class="form-control" placeholder="" maxlength="240">
								     <span id="reset_psw_err_tooltip" style="color: #ff0000"></span>
									<span id="CurrentUserId" style = " visibility: hidden;"></span>
									<span id="CurrentUserPswRule"  style = " visibility: hidden;"></span>
								</div>
								<div class="col-sm-6 form-group">
									<label> Re-enter Password </label>
									<input type="password" id="Text_ReEnterPassword" name="Text_ReEnterPassword" class="form-control" placeholder="" maxlength="25">
								</div>
							</div>
						</div>
						<!-- end -->
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						  <div class="col-sm-8" style="text-align: left;">
								
								New Password must have:
								<ol>
								<?php foreach($password_rules as $rl){ ?>
								<li><?php echo $rl; ?></li>
								<?php } ?>
								</ol>
						  </div>
						  <div class="col-sm-4">
						  <input type='hidden' name='h_userid' id="h_userid" >
						  <input type="hidden" id="rsPsw_userId" name="rsPsw_userId"/>
						  <button type="submit" id = "cmdResetPassword" name = "cmdResetPassword"  class="btn btn-primary btn-style" disabled="disabled"> Save </button>
						  </div>
					</div>
				</div>
			</div>
		</div>
	</form>
    <!--Password Reset modals end -->
	
	
	<!--View Role modals start -->
    <div class="modal fade bs-example-modal-lg2 custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title " id="myModalLabel"> User Roles & Permissions </h4>
                </div>
                <div class="modal-body">
                    <!-- field start-->
                <!--    <div class="col-sm-12">
                        <div class="cus-form-cont">
                            <div class="col-sm-6 form-group">
                                <label> New Password </label>
                                <input type="password" class="form-control" placeholder="" maxlength="25">
                            </div>
                            <div class="col-sm-6 form-group">
                                <label> Re-enter Password </label>
                                <input type="email" class="form-control" placeholder="" maxlength="25">
                            </div>
                        </div>
                    </div>
                    <!-- end -->
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                <!--    <button type="button" class="btn btn-primary btn-style"> Save </button> -->
                </div>
            </div>
        </div>
    </div>
	
    <!--View Role modals end -->
	<!--New View Role modals START - PR-->
	<div class="modal fade bs-example-modal-lg custom-modal" id="Modal_ViewRoleDetails" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" >
		<div class="modal-dialog modal-lg cus-modal-lg" role="document" style = "min-width: 950px;">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel"> Role Details </h4>
				</div>
				<div class="modal-body">
					<div class="col-md-12">
						<div class="row tab-edit">		
							<?php 							
								include("view-role-details.php");
							?>
						</div>
					</div>
				</div>
				<div class="clear-both"></div>
			</div>
		</div>		
	</div>
	<!--New View Role modals END - PR-->

	<?php include("header.php"); ?>
	<section class="md-bg">
		<div class="container-fluid">
			<div class="row">
			  <div class="brd-crmb">
				<ul>
				  <li> <a href="#"> Users And Roles </a></li>
				  <li> <a href="#"> User Administration </a></li>
				</ul>
				</div>
				<div class="dash-strip">
				  <div class="fleft cr-user">
					<a href="rbam.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button></a>
				  </div>
				  <div class="fright">										
				<?php
					$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName'";
					$result=mysql_query	($qry);
					$TotalRecords = mysql_num_rows($result);
					if($TotalRecords == 0)
					{
						$s_Style = "";
					}
					else
					{
						$s_Style = "background-color: #000;";
					}
				?>
					<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
					<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
					<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>
				  </div>
				</div>
            <div class="cont-box">
				<div class="pge-hd">
                  <h2 class="sec-title"> <label id="Label_Title"> User Administration </label> </h2>
                </div>
				<?php
					$UpdateButtonStyle="onclick= 'EditRecord();' ";
					$ViewButtonStyle="onclick= 'ExportRecord();'";
					$Query ="Select * from cxs_am_user_admin where USER_ID = $LoginUserId";
					/*$RunQuery = mysql_query($Query);
					while($row=mysql_fetch_array($RunQuery))
					{
						$IsCreateUser	 = $row['CREATE_NEW_USER'];
						$IsViewOnly 	 = $row['VIEW_ONLY'];
						$IsUpdateOnly 	 = $row['UPDATE_ONLY'];
						
						if($IsUpdateOnly == "Y" && $IsViewOnly == "Y")
						{
							$UpdateButtonStyle="onclick= 'EditRecord();' ";
							$ViewButtonStyle="onclick= 'ExportRecord();'";
						}
						else if($IsCreateUser == "N" && $IsViewOnly == "N")
						{
							$UpdateButtonStyle="style='display:none;'";
							$ViewButtonStyle="style='display:none;'";
						}
						else if($IsViewOnly == "Y")
						{
							$ViewButtonStyle="onclick= 'ExportRecord();'";
						}
						else if($IsViewOnly == "N")
						{
							$ViewButtonStyle="disabled";
							$UpdateButtonStyle="disabled";
						}
						if($IsUpdateOnly == "N")
						{
							$UpdateButtonStyle="style='display:none;'";
						}
					}	*/			
					$msg = "";
					$s_Query = str_replace("\\","",$s_Query);
					$selectQuery = "select count(*) as expr1 from (SELECT  concat( cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as RESOURCE_NAME,cxs_users.* FROM cxs_users Left JOIN cxs_resources ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE 1=1 and cxs_users.SITE_ID = $SiteId $s_Query  ) as a";
					$RunUserQuery=mysql_query($selectQuery);
					while($row = mysql_fetch_array($RunUserQuery))
					{
						$TotalSearchRecords = $row['expr1'];
					}
					if ($TotalSearchRecords==0)
					{
						$msg = "No Record Found";
					}
				?>
                <div>
					<form class="form" id="AdministrationList" name="AdministrationList" action="" method="POST">
						<div class="row">
							<h4 class="text-center" style = "color:red;"> <?php echo $msg; ?> </h4>
						</div>
						<div class="fleft two">					
							<button type="button" class="btn-style btn"  <?php if($UPDATE_PRIV_ua_PERMISSION =='Y' ){ ?> id="cmdUpdateSelected" name="cmdUpdateSelected"   <?php echo $UpdateButtonStyle; ?><?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>
							<button type="button" class="btn-style btn" id="cmdExport" name="cmdExport"  <?php echo $ViewButtonStyle; ?> > Export </button>
							<!--<button type="button" class="btn-style btn" id="cmdCancel" name="cmdCancel" disabled="disabled"> Cancel</button>-->
							<!--<a href="downloaddata.php?r=user-administration" target= "_blank" class="btn-style btn">Export</a>-->
						</div>
						<div class="fright cr-user">
							<a <?php $IsDisable = ""; if($CREATE_PRIV_ua_PERMISSION=='Y' ){ ?> href="users-administration-create.php"  <?php }else{ $IsDisable = "disabled='disabled'"; } ?>  >
								<button type="button" class="btn btn-primary btn-style"   <?php echo $IsDisable; ?> > Create User</button> </a>
							<!--<button type="button" onclick="ClearField()" class="btn btn-primary btn-style" <?php if($CREATE_PRIV_ua_PERMISSION =='Y' ){ ?>data-toggle="modal" data-target=".createUserModal" <?php } else{ ?> disabled="disabled" <?php } ?> > Create User</button>-->
						</div>
						
					<div id = "dataView" name = "dataView">
						<div class="data-bx">
							<div class="table-responsive">
							<table id='UserDataTable' class="table table-bordered " width="100%" >
							<thead>
							<tr>
								<th style="display:none;"><span> </span></th>
								<th width="5%" class="check-bx"> <input type="checkbox" id="selectall"  onchange="checkAll(this)"> </th>
								<th width="20%">
									<?php if($Sorts == 'desc' && $FileName == 'USER_NAME') { ?>
									  <span style="">
											User Name 
										<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('USER_NAME','asc');"></i>
									  </span>
									<?php } else { ?>
									  <span style="">
											User Name 
										<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('USER_NAME','desc');"></i>
									  </span>
									<?php } ?>
								</th>

								<th width="20%">
									<?php if($Sorts == 'desc' && $FileName == 'RESOURCE_NAME') { ?>
										  <span style="">
											Resource Name 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_NAME','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Resource Name 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('RESOURCE_NAME','desc');"></i>
										  </span>
									<?php } ?>
								</th>

								<th width="8%"> Resource ID </th>

								<th width="12%">
									<?php if($Sorts == 'desc' && $FileName == 'START_DATE') { ?>
										  <span style="">
											Start Date Active 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('START_DATE','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Start Date Active 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('START_DATE','desc');"></i>
										  </span>
									<?php } ?>
								</th>

								<th width="12%">
									<?php if($Sorts == 'desc' && $FileName == 'END_DATE') { ?>
										  <span style="">
											End Date Active 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('END_DATE','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											End Date Active 
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('END_DATE','desc');"></i>
										  </span>
									<?php } ?>
								</th>

								<th width="8%"> Active User </th>
								<th width="5%"> Actions </th>
								<th width="5%"> Actions </th>
							  </tr>
						</thead>
						<tbody>
						<?php							
							$selectQuery = "SELECT USER_NAME,CONCAT(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) AS RESOURCE_NAME,cxs_users.RESOURCE_ID,START_DATE,END_DATE,'' as UserStatus, cxs_users.* FROM cxs_users Left JOIN cxs_resources ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_users.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";
							$selectQueryForPages  = $selectQuery;
							$selectQuery = $selectQuery." limit $start_from , $record_per_page";
							
							$ExportQry = $selectQuery;
							
							$RunUserQuery=mysql_query($selectQuery);
							$StdNumRows = mysql_num_rows($RunUserQuery);
							$i= 1;
							while($rows=mysql_fetch_array($RunUserQuery))
							{ 
								$UserId			= $rows['USER_ID'];
								$UserName 		= $rows['USER_NAME'];
								$ResourceId 	= $rows['RESOURCE_ID'];
								$CurrentDate = date('m/d/Y');
								if((!is_null($rows['START_DATE'])) && (($rows['START_DATE'])!='0000-00-00') )
								{			
									$StartDate = date('m/d/Y', strtotime($rows['START_DATE']));
								}
								else
								{
									$StartDate ='';
								}
								if((!is_null($rows['END_DATE'])) && (($rows['END_DATE'])!='0000-00-00'))
								{			
									$EndDate = date('m/d/Y', strtotime($rows['END_DATE']));
									$EndDate1 = strtotime($EndDate);
									$CurrentDate1 = strtotime($CurrentDate);
													
									if($EndDate1 >= $CurrentDate1)
									{
										$ActiveUser = "Active";
									}
									else
									{
										$ActiveUser = "Inactive";
									}
								}
								else
								{
									$EndDate ='';
									$ActiveUser = "Active";
								}
								//$EndDate 		= $rows['END_DATE'];
								$ResourceName	= $rows['RESOURCE_NAME'];
								$CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));
								$CreatedBy		= $rows['CREATED_BY'];		
								$LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));
								$UpdatedBy		= $rows['LAST_UPDATED_BY'];
								$CreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $CreatedBy");
								$UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");
								$PasswardSecurityRules = $rows['PWD_RULE_CODE'];
							?>
							  <tr id = "<?php $rowId = "row$i"; echo $rowId; ?>" <?php if (getRoleAccessStatusByUser('VIEW_ONLY',$_SESSION['user_id'])=='Y') { ?> ondblclick="TableRowFunction('<?php echo $UserId; ?>')" <?php } ?>>
								<td style="display:none;" id="<?php echo $i."_0";?>">
									 <?php echo $UserId; ?>
								</td>
								<th id="<?php echo $i."_1"; ?>" class="check-bx"> 
									<input type="checkbox" id="<?php echo "Check_Record$i";?>" name="<?php echo "Check_Record$i";?>" onclick="checkAll1()" value = "<?php echo $i; ?>" class="record_chk">
									<input type="hidden" id = <?php echo "h_userid".$i; ?> name = <?php echo "h_userid".$i; ?> value = "<?php echo $UserId; ?>">
									<input type="hidden" id = <?php echo "h_resourceId".$i; ?> name = <?php echo "h_resourceId".$i; ?> value = "<?php echo $ResourceId; ?>">
								</th>
								<td id="<?php echo $i."_2";?>"  > <?php echo $UserName; ?></td>
								<td id="<?php echo $i."_3";?>" >
									 <span id = "<?php echo "span".$i."_3"; ?>"><?php echo $ResourceName; ?></span>						</td>
								<td id="<?php echo $i."_4";?>"> <?php echo $ResourceId; ?></td>
								<td id="<?php echo $i."_5";?>" >
									<span id = "<?php echo "span".$i."_5"; ?>" style = "display:show">	<?php echo $StartDate; ?></span>																		
								</td>
								<td id="<?php echo $i."_6";?>" >
									<span id = "<?php echo "span".$i."_6"; ?>" style = "display:show">	<?php echo $EndDate; ?></span>									
								</td>
								<td id="<?php echo $i."_7";?>" > <span id = "<?php echo "span".$i."_7"; ?>" style = "display:show">	<?php echo $ActiveUser; ?></span>
										
							</td>
							<td id="<?php echo $i."_8";?>" >
								<ul class="action-bx">
									<li class="dropdown">
									  <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
									  <ul class="dropdown-menu ac-custom" id = "CurrentUserAction">
										<li data-toggle="modal" data-target="#ModalResetPassword"><a href="javascript:fun1(<?php echo $UserId; ?>,'<?php echo $PasswardSecurityRules;?>');"><i class="fa fa-key"></i> Reset Password </a></li>
										<li data-toggle="modal"  title = 'Creation Date: <?php  echo $CreationDate; ?>&#013; Created By: <?php echo $CreatedByName; ?> &#013 Last Update Date : <?php  echo $LastUpdate; ?>&#013; Updated By: <?php echo $UpdatedByName; ?>'><a href="javascript:ViewRole('<?php echo $UserName; ?>')"> <i class="fa fa-eye"></i> View Roles </a></li>
									  </ul>
									</li>
								</ul>
							</td>
							<td>							
								<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
								Created By: <?php echo $CreatedByName; ?> <br> Updated By: <?php echo $UpdatedByName; ?> 
								<br> Creation Date: <?php echo $CreationDate; ?> <br> Last Update Date: <?php echo $LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>							
							</td>
						</tr>
						<?php
							$i=$i+1;						
						}						
						?>
						</tbody>
					</table>
					</div>
					</div>
									  
					<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FileName; ?>">
					<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">						  					
					<input type = "hidden" id="h_query" name="h_query" value=""/>
					<input type = "hidden" id="h_pagename" name="h_pagename" value="<?php echo $PageName; ?>"/>
						<!-- pagination start-->
						<div class="pagination-bx">
							<div class="bs-example">
								<ul class="pagination">
								<?php
								//$selectQueryForPages=$selectQueryForPages;
								$RunDepQuery=mysql_query($selectQueryForPages);
								$num_records = mysql_num_rows($RunDepQuery);
								$total_pages= ceil($num_records/$record_per_page);
								if (($page-1)==0){ ?>
									<li class="disabled">
										<!--<a rel="0" href="#"> «</a>-->
										<a rel="0" href="#">&laquo;</a>
									</li>
								  <?php  } else{  ?>
									<li class="">
										<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
									</li>
								<?php }
								   for($i=1;$i<=$total_pages;$i++){ ?>
									<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
								<?php }
								 if (($page+1)>$total_pages){   ?>
									<li class="disabled"><a href="#">&raquo;</a></li>
								<?php  }else{    ?>
								   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
								  <?php } ?>
								</ul>
							</div>
						</div>
						<!-- pagination end -->
					</div>				
				</form>
			</div>
		</div>
		</div>
	  </div>
	</section>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript">	
$('#Text_Password').blur(function() {
	   checkPasswordError($(this).val(),$("#new_psw_err_tooltip"),$("#cmdCreateUser"));
});
$('#Text_NewPassword').blur(function() {
	   checkPasswordError($(this).val(),$("#reset_psw_err_tooltip"),$("#cmdResetPassword"));
});
$('#Text_ReEnterPassword').keyup(function() {
	   form_element_correct($('#Text_ReEnterPassword'));
});
$('#Text_Password,#Text_NewPassword,#Text_ReEnterPassword').keypress(function(e) {
	 
	   if ((e.which >= 33 && e.which<=45) || (e.which >= 47 && e.which<=126) || e.which==8 || e.which==0) {
			 return true;
	   }
	   else{
			 return false;
	   }
	   
	   /*if(e.which === 32 || e.which === 46) //not accepts space and dot
	   {
			 return false;
	   }*/
});
/*$("#cmdCancel").click(function()
{
   $('.record_chk').each(function () 
   {
		$(this).prop('checked' , false);		
   });
	if ($('.record_chk:checked').length == 0)
	{
		document.getElementById("cmdUpdateSelected").innerHTML = "Update selected";
		$("#cmdCancel").attr('disabled',true);
		$("#cmdExport").attr('disabled',false);
		$("#selectall").prop('checked' , false);
		//flag_checked="N";
		flag_updaterecord = "N";
	}
});*/
function fun1(userid,rules)
{
	document.getElementById("CurrentUserId").innerHTML =userid;
	document.getElementById("CurrentUserPswRule").innerHTML =rules;
	$("#rsPsw_userId").val(userid);
}
		
var TotalRows = document.getElementById("UserDataTable").rows.length;
TotalRows=TotalRows-1;

function makeRequest(url,data)
{
		var http_request = false;
		if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
}

function alertContents(http_request)
{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{
				if (KEY == "message")
				{
					//document.getElementById("message").innerHTML = http_request.responseText;
					if (document.getElementById("message").innerHTML == "")
					{
						document.getElementById("h_IsDuplicateEntry").value = "";
					}
					else
					{
						document.getElementById("h_IsDuplicateEntry").value = "y";
						document.getElementById("txtLeadName").focus();
						document.getElementById("message").style.display="block";
						return false;
					}
				}
				else if (KEY == "SubjectData")
				{
						document.getElementById("SubjectData").innerHTML = http_request.responseText;
				}

				else if(KEY == 'UserName')
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)
					{
						alert(s1);
						document.getElementById("Text_UserName").focus();
					}
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText); 					
					//alert(JSON.stringify(JSONObject));				
									
					$('#Text_UserName').val(JSONObject['cxs_users']["USER_NAME"]);
					$('#Text_Password').val(JSONObject['cxs_users']["convertpsw"]);					
					$('#Combo_ResourceName').val(JSONObject['cxs_users']["RESOURCE_ID"]);
					//$('#DTPicker_StartDate').val(JSONObject['cxs_users']["START_DATE"]);
					
					$('#DTPicker_StartDate').val(MyDateFormat(JSONObject['cxs_users']["START_DATE"]));
					$('#DTPicker_EndDate').val(MyDateFormat(JSONObject['cxs_users']["END_DATE"]));
					//$('#Text_EndDate').val(MyDateFormat(JSONObject['cxs_resources']["END_DATE_ACTIVE"]));
					
					
					$('#Combo_ApplicationRoles').val(JSONObject['cxs_users']["ROLE_ID"]);
					$('#DTPicker_RoleStartDate').val(MyDateFormat(JSONObject['cxs_users']["ROLE_START_DATE"]));
					$('#DTPicker_RoleEndDate').val(MyDateFormat(JSONObject['cxs_users']["ROLE_END_DATE"]));
					
					//$('#Text_CalendarName').val(JSONObject['cxs_holidays']["CALENDAR_NAME"]);					
					//$('#Text_PeriodYear').val(JSONObject['cxs_holidays']["PERIOD_YEAR"]);
					
				}
				else if (KEY == "SearchResourceNameData")
				{
					var str = http_request.responseText;					
					document.getElementById("ListResourceResult").innerHTML = str;
					
					if (document.getElementById("Text_ResourceName").value ==""	)
					{
						ResetResourceDiv();
					}
				}				
				else if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
			}
			else
			{
				//document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}
function resetPasswordFormValidation()
{
	   var valid_frm = 'Y';
	   
	   var minPswLength = <?php echo getSettingVal('MINIMUM_ALLOWED'); ?>;
	   
	   var oneCapLtr = new RegExp('(?=.*[A-Z])');
	   var oneLowrLtr = new RegExp('(?=.*[a-z])');
	   var oneDigit = new RegExp('(?=.*\d)');
	   var oneSplChar = /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/;
	   
	   var new_Password = $("#Text_NewPassword");
	   var reentered_Password = $("#Text_ReEnterPassword");
	   
	   if ($.trim(new_Password.val())!='') {
			 comparePswdWithCommonWords($.trim(new_Password.val()),$("#reset_psw_used_common_word"));
	   }	   
	   
	   if ($.trim(new_Password.val())=='') {
			 form_element_correct(new_Password);
			 form_element_empty_err(new_Password);
			 valid_frm = 'N';
	   }
	   else if ($.trim(new_Password.val()).length<minPswLength) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The New Password should contain atleast '+minPswLength+' characters.</span>');
			 valid_frm = 'N';
	   }
	   <?php if(getSettingVal('ALLOW_SPECIALS')=='Y'){ ?>
	   else if (!oneSplChar.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one special character: \':;/?.>,<`~@#$%^&*()_+=-][{}\|"</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_UPPERCASE')=='Y'){ ?>
	   else if (!oneCapLtr.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one uppercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_LOWERCASE')=='Y'){ ?>
	   else if (!oneLowrLtr.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one lowercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_NUMERIC')=='Y'){ ?>
	   else if ($.trim(new_Password.val()).search(/\d/) == -1) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one Numeric Value.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ENABLE_COMMON')=='Y'){ ?>
	   else if ($("#reset_psw_used_common_word").val() >= 1) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">You have entered a password that is a very commonly or known word, consecutive alphabets or with consecutive numbers. This is not allowed. Please try different combination that is not common.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   else
	   {
			 form_element_correct(new_Password);
	   }
			 
	   if ($.trim(reentered_Password.val())==''){
			 form_element_correct(reentered_Password);
			 form_element_empty_err(reentered_Password);
			 valid_frm = 'N';
	   }
	   else
	   {
			 form_element_correct(reentered_Password);
	   }
	   
	   if ($.trim(new_Password.val())!='' && $.trim(reentered_Password.val())!='' && ($.trim(new_Password.val())!=$.trim(reentered_Password.val()))){
			 form_element_correct(reentered_Password);
			 reentered_Password.addClass('error_ele');
			 reentered_Password.after('<span role="alert" class="not-valid-tip">Password not matched.</span>');
			 valid_frm = 'N';
	   }
	   else if ($.trim(new_Password.val())!='' && $.trim(reentered_Password.val())!='') {
			
			 form_element_correct(reentered_Password);
	   }
	   
	   if (valid_frm == 'Y') {
			 return true;
	   }
	   else
	   {
			 return false;
	   }
}
function checkPasswordError(password,ele_error_tooltip,btn_submit_ele)
{
	   ele_error_tooltip.empty();
	   
	   var valid_frm = 'Y';
	   
	   var minPswLength = <?php echo getSettingVal('MINIMUM_ALLOWED'); ?>;
	   
	   var oneCapLtr = new RegExp('(?=.*[A-Z])');
	   var oneLowrLtr = new RegExp('(?=.*[a-z])');
	   var oneDigit = new RegExp('(?=.*\d)');
	   var oneSplChar = /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/;
	   
	   
	   <?php if(getSettingVal('ALLOW_NUMERIC')=='Y'){ ?>
	   if (password.search(/\d/) == -1) {
			 //ele_error_tooltip.append('<span>* The new password must have at least one Numeric Value.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_UPPERCASE')=='Y'){ ?>
	   if (!oneCapLtr.test(password)) {
			 //ele_error_tooltip.append('<span>* The new password must have at least one uppercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_LOWERCASE')=='Y'){ ?>
	   if (!oneLowrLtr.test(password)) {
			 //ele_error_tooltip.append('<span>* The new password must have at least one lowercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_SPECIALS')=='Y'){ ?>
	   if (!oneSplChar.test(password)) {
			// ele_error_tooltip.append('<span>* The new password must have at least one special character: \':;/?.>,<`~@#$%^&*()_+=-][{}\|</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   if (password.length<minPswLength) {
			 			 
			 //ele_error_tooltip.append('<span>* The New Password should contain atleast '+minPswLength+' characters.</span>');
			 valid_frm = 'N';
	   }
	   if (password.length>240) {
			 			 
			 //ele_error_tooltip.append('<span>* The New Password should contain maximum 240 characters.</span>');
			 valid_frm = 'N';
	   }
	   <?php if(getSettingVal('ENABLE_COMMON')=='Y'){ ?>
	   comparePswdWithCommonWords(password,$("#reset_psw_used_common_word"));
	   if ($("#reset_psw_used_common_word").val() >= 1) {
			// ele_error_tooltip.append('<span>* You have entered a password that is a very commonly or known word, consecutive alphabets or with consecutive numbers. This is not allowed. Please try different combination that is not common.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   
	   if (valid_frm=='Y') {
			 btn_submit_ele.attr('disabled',false);
	   }
	   else
	   {
			 btn_submit_ele.attr('disabled',true);
	   }
	   	   
}
function comparePswdWithCommonWords(pwd,ele_psw_used_cmn_wrd){
	   
	   var form_data = new FormData();
	   form_data.append("psword", pwd);
	   
	   jQuery.ajax({
			url: "../ajax-functions/comparePswdWithCommonWords.php", // point to server-side PHP script 
			dataType: 'text', // what to expect back from the PHP script
			cache: false,
			contentType: false,
			processData: false,
			async: false,
			data: form_data,
			type: 'POST',
			success: function (response) {
				ele_psw_used_cmn_wrd.val(response);
			},
			error: function (response) {
				//$('#fileMsg').html(response); // display error response from the PHP script
			}
	   });
}
function form_element_empty_err(element)
{
    element.addClass('error_ele');
    element.after('<span role="alert" class="not-valid-tip">The field is required.</span>');
}
function form_element_valid_err(element)
{
    element.addClass('error_ele');
    element.after('<span role="alert" class="not-valid-tip">The field is not valid.</span>');
}
function form_element_correct(element)
{
    element.removeClass('error_ele');
    element.next('span.not-valid-tip').remove();
    //element.nextAll().remove();
}
/*
function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}
*/
function ExportRecord1()
	{
	   
		KEY= "ExportRecord";
		var qry="";
		var qry1="";
		var s1="";
		var counter = document.getElementById("UserDataTable").rows.length;
		counter = counter-1; // heading not count
		var flag_checked="";
		for(i=1;i<=counter;i++)
		{
			if (document.getElementById("Check_Record"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById(i+"_0").innerHTML;
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		qry1 = '<?php echo $SQueryOrderBy; ?>';					
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportUsrAdministration&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("selectall").focus();
		}
	}	
	
			
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = "<?php echo $ExportQry; ?>";	
		var flag_checked = "";
		var TotalRows = $("#UserDataTable tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#Check_Record"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_userid"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#UserDataTable thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='' && $(this).text().trim()!= 'Actions')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'USER_ID', ExportIdList:exportIds,
						  ExportFileName:'_users-administration.xls', ExportSheetTitle:"User Administration"
						  },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	</script>
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>