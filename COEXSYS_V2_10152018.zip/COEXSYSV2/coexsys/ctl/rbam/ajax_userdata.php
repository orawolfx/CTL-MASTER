<?php
include('../conn.php');
include ("functions.php");
if(isset($_POST['uname']) && $_POST['uname'] != "" )
{
	$UserName = $_POST['uname'];
	$UserID = getvalue("cxs_users","USER_ID"," where USER_NAME = '$s_uname'")	;
	//DisplayRecords("USER_ID",$UserID);
	
	$qry = "SELECT cxs_users.*,cxs_resources.*,cxs_am_roles.*,cxs_am_approval_mgmt.*,cxs_am_ta_rules.*,
			cxs_am_roles.CREATED_BY as ua_createdby,cxs_am_roles.CREATION_DATE as ua_createddt,
			cxs_am_roles.LAST_UPDATED_BY as ua_lastupdatedby,cxs_am_roles.LAST_UPDATE_DATE	as ua_lastupdateddt,
			cxs_am_ta_rules.CREATED_BY as ta_createdby,cxs_am_ta_rules.CREATION_DATE as ta_createddt,
			cxs_am_ta_rules.LAST_UPDATED_BY as ta_lastupdatedby,cxs_am_ta_rules.LAST_UPDATE_DATE	as ta_lastupdateddt,
			cxs_am_approval_mgmt.CREATED_BY as apmgmt_createdby,cxs_am_approval_mgmt.CREATION_DATE	as apmgmt_createddt,
			cxs_am_approval_mgmt.LAST_UPDATED_BY as apmgmt_lastupdatedby,cxs_am_approval_mgmt.LAST_UPDATE_DATE	as apmgmt_lastupdateddt from cxs_users 
		Inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID  
		LEFT join cxs_am_roles on cxs_am_roles.ROLE_ID = cxs_users.ROLE_ID
		LEFT join cxs_am_approval_mgmt on cxs_am_approval_mgmt.USER_ID = cxs_users.USER_ID			
		LEFT JOIN cxs_am_ta_rules ON cxs_am_ta_rules.USER_ID = cxs_users.USER_ID
		where USER_NAME = '$UserName'";
		
	$result = mysql_query($qry);
	$TotalRecords = mysql_num_rows($result);
	while($row=mysql_fetch_array($result))
	{
		/******User Administration******/		
		$data['CreateUser']=$row['CREATE_NEW_USER'];
		$data['ViewOnly']=$row['VIEW_ONLY'];
		$data['UpdateOnly']=$row['UPDATE_ONLY'];
		$data['OverideInUse']=$row['OVERRIDE_INUSE'];
		$data['ViewSubscribers']=$row['VIEW_SUBSCRIBERS'];					
		$data['SubmitCustom']=$row['SUBMIT_CUSTOM'];
		$data['ViewSLA']=$row['VIEW_SLA'];
		$data['ExistUserAdmin']=$row['EXISTING_USER'];
		$data['UsageHistory']=$row['USAGE_HISTORY'];
		$data['UpdateSiteContacts']=$row['UPDATE_SITE_CONTACTS'];
		
		/******Time Accounting Rules******/
		
	//	$data['BusinessMessage']=$row['BIZ_MSG_FLAG'];
	//	$data['SetAudit']=$row['AUDIT_FLAG'];
	//	$data['AllowNegativeTimeEntry']=$row['ALLOW_NEGATIVE'];
	//	$data['AdvanceForOvertime']=$row['ADVANCE_FOR_OVERTIME'];
	//	$data['SubmittedTime']=$row['UPDATE_SUBMITTED'];		
	//	$data['PrimaryApprover']=$row['OVERRIDE_PRIMARY'];		
	//	$data['MaxDailyLimit']=$row['MAX_DAILY_LIMIT'];
	//	$data['FlexibleTimeEntry']=$row['AFT_ENTRY'];		
	//	$data['CopyTimesheetEmployees']=$row['ALLOW_COPY'];
	//	$data['AllowOverrideWorkshift'] 	= $row['ALLOW_OVERRIDE_WORKSHIFT'];
		$data['RecentTimecards']=$row['RECENT_TIMECARDS'];
		$data['RetroAdjustments']=$row['RETRO_ADJUST'];			
		$data['AllowRetroUpdates']=$row['RETRO_PERIOD_NUM'];
		$data['AllowPreApproval'] 		= $row['ALLOW_PREAPPROVAL'];
		
		/*$data['CreateTimeSheet'] 			= $row['COPY_ANYONE_TS_FLAG'];
		$data['ApproveTimeSheet'] 			= $row['APPROVE_ANYONE_TS'];
		$data['CreateTimeSheetTeam'] 		= $row['CREATE_ANYONE_TS'];
		$data['ApproveTimeSheetTeam'] 		= $row['APPROVE_ANYONE_TS_TEAM'];
		$data['CreateSupervisorTimeSheet']	= $row['ALLOW_SUP_TS'];	*/	
		
		$UACreatedBy  	 	= $row['ua_createdby']; //cxs_am_roles
		$UAUpdatedBy 		= $row['ua_lastupdatedby'];//cxs_am_roles
		
		$TARCreatedBy  	 	= $row['ta_createdby'];
		$TARUpdatedBy 		= $row['ta_lastupdatedby'];
		
		if($UACreatedBy!='') $CreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UACreatedBy");
		if($UAUpdatedBy!='') $UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UAUpdatedBy");
		$data['UACreatedBy']=$CreatedByName;
		$data['UAUpdatedBy']=$UpdatedByName;
		
		if($TARCreatedBy!='') $TARCreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $TARCreatedBy");
		if($TARUpdatedBy!='') $TARUpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $TARUpdatedBy");
		$data['TARCreatedBy']=$TARCreatedByName;
		$data['TARUpdatedBy']=$TARUpdatedByName;
		//$data['TARCreatedBy']=$TARCreatedBy;
		//$data['TARUpdatedBy']=$TARCreatedBy;
		/*
		if($PACreatedBy!='') $PACreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $PACreatedBy");
		if($PAUpdatedBy!='') $PAUpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $PAUpdatedBy");
		*/
		if($AMCreatedBy!='') $AMCreatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $AMCreatedBy");
		if($AMUpdatedBy!='') $AMUpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $AMUpdatedBy");
		
		if((!is_null($row['ua_createddt'])) && (($row['ua_createddt'])!='0000-00-00 00:00:00') )
		{
			$UACreationDate = date('m/d/Y h:i:sa', strtotime($row['ua_createddt']));	
			$data['UACreationDate']=$UACreationDate;
		}
		if(!is_null($row['ua_lastupdateddt']))
		{
			$UALastUpdateDate = date('m/d/Y h:i:sa', strtotime($row['ua_lastupdateddt']));
			$data['UALastUpdateDate']=$UALastUpdateDate;
		}
		if((!is_null($row['ta_createddt'])) && (($row['ta_createddt'])!='0000-00-00 00:00:00') )
		{
			$TARCreationDate = date('m/d/Y h:i:sa', strtotime($row['ta_createddt']));	
			$data['TARCreationDate']=$TARCreationDate;
		}
		if(!is_null($row['ta_lastupdateddt']))
		{
			$TARLastUpdateDate = date('m/d/Y  h:i:sa', strtotime($row['ta_lastupdateddt']));
			$data['TARLastUpdateDate']=$TARLastUpdateDate;
		}	
	}
	/******Approval Management******/
	$TotalModuleNumbers=18;
	$data[TotalRecords1]=$TotalModuleNumbers;
	
	$ModuleListRows=array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18);
	
	$TAMCreatedBy = '';
	$TAMUpdatedBy = '';
	$TAMCreationDate='';
	$TAMLastUpdateDate = '';
	
	foreach ($ModuleListRows as $value) 
	{
		$DBRowNo = $value;			
		${ModuleName.$DBRowNo}	= '';
		${CreatePriv.$DBRowNo}	= '';	
		${UpdatePriv.$DBRowNo}	= '';
		${ViewPriv.$DBRowNo} 	= '';
		${EnableAudit.$DBRowNo}	= '';
		
		$qry = "select cxs_ta_modules.* from cxs_ta_modules left join  cxs_users on cxs_users.USER_ID = cxs_ta_modules.USER_ID where  USER_NAME = '$UserName' and ROWNO = $value";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			${ModuleName.$DBRowNo}	= $row['MODULE_NAME'];
			${CreatePriv.$DBRowNo}	= $row['CREATE_PRIV'];	
			${UpdatePriv.$DBRowNo}	= $row['UPDATE_PRIV'];
			${ViewPriv.$DBRowNo} 	= $row['VIEW_PRIV'];
			${EnableAudit.$DBRowNo}	= $row['ENABLE_AUDIT'];			
			
			if((!is_null($row['CREATION_DATE'])) && (($row['CREATION_DATE'])!='0000-00-00 00:00:00') )
			{
				$TAMCreationDate = date('m/d/Y h:i:sa', strtotime($row['CREATION_DATE']));	
				$TAMCreatedBy  			= $row['CREATED_BY'];
				$TAMCreatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TAMCreatedBy");
				
				$data[TAMCreationDate]=$TAMCreationDate;
				$data[TAMCreatedBy]=$TAMCreatedBy;
			}
			if(!is_null($row['LAST_UPDATE_DATE']))
			{
				$TAMLastUpdateDate = date('m/d/Y  h:i:sa', strtotime($row['LAST_UPDATE_DATE']));
				$TAMUpdatedBy = $row['LAST_UPDATED_BY'];
				$TAMUpdatedBy = getvalue("cxs_users","USER_NAME", "where USER_ID = $TAMUpdatedBy");
				$data[TAMUpdatedBy]=$TAMUpdatedBy;
			}
		}
		$data[ModuleName.$DBRowNo]=${ModuleName.$DBRowNo};
		$data[CreatePriv.$DBRowNo]=${CreatePriv.$DBRowNo};
		$data[UpdatePriv.$DBRowNo]=${UpdatePriv.$DBRowNo};
		$data[ViewPriv.$DBRowNo]=${ViewPriv.$DBRowNo};
		$data[EnableAudit.$DBRowNo]=${EnableAudit.$DBRowNo};
		
	}
	
	$data[TAMLastUpdateDate]=$TAMLastUpdateDate;
	/******Personal Aliases******/
	/*$qry = "select * from cxs_am_personal_alias inner join cxs_users on cxs_users.USER_ID = cxs_am_personal_alias.USER_ID where cxs_users.USER_NAME = '$UserName'";
	$result = mysql_query($qry);
	$TotalRecords1 = mysql_num_rows($result);
	while($row = mysql_fetch_array($result))
	{
		$data['cxs_am_personal_alias'][]=$row;
	}
	
	$s_qry = "SELECT cxs_am_approval_mgmt.REFERENCE_APPROVER_ID,CONCAT(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as ApproverName,cxs_resources.RESOURCE_TYPE as ApproverType,
	(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_am_approval_mgmt.CREATED_BY) as CreatedBy,
	(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_am_approval_mgmt.LAST_UPDATED_BY) as UpdatedBy,cxs_am_approval_mgmt.CREATION_DATE,cxs_am_approval_mgmt.LAST_UPDATE_DATE
	FROM cxs_resources inner join cxs_am_approval_mgmt on cxs_am_approval_mgmt.REFERENCE_APPROVER_ID = cxs_resources.RESOURCE_ID
	inner join cxs_users on cxs_users.USER_ID = cxs_am_approval_mgmt.USER_ID
	where cxs_users.USER_NAME = '$UserName' order by ROWNO";			

	$s_result = mysql_query($s_qry);
	while($row=mysql_fetch_array($s_result))
	{
		$data['cxs_am_approval_mgmt'][]=$row;		
	}*/
	echo json_encode($data);
}

?>
