<?php
include('../conn.php');
?>
<?php
if($_REQUEST['REQUEST'] == "FindDataCopyAlias")
{
	$AliasName = $_REQUEST['AliasName'];	
	$LoginUserId = $_SESSION['user_id']; 
	$SiteId = $_SESSION['user-siteid']; 
?>
	<table id='TablePopup-CopyAliasHd' class="table table-bordered " width="100%"  >
		<thead>
		  <tr>
			<th width="5%" class="check-bx "><input type="checkbox" id="Copy_Checkbox_SelectAll" onchange="CopyCheckAll()"></th>
			<th width="10%"> User Name </th>
			<th width="15%"> Alias Name </th>
			<th width="35%"> Description </th>
		  </tr>
		</thead>
		<tbody id = "TablePopup-CopyAliasList">
<?php	//if(//$AliasName!='')
	{ 	
		$i=1;
		$sql = "SELECT cxs_aliases.*,cxs_users.USER_NAME from cxs_aliases  inner join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY where cxs_aliases.ALIAS_CLASS <> '' and COPY_ALLOWED = 'Y' and cxs_aliases.ALIAS_NAME like '%$AliasName%' and cxs_aliases.CREATED_BY <> $LoginUserId  AND ACTIVE_FLAG = 'Y' and cxs_aliases.ALIAS_NAME  not in (select cxs_aliases.ALIAS_NAME from cxs_aliases where cxs_aliases.CREATED_BY = $LoginUserId) and cxs_aliases.SITE_ID = $SiteId order by cxs_aliases.ALIAS_NAME";
		$result = mysql_query($sql);	
		while($row=mysql_fetch_array($result))
		{
			$UserName = $row['USER_NAME'];
			$AliasId = $row['ALIAS_ID'];
			$AliasName =  $row['ALIAS_NAME'];
			$Description =  $row['DESCRIPTION'];			
		?>
			<tr style="cursor:pointer"  >
				<td class="check-bx "><input type="checkbox" id="<?php echo "Copy_CheckboxInline$i" ?>" name="<?php echo "Copy_CheckboxInline$i" ?>" onchange="CopyCheckInline()"></th>
				<td><?php echo $UserName; ?>
					<input type="hidden" id = <?php echo "h_AliasId$i"; ?> name = <?php echo "h_AliasId$i "; ?> value = "<?php echo $AliasId; ?>">
				</td> 
				<td><?php echo $AliasName; ?></td> 
				<td><?php echo $Description; ?></td>  				
			</tr>
	<?php
			$i=$i+1;
		}	}?>
		</tbody>
	</table>
<?php }
if($_REQUEST['REQUEST'] == "CopyAliasData")
{
	$AliasId = $_REQUEST['AliasId'];
	$CurrentUserId = $_SESSION["user_id"];
	$SiteId = $_SESSION['user-siteid'];
	$AlreadyExist = "";
	if($AliasId!='')
	{	
		do
		{
			$pos = strpos($AliasId,"|");
			$s1 = trim(substr($AliasId, 0, $pos));  //id
			$sQuery = $sQuery."ALIAS_ID=$s1 or ";
			$AliasId = substr($AliasId, $pos+1);
		}while($AliasId.length>0);			
		$sQuery=substr( $sQuery, 0, -3 ); // create query
	/*	if ($sQuery!='') // check already exists or not
		{
			$qry = "Select * from cxs_aliases where 1=1 and ($sQuery) and CREATED_BY = $CurrentUserId order by ALIAS_NAME";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$AlreadyExist = $AlreadyExist.$row['ALIAS_NAME'].",";
			}
		}
		
		if ($AlreadyExist!='') 
		{
			$AlreadyExist = substr($AlreadyExist,0,-1);
			echo "You cannot copy your own aliases name - $AlreadyExist";	
		}
		else //when not exists - insert record
		{*/				$qry = "Select * from cxs_aliases where 1=1 and ($sQuery) order by ALIAS_NAME";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$insArr = array();
				$insArr['ALIAS_NAME'] = $row['ALIAS_NAME'];
				$insArr['DESCRIPTION'] =  $row['DESCRIPTION'];
				$insArr['ALIAS_TYPE'] =  $row['ALIAS_TYPE'];
				$insArr['ALIAS_CLASS'] =  $row['ALIAS_CLASS'];
				$insArr['WBS_ID'] =  $row['WBS_ID'];
				$insArr['COPY_ALLOWED'] =  $row['COPY_ALLOWED'];
				$insArr['AUTOPOPULATE'] =  $row['AUTOPOPULATE'];
				$insArr['ACTIVE_FLAG'] =  $row['ACTIVE_FLAG'];
				$insArr['ADDINUSE_FLAG'] =  $row['ADDINUSE_FLAG'];
				$insArr['LAST_UPDATED_BY'] = $CurrentUserId;		
				$insArr['CREATION_DATE']='now()' ;
				$insArr['CREATED_BY']=$CurrentUserId;
				$insArr['SITE_ID']=$SiteId;
				insertdata("cxs_aliases",$insArr);
			}
			echo "Records Copied";
		//}
	}
	
}
if($_REQUEST['REQUEST'] == "FindDataWBS")
{
	$Segment1 = $_REQUEST['Segment1'];
	$Segment2 = $_REQUEST['Segment2'];
	$Segment3 = $_REQUEST['Segment3'];
	$SiteId = $_SESSION['user-siteid'];
	$query_1 = "";
	if($Segment1!='')
	{
		$query_1 .= "SEGMENT1 like '%$Segment1%' or ";
	}
	if($Segment2!='')
	{
		$query_1 .= "SEGMENT2 like '%$Segment2%' or ";
	}
	if($Segment3!='')
	{
		$query_1 .= "SEGMENT3 like '%$Segment3%' or ";
	}
	if($query_1!='')
	{
		$query_1 = substr($query_1,0,-3);
		$query_1 = "and ( $query_1 )";
	}
?>	
	<table id='TablePopupHeading' class="table table-bordered " width="100%" >
		<thead>
			  <tr>
				<?php
					for($i=1;$i<=15;$i++)
					{
				?>		<th> Segment<?php echo $i; ?> </th>
			<?php	} ?>
			  </tr>
			</thead>
			<tbody id = "TablePopupList" >
				<?php
					//if($Criteria!='')
					{
						//$sql = "SELECT * from cxs_wbs where SEGMENT1 like '%$Criteria%' limit $startnumber, $endnumber";
						$sql = "SELECT * from cxs_wbs where SITE_ID = $SiteId $query_1 order by segment1,segment2,segment3,segment4,segment5,segment6,segment7,segment8,segment9,segment10,segment11,segment12";
						$result = mysql_query($sql);	
						while($row=mysql_fetch_array($result))
						{
						?>
							<tr style="cursor:pointer"  onClick="SelectedWBSProject(<?php echo $row['WBS_ID']; ?>)">
								<td><?php echo $row['SEGMENT1']; ?></td> 
								<td><?php echo $row['SEGMENT2']; ?></td> 
								<td><?php echo $row['SEGMENT3']; ?> </td> 
								<td> <?php echo $row['SEGMENT4']; ?></td>
								<td> <?php echo $row['SEGMENT5']; ?></td>
								<td> <?php echo $row['SEGMENT6']; ?></td>
								<td> <?php echo $row['SEGMENT7']; ?></td>
								<td> <?php echo $row['SEGMENT8']; ?></td>
								<td> <?php echo $row['SEGMENT9']; ?></td>
								<td> <?php echo $row['SEGMENT10']; ?></td>
								<td> <?php echo $row['SEGMENT11']; ?></td>
								<td> <?php echo $row['SEGMENT12']; ?></td>
								<td> <?php echo $row['SEGMENT13']; ?></td>
								<td> <?php echo $row['SEGMENT14']; ?></td>
								<td> <?php echo $row['SEGMENT15']; ?></td>
							</tr>
					<?php	
						} 
					} ?>
				</tbody>
			</table>
<?php }	
if($_POST['REQUEST'] == "FindDataPeriodAudit") {	$ResourceName = $_POST['ResourceName'];	$SupervisorName = $_POST['SupervisorName'];	$PayPeriName = $_POST['PayPeriod'];		$s_query = "";	if($ResourceName!='')	{		$s_query .= " and cxs_period_audit.FULL_NAME = '$ResourceName' ";	}	if($SupervisorName!='')	{		$s_query .= "and cxs_te_header.SUPERVISOR_ID = '$SupervisorName' ";	}		if($PayPeriName!='')	{		$s_query .= "and cxs_period_audit.PERIOD_NAME = '$PayPeriName' ";	}			echo $s_query;}
?>