	function onlyNos(e, t)
	{
		try {
			if (window.event) {
				var charCode = window.event.keyCode;
			}
			else if (e) {
				var charCode = e.which;
			}
			else { return true; }
			if (charCode > 31 && (charCode != 46) &&((charCode < 48 || charCode > 57)))															
			{
				return false;
			}
			return true;
		}
		catch (err) {
			alert(err.Description);
		}
	}
	function MyDateFormat(inputDate)
	{
		var date = new Date(inputDate);
		if (!isNaN(date.getTime())) 
		{
			// Months use 0 index.
			var mon = date.getMonth() + 1;
			var dt  = date.getDate();
			if(mon<=9)	{ mon = "0"+mon}; 
			if(dt<=9)	{ dt = "0"+dt}; 
			return mon + '/' + dt + '/' + date.getFullYear();
		}
		else
		{
			return '';
		}
	}
	
	
	function selectValue(ElementId,SelectedValue)
	{
		document.getElementById(ElementId).value=SelectedValue;
	}	
	function CompareTwoDates(date1,date2)
	{
		if (date1!='' && date2!='')
		{
			date1 = new Date(date1);
			date2 = new Date(date2);
			if (date1 > date2)
			{
				return "N";
			}			
			return "Y";
		}
	}
	
	function DifferenceTwoDate(date1,date2)
	{
		date1 = new Date(date1);
		date2 = new Date(date2);
		var diff = date2.getTime() - date1.getTime();
		diff = diff / (1000 * 60 * 60 * 24 * 30);
		return diff;
	}
	
	function form_element_correct(element)
	{
    	element.removeClass('error_ele');
    	element.next('span.not-valid-tip').remove();
    	//element.nextAll().remove();
	}
	function FindNumFromString(thestring)
	{
		var thenum = thestring.match(/\d+$/);		
		return thenum;
	}
	
	function isEmailValid(email) {
	  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	  return regex.test(email);
	}	
