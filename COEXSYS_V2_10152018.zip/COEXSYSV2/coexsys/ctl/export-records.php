<?php
include('conn.php');
error_reporting(E_ALL);
ini_set("display_errors", "ON");
require_once 'lib/PHPExcel.php';
require_once 'lib/PHPExcel/IOFactory.php';

function checkIsAValidDate($myString)
{
    return (bool)strtotime($myString);
}
	$heading = $_SESSION['ExportHeadings'];
	$ExportQry = $_SESSION['ExportQry'];
	$ExportFileName = $_SESSION['ExportFileName'];
	$ExportSheetTitle = $_SESSION['ExportSheetTitle'];
	
	$columns = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ','BA','BB','BC','BD','BE','BF','BG','BH','BI','BJ','BK','BL','BM','BN','BO','BP','BQ','BR','BS','BT','BU','BV','BW','BX','BY','BZ','CA','CB','CC','CD','CE','CF','CG','CH','CI','CJ','CK','CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU','CV','CW','CX','CY','CZ');
	$objPHPExcel = new PHPExcel();	
	
	$rw=1;
	$col=0;
	$objPHPExcel->setActiveSheetIndex(0);
	
	$i=0;
	foreach($heading as $hd)
	{
		$objPHPExcel->getActiveSheet()->getRowDimension($rw)->setRowHeight(20);   
		$objPHPExcel->getActiveSheet()->getColumnDimension($columns[$col])->setWidth(15);
		$objPHPExcel->getActiveSheet()->setCellValue($columns[$col].$rw, $hd);				
		$col++;   
	}
	
	$xls_filename = date('m-d-Y').$ExportFileName;		
	$objPHPExcel->getActiveSheet()->setTitle($ExportSheetTitle);		
		
	$sql = $ExportQry;			
	$res = mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{   
		$col=0;
		$rw++;			
		
		$FirstCol = $heading[0];	
		$objPHPExcel->getActiveSheet()->getRowDimension($rw)->setRowHeight(22);   	
		
		foreach($heading as $hd)
		{
			$value = $row[$col];
			if(checkIsAValidDate($value))
			{
				if(strlen($value)>4)
				{
					$value = date('m/d/Y', strtotime($value));
				}
			}
			else 
			{
				if($value=='0000-00-00')
				{
					$value = "";
				}
			}
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col].$rw, $value);	
			$col++;
		}	
	}

unset($_SESSION['ExportHeadings']);
unset($_SESSION['ExportQry']);
unset($_SESSION['ExportFileName']);
unset($_SESSION['ExportSheetTitle']);
	
// Redirect output to a clients web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename='.$xls_filename);  
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');



?>