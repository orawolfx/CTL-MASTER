<?php ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php 
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_alias_PERMISSION = "Y";
		$UPDATE_PRIV_alias_PERMISSION = "Y";	
	}
	else
	{
		$CREATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
		$UPDATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
	}					
	if($CREATE_PRIV_alias_PERMISSION=='N' && $UPDATE_PRIV_alias_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "create-new-alias.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$insArr = array();
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];
	//	DisplayRecord($HeaderId);	
	}
	
	if (isset($_POST['cmdSaveRecord'] ))
	{
		$Text_AliasName = isset($_POST["Text_AliasName"] )? $_POST["Text_AliasName"]: false;
		$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;
		$Combo_AliasType = isset($_POST["Combo_AliasType"] )? $_POST["Combo_AliasType"]: false;
		$Combo_AliasClass = isset($_POST["Check_PreApprove"] )? $_POST["Check_PreApprove"]: false;
	//	$Text_ProjectWBS = isset($_POST["Text_ProjectWBS"] )? $_POST["Text_ProjectWBS"]: false;
		$Check_CopyAllowed = isset($_POST['Check_CopyAllowed'] )? $_POST['Check_CopyAllowed']: false;
		$Check_AutoPopulate = isset($_POST['Check_AutoPopulate'] )? $_POST['Check_AutoPopulate']: false;
		$Check_Active = isset($_POST['Check_Active'] )? $_POST['Check_Active']: false;
	//	$Check_AddInUse = isset($_POST['Check_AddInUse'] )? $_POST['Check_AddInUse']: false;
		$WBSProjectId = isset($_POST['h_ProjectWBSId'] )? $_POST['h_ProjectWBSId']: false;
		$insArr['ALIAS_NAME'] = $Text_AliasName;
		$insArr['DESCRIPTION'] = $Text_Description;
		$insArr['ALIAS_TYPE'] = $Combo_AliasType;
		$insArr['ALIAS_CLASS'] = $Combo_AliasClass;
		$insArr['WBS_ID'] = $WBSProjectId;
		$insArr['COPY_ALLOWED'] = ($Check_CopyAllowed==1)?"Y":"N";
		$insArr['AUTOPOPULATE'] = ($Check_AutoPopulate==1)?"Y":"N";
		$insArr['ACTIVE_FLAG'] = ($Check_Active==1)?"Y":"N";
	//	$insArr['ADDINUSE_FLAG'] = ($Check_AddInUse==1)?"Y":"N";
		$insArr['LAST_UPDATED_BY'] = $LoginUserId;
		$insArr['SITE_ID'] = $SiteId;
		if($HeaderId!='')
		{
			updatedata("cxs_aliases",$insArr,"Where cxs_aliases.ALIAS_ID = $HeaderId");		
		}	
		else
		{
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;			
			insertdata("cxs_aliases",$insArr);	
			$HeaderId= mysql_insert_id();						
		/*	echo "<script>";
			echo "document.getElementById('h_field_headerid').value = $HeaderId";
			echo "</script>";
		*/			
		}
		
		header("Location:aliases.php");
	}	
	if ($HeaderId != '')
	{
		$qry = "SELECT cxs_aliases.*,cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4,cxs_wbs.SEGMENT5,cxs_wbs.SEGMENT6,cxs_wbs.SEGMENT7,cxs_wbs.SEGMENT8,cxs_wbs.SEGMENT9,cxs_wbs.SEGMENT10,cxs_wbs.SEGMENT11,cxs_wbs.SEGMENT11,cxs_wbs.SEGMENT12,cxs_wbs.SEGMENT13,cxs_wbs.SEGMENT14,cxs_wbs.SEGMENT15 from cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where cxs_aliases.ALIAS_ID = $HeaderId and cxs_aliases.SITE_ID = $SiteId ";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_AliasName = $row['ALIAS_NAME'];
			$Display_Description = $row['DESCRIPTION'];
			$Display_AliasType = $row['ALIAS_TYPE'];				
			$Display_CopyAllowed = $row['COPY_ALLOWED'];
			$Display_AutoPopulate = $row['AUTOPOPULATE'];
			$Display_Active = $row['ACTIVE_FLAG'];
			$Display_InUse = $row['ADDINUSE_FLAG'];
			$Display_WBSProjectId = $row['WBS_ID'];
			$Segment1 =  $row['SEGMENT1'];	
			$Segment2 =  $row['SEGMENT2'];
			$Segment3 =  $row['SEGMENT3'];
			$Segment4 =  $row['SEGMENT4'];
			$Segment5 =  $row['SEGMENT5'];	
			$Segment6 =  $row['SEGMENT6'];	
			$Segment7 =  $row['SEGMENT7'];
			$Segment8 =  $row['SEGMENT8'];
			$Segment9 =  $row['SEGMENT9'];
			$Segment10 =  $row['SEGMENT10'];	
			$Segment11 =  $row['SEGMENT11'];	
			$Segment12 =  $row['SEGMENT12'];
			$Segment13 =  $row['SEGMENT13'];
			$Segment14 =  $row['SEGMENT14'];
			$Segment15 =  $row['SEGMENT15'];	
			
			if ($Segment1!="")
			{
				$WBSValue = $Segment1;
				$WBSValue .= ($Segment2!='')?".$Segment2":"";
				$WBSValue .= ($Segment3!='')?".$Segment3":"";
				$WBSValue .= ($Segment4!='')?".$Segment4":"";
				$WBSValue .= ($Segment5!='')?".$Segment5":"";
				$WBSValue .= ($Segment6!='')?".$Segment6":"";
				$WBSValue .= ($Segment7!='')?".$Segment7":"";
				$WBSValue .= ($Segment8!='')?".$Segment8":"";
				$WBSValue .= ($Segment9!='')?".$Segment9":"";
				$WBSValue .= ($Segment10!='')?".$Segment10":"";
				$WBSValue .= ($Segment11!='')?".$Segment11":"";
				$WBSValue .= ($Segment12!='')?".$Segment12":"";
				$WBSValue .= ($Segment13!='')?".$Segment13":"";
				$WBSValue .= ($Segment14!='')?".$Segment14":"";
				$WBSValue .= ($Segment15!='')?".$Segment15":"";
			}
			$Display_ProjectWBS = $WBSValue;
		}
	}
?>
<script type="text/javascript" >
	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create Resource Alias";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
	
	function AliasNameValidation(e)
	{
	   keyEntry = (e.keyCode) ? e.keyCode : e.which;
	   //if (((keyEntry >= '65') && (keyEntry <= '90')) || ((keyEntry >= '97') && (keyEntry <= '122')) || (keyEntry == '46') || keyEntry == '8' || keyEntry == '9' || keyEntry == '32' || keyEntry == '37'|| keyEntry == '38')
	   if (keyEntry == '32' ) //do not allow space
		   return false;
	   else
		   return true;
	}
	function CheckDuplicate(name)
	{	
		if (name!='')
		{
			KEY = "CheckDuplicate";
			var regex = /\d+/g;
			var position = name.match(regex);
			
			var s1="";
			var str="";
			var TableName = "cxs_aliases";
			var FieldName = "ALIAS_NAME";
			var FieldValue = "";
			var FieldId = "ALIAS_ID";
			var SelectedId = "";
			
			if (position==null)
			{
				FieldValue = document.getElementById('Text_AliasName').value;	
				SelectedId = "<?php echo $HeaderId;?>";
			}
			else
			{
				RELATEDPOSITION = position; 
				FieldValue = document.getElementById('Text_AliasName'+position).value;
				SelectedId = document.getElementById('h_AliasId'+position).value;
			}								
			//makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&aliasname=" + str+"&selectedid="+s1+"&tablename="+TableName+"&FieldName="+FieldName);
			makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName=" + TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);
		}
	}
	function SearchPopUp()
	{	
		$("#div-wbs").html(' ');
		var form = $("#Find-Alias-Form");
		form.validate().resetForm();      // clear out the validation errors
		form[0].reset();
		
		$('#ModalFindProjectWBS').modal();	
		$('#Text_FindProjectWBS').focus();			
	}
	function FindData()
	{	
		KEY = "FindData";
		var formdata = $( "#Find-Alias-Form" ).serialize();		
		var str = $("#Text_FindProjectWBS").val();		
		if (str=="")
		{
			$("#span_find").text("");
			$("#span_find").append("<b>Do not leave blank.</b>");
			$("#Text_FindProjectWBS").focus();
		}
		else
		{
			makeRequest("ajax-finddata.php","REQUEST=FindDataWBS&"+formdata);			
		}
	}		 
	function SelectedWBSProject(s1)	
	{	
		if(s1!="")
		{
			document.getElementById("h_ProjectWBSId").value = s1;
			KEY = "SelectedWBS";
			makeRequest("ajax-finddata.php","REQUEST=SelectedWBS&Id=" +s1);
		}
	}
	
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
<!--width: 1280px;-->
<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	@media (min-width: 992px) 
	{
		.modal-lg
		{	
			width: 95%
			
		}
	}
</style>

</head>

<body>
<?php include("header.php"); ?>

<!-- modals start -->
	<form id="Find-Alias-Form" >
		<!--<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalFindProjectWBS" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Find Project WBS </h4>
					</div>-->
		<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ModalFindProjectWBS" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Find Project WBS </h4>
		  </div>			
					<div class="modal-body"> 
			<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								
								<div class="col-sm-4 form-group">
								  <label>Project WBS</label>
								  <input type="text" id="Text_FindProjectWBS" name="Text_FindProjectWBS" class="form-control requirefieldcls" required  maxlength="100" onkeypress="Javascript: if (event.keyCode==13) FindData();" autofocus >
								  <span id = "span_find"></span>
								</div>
								
								<div class="col-sm-4 form-group cr-user" >	
								<br>	
								  <button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style " onclick="FindData()" >Find</button>								  
								</div>
							
								
								<div class="col-sm-12 form-group" style = "margin: 0px;">									
									<div class="data-bx" style = "margin: 0px;">
										<div class="table-responsive" id = "div-wbs">
											
										</div>	
									</div>									
								</div>			
							</div>							
						</div>
						<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						
					</div>					
				</div>
			</div>
		</div>
	</form>
	<!-- modals end -->

<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="aliases.php"> Aliases </a></li>
          <li> <a href="#"> <?php echo $s_caption; ?> Resource Alias </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
	
		<div class="cont-box">
		<form class="form" id="Form1" name="Form1" action="" method="POST">	<!--  onsubmit = "return chkfld_form1()" -->
			<div class="pge-hd">
			  <h2 class="sec-title"  > 
			  <label><?php echo $s_caption; ?> Resource Alias</label>   
			  <label class = "fright" style = "font-size: 12px; margin-right : 40px;"> <input type="checkbox" id="Check_AddInUse" name="Check_AddInUse" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled > In Use </label>
			  </h2>
			  
			</div>					
			<div class="upp-form row"> 
				<div class="cus-form-cont">
					<div class="col-sm-4 form-group">
					  <label> Alias Name </label>
					  <input id = "Text_AliasName" name = "Text_AliasName" type="text" class="form-control requirefieldcls"  value = "<?php echo $Display_AliasName; ?>" maxlength="40" required oninput="this.value=this.value.toUpperCase()" onkeypress = 'return AliasNameValidation(event);' onblur = "CheckDuplicate(this.id)">
					  <span id = "Span_AliasName">&nbsp;</span>
					</div>
					<div class="col-sm-4 form-group">
					  <label> Description </label>
					  <input id = "Text_Description" name = "Text_Description" type="text" class="form-control requirefieldcls" value = "<?php echo $Display_Description; ?>"  maxlength="100" required>
					 <span>&nbsp;&nbsp;</span>
					
					</div>
					<div class="col-sm-4 form-group">
					  <label> Alias Type </label>
					  <select id = "Combo_AliasType" name = "Combo_AliasType" class="form-control requirefieldcls" required maxlength="20">
						<option value="RES-Resource Specific Alias" selected>RES-Resource Specific Alias</option>												
					  </select>
					  <span>&nbsp;&nbsp;</span>
					</div>
				
										
					<div class="col-sm-8 form-group">
					  <label> Project WBS </label>
					  <input type="text" id="Text_ProjectWBS" name="Text_ProjectWBS"value = "<?php echo $Display_ProjectWBS; ?>" class="form-control requirefieldcls" onkeypress="return false" required placeholder="" maxlength="25" onfocus="SearchPopUp()">
					</div>
					<div class="col-sm-4 form-group">
						<label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
						<div class="checkbox">
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_CopyAllowed" name="Check_CopyAllowed" value="1" <?php echo($Display_CopyAllowed == "Y")?"checked":""; ?>> Copy Allowed </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_AutoPopulate" name="Check_AutoPopulate" value="1" <?php echo($Display_AutoPopulate == "Y")?"checked":""; ?>> Auto Populate </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_Active" name="Check_Active" value="1" <?php echo($Display_Active == "Y")?"checked":""; ?>> Active </label>
							
						</div>
					</div>	
					<div class="clear-both"></div>
					<div class="col-sm-12 form-group text-right cr-user">
						<button <?php if(($CREATE_PRIV_alias_PERMISSION=='Y' || $UPDATE_PRIV_alias_PERMISSION == 'Y') && $Display_InUse!='Y'){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style"> Save Record </button>
					</div>
				</div>
			</div>
			<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>
			<input type="hidden" id="h_ProjectWBSId" name="h_ProjectWBSId" value="<?php echo $Display_WBSProjectId; ?>"/>
			<input type="hidden" id="h_IsEditAllowed" <?php if(($CREATE_PRIV_alias_PERMISSION=='Y' || $UPDATE_PRIV_alias_PERMISSION == 'Y') && $Display_InUse!='Y'){ ?> value = "Y" <?php } else {?> value = "N" <?php } ?> >
		</form>			
		</div>			
    </div>
  </div>  
</section>
	
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script src="../js/jquery.validate.js"></script>
<!--<script src="../js/jquery.validate.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
-->
<script type="text/javascript">
	$('#Find-Alias-Form').keypress(function(e) {
		if (e.which == 13) {
		//e.preventDefault();    
		return false;
		}
	});
	$(document).ready(function()
	{
		if ($("#h_IsEditAllowed").val()=="N")
		{
			$("#Form1 :input").prop("disabled",true);
		}
	});
	
	$('#Form1').submit(function (evt) 
	{
		$('#Check_AddInUse').prop('disabled',false);
	});
	
	function makeRequest(url,data)
	{
		var http_request = false;
		if (window.XMLHttpRequest) 
		{ // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
		} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;						
					//alert(str);
					window.open('downloaddata.php?r=holiday-calendars', '_blank');
				}
				else if(KEY == "ExportRecordCont")
				{
					var str = http_request.responseText;	
					
					//alert(str);
					window.open('downloaddata.php?r=new-resource-contacts', '_blank');					
					//window.location.href = "downloaddata.php?r=user-administration","target='_blank'";					
				}
				else if(KEY == 'CheckDuplicate')
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)
					{
						//alert(s1);
						document.getElementById("Span_AliasName").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Text_AliasName").focus();					
					}
					else
					{
					/*	if (RELATEDPOSITION!="")
						{
							document.getElementById("h_duplicate1").value = "";
						}
						else
						{
							document.getElementById("h_duplicate").value = "";
						}*/
						document.getElementById("Span_AliasName").innerHTML = "&nbsp;";
					}
				}
				else if(KEY == 'FindData')
				{					
					$("#div-wbs").html(http_request.responseText);
					$("#TablePopupHeading").DataTable({"searching": false});
					var TableTotalRows = document.getElementById("TablePopupList").rows.length;
					if (TableTotalRows==0)
					{
						document.getElementById("span_msg").innerHTML = "No Record Found.";
					}
					else
					{
						document.getElementById("span_msg").innerHTML = "";
					}
				}
				else if (KEY == 'SelectedWBS')
				{
					var s = http_request.responseText;
					s = s.trim();						
					document.getElementById("Text_ProjectWBS").value = s;					
					$("#ModalFindProjectWBS .close").click();					
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}		
	</script>

</body>
</html>