<?php ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_holiday_PERMISSION = "Y";
		$UPDATE_PRIV_holiday_PERMISSION = "Y";
		$VIEW_PRIV_holiday_PERMISSION = "Y";
		$ENABLE_AUDIT_holiday_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
		$UPDATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
		$VIEW_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Holiday Calenders',$_SESSION['user_id']);
		$ENABLE_AUDIT_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Holiday Calenders',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_holiday_PERMISSION=='N' && $UPDATE_PRIV_holiday_PERMISSION=='N' && $VIEW_PRIV_holiday_PERMISSION=='N' && $ENABLE_AUDIT_holiday_PERMISSION=='N')
	{
		header('location:te.php');
	}
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "holiday-calendar.php";	
	$SiteId = $_SESSION['user-siteid'];
	
	// update in use flag when page render
	$currentdate = date('Y-m-d');
	$qry = "update cxs_holiday_calendar set INUSE_FLAG = 'Y' where (HOLIDAY_START_DATE <= '$currentdate' and HOLIDAY_END_DATE >= '$currentdate') and INUSE_FLAG <> 'Y' and SITE_ID = $SiteId";
	mysql_query($qry);
	
	$DisplayPayPeriodValues = "";
	$query = "select CALENDAR_ID,PERIOD_YEAR from cxs_calendars where PERIOD_YEAR<>''  and SITE_ID = $SiteId order by PERIOD_YEAR ";
	$result = mysql_query($query);
	$DisplayPayPeriodValues .= "<option value=''>- Pay Period Year -</option>";
	while ($row = mysql_fetch_array($result))
	{
		$PeriodName = $row['PERIOD_YEAR'];
		$PeriodId = $row['CALENDAR_ID'];
		$DisplayPayPeriodValues .= "<option value='$PeriodName'> $PeriodName </option>";
	}	
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "CALENDAR_NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
   	 $OrderBY = " desc";
   	 $FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";
	

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	//	$record_per_page=$RecordsPerPage;
	// $start_from = ($page-1) *  $record_per_page;
	$start_from = ($page-1) *  $RecordsPerPage;	
	$i=1;	
	
	
	
?>
<script type="text/javascript" >
	var TABLE_ROW=0;	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Holiday Calender";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;		
		HolidayList.submit();
	}	
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		
		}
	}   
	
	function checkInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;		
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
			
		}		
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_holidayCalendarId"+selectedRow).value;
			location.href="create-new-holiday-calendar.php?hid="+s;
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}
	}
	
	function ExportRecord1()
	{	
		KEY= "ExportRecord";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_holidayCalendarId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		
		qry1 = '<?php echo $SQueryOrderBy; ?>';					
		//qry1 = 'order by ROW_NO';		
			
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportHolidayCalendar&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("Checkbox_SelectAll").focus();
		}
	}
	
	function FindData()
	{
		KEY = "FindData";
		var str = document.getElementById("Text_FindCalendarName").value;
		var str1 = document.getElementById("Combo_FindPayPeriod").value;		
		makeRequest("ajax-finddata.php","REQUEST=FindDataHolidayCalendar&CalendarName=" +str+"&PayPeriodYear="+str1);		
	}
	function RefreshData()
	{
		HolidayList.submit();
	}
	function ShowReadOnly(Id)
	{
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{	
			KEY= "SingleRecord";								
			$("#ModalElements :input").prop('disabled', true);			
			$('#ModalDisplayHolidayPeriod').modal();		
			var FieldValue = Id;
			var FieldName = "HOLIDAY_CALENDAR_ID";
			var TableName = "cxs_holidays";
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
	}
		
</script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	
	
	<script src="../datepicker/jquery.js"></script>
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<script src="../js/jsfunctions.js"></script>
	<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
	<style type="text/css">
		.requirefieldcls
		{
			background-color: #fff99c;
		}		
	</style>
</head>

<body>
<?php include("header.php"); ?>	
	<!-- modals start -->
	<form>
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalDisplayHolidayPeriod" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">							
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">			
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Holiday Calendar </h4>
					</div>
					<div class="modal-body" id = "ModalElements"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> Calendar Name </label>
								  <input type="text" id = "Text_CalendarName" name = "Text_CalendarName" class="form-control requirefieldcls" required  onblur = "CheckDuplicate(this.id)">
								  <span id = "span_periodname"></span>
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> Period Year </label>
								  <input type="text" id = "Text_PeriodYear" name = "Text_PeriodYear" class="form-control requirefieldcls"  onchange = "SetYear()" onkeypress="return onlyNos(event,this);" required maxlength="40">
								</div>
								<div class="clear-both"></div>
								
								
								<div class="data-bx">
								  <div class="table-responsive">
									<table id='Table2'  class="table table-bordered mar-cont" width = "100%">
									  <thead>
										<tr>
											<th width="20%"> Holiday Name </th>
											<th width="20%"> Description </th>
											<th width="10%"> Start Date </th>
											<th width="10%"> End Date </th>
											<th width="5%"> Enforce </th>
											<th width="10%"> Recess Allowed </th>
											<th width="5%"> Enabled </th>									
											<th width="7%"> In Use </th>											
											<th width="0%" style = "display:none">Header Id </th>
										</tr>
									  </thead>
									  
									  <tbody>
										
									  </tbody>
									</table>
								  </div>
								</div>		
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>					
				</div>
			</div>
		</div>
		<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>
	</form>
	<!-- modals end -->
	
	<!--Search modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Find Holiday Calendar </h4>
				</div>
				<div class="modal-body"> 
				<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">						
							<div class="col-sm-6 form-group">
							  <label> Calendar Name  </label>
							  <input type="text" id = "Text_FindCalendarName" name = "Text_FindCalendarName" class="form-control "  maxlength="50"  >
							</div>
							
							<div class="col-sm-6 form-group">
							  <label> Pay Period Year </label>
								<select id = "Combo_FindPayPeriod" name = "Combo_FindPayPeriod"  class="form-control " >
								  <?php echo $DisplayPayPeriodValues; ?>					  
								</select> 
							</div>
						</div>
					</div>
					<!-- end --> 
				</div>
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
					<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Search Modal  -->
	
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <!-- brd crum-->
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#"> Set Up </a></li>
                        <li> <a href="#"> Holiday Calendar </a></li>
                    </ul>
                </div>
                <!-- Dash board -->
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> 
                    </div>
                    <div class="fright">
				<?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						}
				?>          
						<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
						<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
						<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>
					</div>
                </div>
                <!-- inner work-->
                <div class="cont-box">
                    <div class="pge-hd">                        
						<h2 class="sec-title"  > <label id="Label_Title">Holiday Calendars</label>  </h2>
                    </div>
					
					<?php
						$ExportQry = "select cxs_holidays.CALENDAR_NAME,cxs_holidays.PERIOD_YEAR from cxs_holidays WHERE cxs_holidays.SITE_ID = $SiteId $s_Query  $SQueryOrderBy  limit $start_from , $RecordsPerPage";						
						$selectQuery = "SELECT  cxs_holidays.*,cxs_users.USER_NAME as CreatedBy,(Select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_holidays.LAST_UPDATED_BY) as UpdatedBy FROM cxs_holidays inner join cxs_users on cxs_users.USER_ID = cxs_holidays.CREATED_BY  WHERE cxs_holidays.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";
						$selectQueryForPages  = $selectQuery;
						$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
						$RunUserQuery=mysql_query($selectQuery);
						$StdNumRows = mysql_num_rows($RunUserQuery);
						$msg = "";
						if($StdNumRows == 0 )
						{
							$msg = "No Record Found";
						}
					?>
					<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
					<br>
					<div class="fleft two">					  
					  <button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_holiday_PERMISSION=='Y'){ ?>id="cmdUpdateSelected" name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>
					  <!--<button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>-->
					</div>					
					
					<div class="fright cr-user">						
						<a <?php $sDisabled = ""; if($CREATE_PRIV_holiday_PERMISSION=='Y'){ ?> href="create-new-holiday-calendar.php" <?php } else $sDisabled ="disabled=disabled"; ?>> 
						<button type="button" class="btn btn-primary btn-style" <?php echo $sDisabled; ?>> <?php echo $s_caption; ?> Create Holiday Calendar</button></a>									
					</div>
					
					<form name = "HolidayList" id = "HolidayList" method="post" >
						<div class="data-bx">
							<div class="table-responsive ">						
								
								<table id='Table1' class="table table-bordered mar-cont" style = "width: 100%">
									<thead>
										<tr>										
											<th width="1%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>
											<th width="8%">
												<?php if($Sorts == 'desc' && $FileName == 'CALENDAR_NAME') { ?>
													  <span style="">
														Calendar Name
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CALENDAR_NAME','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Calendar Name 
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('CALENDAR_NAME','desc');"></i>
													  </span>
												<?php } ?>
											</th>
											
											<th width="8%">
												<?php if($Sorts == 'desc' && $FileName == 'DESCRIPTION') { ?>
													  <span style="">
														Pay Period Year
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','asc');"></i>
													  </span>
												<?php } else { ?>
													  <span style="">
														Pay Period Year 
														<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','desc');"></i>
													  </span>
												<?php } ?>
											</th>											
											<th width="1%"> </th>
										</tr>
									</thead> 
									<tbody>
										<?php	
											$i= 1; 
											while($rows=mysql_fetch_array($RunUserQuery))
											{
												$Display_CreatedByName	= $rows['CreatedBy'];	
												$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));												
												$Display_UpdatedByName		= $rows['UpdatedBy'];												
												$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));
											?>
										<tr ondblclick="ShowReadOnly('<?php echo $rows['HOLIDAY_CALENDAR_ID']; ?>')">
											<td class="check-bx "><input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
												<input type="hidden" id = <?php echo "h_holidayCalendarId".$i; ?> name = <?php echo "h_holidayCalendarId".$i; ?> value = "<?php echo $rows['HOLIDAY_CALENDAR_ID']; ?>">
											</td>
											<td> 
												<?php echo $rows['CALENDAR_NAME']; ?> 												
											</td>
											<td> 
												<?php echo $rows['PERIOD_YEAR']; ?>												
											</td>											
											<td class = 'check-bx'>
												<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
												Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
												<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
											</td>
										</tr>
									 <?php   
											$i=$i+1;
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
						<!-- save btn  -->
						
						<!-- pagination start-->
			
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php

											//$selectQueryForPages=$selectQueryForPages;
											$RunDepQuery=mysql_query($selectQueryForPages);
											$num_records = mysql_num_rows($RunDepQuery);
											$total_pages= ceil($num_records/$RecordsPerPage);
											if (($page-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pages;$i++){ ?>
											<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($page+1)>$total_pages){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
													  <?php } ?>

								  </ul>
								</div>
							</div>
							<!-- pagination end -->
							<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
							<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	
							<input type="hidden" id="h_field_update" name="h_field_update" value="">
							<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>
							<input type="hidden" id="h_duplicate1" name="h_duplicate1" value=""/>
							<input type="hidden" id="h_query" name="h_query" value=""/>
					</form>	
                   
                </div>
            </div>
        </div>
        </div>
    </section>
    <footer> </footer>
	
	

<script type="text/javascript">	
	
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count		
	$('.form_datetime').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});		
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;						
					//alert(str);
					window.open('downloaddata.php?r=accounting-periods', '_blank');
				}
				else if(KEY == 'CheckAccountingPeriod')
				{
					
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)
					{
						//alert(s1);
						//span_periodname
						document.getElementById("span_periodname").innerHTML = s1;
						if (RELATEDPOSITION!="")
						{
							document.getElementById("h_duplicate1").value = "Y";
							document.getElementById("Text_PeriodName"+RELATEDPOSITION).focus();
						}
						else
						{
							document.getElementById("h_duplicate").value = "Y";							
							document.getElementById("Text_PeriodName").focus();
						}
						
					}
					else
					{
						if (RELATEDPOSITION!="")
						{
							document.getElementById("h_duplicate1").value = "";
						}
						else
						{
							document.getElementById("h_duplicate").value = "";
						}
						document.getElementById("span_periodname").innerHTML = "";
					}
				}
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;
					document.getElementById("h_query").value=s1;					
					s1 = s1.trim();					
					HolidayList.submit();
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText); 					
					//alert(JSON.stringify(JSONObject));
					
					$('#Text_CalendarName').val(JSONObject['cxs_holidays']["CALENDAR_NAME"]);					
					$('#Text_PeriodYear').val(JSONObject['cxs_holidays']["PERIOD_YEAR"]);
					
					
					var DetailRows = JSONObject['DetailRows'];
					$('#Table2').find('tbody').remove();
					var check1='',check2='',check3='',check4='',check1value='',check2value='',check3value='',check4value='';

					for(i=0;i<DetailRows;i++)
					{
						startdate = JSONObject[i]["START_DATE"];//MyDateFormat(JSONObject[i]["HOLIDAY_START_DATE"]);
						enddate = JSONObject[i]["END_DATE"];
						check1value = (JSONObject[i]['ENFORCE_FLAG']=='Y')?'checked':'' ;
						check1 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						
						check2value = (JSONObject[i]['RECESS_ALLOWED']=='Y')?'checked':'' ;
						check2 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						
						check3value = (JSONObject[i]['ENABLED_FLAG']=='Y')?'checked':'' ;
						check3 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						
						check4value = (JSONObject[i]['FLAG_INUSE']=='Y')?'checked':'' ;
						check4 = "<td class='check-bx'><input type='checkbox'" + check1value + " disabled ></td>";
						
						SelectedId = "<td style = 'display:none'>"+JSONObject[i]['HOLIDAY_CALENDAR_ID']+"</td>";
						$('#Table2').append('<tr><td>'+JSONObject[i]["HOLIDAY_TAG_NAME"]+'</td><td>'+JSONObject[i]["DESCRIPTION"]+'</td><td>'+startdate+'</td><td>'+enddate+'</td>'+check1+check2+check3+check4+SelectedId+'</tr>');					
					}	 
					var table = $("#Table2").DataTable({
						"searching": false,
						'order': [[ 6, "asc" ]],
						destroy: true,
						
						//'columnDefs': [{"targets": [-1],"visible": false}]
						});						
					//table.column( 6 ).visible( false );						
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = '<?php echo $ExportQry; ?>';	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#CheckboxInline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_PeriodId"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'CALENDAR_ID', ExportIdList:exportIds,
						  ExportFileName:'_holiday-calendar.xls', ExportSheetTitle:"Holiday Calendar"
						  },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	</script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) kuparmar@yahoo.com -->
   <script src="../js/jquery.min.js"></script>
   <script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/dataTables.bootstrap.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>

</html>