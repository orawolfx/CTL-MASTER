<?php ob_start ();
	 
	include("te-functions.php"); 
	check_login();	
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_alias_PERMISSION = "Y";
		$UPDATE_PRIV_alias_PERMISSION = "Y";
		$VIEW_PRIV_alias_PERMISSION = "Y";
		$ENABLE_AUDIT_alias_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
		$UPDATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
		$VIEW_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Create Personal Aliases',$_SESSION['user_id']);
		$ENABLE_AUDIT_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Create Personal Aliases',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_alias_PERMISSION=='N' && $UPDATE_PRIV_alias_PERMISSION=='N' && $VIEW_PRIV_alias_PERMISSION=='N' && $ENABLE_AUDIT_alias_PERMISSION=='N')
	{
		header('location:te.php');
	}	
		
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "aliases.php";
	$SiteId = $_SESSION['user-siteid'];
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "ALIAS_NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
		$OrderBY = " desc";
		$FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}
	$SQueryOrderBy = " order by $FieldName $OrderBY";	

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	
	$start_from = ($page-1) *  $RecordsPerPage;
	
	//$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	//$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$insArr = array();	
?>
<script type="text/javascript" >
	var TABLE_ROW;
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Aliases";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;		
		AliasList.submit();
	}
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		
		}
	}   	
	function checkInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function CopyCheckAll()
	{
		var checkboxValue=document.getElementById('Copy_Checkbox_SelectAll').checked;
		var i=1,TotalPopupRows;
		
		TotalPopupRows = document.getElementById("TablePopup-CopyAliasHd").rows.length;
		TotalPopupRows=TotalPopupRows-1;
		for(i=1;i<=TotalPopupRows;i++)
		{
			document.getElementById("Copy_CheckboxInline"+i).checked = checkboxValue;		
		}
	}
	
	
	function CopyCheckInline()
	{
		var i=1,TotalPopupRows;
		TotalPopupRows = document.getElementById("TablePopup-CopyAliasHd").rows.length;
		TotalPopupRows=TotalPopupRows-1;
		
		for(i=1;i<=TotalPopupRows;i++)
		{
			if (document.getElementById("Copy_CheckboxInline"+i).checked == false)
			{
				document.getElementById('Copy_Checkbox_SelectAll').checked = false;
			}
		}
	}

	function FindData()
	{
		KEY = "FindData";
		var str = document.getElementById("Text_FindAliasName").value;		
		var IsActive="",IsCopy="",IsAutoPopulate="",IsInUse = "";
	/*	//if($("#Check_FindActive").is(':checked'))	both worked
		if ($('#Check_FindCopyAllowed').prop("checked")==true){IsCopy = "Y";}else{	IsCopy = "N";}
		if ($('#Check_FindAutoPopulate').prop("checked")==true){IsAutoPopulate = "Y";}else{	IsAutoPopulate = "N";}
		if ($('#Check_FindActive').prop("checked")==true){IsActive = "Y";}else{	IsActive = "N";}
		if ($('#Check_FindInUse').prop("checked")==true){IsInUse = "Y";}else{	IsInUse = "N";}
	*/	
		makeRequest("ajax-finddata.php","REQUEST=FindDataAliases&AliasName=" +str+"&IsCopy="+IsCopy+"&IsAutoPopulate="+IsAutoPopulate+"&IsActive="+IsActive+"&IsInUse="+IsInUse);
	
	}
	function FindDataCopyAlias()
	{
		KEY = "FindData-CopyAlias";		
		var str = document.getElementById("Text_CopyAliasName").value;		
		/*if (str=="")
		{
			document.getElementById("span_find").innerHTML = "<b>Do not leave blank.</b>";
			document.getElementById("Text_FindProjectWBS").focus();
		}
		else
		{*/
			//document.getElementById("span_find").innerHTML = "";
			KEY = "FindData-CopyAlias";
			makeRequest("ajax-finddata.php","REQUEST=FindDataCopyAlias&AliasName=" +str);
		//}
		
	}
	function CopyData()
	{
		var i=1,TotalPopupRows;
		TotalPopupRows = document.getElementById("TablePopup-CopyAliasHd").rows.length;
		
		TotalPopupRows=TotalPopupRows-1;
		var IdList="";	
		for(i=1;i<=TotalPopupRows;i++)
		{
			if (document.getElementById("Copy_CheckboxInline"+i).checked == true)
			{
					IdList = IdList+$('#h_AliasId'+i).val()+"|";					
			}
		}
		if (IdList != '')
		{
			KEY = "CopyData";			
			makeRequest("ajax-finddata.php","REQUEST=CopyAliasData&AliasId=" +IdList);
		}
	}
	function RefreshData()
	{
		AliasList.submit();
	}
	function ShowReadOnly(Id)
	{
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{	
			KEY= "SingleRecord";				
			$("#ModalElements :input").prop('disabled', true);
			$('#ModalDisplayPopup').modal();		
			var FieldValue = Id;
			var FieldName = "ALIAS_ID";
			var TableName = "cxs_aliases";
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
	}
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;		
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
			
		}		
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_AliasId"+selectedRow).value;
			location.href="create-new-alias.php?hid="+s;
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}

		
	}
	
	function ExportRecord1()
	{	
		KEY= "ExportRecord";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_PeriodId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		
		qry1 = '<?php echo $SQueryOrderBy; ?>';					
		//qry1 = 'order by ROW_NO';		
			
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportAccountingPeriod&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("Checkbox_SelectAll").focus();
		}
	}
	
	
	
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">
<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
</style>

<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
</head>

<body>

<!--Search modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Find Resource Aliases </h4>
		  </div>
		  <div class="modal-body"> 
			<!-- field start-->			
			<div class="col-sm-12">
				<div class="cus-form-cont">
					
					<div class="col-sm-5 form-group">
					  <label>Resource Alias Name</label>
					  <input type="text" id="Text_FindAliasName" name="Text_FindAliasName" class="form-control" placeholder="" maxlength="100">
					</div>
					
					<div class="col-sm-7 form-group">
						<label>&nbsp;&nbsp;&nbsp;</label>
						<div class="checkbox" style = "display:none">
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_FindCopyAllowed" name="Check_CopyAllowed"> Copy Allowed </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_FindAutoPopulate" name="Check_AutoPopulate" > Auto Populate </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_FindActive" name="Check_Active" > Active </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_FindInUse" name="Check_FindInUse" > In Use </label>
						</div>
					</div>					
				</div>
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
		  </div>
		</div>
	  </div>
	</div>
	<!-- Search Modal  -->
	
	<!--Display modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ModalDisplayPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Alias</h4>
		  </div>
		  <div class="modal-body" id = "ModalElements"> 
			<!-- field start-->
			<div class="col-sm-12">
				<div class="cus-form-cont">
					
					<div class="col-sm-4 form-group">
					  <label>Alias Name</label>
					  <input type="text" id="Text_AliasName" name="Text_AliasName" class="form-control"  maxlength="100">
					</div>
					
					<div class="col-sm-4 form-group">
					  <label>Description</label>
					  <input type="text" id="Text_Description" name="Text_Description" class="form-control"  maxlength="100">
					</div>
					
					<div class="col-sm-4 form-group">
						<label> Alias Type </label>
						<select id = "Combo_AliasType" name = "Combo_AliasType" class="form-control "  maxlength="20">
							<option value="RES-Resource Specific Alias">RES-Resource Specific Alias</option>
						</select>
					</div>	
					
					
					<div class="col-sm-12 form-group">
					  <label> Project WBS </label>
					  <input type="text" id="Text_ProjectWBS" name="Text_ProjectWBS"value = "<?php echo $Text_ProjectWBS; ?>" class="form-control" disabled maxlength="25" >
					</div>
					
					<div class="col-sm-8 form-group">
						
						<div class="checkbox">
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_CopyAllowed" name="Check_CopyAllowed" disabled> Copy Allowed </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_AutoPopulate" name="Check_AutoPopulate" disabled> Auto Populate </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_Active" name="Check_Active" disabled> Active </label>
							<label style = "padding-right:5px;"> <input type="checkbox" id="Check_InUse" name="Check_InUse" disabled> In Use </label>
						</div>
					</div>					
				</div>
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			
		  </div>
		</div>
	  </div>
	</div>
	<!-- Display Modal  -->
	
	
<!--Copy Alias modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "CopyAliasPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Copy Aliases </h4>
		  </div>
		  <div class="modal-body"> 
			<!-- field start-->
			<div class="col-sm-12">
				<div class="cus-form-cont">
					
					<div class="col-sm-5 form-group">
					  <label>Alias Name</label>
					  <input type="text" id="Text_CopyAliasName" name="Text_CopyAliasName" class="form-control" maxlength="100" onkeypress="Javascript: if (event.keyCode==13) FindDataCopyAlias();" autofocus >
					</div>					
					<div class="col-sm-4 form-group">
						<br>
					  <button type="button" id="cmdFindPopup-CopyAlias" name="cmdFindPopup-CopyAlias" class="btn btn-primary btn-style " onclick="FindDataCopyAlias()" >Find</button>
					</div>	
					
					<div class="col-sm-12 form-group">
						<div id="span_msg" class="text-center" style = "font-weight:bold"> </div>
						<div class="data-bx">
							<div class="table-responsive" id = "divFindCopyAlias">
								
							</div>	
						</div>									
					</div>	
					
				</div>
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			<button type="button" id="cmdCopyAliasPopup" name="cmdCopyAliasPopup" class="btn btn-primary btn-style " onclick="CopyData()" >Copy Aliases</button>
		  </div>
		</div>
	  </div>
	</div>
	<!-- Search Modal  -->
	
	
	
	
	
	
	
	
<?php include("header.php"); ?>
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="#"> Resource Aliases </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> 
        </div>
        <div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
			<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
			<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
			<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>
        </div>
      </div>
      <!-- inner work-->
      <div class="cont-box">
        <div class="pge-hd">
          <h2 class="sec-title"> <label id="Label_Title">Resource Aliases </label> </h2>
        </div>
		
		<?php
			/*$selectQuery = "SELECT  cxs_aliases.*,cxs_wbs.*,cxs_users.USER_NAME as CreatedBy,cxs_aliases.CREATION_DATE as CreateDate,cxs_aliases.LAST_UPDATED_BY as LasUpdateBy,cxs_aliases.LAST_UPDATE_DATE as LAST_UPDATE_DATE_ALIAS FROM cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID inner join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY  WHERE cxs_aliases.SITE_ID = $SiteId and (cxs_aliases.ALIAS_CLASS = '' and cxs_aliases.CREATED_BY = $LoginUserId )
			or (cxs_aliases.ALIAS_ID in (select cxs_policy_general.ALIAS_ID from cxs_policy_general where cxs_policy_general.CREATED_BY=$LoginUserId))
			or (cxs_aliases.ALIAS_ID in (select cxs_policy_time_off.ALIAS_ID from cxs_policy_time_off where cxs_policy_time_off.CREATED_BY=$LoginUserId))
			$s_Query  $SQueryOrderBy";*/
			
			$selectQuery = "SELECT  cxs_aliases.ALIAS_NAME,ALIAS_TYPE,DESCRIPTION,ACTIVE_FLAG, ";
			$selectQuery .= "(concat (SEGMENT1, if (SEGMENT2<>'', concat('.',SEGMENT2),''), ";
			$selectQuery .= "if (SEGMENT3<>'', concat('.',SEGMENT3),''),if (SEGMENT4<>'', concat('.',SEGMENT4),''), ";
			$selectQuery .= "if (SEGMENT5<>'', concat('.',SEGMENT5),''),if (SEGMENT6<>'', concat('.',SEGMENT6),''), ";
			$selectQuery .= "if (SEGMENT7<>'', concat('.',SEGMENT7),''),if (SEGMENT8<>'', concat('.',SEGMENT8),''), ";
			$selectQuery .= "if (SEGMENT9<>'', concat('.',SEGMENT9),''),if (SEGMENT10<>'', concat('.',SEGMENT10),''), ";
			$selectQuery .= "if (SEGMENT11<>'', concat('.',SEGMENT11),''),if (SEGMENT12<>'', concat('.',SEGMENT12),''), ";
			$selectQuery .= "if (SEGMENT13<>'', concat('.',SEGMENT13),''),if (SEGMENT14<>'', concat('.',SEGMENT14),''), ";
			$selectQuery .= "if (SEGMENT15<>'', concat('.',SEGMENT15),'')) ) as WBS, ";
			$selectQuery .= "COPY_ALLOWED,AUTOPOPULATE,ADDINUSE_FLAG, cxs_aliases.*,cxs_wbs.*,cxs_users.USER_NAME as CreatedBy,cxs_aliases.CREATION_DATE as CreateDate,cxs_aliases.LAST_UPDATED_BY as LasUpdateBy,cxs_aliases.LAST_UPDATE_DATE as LAST_UPDATE_DATE_ALIAS FROM cxs_aliases left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID inner join cxs_users on cxs_users.USER_ID = cxs_aliases.CREATED_BY  WHERE cxs_aliases.SITE_ID = $SiteId and (cxs_aliases.ALIAS_CLASS = '' and cxs_aliases.CREATED_BY = $LoginUserId ) ";
			$selectQuery .= "or (cxs_aliases.ALIAS_ID in (select cxs_policy_general.ALIAS_ID from cxs_policy_general where cxs_policy_general.CREATED_BY=$LoginUserId)) ";
			$selectQuery .= "or (cxs_aliases.ALIAS_ID in (select cxs_policy_time_off.ALIAS_ID from cxs_policy_time_off where cxs_policy_time_off.CREATED_BY=$LoginUserId)) ";
			$selectQuery .= "$s_Query  $SQueryOrderBy";
			
			$selectQueryForPages  = $selectQuery;
			
			$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
			
			$ExportQry = $selectQuery;
						
			$RunUserQuery=mysql_query($selectQuery);
			$StdNumRows = mysql_num_rows($RunUserQuery);
			$msg = "";
			if($StdNumRows == 0 )
			{
				$msg = "No Record Found";
			} 
		?>
		<div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
		<br>
        <div>
			<div class="fleft two">				
				<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_alias_PERMISSION=='Y'){ ?>id="cmdUpdateSelected" name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>
				<button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>
			</div>
          
			<div class="fright cr-user">
				<a <?php $sDisabled = ""; if($CREATE_PRIV_alias_PERMISSION=='Y'){ ?> href="create-new-alias.php" <?php } else $sDisabled ="disabled=disabled"; ?>> 
				<button type="button" class="btn btn-primary btn-style" <?php echo $sDisabled; ?>> <?php echo $s_caption; ?>  Create Resource Alias </button></a>						
			</div>
			<form name = "AliasList" id = "AliasList" method="post" >
				<div class="data-bx">
					<div class="table-responsive">
						<table class="table table-bordered mar-cont" id = "Table1" name = "Table1">
						<thead>
							<tr>
								<th width="3%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>											
							   
								 <th width="13%">
									<?php if($Sorts == 'desc' && $FileName == 'ALIAS_NAME') { ?>
										  <span style="">
											Alias Name
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ALIAS_NAME','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Alias Name
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ALIAS_NAME','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								 <th width="15%">
									<?php if($Sorts == 'desc' && $FileName == 'ALIAS_NAME') { ?>
										  <span style="">
											Alias Type
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ALIAS_NAME','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Alias Type
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ALIAS_NAME','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								 <th width="15%">
									<?php if($Sorts == 'desc' && $FileName == 'DESCRIPTION') { ?>
										  <span style="">
											Description
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Description
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								 <th width="6%">
									<?php if($Sorts == 'desc' && $FileName == 'ACTIVE_FLAG') { ?>
										  <span style="">
											Active
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Active
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								 <th width="25%">										  
									Project WBS									
								</th>
								
								<th width="5%">
									<?php if($Sorts == 'desc' && $FileName == 'COPY_ALLOWED') { ?>
										  <span style="">
											Copy
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('COPY_ALLOWED','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Copy
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('COPY_ALLOWED','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								 <th width="7%">
									<?php if($Sorts == 'desc' && $FileName == 'AUTOPOPULATE') { ?>
										  <span style="">
											Auto Populate
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('AUTOPOPULATE','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											Auto Populate
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('AUTOPOPULATE','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								
								<th width="6%">
									<?php if($Sorts == 'desc' && $FileName == 'ADDINUSE_FLAG') { ?>
										  <span style="">
											In Use
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ADDINUSE_FLAG','asc');"></i>
										  </span>
									<?php } else { ?>
										  <span style="">
											In Use
											<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ADDINUSE_FLAG','desc');"></i>
										  </span>
									<?php } ?>
								</th>
								<th width="5%"> </th>
							</tr>
						</thead>
						<tbody>
						<?php							
							$i= 1;
							while($rows=mysql_fetch_array($RunUserQuery))
							{
								$Display_AliasId = $rows['ALIAS_ID'];							
								$Display_AliasName	= $rows['ALIAS_NAME'];
								$Display_AliasType	= $rows['ALIAS_TYPE'];	
								$Display_Description = $rows['DESCRIPTION'];
								
								$Display_Active	= $rows['ACTIVE_FLAG'];
								$Display_Copy	= $rows['COPY_ALLOWED'];
								$Display_AutoPopulate	= $rows['AUTOPOPULATE'];
								$Display_InUse	= $rows['ADDINUSE_FLAG'];								
								$WBSValue = $rows['WBS'];
								$Display_ProjectWBS = $WBSValue;								
								$Display_CreatedByName	= $rows['CreatedBy'];	
								$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CreateDate']));							
								$UpdatedBy		= $rows['LasUpdateBy'];
								$Display_UpdatedByName = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedBy");							
								$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE_ALIAS']));
								
							?>						  
							<tr  <?php if($VIEW_PRIV_alias_PERMISSION=='Y') {?> ondblclick="ShowReadOnly('<?php echo $Display_AliasId; ?>')" <?php } ?>>
								<td class="check-bx "><input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
									<input type="hidden" id = <?php echo "h_AliasId".$i; ?> name = <?php echo "h_AliasId".$i; ?> value = "<?php echo $Display_AliasId; ?>">												
								</td>
								
								<td> 
									<span id = "<?php echo "span".$i."_2"; ?>"> <?php echo $Display_AliasName; ?> </span>
									<input type="text" id="<?php echo "Text_AliasName".$i; ?>" name="<?php echo "Text_AliasName".$i; ?>" class="form-control small  requirefieldcls" required value = "<?php echo $Display_AliasName; ?>"  style = "height : 30px;font-size:9pt;   display:none" >
								</td>	
								
								<td> 
									<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $Display_AliasType; ?> </span>
									<input type="text" id="<?php echo "Text_AliasType".$i; ?>" name="<?php echo "Text_AliasType".$i; ?>" class="form-control small  "  value = "<?php echo $Display_AliasType; ?>"  style = "height : 30px;font-size:9pt;   display:none" >
									<select id="<?php echo "Combo_AliasType".$i; ?>" name="<?php echo "Combo_AliasType".$i; ?>" class="form-control requirefieldcls" required style = "height : 30px;font-size:9pt;   display:none" >
										<option value="RES-Resource Specific Alias">RES-Resource Specific Alias</option>
									</select>
								</td>						  
								
								<td> 
									<span id = "<?php echo "span".$i."_4"; ?>"> <?php echo $Display_Description; ?> </span>
									<input type="text" id="<?php echo "Text_Description".$i; ?>" name="<?php echo "Text_Description".$i; ?>"  class="form-control requirefieldcls" required value = "<?php echo $Display_Description; ?>" style = "height : 30px; font-size:9pt;display:none" >
								</td>
								
								<td class="check-bx ">
									<input type="checkbox" id="<?php echo "Checkbox_Active$i"; ?>" name="<?php echo "Checkbox_Active$i"; ?>" value="1" <?php echo($Display_Active == "Y")?"checked":""; ?> disabled >	
								</td>
								
								<td> 
									<span id = "<?php echo "span".$i."_6"; ?>"> <?php echo $Display_ProjectWBS; ?> </span>							
								</td>
								
								<td class="check-bx ">
									<input type="checkbox" id="<?php echo "Checkbox_Copy$i"; ?>" name="<?php echo "Checkbox_Copy$i"; ?>" value="1" <?php echo($Display_Copy == "Y")?"checked":""; ?>  disabled>		
								</td>
								
								<td class="check-bx ">
									<input type="checkbox" id="<?php echo "Checkbox_AutoPopulate$i"; ?>" name="<?php echo "Checkbox_AutoPopulate$i"; ?>" value="1" <?php echo($Display_AutoPopulate == "Y")?"checked":""; ?> disabled>	
								</td>
								<td class="check-bx ">
									<input type="checkbox" id="<?php echo "Checkbox_InUse$i"; ?>" name="<?php echo "Checkbox_InUse$i"; ?>" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled>	
								</td>
								<td>
									<?php if($VIEW_PRIV_alias_PERMISSION=='Y') {?> 
									<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
									Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
									<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
									<?php } else {?> <button type="button" class="btn btn-default"><i class=" fa fa-eye"></i></button> <?php } ?>
								</td>
							</tr>
						<?php   
							$i=$i+1;
							}
						?>
						</tbody>
						</table>
					</div>
				</div>
				<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
				<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	
				<input type="hidden" id="h_field_update" name="h_field_update" value="">
				<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>
				<input type="hidden" id="h_query" name="h_query" value=""/>
			</form>
			<div class="fright cr-user mar-top-20pxs">				
				<button type="button" <?php if($CREATE_PRIV_alias_PERMISSION=='Y'){ ?> id = "cmdCopyAlias" name = "cmdCopyAlias"  <?php } else {?> disabled = "disabled" <?php } ?> class="btn btn-primary btn-style2" > Copy Alias</button>				
			</div>
         <!-- pagination start-->
			
			<div class="pagination-bx">
				<div class="bs-example">
				  <ul class="pagination">
					<?php

							//$selectQueryForPages=$selectQueryForPages;
							$RunDepQuery=mysql_query($selectQueryForPages);
							$num_records = mysql_num_rows($RunDepQuery);
							$total_pages= ceil($num_records/$RecordsPerPage);
							if (($page-1)==0){ ?>
								<li class="disabled">
									<!--<a rel="0" href="#"> «</a>-->
									<a rel="0" href="#">&laquo;</a>
								</li>
					  <?php  } else{  ?>
						<li class="">
						<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
						</li>
						<?php }
					   for($i=1;$i<=$total_pages;$i++){ ?>
							<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
							<?php }
							 if (($page+1)>$total_pages){   ?>
							<li class="disabled"><a href="#">&raquo;</a></li>
								<?php  }else{    ?>
						   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
									  <?php } ?>

				  </ul>

				</div>
			</div>
		<!-- pagination end -->
        </div>
      </div>
    </div>
  </div>
</section>
<footer> </footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText);
					document.getElementById("Text_AliasName").value = JSONObject['cxs_aliases']["ALIAS_NAME"];
					document.getElementById("Text_Description").value = JSONObject['cxs_aliases']["DESCRIPTION"];
					document.getElementById("Combo_AliasType").value = JSONObject['cxs_aliases']["ALIAS_TYPE"];					
					document.getElementById("Text_ProjectWBS").value = JSONObject['cxs_aliases']["WBSValue"];
					if(JSONObject['cxs_aliases']["COPY_ALLOWED"]=="Y")
					{
						document.getElementById("Check_CopyAllowed").checked=true;
					}
					else
					{
						document.getElementById("Check_CopyAllowed").checked=false;
					}	
					
					if(JSONObject['cxs_aliases']["AUTOPOPULATE"]=="Y")
					{
						document.getElementById("Check_AutoPopulate").checked=true;
					}
					else
					{
						document.getElementById("Check_AutoPopulate").checked=false;
					}	
					
					if(JSONObject['cxs_aliases']["ACTIVE_FLAG"]=="Y")
					{
						document.getElementById("Check_Active").checked=true;
					}
					else
					{
						document.getElementById("Check_Active").checked=false;
					}	
					
					if(JSONObject['cxs_aliases']["ADDINUSE_FLAG"]=="Y")
					{
						document.getElementById("Check_InUse").checked=true;
					}
					else
					{
						document.getElementById("Check_InUse").checked=false;
					}	
				}
				
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;					
					document.getElementById("h_query").value=s1;						
					s1 = s1.trim();					
					AliasList.submit();
				}
				else if (KEY == "FindData-CopyAlias")
				{
					$("#divFindCopyAlias").html(http_request.responseText);
					$("#TablePopup-CopyAliasHd").DataTable({"searching": false});
					//document.getElementById("TablePopup-CopyAliasList").innerHTML = s1;	
					//document.getElementById("TablePopup-CopyAliasHd").style.display = "block";					
					
				}
				else if (KEY=="CopyData")
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					//alert(s1);
					if (s1 == "Records Copied")
					{
						$('#CopyAliasPopup').modal('toggle'); 						
					}
					/*var JSONObject = JSON.parse(http_request.responseText);
					//if(JSONObject['AlreadyExist']["ALIAS_NAME"]!="")
					//{
						for (i = 0; i < JSONObject.length; ++i) 
						{
							// do something with `substr[i]`
							alert(JSONObject['AlreadyExist']["ALIAS_NAME"]);
						}
					//}*/
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	$("#cmdCopyAlias").click(function()
	{
		$("#divFindCopyAlias").text("");
		$("#CopyAliasPopup").modal('show');
		
	});
	
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = "<?php echo $ExportQry; ?>";	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#CheckboxInline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_AliasId"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'ALIAS_ID', ExportIdList:exportIds,
						  ExportFileName:'_aliases.xls', ExportSheetTitle:"Resource Aliases"
						  },
					type:"POST",
					success:function(response)
					{
						//alert(response);
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	</script>

</body>
</html>