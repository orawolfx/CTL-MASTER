<?php ob_start ();
 
include('../conn.php');
if($_REQUEST['TableName']!='')
{
	$TableName = $_REQUEST['TableName'];
	$FieldName = $_REQUEST['FieldName'];
	$FieldValue = $_REQUEST['FieldValue'];
	$qry = "Select * from $TableName Where $FieldName='$FieldValue'";
	$result = mysql_query($qry);
	while($row=mysql_fetch_array($result))
	{
	   $data[$TableName] = $row;		
	}
	echo json_encode($data);
}
else if($_REQUEST['StartDate']!='' && $_REQUEST['EndDate']!='')
{
	
	function isWeekend($date) 
	{
		$weekDay = date('w', strtotime($date));
		//return ($weekDay == 0 || $weekDay == 6);
		if($weekDay==0|| $weekDay==6)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	//$IsWeekend = "N";
	$StartDate = $_REQUEST['StartDate'];
	$EndDate = $_REQUEST['EndDate'];
	
	$StartDate = strtotime($StartDate);		
	$StartDate = date('m/d/Y', $StartDate);
	
	$EndDate = strtotime($EndDate);		
	$EndDate = date('m/d/Y', $EndDate);
	$date = $StartDate;
	while (strtotime($date) <= strtotime($EndDate)) 
	{
		//echo "$date\n";
		if(isWeekend($date)==1)
		{
			$IsWeekend="Y";
			break;
		}
		$date = date ("Y-m-d", strtotime("+1 day", strtotime($date)));
	}
	if($IsWeekend=="")
	{
		$IsWeekend= "N";
	}
	echo json_encode($IsWeekend);
}

else if ($_POST['REQUEST']="SearchRequiredHours")
{
	$WorkshiftId = $_REQUEST['WorkshiftId'];
	$requiredHours = "";//$WorkshiftType=='Flexible Shift'||$WorkshiftType=='Hourly Shift'
	$qry = "Select * from cxs_workshifts where WORKSHIFT_ID = $WorkshiftId";
	$result = mysql_query($qry);
	while($row = mysql_fetch_array($result))
	{
		$WorkshiftType = $row['WORKSHIFT_TYPE']	;
		$PartTime = $row['PART_TIME'];
		$PartTime = stripcslashes($PartTime);
	}
	if ($WorkshiftType=='9/8/80 Shift')
	{
		$requiredHours = "80";
	}
	else if ($WorkshiftType=='4/10/40 Shift' || $WorkshiftType=='Regular 40Hours Shift')
	{
		$requiredHours = "40";
	}
	else if ($WorkshiftType=='Six Days Shift')
	{
		$requiredHours = "48";
	}
	else if ($WorkshiftType=='Part Time Shift')
	{
		$arr = explode(' ',$PartTime);
		$arr2 = explode('/',$arr[0]);
		$num1 = (float)$arr2[0];
		$num2 = (float)$arr2[1];
		
		$requiredHours = 8*($num1/$num2)*5;
	}
	echo json_encode ($requiredHours);
}

?>