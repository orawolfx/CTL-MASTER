<?php 
	ob_start ();
	 
	include("te-functions.php");  
	check_login();
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$Notifications_PERMISSION = "Y";		
	}
	else
	{
		$Notifications_PERMISSION = getTimeAccountingRulesByUserId('BIZ_MSG_FLAG',$_SESSION['user_id']);
	}	
	if($Notifications_PERMISSION=='N')
	{
		header('location:te.php');
	}
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "notifications.php";
?>
<script type="text/javascript" >
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Notifications";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
</script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
</head>

<body>

    <!-- modals start -->
    <div id="detail1" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times;</span></button>
                    <h4 class="modal-title " id="myModalLabel"> Sender Details </h4>
                </div>
                <div class="modal-body">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="sen-det-bx">
                                    <li> <span> Sender :</span> RVAISHNA </li>
                                    <li> <span> Message Type :</span> Call for Action </li>
                                    <li> <span> Timesheet :</span> Timesheet:March-2017 </li>
                                    
                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <ul class="sen-det-bx">
                                    <li> <span> Time Sent :</span> Monday, January 14th, 2017 </li>
                                    <li> <span> Urgent </span>
                                        <input type="checkbox" id="inlineCheckbox1" value="option1" checked>
                                    </li>
                                    <li> <span> Subject :</span> Lorem lisum awasmohe to ha thest </li>
                                    
                                </ul>
                            </div>
                            <div class="col-sm-12">
                                <ul class="sen-det-bx">
                                    <li> <span> Message </span> Lorem lisum awasmohe to ha thest hdyhs Lorem lisum awasmohe to ha thest hdyhs sdre
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                    <button type="button" class="btn btn-primary btn-style" data-dismiss="modal" aria-label="Close"> Ok </button>
                </div>
            </div>
        </div>
    </div>
    <!-- modals end -->
    <!-- new notification start -->
    <div id="new-noti" class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog modal-lg cus-modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times;</span></button>
                    <h4 class="modal-title " id="myModalLabel"> Outbound Notifications </h4>
                </div>
                <div class="modal-body">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="cr-new-noti">
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> Sender </label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="" placeholder="" maxlength="20">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> Message Type </label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="" placeholder="" maxlength="20">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> Urgent  </label>
                                    <div class="col-sm-10">
                                        <input type="checkbox" id="inlineCheckbox1" value="option1" class="check-cont">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> TimeSheet </label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="" placeholder="" maxlength="100">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> Subject  </label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="" placeholder="" maxlength="100">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="" class="col-sm-2 control-label"> Message </label>
                                    <div class="col-sm-10">
                                        <textarea type="text" class="form-control" id="" placeholder="" maxlength="100" rows="4"></textarea>
                                    </div>
                                </div>




                                <div class="clear"></div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="clear-both"></div>
                <div class="modal-footer cr-user">
                    <button type="button" class="btn btn-primary btn-style fright"> Send  </button>
                </div>
            </div>
        </div>
    </div>
    <!-- new notification end-->
	<?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <!-- brd crum-->
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#"> Time Accounting </a></li>
                        <li> <a href="#"> Notifications </a></li>
                    </ul>
                </div>
                <!-- Dash board -->
                <div class="dash-strip">
                    <div class="fleft cr-user"> <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> </div>
					<div class="fright">
				<?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						}
				?>          
						<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
						<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
						<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>						
					</div>
                </div>

                <!-- inner work-->
                <div class="cont-box">
                    <div>
                        <h2 class="sec-title"> <label id="Label_Title"> Notifications </label></h2>
                        <p class="sec-sunx-txt mar-tp20"> Inbound Notifications </p>
                    </div>
                    <div class="cr-user fright">
                        <a <?php $sDisabled = ""; if($Notifications_PERMISSION=='Y'){ ?> href="#new-noti" data-toggle="modal" <?php } else  $sDisabled ="disabled=disabled";?>> <button type="button" class="btn btn-primary btn-style"> <?php echo $s_caption; ?> Notification </button> </a>						
					
						
                    </div>
                    <div>
                        <div class="data-bx">
                            <div class="table-responsive">
                                <table class="table table-bordered mar-cont">
                                    <thead>
                                        <tr>
                                            <th width="10%"> Sender
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="20%"> Date & Time
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="10%"> Subject
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="15%"> Message Type </th>
                                            <th width="8%"> Urgent
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="10%"> Time Sheet
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="10%"> Status
                                                <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                            </th>
                                            <th width="7%"> See Details
                                               
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td> Dummy Text </td>
                                            <td> January 1st 2017,12:00 AM <i class="fa fa-calendar pd-lft10"></i></td>
                                            <td> Dummy Text </td>
                                            <td> Call to Action </td>
                                            <td><input type="checkbox" id="inlineCheckbox1" value="option1"></td>
                                            <td> Dummy Text </td>
                                            <td> Dummy Text </td>
                                            <td> <a href="#detail1" data-toggle="modal" class="show-btn"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Dummy Text </td>
                                            <td> January 1st 2017,12:00 AM <i class="fa fa-calendar pd-lft10"></i></td>
                                            <td> Dummy Text </td>
                                            <td> Call to Action </td>
                                            <td><input type="checkbox" id="inlineCheckbox1" value="option1"></td>
                                            <td> Dummy Text </td>
                                            <td> Dummy Text </td>
                                            <td> <a href="#detail1" data-toggle="modal" class="show-btn"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Dummy Text </td>
                                            <td> January 1st 2017,12:00 AM <i class="fa fa-calendar pd-lft10"></i></td>
                                            <td> Dummy Text </td>
                                            <td> Call to Action </td>
                                            <td><input type="checkbox" id="inlineCheckbox1" value="option1"></td>
                                            <td> Dummy Text </td>
                                            <td> Dummy Text </td>
                                            <td> <a href="#detail1" data-toggle="modal" class="show-btn"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Dummy Text </td>
                                            <td> January 1st 2017,12:00 AM <i class="fa fa-calendar pd-lft10"></i></td>
                                            <td> Dummy Text </td>
                                            <td> Call to Action </td>
                                            <td><input type="checkbox" id="inlineCheckbox1" value="option1"></td>
                                            <td> Dummy Text </td>
                                            <td> Dummy Text </td>
                                            <td> <a href="#detail1" data-toggle="modal" class="show-btn"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td> Dummy Text </td>
                                            <td> January 1st 2017,12:00 AM <i class="fa fa-calendar pd-lft10"></i></td>
                                            <td> Dummy Text </td>
                                            <td> Call to Action </td>
                                            <td><input type="checkbox" id="inlineCheckbox1" value="option1"></td>
                                            <td> Dummy Text </td>
                                            <td> Dummy Text </td>
                                            <td> <a href="#detail1" data-toggle="modal" class="show-btn"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                            </div>
                        </div>

                        <!-- pagination start-->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- pagination end -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer> </footer>
	<script type="text/javascript">
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>

</html>