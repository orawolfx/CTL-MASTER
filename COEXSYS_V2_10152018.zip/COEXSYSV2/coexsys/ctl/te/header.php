<?php //ob_start ();
	 
	$LoginUserId = $_SESSION['user_id'];
	$CurrentUserType = "";
	
	if(HasUserType($_SESSION['user-type'],'TE-Admin'))
	{
		$CurrentUserType = "TE-Admin";
	}
	else if(HasUserType($_SESSION['user-type'],'TE-User'))
	{
		$CurrentUserType = "TE-User ";
	}		
	$_SESSION['current-user-type']=$CurrentUserType;	
	$SiteId1 = $_SESSION['user-siteid'];
	$SiteName = "";
	$qry = "Select * from cxs_sites where SITE_ID = $SiteId1";
	$result = mysql_query($qry);
	while($row = mysql_fetch_array($result))
	{
		$SiteName = "[".$row['SITE_NAME']."]";
	}
?>
<header>	
  <div class="top-nav-bx">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 col-md-6" style = "padding-left:2px;padding-right:2px;">
          <div class="logo"> <a href="te.php"> <img src="../img/logo.jpg"></a> <span class="ac-manage"> Time & Labor <?php echo $SiteName; ?></span> </div>
        </div>
        <div class="col-sm-6 col-md-6" style = "padding-left:2px;padding-right:2px;">
			<ul class="top-nav">
				<?php
					$OpenSupportRequest = "";
					if ($CurrentUserType == "TE-Admin")
					{
						$OpenSupportRequest = "Y";
					}
					else
					{
						$qry = "select SUBMIT_CUSTOM from cxs_users left join cxs_am_roles on cxs_am_roles.ROLE_ID = cxs_users.ROLE_ID where cxs_users.USER_ID = $LoginUserId";
						$result=mysql_query	($qry);				
						while($rows = mysql_fetch_array($result))
						{
							$OpenSupportRequest = $rows['SUBMIT_CUSTOM'];
						}				
					}
				if($OpenSupportRequest=="Y"){ ?> 
				<li class="dropdown">
					<a href="te-support.php" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown " role="button" aria-haspopup="true" aria-expanded="false">  <span class="sm-hide"> Contact Support </span> </a>
				</li>	
			<?php } ?>
			<!-- 	<li class="dropdown"> <a href="#" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="sm-hide"> Contact Support </span> <b class="fa fa-angle-down"></b></a>
             
				<li class="dropdown"> <a href="#" class="dropdown-toggle btn-warning cont-supp" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-phone"></i> <span class="sm-hide"> Contact Support </span> <b class="fa fa-angle-down"></b></a>
				<ul class="dropdown-menu">
                <li><a href="te.php"> Chat Now </a></li>
                <li><a href="#"> Schedule a Call </a></li>
                <li><a href="#"> Send Message </a></li>
                <li><a href="#"> Call 858-945-8003 </a></li>
                <li><a href="#"> Open a Service request </a></li>
              </ul>
            </li>-->
				<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-star"></i> <span class="sm-hide"> Favorites </span> <b class="fa fa-angle-down"></b></a>
				  <ul class="dropdown-menu" id = "favorite_list" name = "favorite_list">
				   <?php										
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId order by FEATURE_NAME";
						$result=mysql_query	($qry);						
						while($rows = mysql_fetch_array($result))
						{
							$FEATURE_NAME = $rows['FEATURE_NAME'];
							$PAGE_NAME = $rows['PAGE_NAME'];
							$MODULE_NAME = $rows['MODULE_NAME'];
							if($ModuleName!=$MODULE_NAME)
							{
								if($MODULE_NAME=='Access Management')
								{
									$Link = "../rbam/".$PAGE_NAME;	
									$Link = "../rbam/".$PAGE_NAME."?m=1";
										
								}
								else if($MODULE_NAME=='Time Accounting')
								{
									$Link = "../te/".$PAGE_NAME."?m=1";
								}
							}
							else
							{
								$Link = $PAGE_NAME;
							}
					?>
						<li><a href="<?php  echo $Link; ?>"> <?php echo $FEATURE_NAME; ?></a></li>
				<?php 	} ?>
				  </ul>
				</li>
				<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-question-circle"></i> <span class="sm-hide"> Help </span><b class="fa fa-angle-down"></b></a>
				  <ul class="dropdown-menu">
					<li><a href="#"> Option 1 </a></li>
					<li><a href="#"> Option 2 </a></li>
				  </ul>
				</li>
				<?php $username = $_SESSION['user_data']['USER_NAME'];  
					include("../uploadphoto.php"); //echo getProfileImg($_SESSION['user_id']);
				?>			
				<li class="dropdown">
					<a href="#" class="dropdown-toggle user-box" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <img class="pro-img-bx" src="<?php echo getProfileImg($_SESSION['user_id']); ?>"/><span class="name-bx2"> <?php echo $username;?> </span><b class="fa fa-angle-down"></b></a>
					<ul class="dropdown-menu">
						<li><a href="javascript:uploadProfilePhotoModal();"> Upload Picture </a></li>
						<?php								
							if(isset($_SESSION['access-module']) && ($_SESSION['access-module']=='Both'))
							{?>
								<li><a href="../rbam/rbam.php"> Access Management </a></li>		
					<?php 	}?>
						<li><a href="../logout.php"> Logout </a></li>
					
					</ul>
				</li>
			</ul>
        </div>
      </div>
    </div>
  </div>
  <!-- navigation  -->
  <nav class="navbar navbar-default custom-navbar">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only"> Toggle navigation </span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav custom-nav">
          <li class="dropdown"> <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Set Up <span class="caret"></span></a>
            <ul class="dropdown-menu">
			
			<?php
			$disableStyle = "color: #e9e9e9; background-color: #ffffff;";
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_accounting_PERMISSION = "Y";
				$UPDATE_PRIV_accounting_PERMISSION = "Y";
				$VIEW_PRIV_accounting_PERMISSION = "Y";
				$ENABLE_AUDIT_accounting_PERMISSION = "Y";
			}		
			else
			{
				$CREATE_PRIV_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Accounting Period',$_SESSION['user_id']);
				$UPDATE_PRIV_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Accounting Period',$_SESSION['user_id']);
				$VIEW_PRIV_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Accounting Period',$_SESSION['user_id']);
				$ENABLE_AUDIT_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Accounting Period',$_SESSION['user_id']);
			}
			
			$accounting_page_visibility = false;
			if($CREATE_PRIV_accounting_PERMISSION=='Y' || $UPDATE_PRIV_accounting_PERMISSION=='Y' || $VIEW_PRIV_accounting_PERMISSION=='Y' || $ENABLE_AUDIT_accounting_PERMISSION=='Y')
			{
				$accounting_page_visibility = true;
			}
			?>	
				<li><a <?php if($accounting_page_visibility==true){ ?>href="accounting-periods.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Accounting Periods </a></li>
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_alias_PERMISSION = "Y";
				$UPDATE_PRIV_alias_PERMISSION = "Y";
				$VIEW_PRIV_alias_PERMISSION = "Y";
				$ENABLE_AUDIT_alias_PERMISSION = "Y";
			}		
			else
			{
				$CREATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
				$UPDATE_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Create Personal Aliases',$_SESSION['user_id']);
				$VIEW_PRIV_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Create Personal Aliases',$_SESSION['user_id']);
				$ENABLE_AUDIT_alias_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Create Personal Aliases',$_SESSION['user_id']);
			}
				$alias_page_visibility = false;
				if($CREATE_PRIV_alias_PERMISSION=='Y' || $UPDATE_PRIV_alias_PERMISSION=='Y' || $VIEW_PRIV_alias_PERMISSION=='Y' || $ENABLE_AUDIT_alias_PERMISSION=='Y')
				{
					$alias_page_visibility = true;
				}
			?>	
				<li><a <?php if($alias_page_visibility==true){ ?>href="aliases.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Resource Aliases </a></li>
			
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_holiday_PERMISSION = "Y";
				$UPDATE_PRIV_holiday_PERMISSION = "Y";
				$VIEW_PRIV_holiday_PERMISSION = "Y";
				$ENABLE_AUDIT_holiday_PERMISSION = "Y";
			}		
			else
			{	
				$CREATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
				$UPDATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
				$VIEW_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Holiday Calenders',$_SESSION['user_id']);
				$ENABLE_AUDIT_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Holiday Calenders',$_SESSION['user_id']);
			}
				$holiday_page_visibility = false;
				if($CREATE_PRIV_holiday_PERMISSION=='Y' || $UPDATE_PRIV_holiday_PERMISSION=='Y' || $VIEW_PRIV_holiday_PERMISSION=='Y' || $ENABLE_AUDIT_holiday_PERMISSION=='Y')
				{
					$holiday_page_visibility = true;
				}
			?>	
				<li><a <?php if($holiday_page_visibility==true){ ?> href="holiday-calendar.php" <?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Holiday Calendar </a></li>
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_PreApproval_PERMISSION = "Y";
				$UPDATE_PRIV_PreApproval_PERMISSION = "Y";
				$VIEW_PRIV_PreApproval_PERMISSION = "Y";
				$ENABLE_AUDIT_PreApproval_PERMISSION = "Y";
			}		
			else
			{		
				$CREATE_PRIV_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','PreApproval Rules',$_SESSION['user_id']);
				$UPDATE_PRIV_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','PreApproval Rules',$_SESSION['user_id']);
				$VIEW_PRIV_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','PreApproval Rules',$_SESSION['user_id']);
				$ENABLE_AUDIT_PreApproval_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','PreApproval Rules',$_SESSION['user_id']);
			}
				$PreApproval_page_visibility = false;
				if($CREATE_PRIV_PreApproval_PERMISSION=='Y' || $UPDATE_PRIV_PreApproval_PERMISSION=='Y' || $VIEW_PRIV_PreApproval_PERMISSION=='Y' || $ENABLE_AUDIT_PreApproval_PERMISSION=='Y')
				{
					$PreApproval_page_visibility = true;
				}
			?>
				<li><a <?php if($PreApproval_page_visibility==true){ ?>href="pre-approval-rules.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Pre Approval Rules </a></li>
			
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_ResourceGroup_PERMISSION = "Y";
				$UPDATE_PRIV_ResourceGroup_PERMISSION = "Y";
				$VIEW_PRIV_ResourceGroup_PERMISSION = "Y";
				$ENABLE_AUDIT_ResourceGroup_PERMISSION = "Y";
			}		
			else
			{		
				$CREATE_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Resource Group',$_SESSION['user_id']);
				$UPDATE_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Resource Group',$_SESSION['user_id']);
				$VIEW_PRIV_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Resource Group',$_SESSION['user_id']);
				$ENABLE_AUDIT_ResourceGroup_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Resource Group',$_SESSION['user_id']);
			}
				$ResourceGroup_page_visibility = false;
				if($CREATE_PRIV_ResourceGroup_PERMISSION=='Y' || $UPDATE_PRIV_ResourceGroup_PERMISSION=='Y' || $VIEW_PRIV_ResourceGroup_PERMISSION=='Y' || $ENABLE_AUDIT_ResourceGroup_PERMISSION=='Y')
				{
					$ResourceGroup_page_visibility = true;
				}
			?>
				<li><a <?php if($ResourceGroup_page_visibility==true){ ?>href="resource-groups.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Resource Groups </a></li>
			
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_Resources_PERMISSION = "Y";
				$UPDATE_PRIV_Resources_PERMISSION = "Y";
				$VIEW_PRIV_Resources_PERMISSION = "Y";
				$ENABLE_AUDIT_Resources_PERMISSION = "Y";
			}		
			else
			{		
				$CREATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Resources',$_SESSION['user_id']);
				$UPDATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Resources',$_SESSION['user_id']);
				$VIEW_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Resources',$_SESSION['user_id']);
				$ENABLE_AUDIT_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Resources',$_SESSION['user_id']);
			}
				$Resources_page_visibility = false;
				if($CREATE_PRIV_Resources_PERMISSION=='Y' || $UPDATE_PRIV_Resources_PERMISSION=='Y' || $VIEW_PRIV_Resources_PERMISSION=='Y' || $ENABLE_AUDIT_Resources_PERMISSION=='Y')
				{
					$Resources_page_visibility = true;
				}
			?>		
				<li><a <?php if($Resources_page_visibility==true){ ?>href="resource-management.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Resources </a></li>
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_TimePolicy_PERMISSION = "Y";
				$UPDATE_PRIV_TimePolicy_PERMISSION = "Y";
				$VIEW_PRIV_TimePolicy_PERMISSION = "Y";
				$ENABLE_AUDIT_TimePolicy_PERMISSION = "Y";
			}		
			else
			{	
				$CREATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Management Policy',$_SESSION['user_id']);
				$UPDATE_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Management Policy',$_SESSION['user_id']);
				$VIEW_PRIV_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Time Management Policy',$_SESSION['user_id']);
				$ENABLE_AUDIT_TimePolicy_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Time Management Policy',$_SESSION['user_id']);
			}
				$TimePolicy_page_visibility = false;
				if($CREATE_PRIV_TimePolicy_PERMISSION=='Y' || $UPDATE_PRIV_TimePolicy_PERMISSION=='Y' || $VIEW_PRIV_TimePolicy_PERMISSION=='Y' || $ENABLE_AUDIT_TimePolicy_PERMISSION=='Y')
				{
					$TimePolicy_page_visibility = true;
				}
			?>			
				<li><a <?php if($TimePolicy_page_visibility==true){ ?>href="time-management-policy.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Time Policies </a></li>
			
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_WorkShift_PERMISSION = "Y";
				$UPDATE_PRIV_WorkShift_PERMISSION = "Y";
				$VIEW_PRIV_WorkShift_PERMISSION = "Y";
				$ENABLE_AUDIT_WorkShift_PERMISSION = "Y";
			}		
			else
			{	
				$CREATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','WorkShift',$_SESSION['user_id']);
				$UPDATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','WorkShift',$_SESSION['user_id']);
				$VIEW_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','WorkShift',$_SESSION['user_id']);
				$ENABLE_AUDIT_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','WorkShift',$_SESSION['user_id']);
			}
			$WorkShift_page_visibility = false;
			if($CREATE_PRIV_WorkShift_PERMISSION=='Y' || $UPDATE_PRIV_WorkShift_PERMISSION=='Y' || $VIEW_PRIV_WorkShift_PERMISSION=='Y' || $ENABLE_AUDIT_WorkShift_PERMISSION=='Y')
			{
				$WorkShift_page_visibility = true;
			}
			?>	
				<li><a <?php if($WorkShift_page_visibility==true){ ?>href="workshifts.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Work Shifts </a></li>              
            </ul>
          </li>
          
		  <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Time Accounting <span class="caret"></span></a>
            <ul class="dropdown-menu">
			<?php
			if ($CurrentUserType == "TE-Admin")
			{
				$CREATE_PRIV_TimeEntry_PERMISSION = "Y";
				$UPDATE_PRIV_TimeEntry_PERMISSION = "Y";
				$VIEW_PRIV_TimeEntry_PERMISSION = "Y";
				$ENABLE_AUDIT_TimeEntry_PERMISSION = "Y";
			}		
			else
			{		
				$CREATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Time Entry',$_SESSION['user_id']);
				$UPDATE_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Time Entry',$_SESSION['user_id']);
				$VIEW_PRIV_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','Time Entry',$_SESSION['user_id']);
				$ENABLE_AUDIT_TimeEntry_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','Time Entry',$_SESSION['user_id']);
			}
				$TimeEntry_page_visibility = false;
				if($CREATE_PRIV_TimeEntry_PERMISSION=='Y' || $UPDATE_PRIV_TimeEntry_PERMISSION=='Y' || $VIEW_PRIV_TimeEntry_PERMISSION=='Y' || $ENABLE_AUDIT_TimeEntry_PERMISSION=='Y')
				{
					$TimeEntry_page_visibility = true;
				}
			?>
			  <li><a <?php if($TimeEntry_page_visibility==true){ ?>href="time-entry.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Time Entry </a></li>
              <!--<li><a href="pre-approved-time-entry.php"> Pre-Approval Time Entry </a></li>-->
             <?php
			if ($CurrentUserType == "TE-Admin")
			{
				$Notifications_PERMISSION = "Y";				
			}		
			else
			{	
				$Notifications_PERMISSION = getTimeAccountingRulesByUserId('BIZ_MSG_FLAG',$_SESSION['user_id']);				
			}
				$Notifications_page_visibility = false;
				if($Notifications_PERMISSION=='Y')
				{
					$Notifications_page_visibility = true;
				}
			?>
			<!-- <li><a <?php if($Notifications_page_visibility==true){ ?>href="notifications.php"<?php }else{ ?>style="<?php echo $disableStyle;?>"<?php } ?>> Notifications </a></li>	-->		 
            </ul>
          </li>
        </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
  </nav>
</header>