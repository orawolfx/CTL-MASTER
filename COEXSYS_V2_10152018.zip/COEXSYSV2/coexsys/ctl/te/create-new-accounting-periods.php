<?php 
	ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_accounting_PERMISSION = "Y";
		$UPDATE_PRIV_accounting_PERMISSION = "Y";		
	}
	else
	{
		$CREATE_PRIV_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Accounting Period',$_SESSION['user_id']);
		$UPDATE_PRIV_accounting_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Accounting Period',$_SESSION['user_id']);
	}		
	if($CREATE_PRIV_accounting_PERMISSION=='N' && $UPDATE_PRIV_accounting_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "create-new-accounting-periods.php";
	$SiteId = $_SESSION['user-siteid'];	
	$StatusValue1 = "<option value=''> - Assing Status - </option><option value='Never Opened'> Never Opened </option><option value='Open'>Open</option><option value='Close'>Close</option><option value='Permanently Closed'>Permanently Closed</option>";	
	$StatusValue = "<option value='Never Opened'> Never Opened </option>";
	
	$insArr = array();
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];
	//	DisplayRecord($HeaderId);	
	}
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "FROM_PERIOD_DATE";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	
	
	
	/*
	if ($Sorts == 'asc')
	{
		$OrderBY = " desc";
		$FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";	

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}	
	$start_from = ($page-1) *  $RecordsPerPage;
	*/
	$msg = "";
	
	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	$IsDuplicate = isset($_REQUEST['h_duplicate'])?$_REQUEST['h_duplicate']:0;
	if(IsDuplicate=="Y")
	{
		$msg = "Calendar Name / Period Year are not allowed duplicate.";
	}
	
	//if (isset($_POST['cmdSaveRecord'] ))
	if($_POST['Text_CalendarName'] != '' && $msg == "")  
	{ 
		$Text_CalendarName = isset($_POST["Text_CalendarName"] )? $_POST["Text_CalendarName"]: false;
		$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;
		$Text_PeriodYear =  isset($_POST["h_PeriodYear"] )? $_POST["h_PeriodYear"]: false; //isset($_POST["Text_PeriodYear"] )? $_POST["Text_PeriodYear"]: false;
		$Combo_PeriodType = isset($_POST["Combo_PeriodType"] )? $_POST["Combo_PeriodType"]: false;	
		$h_IsInuse = isset($_POST["h_IsInuse"] )? $_POST["h_IsInuse"]: false;	
		
		$pos = strpos($Text_CalendarName,$Text_PeriodYear);
		if (is_numeric($pos))
		{
			$insArr['NAME'] = $Text_CalendarName;
		}
		else
		{
			$insArr['NAME'] = $Text_CalendarName."-".$Text_PeriodYear;
		}
		
		$insArr['DESCR'] = $Text_Description;
		$insArr['PERIOD_YEAR'] = $Text_PeriodYear;
		if($h_IsInuse=="")
		{
			$insArr['PERIOD_TYPE'] = $Combo_PeriodType;	
		}
			
		$insArr['LAST_UPDATED_BY']=$LoginUserId;	
		$insArr['SITE_ID']=$SiteId;		
		if($HeaderId=='')
		{
			$insArr['CREATED_BY']=$LoginUserId;
			$insArr['CREATION_DATE']='now()';	
			insertdata("cxs_calendars",$insArr);			
			$HeaderId = mysql_insert_id();
		}
		else
		{
			if ($IsUpdate =='')
			{
				updatedata("cxs_calendars",$insArr,"Where cxs_calendars.CALENDAR_ID = $HeaderId");			
			}
		}
		if($HeaderId!='')
		{
			/*$qry = "select * from cxs_policy_general where CALENDAR_ID = $HeaderId ";
			$result = mysql_query($qry);
			$TotalRecordsPolicy = mysql_num_rows($result);
			*/
			for($i=1;$i<=$TotalRows;$i++)
			{
				$hPeriodId = isset( $_POST['h_PeriodId'.$i] )? $_POST['h_PeriodId'.$i]: false;
				$Check_Record = isset( $_POST['CheckboxInline'.$i] )? $_POST['CheckboxInline'.$i]: false;
				
				$Text_StartDate = isset( $_POST['Text_StartDate'.$i] )? $_POST['Text_StartDate'.$i]: false;
				$Text_EndDate = isset( $_POST['Text_EndDate'.$i] )? $_POST['Text_EndDate'.$i]: false;
				$Text_PeriodName = isset( $_POST['Text_PeriodName'.$i] )? $_POST['Text_PeriodName'.$i]: false;
				$Check_InUse = isset($_POST["Check_InUse$i"] )? $_POST["Check_InUse$i"]: false;
				
				$Combo_Status = isset($_POST["Combo_Status$i"] )? $_POST["Combo_Status$i"]: false;				
				if($Check_InUse!=1 && $Combo_Status=='Open'&& $TotalRecordsPolicy>0)
				{
					$Check_InUse = 1;						
				}
				
				if($Text_StartDate!='' && $Text_EndDate!= '')
				{
					$Text_StartDate = date("Y/m/d", strtotime($Text_StartDate));
					$Text_EndDate = date("Y/m/d", strtotime($Text_EndDate));
					
					unset($inArr1); 
					$insArr1['PERIOD_YEAR'] = $Text_PeriodYear;
					$insArr1['FROM_PERIOD_DATE'] = $Text_StartDate;
					$insArr1['TO_PERIOD_DATE'] = $Text_EndDate;
					$insArr1['PERIOD_NAME'] = $Text_PeriodName;
					$insArr1['STATUS'] = $Combo_Status;
					$insArr1['FLAG_INUSE'] = ($Check_InUse==1)?"Y":"N";					
					$insArr1['LAST_UPDATED_BY']=$LoginUserId;
					$insArr1['CALENDAR_ID']=$HeaderId;
					$insArr1['SITE_ID']=$SiteId;		
					if($hPeriodId=='')
					{
						$insArr1['CREATED_BY']=$LoginUserId;
						$insArr1['CREATION_DATE']='now()' ;				
						insertdata("cxs_periods",$insArr1);		
					}
					else
					{
						if($Check_Record==1)
						{
							updatedata("cxs_periods",$insArr1,"where cxs_periods.PERIOD_ID = $hPeriodId");		
							if($Combo_Status=='Close')
							{
								$qry = "update cxs_te_header set STATUS = 'Close' where PAY_PERIOD_ID = $hPeriodId";
								mysql_query($qry);
							}
						}
					}
				}
			}
			$PermanentCloseCounter = 0;
			$qry = "select * from cxs_periods where CALENDAR_ID = $HeaderId and SITE_ID = $SiteId";
			$result = mysql_query($qry);
			$TotalPeriods = mysql_num_rows($result);
			while($rows=mysql_fetch_array($result))
			{
				if($rows['STATUS']=='Permanently Closed')
				{
					$PermanentCloseCounter++;
				}	
			}
			if($TotalPeriods==$PermanentCloseCounter)	
			{
				InsertNextYearRecord($HeaderId);
			}
		}		
		header("Location:accounting-periods.php");
		
	}
		
	if ($HeaderId != '')
	{
		/*$qry = "SELECT cxs_calendars.NAME as CalendarName,cxs_calendars.DESCR,cxs_calendars.PERIOD_TYPE,cxs_periods.*,cxs_users.USER_NAME as CreatedByName,
		(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_periods.LAST_UPDATED_BY)  as UpdatedByName  from cxs_calendars inner join cxs_periods on cxs_periods.CALENDAR_ID = cxs_calendars.CALENDAR_ID INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_periods.CREATED_BY where cxs_calendars.CALENDAR_ID = $HeaderId";		*/
		$qry = "SELECT cxs_calendars.*,cxs_calendars.NAME as CalendarName from cxs_calendars where cxs_calendars.CALENDAR_ID = $HeaderId";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_CalendarName = $row['CalendarName'];
			$Display_Description = $row['DESCR'];
			$Display_PeriodType = $row['PERIOD_TYPE'];
			$Display_PeriodYear = $row['PERIOD_YEAR'];
		}
	}
	
	function InsertNextYearRecord($ExistCalendarId)
	{
		$LoginUserId = $_SESSION['user_id']; 
		
		
		$qry = "select * from cxs_periods where CALENDAR_ID = $ExistCalendarId order by PERIOD_ID desc limit 0,1";
		$result = mysql_query($qry);
		while($rows=mysql_fetch_array($result))
		{
			$StartDate = $rows['TO_PERIOD_DATE'];
		}
		
		$StartDate = date('Y-m-d', strtotime('1 day', strtotime($StartDate)));
		$EndDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($StartDate)) . " + 1 year"));
		$EndDate = date('Y-m-d', strtotime('-1 day', strtotime($EndDate)));
		if( date('Y',strtotime($StartDate)) == date('Y',strtotime($EndDate )))
		{
			$PeriodYear = date('Y',strtotime($StartDate));
		}
		else
		{
			$PeriodYear = date('Y',strtotime($StartDate))."-".$PeriodYear = date('Y',strtotime($EndDate));
		}
		
		$Flag_AllowInsert = "";
		$qry = "select * from cxs_calendars where PERIOD_YEAR = '$PeriodYear' and SITE_ID = $SiteId";
		$result = mysql_query($qry);
		while($rows=mysql_fetch_array($result))
		{
			$IsSystemCreated = $rows['FLAG_SYSTEMCREATED'];
			$TempId = $rows['CALENDAR_ID'];
			
			if($IsSystemCreated=='N')
			{
				$qry1 = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID and cxs_calendars.PERIOD_YEAR = '$PeriodYear' and cxs_periods.FLAG_INUSE = 'Y' and cxs_calendars.SITE_ID = $SiteId";
				$result1 = mysql_query($qry1);
				$noofRecords = mysql_num_rows($result1);
				if ($noofRecords == 0)
				{
					mysql_query("delete from cxs_calendars where CALENDAR_ID = $TempId");
					mysql_query("delete from cxs_periods where CALENDAR_ID = $TempId");
				}
				else
				{
					$Flag_AllowInsert = "N";
				}
			}
		}
		
		if($Flag_AllowInsert == "")
		{
			$qry = "select * from cxs_calendars where CALENDAR_ID = $ExistCalendarId";
			$result = mysql_query($qry);
			while($rows=mysql_fetch_array($result))
			{
				$Text_CalendarName = $rows['NAME'];
				$Text_PeriodYear = $rows['PERIOD_YEAR'];
				$PeriodType = $rows['PERIOD_TYPE'];
				$Text_CalendarName = str_replace($Text_PeriodYear,"",$Text_CalendarName);
				/*if(is_numeric($Text_PeriodYear))
				{
					$Text_PeriodYear=$Text_PeriodYear+1;
				}	*/		
				
				$date1 = $StartDate;
				if($PeriodType=='Weekly')
				{	
					$date2= date('Y-m-d', strtotime('6 day', strtotime($date1)));
				}
				else if($PeriodType=='Semi-Monthly')
				{
					$date2= date('Y-m-d', strtotime('14 day', strtotime($date1)));
				}
				else if($PeriodType=='Monthly')
				{
					$date2= date("Y/m/t", strtotime($date1)) ;
					$date2 = date("Y-m-d",strtotime($date2));			
				}
				$insArr = array();
				$insArr['NAME'] = $Text_CalendarName;
				$insArr['PERIOD_TYPE'] = $rows['PERIOD_TYPE'];
				$insArr['CREATED_BY']=$LoginUserId;
				$insArr['CREATION_DATE']='now()' ;
				$insArr['LAST_UPDATED_BY']=$LoginUserId;
				$insArr['FLAG_SYSTEMCREATED'] = 'Y';
				$insArr['SITE_ID'] = $SiteId;
				insertdata("cxs_calendars",$insArr);			
				$NewHeaderId = mysql_insert_id();
			}	
			
			$i=1;
			do
			{
				if($PeriodType=='Weekly')
				{
					$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1))."-W".week_number( $date1);
				}
				else if($PeriodType=='Semi-Monthly')
				{
					$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1))."-H".semiMonth_number( $date1);
				}
				else if($PeriodType=='Monthly')
				{
					$PeriodName = strtoupper(date("M",strtotime($date1)))."-".date("Y",strtotime($date1));
				}
				
				$insArr = array();
				
				$insArr['PERIOD_YEAR'] = $PeriodYear;
				$insArr['FROM_PERIOD_DATE'] = $date1;
				$insArr['TO_PERIOD_DATE'] = $date2;
				$insArr['PERIOD_NAME'] = $PeriodName;
				$insArr['STATUS'] = 'Never Opened';
				$insArr['FLAG_INUSE'] = ($Check_InUse==1)?"Y":"N";	
				$insArr['CALENDAR_ID']=$NewHeaderId;
				$insArr['LAST_UPDATED_BY']=$LoginUserId;
				
				$insArr['CREATED_BY']=$LoginUserId;
				$insArr['CREATION_DATE']='now()' ;
				$insArr['SITE_ID'] = $SiteId;				
				insertdata("cxs_periods",$insArr);	
				
				if($PeriodType=='Weekly')
				{
					$date1 = date('Y-m-d', strtotime('7 day', strtotime($date1)));
					$date2= date('Y-m-d', strtotime('6 day', strtotime($date1)));
				}
				else if($PeriodType=='Semi-Monthly')
				{
					if($i%2==1)
					{
						$date1 = date('Y-m-d', strtotime('15 day', strtotime($date1)));
						$date2= date("Y/m/t", strtotime($date1)) ;
						$date2 = date("Y-m-d",strtotime($date2));
					}
					else
					{
						$date1 = date('Y-m-d', strtotime('1 day', strtotime($date2)));
						$date2=date('Y-m-d', strtotime('14 day', strtotime($date1)));					
					}
				}
				else if($PeriodType=='Monthly')
				{
					$date1 = date('Y-m-d', strtotime('1 month', strtotime($date1)));
					$date2= date("Y/m/t", strtotime($date1)) ;
					$date2 = date("Y-m-d",strtotime($date2));
				}
				$i=$i+1;
				
			}while(strtotime($date2)<=strtotime($EndDate));
			
			$insArr = array();
			$insArr['NAME'] = $Text_CalendarName.$PeriodYear;
			$insArr['PERIOD_YEAR'] = $PeriodYear;		
			updatedata("cxs_calendars",$insArr,"Where cxs_calendars.CALENDAR_ID = $NewHeaderId");		
		}		
	}
	
	function CreateBlankRow($i,$Display_FirstDate)
	{
		//$StatusValue1 = "<option value=''> - Assing Status - </option><option value='Never Opened'> Never Opened </option><option value='Open'>Open</option><option value='In Use'>In Use</option><option value='Close'>Close</option><option value='Permanently Closed'>Permanently Closed</option>";
		$var1="span".$i."_4";
		$var2="span".$i."_5";
		$StatusValue = "<option value='Never Opened'> Never Opened </option>";
		$BlankRow = "<tr id = 'row$i'>
						<td class='check-bx'><input type='checkbox' id='CheckboxInline$i' name = 'CheckboxInline$i'  value='1' onchange='checkInline()' disabled>
						<input type='hidden' id = 'h_PeriodId$i' name = 'h_PeriodId$i' value = ''></td>	
						<td><input type='text' id='Text_StartDate$i' name='Text_StartDate$i' class='form-control small form_datetime'  onchange='SetYear($i,this);' value = '$Display_FirstDate' ></td>
						<td></td>
						<td><span id='$var1'></span></td>											
						<td><span id='$var2'></span><input type = 'hidden' id='Text_PeriodName$i' name='Text_PeriodName$i'></td>
						<td><select class='form-control' id = 'Combo_Status$i' name = 'Combo_Status$i' class='form-control' > $StatusValue </select></td>
						<td class='check-bx'><input type='checkbox' id='Check_InUse$i' name='Check_InUse$i' value='1' disabled></td>
						<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>
					</tr>";
		return $BlankRow;
	}

?>
<script type="text/javascript" >	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create Accounting Period";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
	function CheckDuplicate(name)
	{	
		if (name!='')
		{
			var s1="";
			var str="";
			var TableName = "cxs_calendars";
			var FieldName = "";
			var FieldValue = "";
			var FieldId = "CALENDAR_ID";
			var SelectedId = "<?php echo $HeaderId; ?>";	
			if(name=='Text_CalendarName')
			{
				KEY = "CheckDuplicate";
				FieldName = "NAME";
				FieldValue = document.getElementById('Text_CalendarName').value;									
			}
			else if(name=='Text_PeriodYear')
			{
				KEY = "CheckDuplicatePeriod";
				FieldName = "PERIOD_YEAR";
				FieldValue = document.getElementById('Text_PeriodYear').value;									
			}
			makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName=" + TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);
		}
	}	
	function is_weekstart(d) 
	{
		d = new Date(d);
		n= (d.getDay());		
		if(n!=1)
		{
			return false;
		}	
		return true;
	}	
	function is_weekend(d) 
	{
		d = new Date(d);
		n= (d.getDay());				
		if(n!=0)
		{
			return false;
		}	
		return true;
	}	
		
	function SetYear(CurrentRow,element)
	{	
		if(PeriodStartValidation(CurrentRow))
		{
			var PeriodYear = $("#Text_PeriodYear").val();
			document.getElementById("span"+CurrentRow+"_4").innerHTML =PeriodYear;										
		}
	}
	function PeriodStartValidation(CurrentRow)
	{
		var v1 = $('#Text_StartDate'+CurrentRow).val();		
		var PeriodType = $('#Combo_PeriodType').val();
		if(PeriodType=='')
		{
			alert("Please select period type.");
			$("#Combo_PeriodType").focus();
			return false;
		}
		
		if (v1!='')
		{
			if(PeriodType=='Weekly')	
			{
				if(is_weekstart(v1)==false)
				{
					alert("Start date must be Monday of the week.");
					DeleteRows();
					$('#Text_StartDate'+CurrentRow).focus();
					return false;
				}				
			}
			else 
			{
				v1 = new Date(v1);
				if(v1.getDate()!=1)
				{
					alert("Start date must be 1st of the period.");					
					$('#Text_StartDate'+CurrentRow).focus();
					return false;
				}
			}
			v1=$('#Text_StartDate'+CurrentRow).val();  // again convert into fixed format mm/dd/yyyy			
			GenerateRows(PeriodType,v1);
		}
	}
	function GenerateRows(PeriodType,StartDate)
	{
		KEY="GenerateRows";		
		//StartDate = new Date(StartDate);		
		//var newDate = Math.round(StartDate.getTime() / 1000);		
		//newDate = StartDate.toDateString();		
		openModal();
		makeRequest("ajax-validations.php","REQUEST=AccountingPeriodRows&PeriodType=" + PeriodType+"&StartDate="+StartDate);
		//makeRequest("ajax-validations.php","REQUEST=AccountingPeriodRows&PeriodType=" + PeriodType+"&StartDate="+newDate);
	}

	function chkfld_form1()
	{
		//PeriodStartValidation()			
		TABLE_ROW = $('#Table1 tr').length-1;
		$('#h_NumRows').val(TABLE_ROW);		
		var prev_status;
		var current_status,current_periodname,prev_periodname;
		var a = document.getElementById("Text_PeriodYear").value;
		//alert(a);
		if (a=='')
		{
			alert("Please select start date ");
			document.getElementById("Text_StartDate1").focus();
			return false;
		}
		for(i=1;i<=TABLE_ROW;i++)
		{
			startdate = $('#Text_StartDate'+i).val();
			enddate = $('#Text_EndDate'+i).val();
			/*if(CompareTwoDates(startdate,enddate)=="N")
			{
				alert("End date can not be less than Start Date. Please re-enter.");
				$('#Text_EndDate'+i).focus();
				return false;
			}
			if(DifferenceTwoDate(startdate,enddate) > 12)
			{
				 alert('Invalid Date Difference');
				 return false;
			}*/
			
			/*if((CurrentRowSDate>=startdate && CurrentRowSDate <= enddate) || (CurrentRowEDate>=startdate && CurrentRowEDate <= enddate))
			{
				alert ("Date Cannot be overlap");
				return false;
			}*/
			for (var j=1;j<=i;j++)
			{
				if(j!=i)
				{
					startdate=$('#Text_StartDate'+j+'').val();
					enddate = $('#Text_EndDate'+j+'').val();
					
					CurrentRowSDate = $('#Text_StartDate'+i+'').val();
					CurrentRowEDate = $('#Text_EndDate'+i+'').val();
					
					startdate = new Date(startdate);
					enddate = new Date(enddate);
					
					CurrentRowSDate = new Date(CurrentRowSDate);
					CurrentRowEDate = new Date(CurrentRowEDate);
					
					if((CurrentRowSDate>=startdate && CurrentRowSDate <= enddate) || (CurrentRowEDate>=startdate && CurrentRowEDate <= enddate))
					{
						alert ("Date Cannot be overlap. Please Check Period "+ $('#Text_PeriodName'+i).val() );
						return false;
					}
				}
			}
			
			current_status = $('#Combo_Status'+i).val();
			if (i!=1)
			{
				prev_periodname = $('#span'+(i-1)+'_5').text().trim();				
				if((current_status == 'Open' && prev_status == 'Never Opened')	||
				  (current_status == 'Close' && prev_status == 'Open') ||
				  (current_status == 'Permanently Closed' && prev_status == 'Close') )	
				{
					alert("Status should change in sequence. First set "+prev_periodname+'.');					
					document.getElementById("Combo_Status"+(i-1)).focus();
					return false;
				}
				
			}
			prev_status = $('#Combo_Status'+i).val();
		}
		
		openModal();
		KEY = "IsOverlap";
		HeaderId = "<?php echo $HeaderId; ?>";
		var formdata = $( "#Form1" ).serialize();		
		makeRequest("ajax-checkduplicate.php","REQUEST=AccountingPeriodOverlap&"+formdata+"&HeaderId="+HeaderId);			
		if(KEY=="IsOverlap")
		{
			return false;
		}
	}	
	function CheckAll()
	{
		TABLE_ROW = $('#Table1 tr').length-1;
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			if ( !$("#CheckboxInline"+i).is(':disabled') ) 
			{             
				//$("#G"+num).attr('checked', $("#all_"+num).is(':checked'));
				document.getElementById("CheckboxInline"+i).checked = checkboxValue;
			}	
		}
	}
	function EditRecord()
	{
		TABLE_ROW = $('#Table1 tr').length-1;
		document.getElementById("h_NumRows").value = TABLE_ROW;
		
		var flag_updaterecord="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
			/*document.getElementById("CheckboxInline"+i).checked=true;
			flag_updaterecord = "Y";*/
		}
		
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelected").innerHTML;
			if (ButtonCaption != "Save")
			{
				document.getElementById("cmdUpdateSelected").innerHTML = "Save";
				$('#Checkbox_SelectAll').hide();
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("CheckboxInline"+i).checked )
					{
						ShowInputElements(i);
					}
					else
					{
						$('#CheckboxInline'+i).hide();
					}
				}
				$('#cmdUpdateSelected').hide();
			}
			else
			{
				/*var flag_final="";	
				document.getElementById('h_field_update').value = 'Y';
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("CheckboxInline"+i).checked )
					{
						if(document.getElementById("Text_StartDate"+i).value == "")
						{
							alert("Pleae Select Start Date");
							document.getElementById("Text_StartDate"+i).focus();
							flag_final = "N";
							break;
						}
						else if(document.getElementById("Text_EndDate"+i).value == "")
						{
							alert("Pleae Select End Date");
							document.getElementById("Text_EndDate"+i).focus();
							flag_final = "N";
							break;
						}
					}
				}				
				if (flag_final=="")
				{	
					flag_final="Y";					
					if (flag_final == "Y")
					{
						Form1.submit();					
					}
				}	*/
			}
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("CheckboxInline1").focus();
		}
	}
	function ShowInputElements(CurrentRow)
	{
		if(CurrentRow==1 && $('#h_IsInuse').val()=="" )
		{
			$('#span1_2').hide();
			$('#Text_StartDate1').show();
		}
		//$('#span'+CurrentRow+"_3").hide();			
		if($('#span'+CurrentRow+"_6").text().trim() != 'Permanently Closed')
		{
			$('#span'+CurrentRow+"_6").hide();
			$('#Combo_Status'+CurrentRow).show();		
		}
	}
	function selectValue(ElementId,SelectedValue)
	{
		//$('#'+ElementId+')
		document.getElementById(ElementId).value=SelectedValue;
	}
	function IsDetailsDisable()
	{
		if ($('#Text_CalendarName').val()!=''  && $('#Combo_PeriodType').val()!='')
		{
			$("#Text_StartDate1").prop("disabled", false);
		}
		else
		{
			$("#Text_StartDate1").prop("disabled", true);			
		}
	}
	function AddBlankRow()
	{
		NewRow =1;
		cell1="<td class='check-bx'><input type='checkbox' id='CheckboxInline"+NewRow+"' name = 'CheckboxInline"+NewRow+"'  value='1' onchange='checkInline()' disabled>"+
		"<input type='hidden' id = 'h_PeriodId"+NewRow+"' name = 'h_PeriodId"+NewRow+"' value = ''></td>";	
		cell2="<td><input type='text' id='Text_StartDate"+NewRow+"' name='Text_StartDate"+NewRow+"' class='form-control small form_datetime'  onchange='SetYear("+NewRow+",this);' value = '<?php echo $Display_FirstDate; ?>'></td>";	
		cell3="<td></td>";	
		cell4="<td><span id='span"+NewRow+"_4'></span></td>";	
		cell5="<td><span id='span"+NewRow+"_5'></span><input type = 'hidden' id='Text_PeriodName"+NewRow+"' name='Text_PeriodName"+NewRow+"'></td>";
		cell6="<td><select class='form-control' id = 'Combo_Status"+NewRow+"' name = 'Combo_Status"+NewRow+"' class='form-control'> <?php echo $StatusValue; ?> </select></td>";
		cell7="<td class = 'check-bx'><input type='checkbox' id='Check_InUse"+NewRow+"' name='Check_InUse"+NewRow+"' value='1' disabled></td>";
		var EyeIcon="<td class = 'check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";
		if($('#h_IsInuse').val()=="")
		{
			$('#Table1').find('tbody').remove();
			$('#Table1').append('<tr id = "row'+NewRow+'">'+cell1+cell2+cell3+cell4+cell5+cell6+cell7+EyeIcon+'</tr>');		
			IsDetailsDisable();
			$('#pageList').empty();
		}
	}
	function DeleteRows() 
	{
        var rowCount = Table1.rows.length;
        for (var i = rowCount - 1; i > 1; i--) 
		{
            Table1.deleteRow(i);
        }
    }
	function checkInline()
	{
		TABLE_ROW = $('#Table1 tr').length-1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<!--
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
-->
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">

<link href="../datepicker/datepicker.css" rel="stylesheet">

<script src="../js/loader-function.js"></script>
<script src="../js/jsfunctions.js"></script>
<!--width: 1280px;-->
<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.myAdjustClass
	{
		text-align: right;
		padding-right:0px;
	}
	@media (min-width: 992px) 
	{
		.modal-lg
		{	
			width: 95%
			
		}
	}
	@media only screen
and (min-device-width : 320px)
and (max-device-width : 480px) 
{
	.myAdjustClass
		{
			text-align: left;
			padding-left:0px;
		}
}
</style>

</head>

<body>
<?php include("header.php"); ?>

<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="accounting-periods.php"> Accounting Periods </a></li>
          <li> <a href="#"><?php echo $s_caption; ?> Accounting Period</a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
	
		<div class="cont-box">
		<form class="form" id="Form1" name="Form1" action="" method="POST" onsubmit = "return chkfld_form1()">	<!--   -->
			<div class="pge-hd">
			  <h2 class="sec-title"  > 
			  <label id="Label_Title"><?php echo $s_caption; ?> Accounting Period</label>   			  
			  </h2>
			  
			</div>					
			<div class="upp-form row"> 
				<div class="cus-form-cont">
					<div class="col-sm-3 form-group">
					  <label> Calendar Name </label>
					  <input id = "Text_CalendarName" name = "Text_CalendarName" type="text" class="form-control requirefieldcls"  onblur = "CheckDuplicate(this.id)" value = "<?php echo $Display_CalendarName; ?>" maxlength="40" required onchange = "IsDetailsDisable()">
					  <span id = "Span_CalendarName"></span>
					</div>
					
					<div class="col-sm-3 form-group">
					  <label> Description </label>
					  <input id = "Text_Description" name = "Text_Description" type="text" class="form-control " value = "<?php echo $Display_Description; ?>"  maxlength="100">								
					</div>
					
					<div class="col-sm-3 form-group">
					  <label> Period Year </label>
					  <input id = "Text_PeriodYear" name = "Text_PeriodYear" type="text" class="form-control requirefieldcls" required value = "<?php echo $Display_PeriodYear; ?>"  readonly    >
					  <input id = "h_PeriodYear" name = "h_PeriodYear" type="hidden" value = "<?php echo $Display_PeriodYear; ?>" >
					  <span id = "Span_PeriodYear"></span>
					</div>
									
					<div class="col-sm-3 form-group">
					  <label> Period Type </label>
					  <select id = "Combo_PeriodType" name = "Combo_PeriodType" class="form-control requirefieldcls" required maxlength="20" onchange = "AddBlankRow()">
							<option value=""> - Period Type - </option>
							<option value="Weekly" <?php echo ($Display_PeriodType=='Weekly')?'selected':''; ?>>Weekly</option>									  
							<option value="Semi-Monthly" <?php echo ($Display_PeriodType=='Semi-Monthly')?'selected':''; ?>>Semi-Monthly</option>
							<option value="Monthly" <?php echo ($Display_PeriodType=='Monthly')?'selected':''; ?>>Monthly</option>
					  </select>
					</div>
						
					<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>
					<div class="col-sm-12 form-group "  >
						<div class = "col-sm-4 fleft two " style = "padding-left:0px;">
							<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_accounting_PERMISSION=='Y'){ ?> id = "cmdUpdateSelected" name = "cmdUpdateSelected" onclick= 'EditRecord();' <?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>				
						</div>
						<div class = "col-sm-4 check-bx " style = "padding-top:15px;">
							<span style = "color:red" id = "spanMsg"> <?php echo $msg; ?> </span>
						</div>
						<div class="col-sm-4 myAdjustClass cr-user" >				   
							<button <?php if($CREATE_PRIV_accounting_PERMISSION=='Y'){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style"> Save Record </button>
							
						</div>
					</div>
				</div>	
				<div class="check-bx"  style = "  text-align:center;  width:100%;">
					<div id="fade">
					</div>
					<div id="modal" >
						<img id="loader" src="../img/loading.gif" style="top:15px;left:15px;" />
					</div>	
				</div>	
				<div class="data-bx col-sm-12">
					<div class="table-responsive">
						<table class="table table-bordered mar-cont" id = "Table1">
							<thead>
								<tr>
									<th data-orderable="false" width="5%" class="check-bx"><input type="checkbox"  id="Checkbox_SelectAll" value="1" onchange="CheckAll()"></th>									
									<th width="10%"> Start Date </th>
									<th width="10%"> End Date </th>
									<th width="10%"> Year </th>
									<th width="20%"> Period Name </th>
									<th width="15%"> Status </th>
									<th width="5%" class="check-bx"> In Use </th>
									<th data-orderable="false" width="5%"> </th>
								</tr>
							</thead>
							<tbody>
								<?php									
									if($HeaderId=='')
									{
										$i=1;
										echo CreateBlankRow($i,$Display_FirstDate);										
									}
									else
									{
										$CloseCounter=0;										
										$PermanentCloseCounter=0;	
										$selectQuery = "SELECT * from cxs_periods where cxs_periods.CALENDAR_ID = $HeaderId";
										$result=mysql_query($selectQuery);
										$TotalRecords=mysql_num_rows($result);
										while($rows=mysql_fetch_array($result))
										{
											if($rows['STATUS']=='Close')
											{
												$CloseCounter++;
											}
											else if($rows['STATUS']=='Permanently Closed')
											{
												$PermanentCloseCounter++;
											}
										}
										
										if($PermanentCloseCounter==$TotalRecords)
										{
											echo "<script>";
												//echo "document.getElementById('cmdSaveRecord').disabled = true; ";
												echo "document.getElementById('cmdSaveRecord').style.display = 'none'; ";
												echo "document.getElementById('cmdUpdateSelected').style.display = 'none'; ";
											echo "</script>";
										}
										$i=1;
										$selectQuery = "SELECT cxs_periods.*,cxs_users.USER_NAME as CreatedByName,(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_periods.LAST_UPDATED_BY)  as UpdatedByName  from cxs_periods
										INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_periods.CREATED_BY where cxs_periods.CALENDAR_ID = $HeaderId order by cxs_periods.PERIOD_ID";	
										
										//$selectQueryForPages  = $selectQuery;
										//$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
										$result = mysql_query($selectQuery);
										while($rows = mysql_fetch_array($result))
										{	
											$Display_StartDate ='';
											$Display_EndDate = '';
											if((!is_null($rows['FROM_PERIOD_DATE'])) && (($rows['FROM_PERIOD_DATE'])!='0000-00-00') )
											{			
												$Display_StartDate = date('m/d/Y', strtotime($rows['FROM_PERIOD_DATE']));
											}
											if((!is_null($rows['TO_PERIOD_DATE'])) && (($rows['TO_PERIOD_DATE'])!='0000-00-00'))
											{			
												$Display_EndDate = date('m/d/Y', strtotime($rows['TO_PERIOD_DATE']));	
											}
											$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));
											$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));
											 
											if($rows['STATUS']=='Never Opened')	
											{
												$StatusValue1 = "<option value='Never Opened'> Never Opened </option><option value='Open'>Open</option>";
											}
											else if($rows['STATUS']=='Open')	
											{
												$StatusValue1 = "<option value='Open'>Open</option><option value='Close'>Close</option>";
											}
											else if($rows['STATUS']=='Close')	
											{
												if(($CloseCounter+$PermanentCloseCounter)==$TotalRecords)
												{
													$StatusValue1 = "<option value='Close'>Close</option><option value='Permanently Closed'>Permanently Closed</option>";
												}
												else
												{
													$StatusValue1 = "<option value='Close'>Close</option>";
												}
											}
											else if($rows['STATUS']=='Permanently Closed')	
											{
												$StatusValue1 = "<option value='Permanently Closed'>Permanently Closed</option>";
											}
											?>
											<tr id = '<?php echo "row$i";?>'>
												<td class="check-bx ">
													<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
													<input type="hidden" id = <?php echo "h_PeriodId$i"; ?> name = <?php echo "h_PeriodId$i"; ?> value = "<?php echo $rows['PERIOD_ID']; ?>">
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_2"; ?>"> <?php echo $Display_StartDate; ?> </span>
													<?php if($i==1) { ?>
														<input type="text" id="<?php echo "Text_StartDate$i"; ?>" name="<?php echo "Text_StartDate$i"; ?>" class="form-control small form_datetime"  value = "<?php echo $Display_StartDate; ?>"  onchange='SetYear(<?php echo $i?>,this);' style = " display:none" >														
													<?php 	}
														  	else{ ?>
														<input type="hidden" id = "<?php echo "Text_StartDate$i"; ?>" name = "<?php echo "Text_StartDate$i"; ?>" value = "<?php echo $Display_StartDate; ?>">		
													<?php	}
													?>
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $Display_EndDate; ?> </span>
													<input type="hidden" id = "<?php echo "Text_EndDate$i"; ?>" name = "<?php echo "Text_EndDate$i"; ?>" value = "<?php echo $Display_EndDate; ?>">
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_4"; ?>"> <?php echo $rows['PERIOD_YEAR']; ?> </span>													
												</td>	
												
												<td> 
													<span id = "<?php echo "span".$i."_5"; ?>"> <?php echo $rows['PERIOD_NAME']; ?> </span>
													<input type = "hidden" id="<?php echo "Text_PeriodName$i"; ?>" name="<?php echo "Text_PeriodName$i"; ?>" value ="<?php echo $rows['PERIOD_NAME']; ?>" > <!--  onblur = "CheckDuplicate(this.id)" -->
												</td>												
												<td> 
													<span id = "<?php echo "span".$i."_6"; ?>"> <?php echo $rows['STATUS']; ?> </span>												
													<select class="form-control" id="<?php echo "Combo_Status$i"; ?>"  name="<?php echo "Combo_Status$i"; ?>" style = "display:none" >
														<?php echo $StatusValue1; ?>	
													</select>
													<script> selectValue('<?php echo"Combo_Status$i";?>','<?php echo$rows['STATUS'];?>') </script>
												</td>
												
												<td class="check-bx ">
													<input type="checkbox" id="<?php echo "Check_InUse$i"; ?>" name="<?php echo "Check_InUse$i"; ?>" value="1" <?php echo($rows['FLAG_INUSE'] == "Y")?"checked":""; ?>  disabled>		
												</td>
												
												<td class="check-bx">
													<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
													Created By: <?php echo $rows['CreatedByName']; ?> <br> Updated By: <?php echo $rows['UpdatedByName']; ?> 
													<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
												</td>
											</tr>
								<?php		$i=$i+1;
										}
										
										
											//echo CreateBlankRow($i);											
									}
								?>
							</tbody>
						</table>						
					</div>	
				</div>	
			
				
		<!--	<div class="col-sm-12 form-group text-right cr-user">
					<button type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord" class="btn btn-primary btn-style"> Save Record </button>
				</div>
		-->
				<!-- pagination start-->
			
				<!-- pagination end -->
			</div>	
			<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>	
			<input type="hidden" id="h_field_update" name="h_field_update" value="">
			<input type="hidden" id="h_IsInuse" name="h_IsInuse" value="">
		</form>			
		</div>			
    </div>
  </div>
  	
</section>
	
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script src="../js/jquery.validate.js"></script>
 
<!--<script src="../datepicker/jquery.js"></script>-->
<script src="../datepicker/bootstrap-datepicker.js"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		closeModal();
		TABLE_ROW = $('#Table1 tr').length-1;	// remove header row	
		var flag_InUse="";
		
		for(var i=1;i<=TABLE_ROW;i++)
		{
			if($('#Check_InUse'+i).prop("checked")==true)
			{
				flag_InUse="Y";
				break;
			}
		}
		
		if(flag_InUse=="Y")
		{
			$('#Combo_PeriodType').prop("disabled", true);			
			$('#h_IsInuse').val(flag_InUse);
		}
		
		//'aoColumnDefs': [{'bSortable': false,'aTargets': [0,-1] }],
		/*$('#Table1').DataTable( 
		{
			'searching': false,
			'order': [[ 1, "asc" ]],			
			 'lengthMenu': [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
			 "bSort" :false,// false all columns sorting off
			 "bInfo" : true //to hide "Showing 1 to 5 of 14 entries" label
		} );*/
		
		
		$('.form_datetime').datepicker(
		{
			format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
		});	
		
		/*HeaderId = "<?php echo $HeaderId; ?>";
		if(HeaderId!='')
		{
			for(var i=1;i<=TABLE_ROW;i++)
			{
				document.getElementById("CheckboxInline"+i).checked=true;
			}
		}*/
	});
	
	/*$('#Form1').submit(function (evt) 
	{
		//alert("submit");
		
		//evt.preventDefault();
		
		//window.history.back();
	});*/
	
	var datePickerOptions = {
    format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
	}
	
	$(document).on('focus',".form_datetime", function()
	{
		$(this).datepicker(datePickerOptions);
	});
	
	function makeRequest(url,data)
	{
		var http_request = false;
		if (window.XMLHttpRequest) { // Mozilla, Safari, ...
			http_request = new XMLHttpRequest();
			if (http_request.overrideMimeType) {
				http_request.overrideMimeType('text/xml');
				// See note below about this line
			}
		} else if (window.ActiveXObject) { // IE
			try {
				http_request = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					http_request = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}

		if (!http_request) {
			alert('Giving up :( Cannot create an XMLHTTP instance');
			return false;
		}
		http_request.onreadystatechange = function() { alertContents(http_request); };
		http_request.open('POST', url, true);
		http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;						
					//alert(str);
					window.open('downloaddata.php?r=holiday-calendars', '_blank');
				}
				else if(KEY == "ExportRecordCont")
				{
					var str = http_request.responseText;	
					
					//alert(str);
					window.open('downloaddata.php?r=new-resource-contacts', '_blank');					
					//window.location.href = "downloaddata.php?r=user-administration","target='_blank'";					
				}
				else if(KEY == 'CheckDuplicate')
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)
					{ 
						document.getElementById("Span_CalendarName").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Text_CalendarName").focus();
					}
					else
					{
						document.getElementById("h_duplicate").value = "";	
						document.getElementById("Span_CalendarName").innerHTML = "";
					}
				}
				else if(KEY == 'CheckDuplicatePeriod')
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();
					if(s1.length > 1)   
					{
						document.getElementById("Span_PeriodYear").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Text_PeriodYear").focus();
					}
					else
					{
						document.getElementById("h_duplicate").value = "";
						document.getElementById("Span_PeriodYear").innerHTML = "";
					}  
				}
				else if (KEY=="GenerateRows")	
				{
					//var JSONObject = JSON.parse(http_request.responseText); 	
					$('#Table1').find('tbody').remove();
					$('#Table1').append(http_request.responseText.trim());
					
					TABLE_ROW = $('#Table1 tr').length-1;
					
					var year1 = $('#span1_4').text().trim();
					var year2 = $('#span'+TABLE_ROW+'_4').text().trim();
					
					
					if (year1==year2)
					{
						$('#Text_PeriodYear').val(year1);
						$('#h_PeriodYear').val(year1);						
					}
					else
					{
						$('#Text_PeriodYear').val(year1+"-"+year2);
						$('#h_PeriodYear').val(year1+"-"+year2);						
						for(var i=1;i<=TABLE_ROW;i++)
						{
							$('#span'+i+'_4').text(year1+"-"+year2);
						}
					}
					
					closeModal();
					//alert(http_request.responseText);					
				}
				else if (KEY == 'IsOverlap')
				{
					s1 = http_request.responseText.trim();
					//alert(s1);					
					if (s1=="No")
					{
						for(i=1;i<=TABLE_ROW;i++)
						{
							$("#Check_InUse"+i).prop("disabled", false);
						}
						Form1.submit();//evt.preventDefault();
					}
					else
					{
						if(s1=="Calendar or Period")
						{
							alert("Calendar Name / Period Year are not allowed duplicate.");
						}
						else
						{
							alert("Date Cannot be overlap. Please Check Period.");
							//$('#Text_StartDate1').focus();
							document.getElementById('Text_StartDate1').focus();
						}
					}
					closeModal();
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}

/*	(function () 
	{
		var previous;
		$("select[name=Combo_Status]").focus(function () 
		{
			// Store the current value on focus, before it changes
			previous = this.value;
		}).change(function() 
		{
			// Do soomething with the previous value after the change			
			//alert(previous);
			if(previous=='Never Opened')
			{
				if(this.value!='Open')
				{
					alert("Set status as Open");
					//this.value='Open';
					$('#'+this.id).val('Open');
				}
			}
			previous = this.value;
		});
	})();*/
	</script>

</body>
</html>