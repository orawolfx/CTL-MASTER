<?php ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php 
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_holiday_PERMISSION = "Y";
		$UPDATE_PRIV_holiday_PERMISSION = "Y";		
	}
	else
	{
		$CREATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
		$UPDATE_PRIV_holiday_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Holiday Calenders',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_holiday_PERMISSION=='N' && $UPDATE_PRIV_holiday_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "create-new-holiday-calendar.php";	
	$SiteId = $_SESSION['user-siteid'];
	
	$DisplayPayPeriodValues = "";
	$query = "select CALENDAR_ID,PERIOD_YEAR from cxs_calendars where PERIOD_YEAR<>'' and SITE_ID = $SiteId order by PERIOD_YEAR ";
	$result = mysql_query($query);
	$DisplayPayPeriodValues .= "<option value=''>- Pay Period Year -</option>";
	while ($row = mysql_fetch_array($result))
	{
		$PeriodName = $row['PERIOD_YEAR'];
		$PeriodId = $row['CALENDAR_ID'];
		$DisplayPayPeriodValues .= "<option value='$PeriodName'> $PeriodName </option>";
	}	
	
	$insArr = array();
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];
	//	DisplayRecord($HeaderId);	
	}
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "HOLIDAY_CALENDAR_ID";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	
	if ($Sorts == 'asc')
	{
   	 $OrderBY = " desc";
   	 $FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";	

	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}	
	$start_from = ($page-1) *  $RecordsPerPage;
	
	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	
	//if (isset($_POST['cmdSaveRecord'] ))
	if($_POST['Text_CalendarName'] != '')  
	{		

		$msg1="";
		$msg2="";
		$Text_CalendarName = isset($_POST["Text_CalendarName"] )? $_POST["Text_CalendarName"]: false;
		$Combo_PayPeriod = isset($_POST["Combo_PayPeriod"] )? $_POST["Combo_PayPeriod"]: false;		
		if($HeaderId!='')
		{
			$Query = "SELECT * FROM cxs_holidays WHERE (CALENDAR_NAME ='$Text_CalendarName' or PERIOD_YEAR = '$Combo_PayPeriod') and HOLIDAY_CALENDAR_ID <> $HeaderId and SITE_ID = $SiteId";				
		}
		else
		{
			$Query = "SELECT * FROM cxs_holidays WHERE (CALENDAR_NAME ='$Text_CalendarName' or PERIOD_YEAR = '$Combo_PayPeriod') and SITE_ID = $SiteId ";				
		}
		$Result = mysql_query($Query);		
		while($row = mysql_fetch_array($Result))
		{
			if($Text_CalendarName==$row['CALENDAR_NAME'])
			{
				$msg1= "Do not allow duplicate entry.";
			}
			if($Combo_PayPeriod==$row['PERIOD_YEAR'])
			{
				$msg2= "Do not allow duplicate entry.";
			}
			$Display_CalendarName = $row['CALENDAR_NAME'];
			$Display_PeriodYear = $row['PERIOD_YEAR'];
		}
		if($msg1=="" && $msg2=="")
		{
			$insArr['CALENDAR_NAME'] = $Text_CalendarName;						
			$insArr['PERIOD_YEAR'] = $Combo_PayPeriod;
			$insArr['LAST_UPDATED_BY']=$LoginUserId;
			$insArr['SITE_ID']=$SiteId;
			
			if($HeaderId=='')
			{
				$insArr['CREATED_BY']=$LoginUserId;
				$insArr['CREATION_DATE']='now()' ;	
				insertdata("cxs_holidays",$insArr);			
				$HeaderId = mysql_insert_id();
			}
			else
			{
				if ($IsUpdate =='')
				{
					updatedata("cxs_holidays",$insArr,"Where cxs_holidays.HOLIDAY_CALENDAR_ID = $HeaderId");			
				}
			}
			if($HeaderId!='')
			{
				//$Text_PeriodYear = isset($_POST["Text_PeriodYear"] )? $_POST["Text_PeriodYear"]: false;
				for($i=1;$i<=$TotalRows;$i++)
				{
					$hCalendarId = isset( $_POST['h_CalendarId'.$i] )? $_POST['h_CalendarId'.$i]: false;
					$Check_Record = isset( $_POST['CheckboxInline'.$i] )? $_POST['CheckboxInline'.$i]: false;
					
					$Text_HolidayName = isset($_POST["Text_HolidayName$i"] )? $_POST["Text_HolidayName$i"]: false;
					$Text_Description = isset($_POST["Text_Description$i"] )? $_POST["Text_Description$i"]: false;
					$Text_StartDate = isset($_POST["Text_StartDate$i"] )? $_POST["Text_StartDate$i"]: false;
					$Text_EndDate = isset($_POST["Text_EndDate$i"] )? $_POST["Text_EndDate$i"]: false;
					$Check_Enforce = isset($_POST["Check_Enforce$i"] )? $_POST["Check_Enforce$i"]: false;
					$Check_Recess = isset($_POST["Check_Recess$i"] )? $_POST["Check_Recess$i"]: false;
					$Check_Enabled = isset($_POST["Check_Enabled$i"] )? $_POST["Check_Enabled$i"]: false;
				//	$Check_ActiveFlag = isset($_POST["Check_ActiveFlag$i"] )? $_POST["Check_ActiveFlag$i"]: false;
				//	$Check_InUse = isset($_POST["Check_InUse$i"] )? $_POST["Check_InUse$i"]: false;
					
					if($Text_StartDate!='' && $Text_EndDate!= '')
					{
						$Text_StartDate = date("Y/m/d", strtotime($Text_StartDate));
						$Text_EndDate = date("Y/m/d", strtotime($Text_EndDate));
						
						unset($inArr1); 
						$insArr1['HOLIDAY_TAG_NAME'] = $Text_HolidayName;
						$insArr1['DESCRIPTION'] = $Text_Description;
						$insArr1['HOLIDAY_START_DATE'] = $Text_StartDate;
						$insArr1['HOLIDAY_END_DATE'] = $Text_EndDate;
						$insArr1['ENFORCE_FLAG'] = ($Check_Enforce==1)?"Y":"N";
						$insArr1['RECESS_ALLOWED'] = ($Check_Recess==1)?"Y":"N";
						$insArr1['ENABLED_FLAG'] = ($Check_Enabled==1)?"Y":"N";
					//	$insArr['ACTIVE_FLAG'] = ($Check_ActiveFlag==1)?"Y":"N";
					//	$insArr1['INUSE_FLAG'] = ($Check_InUse==1)?"Y":"N";
						
						$insArr1['LAST_UPDATED_BY']=$LoginUserId;
						$insArr1['HOLIDAY_CALENDAR_ID']=$HeaderId;
						$insArr1['SITE_ID']=$SiteId;
						if($hCalendarId=='')
						{
							$insArr1['CREATED_BY']=$LoginUserId;
							$insArr1['CREATION_DATE']='now()' ;				
							insertdata("cxs_holiday_calendar",$insArr1);		
						}
						else
						{
							if($Check_Record==1)
							{
								updatedata("cxs_holiday_calendar",$insArr1,"where cxs_holiday_calendar.CALENDAR_ID = $hCalendarId");		
							}
						}
					}
				}
			}
		}
		//header("Location:create-new-holiday-calendar.php?hid=$HeaderId");
		header("Location:holiday-calendar.php");
	}	
	if ($HeaderId != '')
	{
		/*$qry = "SELECT cxs_calendars.NAME as CalendarName,cxs_calendars.DESCR,cxs_calendars.PERIOD_TYPE,cxs_periods.*,cxs_users.USER_NAME as CreatedByName,
		(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_periods.LAST_UPDATED_BY)  as UpdatedByName  from cxs_calendars inner join cxs_periods on cxs_periods.CALENDAR_ID = cxs_calendars.CALENDAR_ID INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_periods.CREATED_BY where cxs_calendars.CALENDAR_ID = $HeaderId";		*/
		$qry = "SELECT cxs_holidays.*  from cxs_holidays where cxs_holidays.HOLIDAY_CALENDAR_ID = $HeaderId";		
		$result = mysql_query($qry);		
		while($row=mysql_fetch_array($result))
		{
			$Display_CalendarName = $row['CALENDAR_NAME'];			
			$Display_PeriodYear = $row['PERIOD_YEAR'];
		}
	}
	
	function CreateBlankRow($i)
	{
		//$StatusValue1 = "<option value=''> - Assing Status - </option><option value='Never Opened'> Never Opened </option><option value='Open'>Open</option><option value='In Use'>In Use</option><option value='Close'>Close</option><option value='Permanently Closed'>Permanently Closed</option>";
		$StatusValue = "<option value='Never Opened'> Never Opened </option>";
		$BlankRow = "<tr id = 'row$i'>
						<td class='check-bx'><input type='checkbox' id='CheckboxInline$i' name = 'CheckboxInline$i'  value='1' onchange='checkInline()' disabled>
						<input type='hidden' id = 'h_CalendarId$i' name = 'h_CalendarId$i' value = '' ></td>	
						<td><input type = 'text' class='form-control' id='Text_HolidayName$i' name='Text_HolidayName$i' onchange = 'AddNewRow(2);'></td>
						<td><input type = 'text' class='form-control' id='Text_Description$i' name='Text_Description$i'></td>
						<td><input type='text' id='Text_StartDate$i' name='Text_StartDate$i' class='form-control small form_datetime'  onchange='SetYear($i,this);'></td>
						<td><input type='text' id='Text_EndDate$i' name='Text_EndDate$i' class='form-control small form_datetime'  onchange='SetYear($i,this);'></td>
						<td class='check-bx'><input type='checkbox' id='Check_Enforce$i' name='Check_Enforce$i' value='1'></td>
						<td class='check-bx'><input type='checkbox' class = 'recess' id='Check_Recess$i' name='Check_Recess$i' value='1'></td>
						<td class='check-bx'><input type='checkbox' id='Check_Enabled$i' name='Check_Enabled$i' value='1'></td>
						<td class='check-bx'><input type='checkbox' class = 'SystemClass' id='Check_InUse$i' name='Check_InUse$i' value='1'></td>
						<td class='check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>
					</tr>";
		return $BlankRow;
	}	
?>
<script type="text/javascript" >	
	var CURRENTROW="";
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create Holiday Calender";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
		 
	function SetYear(CurrentRow,element)
	{	
		var PeriodYear = $("#Text_PeriodYear").val();		
		//$(element).off("focus").datepicker("hide");
		var NewRow = CurrentRow+1;
		AddNewRow(NewRow);		
	}	
	function AddNewRow(NewRow)
	{
		var startdate='',enddate='';
		startdate = $('#Text_StartDate'+(NewRow-1)+'').val();
		enddate = $('#Text_EndDate'+(NewRow-1)+'').val();		
		if(startdate != '' && enddate != '' )		
		{
			if(CompareTwoDates(startdate,enddate)=="N")
			{
				alert("End date can not be less than Start Date. Please re-enter.");
				return false;
			}
			if($('#Text_HolidayName'+(NewRow-1)).val()=='')
			{
				$('Text_HolidayName'+(NewRow-1)).focus();
				alert("Holiday name required.");
				return false;
			}
			CURRENTROW=NewRow-1;
			KEY = "ValidateDates";				
			PeriodYear = $('#Combo_PayPeriod').val();
			makeRequest("ajax-validations.php","REQUEST=HolidayDatePeriod&date1="+startdate+"&date2="+enddate+"&PeriodYear="+ PeriodYear);			
		/*	if( TABLE_ROW == NewRow-1)
			{
				cell1="<td class='check-bx'><input type='checkbox' id='CheckboxInline"+NewRow+"' name = 'CheckboxInline"+NewRow+"'  value='1' onchange='checkInline()' disabled>"+
				"<input type='hidden' id = 'h_CalendarId"+NewRow+"' name = 'h_CalendarId"+NewRow+"' value = ''></td>";	
				cell2="<td><input type = 'text' class='form-control' id='Text_HolidayName"+NewRow+"' name='Text_HolidayName"+NewRow+"'></td>";	
				cell3="<td><input type = 'text' class='form-control' id='Text_Description"+NewRow+"' name='Text_Description"+NewRow+"'></td>";				
				cell4="<td><input type='text' id='Text_StartDate"+NewRow+"' name='Text_StartDate"+NewRow+"' class='form-control small form_datetime'  onchange='SetYear("+NewRow+",this);'></td>";	
				cell5="<td><input type='text' id='Text_EndDate"+NewRow+"' name='Text_EndDate"+NewRow+"' class='form-control small form_datetime'  onchange='SetYear("+NewRow+",this);'></td>";				
				cell6="<td class = 'check-bx'><input type='checkbox' id='Check_Enforce"+NewRow+"' name='Check_Enforce"+NewRow+"' value='1'></td>";
				cell7="<td class = 'check-bx'><input type='checkbox' id='Check_Recess"+NewRow+"' name='Check_Recess"+NewRow+"' value='1'></td>";
				cell8="<td class = 'check-bx'><input type='checkbox' id='Check_Enabled"+NewRow+"' name='Check_Enabled"+NewRow+"' value='1'></td>";
				cell9="<td class = 'check-bx'><input type='checkbox' id='Check_InUse"+NewRow+"' name='Check_InUse"+NewRow+"' value='1'></td>";
				var EyeIcon="<td class = 'check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";
				$('#Table1').append('<tr id = "row'+NewRow+'">'+cell1+cell2+cell3+cell4+cell5+cell6+cell7+cell8+cell9+EyeIcon+'</tr>');		
			}*/
		}
	} 

	function chkfld_form1()
	{
		TABLE_ROW = $('#Table1 tr').length-1;
		if (TABLE_ROW==1 && $('#Text_StartDate1').val()=="" && $('#Text_EndDate1').val()=="" )
		{
			alert("Please add holiday list.");			
			$('#Text_StartDate1').focus();
			return false;
		}
		$('#h_NumRows').val(TABLE_ROW);		
		var PeriodYear = $('#Combo_PayPeriod').val();
		var IsRecessAllowed='';
		
		var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
		//var a = new Date('08/11/2015');
		//alert(weekday[a.getDay()]);
		
		for(i=1;i<TABLE_ROW;i++)
		{
			startdate = $('#Text_StartDate'+i).val();
			enddate = $('#Text_EndDate'+i).val();
			var IsRecessAllowed = "";			
			if(CompareTwoDates(startdate,enddate)=="N")
			{
				alert("End date can not be less than Start Date. Please re-enter.");
				$('#Text_EndDate'+i).focus();
				return false;
			}
			if($('#Check_Recess'+i).prop("checked")==true && (startdate!='' && enddate!=''))
			{
				if(IsRecessAllowed=="N")
				{
					alert("Recess Allowed is not accepted for holiday name <" + $('#Text_HolidayName'+i).val()+">.");
					return false;
				}
			}
			
		/*	if($('#Check_Recess'+i).prop("checked")==true  && 	$('#Check_Enforce'+i).prop("checked")==true)
			{
				alert("Enforce and Recess Allowed both are not check for "+ $('#Text_HolidayName'+i).val()+".");
				return false;
			}*/
		}		
		KEY = "AllHolidayPeriods";		
		var formdata = $( "#Form1" ).serialize();				
		makeRequest("ajax-validations.php","REQUEST=AllHolidayPeriods&"+formdata);			
		if(KEY=="AllHolidayPeriods")
		{
			return false;
		}
		
	}
	function CheckAll()
	{
		TABLE_ROW = $('#Table1 tr').length-1;		
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<TABLE_ROW;i++)
		{	
			if ( !$("#CheckboxInline"+i).is(':disabled') ) 
			{   
				document.getElementById("CheckboxInline"+i).checked = checkboxValue;
			}
		}
	}
	function checkInline()
	{
		TABLE_ROW = $('#Table1 tr').length-1;	
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	function EditRecord()
	{
		TABLE_ROW = $('#Table1 tr').length-1;
		document.getElementById("h_NumRows").value = TABLE_ROW;
		
		var flag_updaterecord="";
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelected").innerHTML;
			if (ButtonCaption != "Save")
			{
				document.getElementById("cmdUpdateSelected").innerHTML = "Save";
				
				$('#Checkbox_SelectAll').hide();
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("CheckboxInline"+i).checked)						
					{
						if ($('#Check_InUse'+i).prop("checked")==false)
						{
							ShowInputElements(i);
						}
					}
					else
					{
						$('#CheckboxInline'+i).hide();
					}
				}
				$('#cmdUpdateSelected').hide();
			}
			else
			{
				/*var flag_final="";	
				document.getElementById('h_field_update').value = 'Y';
				for(i=1;i<=TABLE_ROW;i++)
				{
					if (document.getElementById("CheckboxInline"+i).checked)
					{
						if(document.getElementById("Text_StartDate"+i).value == "")
						{
							alert("Pleae Select Start Date");
							document.getElementById("Text_StartDate"+i).focus();
							flag_final = "N";
							break;
						}
						else if(document.getElementById("Text_EndDate"+i).value == "")
						{
							alert("Pleae Select End Date");
							document.getElementById("Text_EndDate"+i).focus();
							flag_final = "N";
							break;
						}					
					}
				}				
				if (flag_final=="")
				{	
					flag_final="Y";					
					if (flag_final == "Y")
					{
						Form1.submit();					
					}
				}	*/
			}
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("CheckboxInline1").focus();
		}
	}
	function ShowInputElements(CurrentRow)
	{
		$('#span'+CurrentRow+"_2").hide();
		$('#Text_HolidayName'+CurrentRow).show();
		
		$('#span'+CurrentRow+"_3").hide();
		$('#Text_Description'+CurrentRow).show();
		
		$('#span'+CurrentRow+"_4").hide();
		$('#Text_StartDate'+CurrentRow).show();
		
		$('#span'+CurrentRow+"_5").hide();
		$('#Text_EndDate'+CurrentRow).show();
		
		$('#Check_Enforce'+CurrentRow).prop('disabled', false);	
		$('#Check_Recess'+CurrentRow).prop('disabled', false);	
		$('#Check_Enabled'+CurrentRow).prop('disabled', false);	
		//$('#Check_InUse'+CurrentRow).prop('disabled', false);	
	}	

</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">

<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../js/jsfunctions.js"></script>
<!--width: 1280px;-->
<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.myAdjustClass
	{
		text-align: right;
		padding-right:0px;
	}
	@media (min-width: 992px) 
	{
		.modal-lg
		{	
			width: 95%
			
		}
	}
	@media only screen
and (min-device-width : 320px)
and (max-device-width : 480px) 
{
	.myAdjustClass
		{
			text-align: left;
			padding-left:0px;
		}
}
</style>

</head>

<body>
<?php include("header.php"); ?>

<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="holiday-calendar.php"> Holiday Calendar </a></li>
          <li> <a href="#"><?php echo $s_caption; ?> Holiday Calendar</a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
	
		<div class="cont-box">
		<form class="form" id="Form1" name="Form1" action="" method="POST" onsubmit = "return chkfld_form1()">	<!--   -->
			<div class="pge-hd">
			  <h2 class="sec-title"  > 
			  <label id="Label_Title"><?php echo $s_caption; ?> Holiday Calendar</label>   			  
			  </h2>
			  
			</div>					
			<div class="upp-form row"> 
				<div class="cus-form-cont">
					<div class="col-sm-6 form-group">
					  <label> Calendar Name </label>
					  <input id = "Text_CalendarName" name = "Text_CalendarName" type="text" class="form-control requirefieldcls"   value = "<?php echo $Display_CalendarName; ?>" maxlength="40" required >
					  <span id = "Span_CalendarName"><?php echo $msg1; ?></span>
					</div>
					
					<div class="col-sm-6 form-group">
					  <label> Pay Period Year </label>
						<select id = "Combo_PayPeriod" name = "Combo_PayPeriod"  class="form-control requirefieldcls" required>
						 <?php echo $DisplayPayPeriodValues; ?>
						</select> 
						 <span id = "Span_PayPeriodYear"><?php echo $msg2; ?></span>
					</div>	
					<script> selectValue('<?php echo"Combo_PayPeriod";?>','<?php echo$Display_PeriodYear;?>') </script>	
					<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>
					
					<div class="col-sm-12 form-group "  >
						<div class = "col-sm-8 fleft two " style = "padding-left:0px;">							
							<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_holiday_PERMISSION=='Y'){ ?> id = "cmdUpdateSelected" name = "cmdUpdateSelected" onclick= 'EditRecord();' <?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>
						</div>
						
						<div class="col-sm-4 myAdjustClass cr-user" >				   								
							<button <?php if($CREATE_PRIV_holiday_PERMISSION=='Y'){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style"> Save Record </button>
						</div>
					</div>
				</div>				
				<div class="data-bx col-sm-12">
					<div class="table-responsive">
						<table class="table table-bordered mar-cont" id = "Table1">
							<thead>
								<tr>
									<th data-orderable="false" width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" value="1" onchange="CheckAll()"></th>
									<th width="20%"> Holiday Name </th>
									<th width="20%"> Description </th>
									<th width="18%"> Start Date </th>
									<th width="18%"> End Date </th>
									<th width="5%"> Enforce </th>
									<th width="7%"> Recess Allowed </th>
									<th width="5%"> Enabled </th>									
									<th width="7%"> In Use </th>
									<th data-orderable="false" width="5%"> </th>
								</tr>
							</thead>
							<tbody>
								<?php									
									if($HeaderId=='')
									{
										$i=1;
										echo CreateBlankRow($i);										
									}
									else
									{
										$i=1;
										$selectQuery = "SELECT cxs_holiday_calendar.*,cxs_users.USER_NAME as CreatedByName,(select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_holiday_calendar.LAST_UPDATED_BY)  as UpdatedByName  from cxs_holiday_calendar
										INNER JOIN cxs_users ON cxs_users.USER_ID = cxs_holiday_calendar.CREATED_BY where cxs_holiday_calendar.HOLIDAY_CALENDAR_ID = $HeaderId $SQueryOrderBy ";	
										
										$selectQueryForPages  = $selectQuery;
										$selectQuery = $selectQuery." limit $start_from , $RecordsPerPage";
										$result = mysql_query($selectQuery);
										while($rows = mysql_fetch_array($result))
										{	
											$Display_StartDate ='';
											$Display_EndDate = '';
											if((!is_null($rows['HOLIDAY_START_DATE'])) && (($rows['HOLIDAY_START_DATE'])!='0000-00-00') )
											{			
												$Display_StartDate = date('l, F d, Y', strtotime($rows['HOLIDAY_START_DATE']));
											}
											if((!is_null($rows['HOLIDAY_END_DATE'])) && (($rows['HOLIDAY_END_DATE'])!='0000-00-00'))
											{			
												$Display_EndDate = date('l, F d, Y', strtotime($rows['HOLIDAY_END_DATE']));	
											}
											$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));
											$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATE_DATE']));
											?>
											<tr id = '<?php echo "row$i";?>'>
												<td class="check-bx ">
													<input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
													<input type="hidden" id = <?php echo "h_CalendarId$i"; ?> name = <?php echo "h_CalendarId$i"; ?> value = "<?php echo $rows['CALENDAR_ID']; ?>">
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_2"; ?>"> <?php echo $rows['HOLIDAY_TAG_NAME']; ?> </span>
													<input type = "text" class="form-control"  id="<?php echo "Text_HolidayName$i"; ?>" name="<?php echo "Text_HolidayName$i"; ?>" value ="<?php echo $rows['HOLIDAY_TAG_NAME']; ?>" style = "display:none" >
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $rows['DESCRIPTION']; ?> </span>
													<input type = "text" class="form-control"  id="<?php echo "Text_Description$i"; ?>" name="<?php echo "Text_Description$i"; ?>" value ="<?php echo $rows['DESCRIPTION']; ?>" style = "display:none" >
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_4"; ?>"> <?php echo $Display_StartDate; ?> </span>
													<input type="text" id="<?php echo "Text_StartDate$i"; ?>" name="<?php echo "Text_StartDate$i"; ?>" class="form-control small form_datetime"  value = "<?php echo $Display_StartDate; ?>"  style = " display:none" >
												</td>
												
												<td> 
													<span id = "<?php echo "span".$i."_5"; ?>"> <?php echo $Display_EndDate; ?> </span>
													<input type="text" id="<?php echo "Text_EndDate$i"; ?>" name="<?php echo "Text_EndDate$i"; ?>"  class="form-control form_datetime"  value = "<?php echo $Display_EndDate; ?>" style = " display:none" >
												</td>
												
												<td class="check-bx ">
													<input type="checkbox" id="<?php echo "Check_Enforce$i"; ?>" name="<?php echo "Check_Enforce$i"; ?>" value="1" <?php echo($rows['ENFORCE_FLAG'] == "Y")?"checked":""; ?>  disabled>		
												</td>
												
												<td class="check-bx ">
													<input type="checkbox" class = 'recess' id="<?php echo "Check_Recess$i"; ?>" name="<?php echo "Check_Recess$i"; ?>" value="1" <?php echo($rows['RECESS_ALLOWED'] == "Y")?"checked":""; ?>  disabled>		
												</td>
												
												<td class="check-bx ">
													<input type="checkbox" id="<?php echo "Check_Enabled$i"; ?>" name="<?php echo "Check_Enabled$i"; ?>" value="1" <?php echo($rows['ENABLED_FLAG'] == "Y")?"checked":""; ?>  disabled>		
												</td>
												
												<td class="check-bx ">
													<input type="checkbox" class = 'SystemClass' id="<?php echo "Check_InUse$i"; ?>" name="<?php echo "Check_InUse$i"; ?>" value="1" <?php echo($rows['INUSE_FLAG'] == "Y")?"checked":""; ?>  disabled>		
												</td>
												
												<td class="check-bx">
													<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
													Created By: <?php echo $rows['CreatedByName']; ?> <br> Updated By: <?php echo $rows['UpdatedByName']; ?> 
													<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
												</td>
											</tr>
								<?php		$i=$i+1;
										}
											echo CreateBlankRow($i);											
									}
								?>
							</tbody>
						</table>						
					</div>	
				</div>	
			
				
		<!--	<div class="col-sm-12 form-group text-right cr-user">
					<button type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord" class="btn btn-primary btn-style"> Save Record </button>
				</div>
		-->
				<!-- pagination start-->
			
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php
									if($HeaderId!='')
									{
											$selectQueryForPages=$selectQueryForPages;
											$RunDepQuery=mysql_query($selectQueryForPages);
											$num_records = mysql_num_rows($RunDepQuery);
											$total_pages= ceil($num_records/$RecordsPerPage);
										
											if (($page-1)==0)
											{?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php } else
											{  ?>
										<li class="">
										<a rel="0" href="?hid=<?php echo $HeaderId; ?>&page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pages;$i++){ ?>
											<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?hid=<?php echo $HeaderId; ?>&page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($page+1)>$total_pages){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?hid=<?php echo $HeaderId; ?>&page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
										  <?php }
									}
										?>

								  </ul>
								</div>
							</div>
							<!-- pagination end -->
			</div>	
			<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>	
			<input type="hidden" id="h_field_update" name="h_field_update" value="">
		</form>			
		</div>			
    </div>
  </div> 
		
</section>
	
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script src="../js/jquery.validate.js"></script>
 
<!--<script src="../datepicker/jquery.js"></script>-->
<script src="../datepicker/bootstrap-datepicker.js"></script>

<script type="text/javascript">
	$(document).ready(function()
	{
		TABLE_ROW = $('#Table1 tr').length-1;	// remove header row	
		
		//'aoColumnDefs': [{'bSortable': false,'aTargets': [0,-1] }],
		/*$('#Table1').DataTable( 
		{
			'searching': false,
			'order': [[ 1, "asc" ]],			
			 'lengthMenu': [[5,10, 25, 50, -1], [5,10, 25, 50, "All"]],
			 "bSort" :false,// false all columns sorting off
			 "bInfo" : true //to hide "Showing 1 to 5 of 14 entries" label
		} );*/
		
		$('.form_datetime').datepicker(
		{
			//format:'mm/dd/yyyy',
			format:'DD,  MM d, yyyy',
			defaultDate: '',
			autoclose : true
		});	
		
		var HeaderId = '<?php echo $HeaderId; ?>';
		if (HeaderId != '')
		{
			$('#cmdUpdateSelected').show();			
			$("#Checkbox_SelectAll").prop("disabled",false);
			
			$('.SystemClass').each(function(index)
			{
				$(this).attr("disabled",true);
			});
		}
		else
		{
			$('#cmdUpdateSelected').hide();
			$("#Table1 :input").prop("disabled", true);
		}
	});
	
	$('#Combo_PayPeriod').change( function()		
	{	
		var HeaderId = '<?php echo $HeaderId; ?>';
		if ($('#Combo_PayPeriod').val()=='')
		{
			$("#Table1 :input").prop("disabled", true);			
			
		}
		else
		{
			$("#Table1 :input").prop("disabled", false);		
			if (HeaderId == '')
			{
				for(i=1;i<=TABLE_ROW;i++)
				{	
					$("#CheckboxInline"+i).prop('disabled',true);					
				}
			}
			$('.SystemClass').each(function(index)
			{
				$(this).attr("disabled",true);
			});
		}
		
	});
	
	$('#Text_CalendarName').blur(function()		
	{	
		KEY = "CheckDuplicate";
		var TableName = "cxs_holidays";
		var FieldName = "CALENDAR_NAME";
		var FieldValue = $('#Text_CalendarName').val();
		var FieldId = "HOLIDAY_CALENDAR_ID";
		var SelectedId = "<?php echo $HeaderId; ?>";
		makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);
	});	
	

	$('#Combo_PayPeriod').on('blur change keyup', function()		
	{	
		KEY = "CheckDuplicatePayPeriod";
		var TableName = "cxs_holidays";
		var FieldName = "PERIOD_YEAR";
		var FieldValue = $('#Combo_PayPeriod').val();
		var FieldId = "HOLIDAY_CALENDAR_ID";
		var SelectedId = "<?php echo $HeaderId; ?>";
		makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);
	});	
	

	var datePickerOptions = {
    //format:'mm/dd/yyyy',
	format:'DD,  MM d, yyyy',
			defaultDate: '',
			autoclose : true
	}
	
	
			
	$(document).on('focus',".form_datetime", function()
	{
		$(this).datepicker(datePickerOptions);
	});
	
	function makeRequest(url,data)
	{
		var http_request = false;
		if (window.XMLHttpRequest) { // Mozilla, Safari, ...
			http_request = new XMLHttpRequest();
			if (http_request.overrideMimeType) {
				http_request.overrideMimeType('text/xml');
				// See note below about this line
			}
		} else if (window.ActiveXObject) { // IE
			try {
				http_request = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					http_request = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}

		if (!http_request) {
			alert('Giving up :( Cannot create an XMLHTTP instance');
			return false;
		}
		http_request.onreadystatechange = function() { alertContents(http_request); };
		http_request.open('POST', url, true);
		http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;						
					//alert(str);
					window.open('downloaddata.php?r=holiday-calendars', '_blank');
				}
				else if(KEY == "ExportRecordCont")
				{
					var str = http_request.responseText;	
					
					//alert(str);
					window.open('downloaddata.php?r=new-resource-contacts', '_blank');					
					//window.location.href = "downloaddata.php?r=user-administration","target='_blank'";					
				}
				else if(KEY == 'CheckDuplicate')
				{
					var s1 = http_request.responseText.trim();					
					if(s1.length > 1)
					{
						document.getElementById("Span_CalendarName").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Text_CalendarName").focus();					
					}
					else
					{
						document.getElementById("Span_CalendarName").innerHTML = "&nbsp;";
					}
				}
				else if(KEY == 'CheckDuplicatePayPeriod')
				{
					var s1 = http_request.responseText.trim();					
					if(s1.length > 1)
					{
						document.getElementById("Span_PayPeriodYear").innerHTML = s1;
						document.getElementById("h_duplicate").value = "Y";	
						document.getElementById("Combo_PayPeriod").focus();					
					}
					else
					{
						document.getElementById("Span_PayPeriodYear").innerHTML = "&nbsp;";
					}
				}
				else if(KEY == 'ValidateDates')				
				{
					if(http_request.responseText.trim()=="valid")
					{
						TABLE_ROW = $('#Table1 tr').length-1;	
						if( TABLE_ROW == CURRENTROW)
						{
							var NewRow = CURRENTROW+1;
							cell1="<td class='check-bx'><input type='checkbox' id='CheckboxInline"+NewRow+"' name = 'CheckboxInline"+NewRow+"'  value='1' onchange='checkInline()' disabled>"+
							"<input type='hidden' id = 'h_CalendarId"+NewRow+"' name = 'h_CalendarId"+NewRow+"' value = ''></td>";	
							cell2="<td><input type = 'text' class='form-control' id='Text_HolidayName"+NewRow+"' name='Text_HolidayName"+NewRow+"' onchange = 'AddNewRow("+NewRow+");' ></td>";	
							cell3="<td><input type = 'text' class='form-control' id='Text_Description"+NewRow+"' name='Text_Description"+NewRow+"'></td>";				
							cell4="<td><input type='text' id='Text_StartDate"+NewRow+"' name='Text_StartDate"+NewRow+"' class='form-control small form_datetime'  onchange='SetYear("+NewRow+",this);'></td>";	
							cell5="<td><input type='text' id='Text_EndDate"+NewRow+"' name='Text_EndDate"+NewRow+"' class='form-control small form_datetime'  onchange='SetYear("+NewRow+",this);'></td>";				
							cell6="<td class = 'check-bx'><input type='checkbox' id='Check_Enforce"+NewRow+"' name='Check_Enforce"+NewRow+"' value='1'></td>";
							cell7="<td class = 'check-bx'><input type='checkbox' class = 'recess' id='Check_Recess"+NewRow+"' name='Check_Recess"+NewRow+"' value='1'></td>";
							cell8="<td class = 'check-bx'><input type='checkbox' id='Check_Enabled"+NewRow+"' name='Check_Enabled"+NewRow+"' value='1'></td>";
							cell9="<td class = 'check-bx'><input type='checkbox' class = 'SystemClass' id='Check_InUse"+NewRow+"' name='Check_InUse"+NewRow+"' value='1'></td>";
							var EyeIcon="<td class = 'check-bx'><button type='button' class='btn btn-default' data-container='body' data-toggle='popover' data-placement='left' data-content='' > <i class=' fa fa-eye'></i> </button></td>";
							$('#Table1').append('<tr id = "row'+NewRow+'">'+cell1+cell2+cell3+cell4+cell5+cell6+cell7+cell8+cell9+EyeIcon+'</tr>');		
						}
					}
					else
					{
						alert("Date period is not match with period year.");
						$('#Text_StartDate'+CURRENTROW).focus();
					}
				}
				else if (KEY == 'AllHolidayPeriods')
				{
					//alert(http_request.responseText.trim());
					if(http_request.responseText.trim()=="valid")
					{
						Form1.submit();
					}
					else
					{
						alert("Date period is not match with period year.");
						$('#Text_StartDate'+http_request.responseText.trim()).focus();
					}
				}
			}	
			
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	

		function CheckRecessAllowed()
	{
		$.ajax({
				url:"ajax2_te.php",
				method:"POST",
				data:{StartDate:startdate,EndDate:enddate },
				success:function(response)
				{
					var JSONObject = JSON.parse(response); 									
					IsRecessAllowed = JSONObject;						
				}
			});
	}
	$('.recess').change(function() 
	{
		thestring = $(this).attr('id');
		//thenum=FindNumFromString(thestring);
		var thenum = thestring.match(/\d+$/)[0];
		var startdate = $("#Text_StartDate"+thenum).val();
		var enddate = $("#Text_EndDate"+thenum).val();
		if ($('#Check_Recess'+thenum).prop("checked")==true)
		{
			$.ajax({
					url:"ajax2_te.php",
					method:"POST",
					data:{StartDate:startdate,EndDate:enddate },
					success:function(response)
					{
						var JSONObject = JSON.parse(response); 									
						if(JSONObject=="N")
						{
							alert("Recess Allowed is not accepted for holiday name <" + $('#Text_HolidayName'+thenum).val()+">.");
							$("#Check_Recess"+thenum).attr("checked",false);
						}
					}
				});	
		}
	});	
	</script>

</body>
</html>