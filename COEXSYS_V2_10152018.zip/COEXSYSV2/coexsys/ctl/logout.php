<?php
include("conn.php");
UpdateLastLogout($_SESSION['user_id']);
setcookie ("cookie_access-module",$_SESSION['access-module'],time()+ (24 * 60 * 60));
session_destroy();
header('location:index.php');

?>