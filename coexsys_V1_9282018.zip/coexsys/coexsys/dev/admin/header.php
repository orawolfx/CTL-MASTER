<?php 
	$LoginUserId = isset($_SESSION['user_id'])?$_SESSION['user_id']:'1';	
?>
<header>	
  <div class="top-nav-bx">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 col-md-6">
          <div class="logo"> <a href="index.php"> <img src="img/logo.jpg"></a> <span class="ac-manage"> Admin </span> </div>
        </div>
        <div class="col-sm-6 col-md-6">			
			<ul class="top-nav">
				<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-question-circle"></i> <span class="sm-hide"> Help </span><b class="fa fa-angle-down"></b></a>
				  <ul class="dropdown-menu">
					<li><a href="#"> Option 1 </a></li>
					<li><a href="#"> Option 2 </a></li>
				  </ul>
				</li>				
			</ul>
        </div>
      </div>
    </div>
  </div>
  <!-- navigation  -->
  <nav class="navbar navbar-default custom-navbar">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only"> Toggle navigation </span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
	  <?php
			$disableStyle = "color: #e9e9e9; background-color: #ffffff;"; ?>
        <ul class="nav navbar-nav custom-nav">
			<li class="dropdown"> <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Site Activity Zone <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="site-data-analystics.php">  Site Data Analystics </a></li>
					<li><a href="account-management.php">Account Management </a></li>
					<li><a href="support-request.php"> Support Request </a></li>
					<li><a href="chat-center.php"> Chat Center </a></li>
					<li><a href="site-communication.php"> Site Communication </a></li>
				</ul>
			</li>
			<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Sales Management <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="pricing-administration.php"> Pricing Administration </a></li>
					<li><a href="site-slas.php"> Site SLAs </a></li>
					<li><a href="billing-payment.php"> Billing and Payment </a></li>
					<li><a href="revenue-recognition.php"> Revenue Recognition </a></li>
					<li><a href="trial-period-management.php"> Trial Peroid Management </a></li>
				</ul>
			</li>
        </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
  </nav>
</header>