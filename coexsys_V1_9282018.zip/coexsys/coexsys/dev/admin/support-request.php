<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- editor css -->
    <link href="css/editor.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">   Customer Activity Zone   </a></li>
                        <li> <a href="#"> Supports Requests </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Supports Requests </h2>
                    </div>

                    <!-- find bx-->
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-8 form-group cus-form-ico">
                                <label> Subject </label>
                                <input type="text" class="form-control" placeholder="" maxlength="150">

                            </div>
                            <div class="col-sm-4 form-group cus-form-ico">
                                <label> Severity </label>
                                <select class="form-control">
                                    <option value=""> Option 1 </option>
                                    <option value="">Option 2</option>
                                    <option value="">Option 3</option>
                                    <option value="">Option 4</option>
                                </select>

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Number </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Originator </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Owner </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Status </label>
                                <input type="text" class="form-control" placeholder="" maxlength="15">

                            </div>


                        </div>
                    </div>

                    <div class="clearfix"> </div>
                    <div class="text-area-bx mar-botn20">
                        <div class="col-lg-12 nopadding">
                            <textarea id="txtEditor"></textarea>
                        </div>
                    </div>
                    <div class="fright cr-user mar-top-20pxs">
                        <button type="button" class="btn btn-primary btn-style"> Submit </button>
                    </div>

                    <div class="clearfix"></div>
                    <div class="cus-que-box">
                        <div class="chat-win-bx">
                            <div class="chat-hd-bx">
                                <h2 class="sec-hd"> Chat with Agent </h2>
                            </div>
                            <div class="chat-mid-bx">

                                <div class="per-block">
                                    <p class="chat-hd"> User <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                    </ul>
                                </div>
                                <div class="per-block ag-chat ag-chat2">
                                    <p class="chat-hd"> Agent <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat agent-rep-chat ">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>

                                    </ul>
                                </div>
                                <div class="per-block">
                                    <p class="chat-hd"> Name <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>
                                    </ul>

                                </div>
                                <div class="per-block ag-chat ag-chat2">
                                    <p class="chat-hd"> Agent <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat agent-rep-chat ">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>

                                    </ul>
                                </div>
                                <div class="per-block">
                                    <p class="chat-hd"> User <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b </li>
                                    </ul>
                                </div>
                                <div class="per-block ag-chat ag-chat2">
                                    <p class="chat-hd"> Agent <span> 9:25 </span></p>
                                    <ul class="cus-rep-chat agent-rep-chat ">
                                        <li> kddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kfkddf vdfk fdmb skfbj bkfsgb kf b
                                        </li>

                                    </ul>
                                </div>
                            </div>
                            <div class="type-bx type-bx2">
                                <div class="type-txt-bx"> <input type="text"> </div>
                                <div class="send-btn-bx">
                                    <a href="#" class="send"> send </a>
                                </div>

                            </div>
                        </div>
                    </div>


                </div>


            </div>


        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/editor.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $("#txtEditor").Editor();
        });
    </script>

</body>

</html>