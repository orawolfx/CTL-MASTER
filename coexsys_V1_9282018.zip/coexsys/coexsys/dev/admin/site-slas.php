<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">   Sales Management   </a></li>
                        <li> <a href="#"> Customer  SLAs </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>

                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> View SLAs </h2>
                    </div>
                    <div>
                        <div class="data-bx">
                            <div class="table-responsive">
                                <table class="table table-bordered mar-cont">
                                    <thead>
                                        <tr>
                                            <th width="5%" class="check-bx "><input type="checkbox" id="inlineCheckbox1" value="option1"></th>
                                            <th width="15%"> Customer <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Sla Title <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Link <i class="fa fa-sort"></i> </th>
                                            <th width="15%"> Creation Date <i class="fa fa-sort"></i> </th>
                                            <th width="20%"> Last Update Date <i class="fa fa-sort"></i> </th>
                                            <th width="10%"> </th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                        <tr>
                                            <td class="check-bx "><input type="checkbox" id="" value="option1"></td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td>Dumy Text </td>
                                            <td class="cr-user text-center"> <a href="#" class="btn btn-primary btn-style tble-in-btn"> Download </a></td>


                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- pagination start-->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- pagination end -->
                    </div>
                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>

</html>