<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">  Customer Activity Zone  </a></li>
                        <li> <a href="#"> Account Management </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <!-- mid part start -->
                <div class="cont-box cont-sep">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Account Management </h2>
                    </div>


                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Number </label>
                                <input type="text" class="form-control" placeholder="" maxlength="15">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Customer Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group">
                                <button type="button" class="btn btn-primary btn-style2 mar-tp22"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
                            </div>
                        </div>
                    </div>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="inlineCheckbox1" value="option1"> </td>
                                        <th width="13%"> Customer Number <i class="fa fa-sort"></i></th>
                                        <th width="12%"> Customer Name <i class="fa fa-sort"></i></th>
                                        <th width="10%"> Incepation Date <i class="fa fa-sort"></i></th>
                                        <th width="18%"> Number of Subscribers <i class="fa fa-sort"></i></th>
                                        <th width="8%"> Plan <i class="fa fa-sort"></i> </th>
                                        <th width="15%"> Channel (Buy or try ) <i class="fa fa-sort"></i></th>
                                        <th width="11%"> Last Update Date <i class="fa fa-sort"></i></th>
                                        <th width="10%"> Last Update By <i class="fa fa-sort"></i></th>
                                        <th width="4%"> </th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Close Account </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Activate Account </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Freeze Account </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>

                    <h3 class="sec-subtitle"> Addressess </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <th width="10%"> Address 1 <i class="fa fa-sort"></i></th>
                                        <th width="10%"> Address 2 <i class="fa fa-sort"></i></th>
                                        <th width="8%"> Address 3 <i class="fa fa-sort"></i></th>
                                        <th width="8%"> Country <i class="fa fa-sort"></i> </th>
                                        <th width="8%"> City <i class="fa fa-sort"></i></th>
                                        <th width="8%"> Zip <i class="fa fa-sort"></i></th>
                                        <th width="10%"> State <i class="fa fa-sort"></i></th>
                                        <th width="12%"> Country <i class="fa fa-sort"></i></th>
                                        <th width="12%"> Primary <i class="fa fa-sort"></i></th>
                                        <th width="12%"> Active <i class="fa fa-sort"></i></th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>


                                    </tr>


                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>

                    <h3 class="sec-subtitle"> Contacts </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <th width="15%"> First Name <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Last Name <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Phone <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Email <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Phone Tyoe <i class="fa fa-sort"></i> </th>
                                        <th width="15%"> Title <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Primary <i class="fa fa-sort"></i> </th>
                                        <th width="15%">Active <i class="fa fa-sort"></i> </th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>

                    <h3 class="sec-subtitle"> Billing and Payment </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <th width="8%"> Bill ID <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Billing Period <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Bill Sent Date <i class="fa fa-sort"></i> </th>
                                        <th width="15%"> Payment Due Date <i class="fa fa-sort"></i> </th>
                                        <th width="8%"> Days Late <i class="fa fa-sort"></i> </th>
                                        <th width="20%"> Payment Reminder Count <i class="fa fa-sort"></i> </th>
                                        <th width="16%"> Last Reminder Date <i class="fa fa-sort"></i> </th>
                                        <th width="15%"> Paymet Status <i class="fa fa-sort"></i> </th>
                                        <th width="5%"> </th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td>
                                            <ul class="action-bx">
                                                <li class="dropdown">
                                                    <a href="#" class="dropdown-toggle action-drop" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-caret-down"></i></a>
                                                    <ul class="dropdown-menu ac-custom ac-custom2">
                                                        <li><a href="javascript:void(0)"> Send Reminder </a></li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Send toCollections </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:void(0)"> Mark as Settled </a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>


                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>


                    <h3 class="sec-subtitle"> Supports Tickets </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <th width="15%"> From <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Time Sent <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Ticket Type <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Ticket Severity <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Status <i class="fa fa-sort"></i> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>


                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>

                    <h3 class="sec-subtitle"> Chat Logs </h3>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <td width="5%" class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <th width="15%"> From <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Time Sent <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Ticket Type <i class="fa fa-sort"></i> </th>
                                        <th width="10%"> Ticket Severity <i class="fa fa-sort"></i> </th>
                                        <th width="12%"> Status <i class="fa fa-sort"></i> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>
                                    <tr>
                                        <td class="check-bx "> <input type="checkbox" id="" value="option1"> </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>
                                        <td> Dummy Text </td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>

                        <!-- pagination -->
                        <div class="pagination-bx">
                            <div class="bs-example">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>





                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>

</html>