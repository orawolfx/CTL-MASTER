
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Coexsys Time Accounting</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include("header.php"); ?>
    <section class="md-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="brd-crmb">
                    <ul>
                        <li> <a href="#">  Site Activity Zone  </a></li>
                        <li> <a href="#"> Site Data Analytics  </a></li>
                    </ul>
                </div>
                <div class="dash-strip">
                    <div class="fleft cr-user">
                        <a href="index.php">
                            <button type="button" class="btn btn-primary dash"> Dashboard </button>
                        </a>
                    </div>
                    <div class="fright">
                        <button type="button" class="btn btn-warning fav-ico"><i class="fa fa-star"></i></button>
                    </div>
                </div>
                <div class="cont-box">
                    <div class="pge-hd">
                        <h2 class="sec-title"> Site Data Analytics </h2>
                    </div>

                    <!-- find bx-->
                    <div class="form-bx2">
                        <div class="cus-form-cont row">
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Site Code </label>
                                <input type="text" class="form-control" placeholder="" maxlength="15">

                            </div>
                            <div class="col-sm-3 form-group cus-form-ico">
                                <label> Site Name </label>
                                <input type="text" class="form-control" placeholder="" maxlength="40">

                            </div>
                            <div class="col-sm-3 form-group">
                                <button type="button" class="btn btn-primary btn-style2 mar-tp22"> <i class="fa fa-search" aria-hidden="true"></i> Find Data </button>
                            </div>
                        </div>
                    </div>



                    <div>
                        <h2 class="sec-title"> Log In Activities </h2>
                    </div>
                    <div class="data-bx">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>                                        
                                        <th> User Name
                                            <a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
                                        </th>
                                        <th> Full Name </th>
                                        <th>Last Logged In TimeStamp </th>
                                        <th> Last Logged Out TimeStamp </th>
                                        <th> Supervisor </th>                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    

                                </tbody>
                            </table> 
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </section>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js" type="text/javascript"></script>
</body>
<?php
	
?>
</html>
