function openModal()
{
	document.getElementById('modal').style.display = 'block';
	document.getElementById('fade').style.display = 'block';
}

function closeModal()
{
	document.getElementById('modal').style.display = 'none';
	document.getElementById('fade').style.display = 'none';
}