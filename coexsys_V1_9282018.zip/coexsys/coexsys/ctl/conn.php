<?php
session_start(); 
/*
$hostname="103.21.58.4";
$username="mis";
$password="mis_2015@";
$dbname="synchronweb_applisoft";
*/

//header("Cache-Control: max-age=300, must-revalidate");




/*
$hostname = 'localhost';
$username = 'root';
$password = '';

$dbname = 'coexsys_server';
$dbname = 'rbam2';*/

$hostname = 'localhost';
$username = 'racyshar_orawolf';
$password = 'HumtumNBT987##';
$dbname = 'racyshar_orawolf';


$user_session_id = session_id();
$ipaddress = getenv('REMOTE_ADDR');
/*
$ipInfo = file_get_contents('http://ip-api.com/json/' . $ipaddress);
$ipInfo = json_decode($ipInfo);
$timezone = $ipInfo->timezone;*/
//$timezone = 'America/Los_Angeles';
//date_default_timezone_set($timezone);
//date_default_timezone_get();

//$conn = mysql_connect("$db1_host", "$db1_user", "$db1_pass") or die(mysql_error()) ;
$conn = mysql_connect("$hostname","$username", "$password") or die("Data not connected".mysql_errno());
mysql_select_db("$dbname",$conn) or die(mysql_error());

//$ModuleName = "Access Management";

function add_security($val)		// RETURN VALUE WITH SECURITY
{
	return mysql_real_escape_string($val);
}
function insertdata($table,$data)	// FUNCTION TO INSERT NEW RECORD IN SPECIFIED TABLE
{
	$qry="INSERT INTO ".$table." set ";
	foreach($data as $fld=>$val)
	{
		if($val=='now()')
		{
			//$qry.= $fld."=now(),";
			$qry.= $fld."=".add_security($val).",";
		}
		else
		{
			$qry.= $fld."='".add_security($val)."',";
		}
	}
	$qry=substr($qry,0,-1);
	//echo $qry;
	$result_insert = mysql_query($qry);
}

function updatedata($table,$data, $wherecondition)	// FUNCTION TO UPDATE RECORD IN SPECIFIED TABLE
{
	$qry="Update ".$table." set ";
	foreach($data as $fld=>$val)
	{
		$qry.= $fld."='".add_security($val)."',";
	}
	$qry=substr($qry,0,-1);
	$qry = $qry . $wherecondition;	
	//echo $qry;
	$result_insert = mysql_query($qry);
}
function getvalue($table,$fieldname, $wherecondition)	// FUNCTION TO GET RECORD IN SPECIFIED TABLE
{	
	$qry="Select $fieldname from ".$table." ".$wherecondition;
	$result = mysql_query($qry) or die(mysql_error($conn));
	while($linedetail=mysql_fetch_array($result))
	{
		$valueResult = $linedetail[$fieldname];			
	}		
	return $valueResult;
}
function getProfileImg($id)	// FUNCTION TO GET RECORD IN SPECIFIED TABLE
{	
	$qry="Select PHOTO from cxs_users where USER_ID=".$id;
	$result = mysql_query($qry) or die(mysql_error($conn));
	while($linedetail=mysql_fetch_array($result))
	{
			 if($linedetail['PHOTO']=='')
			 {
				    $valueResult = "../img/default_profile_img.jpg";
			 }
			 else
			 {	
				    $valueResult = "../img/uploads/user_images/".$id."/".$linedetail['PHOTO'];					
				    if (!file_exists($valueResult)) 
					{
						$valueResult = "../img/default_profile_img.jpg";
				    }
			 }
	}		
	return $valueResult;
}
function GetPassword($s)
{
	$l = strlen($s);
	$s1 = "";
	$s2 = "";
	$s3 = "";
	$s4 = "";
	for ($i=0; $i <= $l-1; $i++ )
	{
		$s1 = substr($s, $i, 1);
		$s2 = ord($s1);
		$s3 = ($s2 ^ 153);
		$s4 = $s4 . chr($s3);
	}
	return "$s4";
}

if(isset($_COOKIE["LogUserId"]))	
{
	$_SESSION["LogUserId"] = $_COOKIE["LogUserId"];
	$_SESSION["LogUserName"] = $_COOKIE["LogUserName"]; 
	
}
//$UserLoginId = $_SESSION['CustomerId'];

function check_login()
{
	if($_SESSION['reset-password']=='Y')
	{
		 header('location:reset-password.php');
	}					
	if(!isset($_SESSION['user_data']) || !isset($_SESSION['user_id']))
	{	
		$_SESSION['redirect_page']=$_SERVER['REQUEST_URI'];		
		header('location:../index.php');
		exit();
	}	
	if ($_SESSION['current-user-type'] == "TE-Admin" && $_GET['m']==1)
	{
		if(HasUserType($_SESSION['user-type'],'RBAM-Admin'))
		{ 
			$_SESSION['current-user-type'] = "RBAM-Admin"; 
		}
	}
	else if ($_SESSION['current-user-type'] == "RBAM-Admin" && $_GET['m']==1)
	{
		if(HasUserType($_SESSION['user-type'],'TE-Admin'))
		{ 
			$_SESSION['current-user-type'] = "TE-Admin"; 
		}
		
	}
}

function check_login1()
{
	/*if($_SESSION['reset-password']=='Y')
	{
		 header('location:reset-password.php');
	}					
   */
   if(!isset($_SESSION['user_data']) || !isset($_SESSION['user_id']))
   {
		header('location:index.php');
   }	
}

	function HasUserType($FromString,$FindString)
	{
/*		$val = strpos($FromString, $FindString);
		if ($val==false) 
		{
			return false;
		}
		else 
		{
			return true;
		}
	*/
		if (strpos($FromString, $FindString) !== false)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}	
	
	function GetCurrentWeekDates($currentDate1)
	{
		//$currentDate1 = strtotime(date('Y-m-d'));				
		if(date('l',strtotime($currentDate1))=='Monday')
		{
			$firstday = strtotime($currentDate1);
		}
		else										
		{
			$firstday = strtotime("last Monday",strtotime($currentDate1));
		}	
	
		$lastday = strtotime(date("Y-m-d",$firstday)." +6 days");			 
		$this_week_sd = date("Y-m-d",$firstday);
		$this_week_ed = date("Y-m-d",$lastday);		
		//return array('startdt'=>$this_week_sd,'enddt'=>$this_week_ed);
		
		$this_week_sd = strtotime($this_week_sd); 
		$this_week_ed = strtotime($this_week_ed); 
		$dates=array();		
		for ($i=$this_week_sd; $i<=$this_week_ed; $i+=86400) 
		{  
			$dates[]= date("Y-m-d", $i);  
		}  
		
		return $dates;
		
	}
	function CreateSystemGenerateUser($LastInsertedSite)
	{
		$qry = "select * from cxs_sites where SITE_ID = $LastInsertedSite";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$SiteId = $row['SITE_ID'];
			$insArr['USER_NAME'] = $row["EMAIL"];
			$insArr['ENC_KEY'] = $row["SYSTEM_PASSWORD"];
			$insArr['START_DATE'] = 'now()';			
			$insArr['CREATION_DATE']='now()' ;	
			$insArr['SITE_ID']=$SiteId ;		
			insertdata("cxs_users",$insArr);
		}
		$LastInsertedId = mysql_insert_id();
		
		//insert data into site settings table
		unset($insArr);		
		$insArr['MANDATORY_PWD'] = "30";
		$insArr['INCORRECT_ATTEMPT'] = "25";
		$insArr['IDLE_SESSION'] = "1243";
		$insArr['MINIMUM_ALLOWED'] = '9';		
		$insArr['ENFORCE_RECENT'] = 'Y';
		$insArr['NUMBER_OF_RECENT'] = '5';
		$insArr['ALLOW_SPECIALS'] = 'Y';
		$insArr['ALLOW_UPPERCASE'] = 'Y';
		$insArr['ALLOW_TIME_ENTRY'] = 'Y';
		$insArr['ALLOW_LOWERCASE'] = 'Y';
		$insArr['ALLOW_NUMERIC'] = 'Y';
		$insArr['ENABLE_COMMON'] = 'Y';
		$insArr['CREATED_BY'] = $LastInsertedId;
		$insArr['LAST_UPDATED_BY'] = $LastInsertedId;		
		$insArr['CREATION_DATE']='now()' ;	
		$insArr['SITE_ID']=$LastInsertedSite ;		
		insertdata("cxs_site_settings",$insArr);
			
		//mysql_query("update cxs_users set CREATED_BY = $LastInsertedId where USER_ID = $LastInsertedId");
		//mysql_query("update cxs_sites set IS_APPROVAL = 'Y', CREATED_BY = $LastInsertedId where SITE_ID = $LastInsertedSite");
		mysql_query("update cxs_sites set IS_APPROVAL = 'Y', DATE_ACTIVATED = now() where SITE_ID = $LastInsertedSite");
		SetUserAccessibility($LastInsertedId);
	}
	function SetUserAccessibility($UserId)
	{
		for($i=1;$i<=2;$i++)
		{
			$insArr['USER_ID']= trim($UserId);
			//$insArr['CREATED_BY']= trim($UserId);
			$insArr['LAST_UPDATED_BY']= $UserId;
			$insArr['CREATION_DATE']= 'now()';
			$insArr['APPLICATION_ID']= $i;//for RBAM
			$insArr['START_DATE_ACTIVE']= 'now()';
			//$insArr['END_DATE_ACTIVE']= $END_DATE_ACTIVE;	
			insertdata("cxs_am_app_admin",$insArr);
		}
	}
	function UpdateLastLogin($CurrentUser)
	{
		mysql_query("update cxs_users set LAST_LOGIN_TIME = now() where USER_ID = $CurrentUser");
		$SiteId = $_SESSION['user-siteid'];
		
		$qry = "select ENABLE_AUDIT from cxs_site_settings where SITE_ID = $SiteId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$IsEnableAudit = $row['ENABLE_AUDIT'];
		}
		$_SESSION['IsEnableAudit'] = $IsEnableAudit;
	}
	
	function UpdateLastLogout($CurrentUser)
	{
		mysql_query("update cxs_users set LAST_LOGOUT_TIME = now() where USER_ID = $CurrentUser");		
	}
	function StateListFun()
	{
		$StateList	= "<option value = '' class = 'option_color'> - State - </option>";
		$StateList .= "<option value = 'AL-ALABAMA' class = 'option_color'>AL-ALABAMA</option>";
		$StateList .= "<option value = 'AK-ALASKA' class = 'option_color'>AK-ALASKA</option>";
		$StateList .= "<option value = 'AZ-ARIZONA' class = 'option_color'>AZ-ARIZONA</option>";
		$StateList .= "<option value = 'AR-ARKANSAS' class = 'option_color'>AR-ARKANSAS</option>";
		$StateList .= "<option value = 'CA-CALIFORNIA' class = 'option_color'>CA-CALIFORNIA</option>";
		$StateList .= "<option value = 'CO-COLORADO' class = 'option_color'>CO-COLORADO</option>";
		$StateList .= "<option value = 'CT-CONNECTICUT' class = 'option_color'>CT-CONNECTICUT</option>";
		$StateList .= "<option value = 'DE-DELAWARE' class = 'option_color'>DE-DELAWARE</option>";
		$StateList .= "<option value = 'FL-FLORIDA' class = 'option_color'>FL-FLORIDA</option>";
		$StateList .= "<option value = 'GA-GEORGIA' class = 'option_color'>GA-GEORGIA</option>";
		$StateList .= "<option value = 'HI-HAWAII' class = 'option_color'>HI-HAWAII</option>";
		$StateList .= "<option value = 'ID-IDAHO' class = 'option_color'>ID-IDAHO</option>";
		$StateList .= "<option value = 'IL-ILLINOIS' class = 'option_color'>IL-ILLINOIS</option>";
		$StateList .= "<option value = 'IN-INDIANA' class = 'option_color'>IN-INDIANA</option>";
		$StateList .= "<option value = 'IA-IOWA' class = 'option_color'>IA-IOWA</option>";
		$StateList .= "<option value = 'KS-KANSAS' class = 'option_color'>KS-KANSAS</option>";
		$StateList .= "<option value = 'KY-KENTUCKY' class = 'option_color'>KY-KENTUCKY</option>";
		$StateList .= "<option value = 'LA-LOUISIANA' class = 'option_color'>LA-LOUISIANA</option>";
		$StateList .= "<option value = 'ME-MAINE' class = 'option_color'>ME-MAINE</option>";
		$StateList .= "<option value = 'MD-MARYLAND' class = 'option_color'>MD-MARYLAND</option>";
		$StateList .= "<option value = 'MA-MASSACHUSETTS' class = 'option_color'>MA-MASSACHUSETTS</option>";
		$StateList .= "<option value = 'MI-MICHIGAN' class = 'option_color'>MI-MICHIGAN</option>";
		$StateList .= "<option value = 'MN-MINNESOTA' class = 'option_color'>MN-MINNESOTA</option>";
		$StateList .= "<option value = 'MS-MISSISSIPPI' class = 'option_color'>MS-MISSISSIPPI</option>";
		$StateList .= "<option value = 'MO-MISSOURI' class = 'option_color'>MO-MISSOURI</option>";
		$StateList .= "<option value = 'MT-MONTANA' class = 'option_color'>MT-MONTANA</option>";
		$StateList .= "<option value = 'NE-NEBRASKA' class = 'option_color'>NE-NEBRASKA</option>";
		$StateList .= "<option value = 'NV-NEVADA' class = 'option_color'>NV-NEVADA</option>";
		$StateList .= "<option value = 'NH-NEW HAMPSHIRE' class = 'option_color'>NH-NEW HAMPSHIRE</option>";
		$StateList .= "<option value = 'NJ-NEW JERSEY' class = 'option_color'>NJ-NEW JERSEY</option>";
		$StateList .= "<option value = 'NM-NEW MEXICO' class = 'option_color'>NM-NEW MEXICO</option>";
		$StateList .= "<option value = 'NY-NEW YORK' class = 'option_color'>NY-NEW YORK</option>";
		$StateList .= "<option value = 'NC-NORTH CAROLINA' class = 'option_color'>NC-NORTH CAROLINA</option>";
		$StateList .= "<option value = 'ND-NORTH DAKOTA' class = 'option_color'>ND-NORTH DAKOTA</option>";
		$StateList .= "<option value = 'OH-OHIO' class = 'option_color'>OH-OHIO</option>";
		$StateList .= "<option value = 'OK-OKLAHOMA' class = 'option_color'>OK-OKLAHOMA</option>";
		
		$StateList .= "<option value = 'OR OREGON' class = 'option_color'>OR OREGON</option>";
		$StateList .= "<option value = 'PA PENNSYLVANIA' class = 'option_color'>PA PENNSYLVANIA</option>";
		$StateList .= "<option value = 'RI RHODE ISLAND' class = 'option_color'>RI RHODE ISLAND</option>";
		$StateList .= "<option value = 'SC SOUTH CAROLINA' class = 'option_color'>SC SOUTH CAROLINA</option>";
		$StateList .= "<option value = 'SD SOUTH DAKOTA' class = 'option_color'>SD SOUTH DAKOTA</option>";
		$StateList .= "<option value = 'TN TENNESSEE' class = 'option_color'>TN TENNESSEE</option>";
		$StateList .= "<option value = 'TX TEXAS' class = 'option_color'>TX TEXAS</option>";
		$StateList .= "<option value = 'UT UTAH' class = 'option_color'>UT UTAH</option>";
		$StateList .= "<option value = 'VT VERMONT' class = 'option_color'>VT VERMONT</option>";
		$StateList .= "<option value = 'VA VIRGINIA' class = 'option_color'>VA VIRGINIA</option>";
		$StateList .= "<option value = 'WA WASHINGTON' class = 'option_color'>WA WASHINGTON</option>";
		$StateList .= "<option value = 'WV WEST VIRGINIA' class = 'option_color'>WV WEST VIRGINIA</option>";
		
		$StateList .= "<option value = 'WI WISCONSIN' class = 'option_color'>WI WISCONSIN</option>";
		$StateList .= "<option value = 'WY WYOMING' class = 'option_color'>WY WYOMING</option>";
		$StateList .= "<option value = 'GU GUAM' class = 'option_color'>GU GUAM</option>";
		$StateList .= "<option value = 'PR PUERTO RICO' class = 'option_color'>PR PUERTO RICO</option>";
		$StateList .= "<option value = 'VI VIRGIN ISLANDS' class = 'option_color'>VI VIRGIN ISLANDS</option>";	
		
		return $StateList;
	}	
?>
