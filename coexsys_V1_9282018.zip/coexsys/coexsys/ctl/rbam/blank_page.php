<?php ob_start ();
	include("../conn.php");

?>
<?php
	
	
?>


<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">	
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title> Coexsys Time Accounting </title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

	<script src="js1/jquery.js"></script>
	<link href="datepicker/datepicker.css" rel="stylesheet">
	<script src="datepicker/bootstrap-datepicker.js"></script>
	

</head>

<body>
    
	<?php include("header.php"); ?>
	<section class="md-bg">
		<div class="container-fluid">
			
		</div>
	  
	</section>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script type="text/javascript">
	
	
	</script>
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>