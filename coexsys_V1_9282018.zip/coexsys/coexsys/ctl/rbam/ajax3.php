<?php
$mystatus = isset($_POST['mystatus'])?$_POST['mystatus']:'';
	if($mystatus=='convert')
	{
		echo "hi";
	}
?>