<?php
include('../conn.php');
?>
<?php
	
	if($_REQUEST['REQUEST'] == "SingleUserRecord")
	{
		
		$TableName = $_REQUEST['TableName'];
		$FieldName = $_REQUEST['FieldName'];
		$FieldValue = $_REQUEST['FieldValue'];		
		$Query = "select * from $TableName where $FieldName = $FieldValue";
		//echo json_encode($Query);
		$result = mysql_query ($Query);
		while($row = mysql_fetch_array($result))
		{
			$data[$TableName] = $row;
			if($TableName=='cxs_users')	
			{
				$psw = GetPassword($row['ENC_KEY']);
			}
			else if($TableName=='cxs_aliases')	
			{
				$WbsId = $row['WBS_ID'];
			}
		}
		if($TableName=='cxs_users')	
		{
			$data['cxs_users']['convertpsw']="";//$psw;
		}	
		else if($TableName=='cxs_aliases')	
		{
			//$WbsId = $row['WBS_ID'];
			$sql1 = "SELECT * from cxs_wbs where WBS_ID = $WbsId";
			$result1 = mysql_query($sql1);	
			$s= "";
			while($row1=mysql_fetch_array($result1))
			{
				if($row1['SEGMENT1']!='') $s = $row1['SEGMENT1'];				
				if($row1['SEGMENT2']!='') $s = $s.".".$row1['SEGMENT2'];
				if($row1['SEGMENT3']!='') $s = $s.".".$row1['SEGMENT3'];
				if($row1['SEGMENT4']!='') $s = $s.".".$row1['SEGMENT4'];
				if($row1['SEGMENT5']!='') $s = $s.".".$row1['SEGMENT5'];
				if($row1['SEGMENT6']!='') $s = $s.".".$row1['SEGMENT6'];
				if($row1['SEGMENT7']!='') $s = $s.".".$row1['SEGMENT7'];				
				if($row1['SEGMENT8']!='') $s = $s.".".$row1['SEGMENT8'];
				if($row1['SEGMENT9']!='') $s = $s.".".$row1['SEGMENT9'];
				if($row1['SEGMENT10']!='') $s = $s.".".$row1['SEGMENT10'];
				if($row1['SEGMENT11']!='') $s = $s.".".$row1['SEGMENT11'];
				if($row1['SEGMENT12']!='') $s = $s.".".$row1['SEGMENT12'];
				if($row1['SEGMENT13']!='') $s = $s.".".$row1['SEGMENT13'];
				if($row1['SEGMENT14']!='') $s = $s.".".$row1['SEGMENT14'];				
				if($row1['SEGMENT15']!='') $s = $s.".".$row1['SEGMENT15'];
			}	
				$data['cxs_aliases']['WBS']=$s;//$psw;
				//$data['cxs_aliases']['WBS']=$sql;//$psw;		
		}	
		echo json_encode($data);
	}
	
	$mystatus = isset($_POST['mystatus'])?$_POST['mystatus']:'';
	if($mystatus=='convert')
	{
		echo "hi";
	}
	//isset($_POST['name'])?$_POST['name']
?>