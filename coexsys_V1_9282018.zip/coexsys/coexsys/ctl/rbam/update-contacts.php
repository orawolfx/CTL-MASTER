<?php ob_start ();
	include("../conn.php");
	include("rbam-functions.php");
	check_login();
?>
<?php 
	$Display_InUse = "";
	if ($_SESSION['current-user-type'] == "RBAM-Admin")
	{
		$VIEW_SLA_permission = "Y";	
		$UpdateSiteContacts_permission = "Y";			
	}
	else
	{
		$VIEW_SLA_permission = getRoleAccessStatusByUser('VIEW_SLA',$_SESSION['user_id']);
		$UpdateSiteContacts_permission = getRoleAccessStatusByUser('UPDATE_SITE_CONTACTS',$_SESSION['user_id']);	
	}
	if($UpdateSiteContacts_permission=='N')
	{
		header('location:rbam.php');
	}	
	$LoginUserId = $_SESSION['user_id']; 	
	$PageName = "update-contacts.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$record_per_pageAddr = 5;
	$record_per_pageCont = 5;
	if (isset($_GET["pageAddr"]))
	{
		$pageAddr  = $_GET["pageAddr"];		
	}
	else
	{
		$pageAddr=1;
	}
	
	if (isset($_GET["pageCont"]))
	{
		$pageCont  = $_GET["pageCont"];
	}
	else
	{
		$pageCont=1;
	}
	
	$start_fromAddr = ($pageAddr-1) *  $record_per_pageAddr;
	$start_fromCont = ($pageCont-1) *  $record_per_pageCont;
	
	$insArr = array();
	
	$AddressListRows= 5;
	$ContactListRows = 5;
	$HeaderId = $SiteId;
	
	$IsUpdateCont = isset( $_POST['h_field_updateCont'] )? $_POST['h_field_updateCont']: "";	
	$TotalRowsCont = isset($_REQUEST['h_NumRowsCont'])?$_REQUEST['h_NumRowsCont']:0;
	
	$IsUpdateAddr = isset( $_POST['h_field_updateAddr'] )? $_POST['h_field_updateAddr']: "";	
	$TotalRowsAddr = isset($_REQUEST['h_NumRowsAddr'])?$_REQUEST['h_NumRowsAddr']:0;
		
	
	if($IsUpdateAddr =='Y' ) // save multiple contacts 
	{	
	/*	if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridAddr"] )? $_POST["h_field_headeridAddr"]: false;
		}	*/
		
		for($i=1;$i<=$TotalRowsAddr;$i++)
		{
			$Check_RecordAddr = isset( $_POST['inlineCheckboxAddr'.$i] )? $_POST['inlineCheckboxAddr'.$i]: false;
			if($Check_RecordAddr==1)
			{
				unset($insArr);
				$Post_AddressId = isset( $_POST['h_AddressId'.$i] )? $_POST['h_AddressId'.$i]: false;				
				$Text_Address1 = isset($_POST["Text_Address1_$i"] )? $_POST["Text_Address1_$i"]: false;
				$Text_Address2 = isset($_POST["Text_Address2_$i"] )? $_POST["Text_Address2_$i"]: false;
				$Text_Address3 = isset($_POST["Text_Address3_$i"] )? $_POST["Text_Address3_$i"]: false;
				$Text_City = isset($_POST["Text_City$i"] )? $_POST["Text_City$i"]: false;
				$Combo_State = isset($_POST["Combo_State$i"] )? $_POST["Combo_State$i"]: false;
				$Text_Country = isset($_POST["Text_Country$i"] )? $_POST["Text_Country$i"]: false;
				$Text_PostalCode = isset($_POST["Text_PostalCode$i"] )? $_POST["Text_PostalCode$i"]: false;
				$Checkbox_APrimary = isset($_POST["Checkbox_APrimary$i"] )? $_POST["Checkbox_APrimary$i"]: false;
				$Checkbox_AActive = isset($_POST["Checkbox_AActive$i"] )? $_POST["Checkbox_AActive$i"]: false;
				
				$insArr['ADDRESS1'] = $Text_Address1;
				$insArr['ADDRESS2'] = $Text_Address2;
				$insArr['ADDRESS3'] = $Text_Address3;
				$insArr['CITY'] = $Text_City;
				$insArr['STATE'] = $Combo_State;
				$insArr['COUNTRY'] = $Text_Country;
				$insArr['POSTAL_CODE'] = $Text_PostalCode;
				$insArr['PRIMARY_FLAG'] = ($Checkbox_APrimary==1)?"Y":"N";
				$insArr['ACTIVE_FLAG'] = ($Checkbox_AActive==1)?"Y":"N";	
				$insArr['LAST_UPDATED_BY']=$LoginUserId;   				
				updatedata("cxs_site_address",$insArr,"Where cxs_site_address.ADDRESS_ID = $Post_AddressId");		
			}
		}
		
		$ExistPrimaryFlagIdAddr = 0;
		$PrimaryFlagCounter = 0;
		$Prev_PrimaryFlagIdAddr="";
		$qry = "select * from cxs_site_address where SITE_ID = $HeaderId and PRIMARY_FLAG = 'Y' order by LAST_UPDATE_DATE  ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			if($PrimaryFlagCounter>0)
			{
				$Prev_PrimaryFlagIdAddr = $ExistPrimaryFlagIdAddr;
			}
			$ExistPrimaryFlagIdAddr  = $row['ADDRESS_ID'];			
			$PrimaryFlagCounter++;			
		}
		
		if ($PrimaryFlagCounter>1 && $Prev_PrimaryFlagIdAddr!='')
		{
			unset($insArr);
			$insArr['PRIMARY_FLAG'] = "N";
			$insArr['LAST_UPDATED_BY']=$LoginUserId;  
			updatedata("cxs_site_address",$insArr,"Where cxs_site_address.ADDRESS_ID = $Prev_PrimaryFlagIdAddr");	
		}		
	}
	
	
	if (isset($_POST['cmdAddAddressPopup'] ))
	{
		/*if ($HeaderId == "")
		{	
			$HeaderId = isset($_POST["h_field_headeridAddr"] )? $_POST["h_field_headeridAddr"]: false;
		}	*/
		$Text_Address1 = isset($_POST["Text_Address1"] )? $_POST["Text_Address1"]: false;
		$Text_Address2 = isset($_POST["Text_Address2"] )? $_POST["Text_Address2"]: false;
		$Text_Address3 = isset($_POST["Text_Address3"] )? $_POST["Text_Address3"]: false;
		$Text_City = isset($_POST["Text_City"] )? $_POST["Text_City"]: false;
		$Combo_State = isset($_POST["Combo_State"] )? $_POST["Combo_State"]: false;
		$Text_Country = isset($_POST["Text_Country"] )? $_POST["Text_Country"]: false;
		$Text_PostalCode = isset($_POST["Text_PostalCode"] )? $_POST["Text_PostalCode"]: false;
		$Checkbox_APrimary = isset($_POST["Checkbox_APrimary"] )? $_POST["Checkbox_APrimary"]: false;
		$Checkbox_AActive = isset($_POST["Checkbox_AActive"] )? $_POST["Checkbox_AActive"]: false;
		$Row_No  = 1;
		$ExistPrimaryFlagIdAddr = 0;
		$qry = "select * from cxs_site_address where SITE_ID = $HeaderId order by ROW_NO ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			//$Row_No = $row['ROW_NO'];
			if ($row['PRIMARY_FLAG']=="Y")
			{
				$ExistPrimaryFlagIdAddr  = $row['ADDRESS_ID'];
			}	
			$Row_No = $Row_No + 1;
		}
			
		unset($insArr);
		if($Text_Address1!='' || $Text_Address2 != '' || $Text_Address3 != '' || $Text_City!='' || $Combo_State != '' || $Text_Country != '' || $Text_PostalCode!='' || $Checkbox_APrimary != '' || $Checkbox_AActive != ''  )
		{
			$insArr['SITE_ID']=$SiteId;
			$insArr['ADDRESS1'] = $Text_Address1;
			$insArr['ADDRESS2'] = $Text_Address2;
			$insArr['ADDRESS3'] = $Text_Address3;
			$insArr['CITY'] = $Text_City;
			$insArr['STATE'] = $Combo_State;
			$insArr['COUNTRY'] = $Text_Country;
			$insArr['POSTAL_CODE'] = $Text_PostalCode;
			if ($Row_No==1)
			{
				$insArr['PRIMARY_FLAG'] = "Y";
			}
			else
			{
				$insArr['PRIMARY_FLAG'] = ($Checkbox_APrimary==1)?"Y":"N";
			}
			$insArr['ACTIVE_FLAG'] = ($Checkbox_AActive==1)?"Y":"N";					
			$insArr['ROW_NO'] = $Row_No; 
			$insArr['LAST_UPDATED_BY']=$LoginUserId;   
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;
			
			insertdata("cxs_site_address",$insArr);	
			
			if ($Checkbox_APrimary==1 && $ExistPrimaryFlagIdAddr > 0 && $Row_No > 1)
			{
				unset($insArr);
				$insArr['PRIMARY_FLAG'] = "N";
				$insArr['LAST_UPDATED_BY']=$LoginUserId;  
				updatedata("cxs_site_address",$insArr,"Where cxs_site_address.ADDRESS_ID = $ExistPrimaryFlagIdAddr");	
			}
			
		}
		//}
	}
	
	
	if($IsUpdateCont =='Y' ) // save multiple contacts 
	{	
		for($i=1;$i<=$TotalRowsCont;$i++)
		{
			$Check_Record = isset( $_POST['inlineCheckboxCont'.$i] )? $_POST['inlineCheckboxCont'.$i]: false;
			if($Check_Record==1)
			{
				
				unset($insArr);
				$Post_ContactId = isset( $_POST['h_ContactId'.$i] )? $_POST['h_ContactId'.$i]: false;				
				$Text_FirstName = isset($_POST["Text_FirstName$i"] )? $_POST["Text_FirstName$i"]: false;
				$Text_LastName = isset($_POST["Text_LastName$i"] )? $_POST["Text_LastName$i"]: false;			
				
				$Text_Phone = isset($_POST["Text_Phone$i"] )? $_POST["Text_Phone$i"]: false;
				$Text_Email = isset($_POST["Text_Email$i"] )? $_POST["Text_Email$i"]: false;			
				$Text_PhoneType = isset($_POST["Text_PhoneType$i"] )? $_POST["Text_PhoneType$i"]: false;
				$Text_Title = isset($_POST["Text_Title$i"] )? $_POST["Text_Title$i"]: false;			
				
				$Checkbox_CPrimary = isset($_POST["Checkbox_CPrimary$i"] )? $_POST["Checkbox_CPrimary$i"]: false;
				$Checkbox_CActive = isset($_POST["Checkbox_CActive$i"] )? $_POST["Checkbox_CActive$i"]: false;
				
				$insArr['FIRST_NAME'] = $Text_FirstName;
				$insArr['LAST_NAME'] = $Text_LastName;
				$insArr['PHONE'] = $Text_Phone;
				$insArr['EMAIL'] = $Text_Email;					
				$insArr['PHONE_TYPE'] = $Text_PhoneType;
				$insArr['TITLE'] = $Text_Title;
				$insArr['PRIMARY_FLAG'] = ($Checkbox_CPrimary==1)?"Y":"N";
				$insArr['ACTIVE_FLAG'] = ($Checkbox_CActive==1)?"Y":"N";					
				$insArr['LAST_UPDATED_BY']=$LoginUserId;   
				$insArr['SITE_ID']=$SiteId;
				
				updatedata("cxs_site_contacts",$insArr,"Where cxs_site_contacts.CONTACT_ID = $Post_ContactId");	
			}
		}
		
		$ExistPrimaryFlagIdCont = 0;
		$PrimaryFlagContCounter = 0;
		$Prev_PrimaryFlagIdCont="";
		$qry = "select * from cxs_site_contacts where SITE_ID = $HeaderId and PRIMARY_FLAG = 'Y' order by LAST_UPDATE_DATE  ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			if($PrimaryFlagContCounter>0)
			{
				$Prev_PrimaryFlagIdCont = $ExistPrimaryFlagIdCont;
			}
			$ExistPrimaryFlagIdCont  = $row['CONTACT_ID'];			
			$PrimaryFlagContCounter++;			
		}
		
		if ($PrimaryFlagContCounter>1 && $Prev_PrimaryFlagIdCont!='')
		{
			unset($insArr);
			$insArr['PRIMARY_FLAG'] = "N";
			$insArr['LAST_UPDATED_BY']=$LoginUserId;  
			updatedata("cxs_site_contacts",$insArr,"Where cxs_site_contacts.CONTACT_ID = $Prev_PrimaryFlagIdCont");	
		}		
	}
	
	if (isset($_POST['cmdAddContactPopup'] ))
	{
		
	/*	if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridCont"] )? $_POST["h_field_headeridCont"]: false;
		}	*/
		$Text_FirstName = isset($_POST["Text_FirstName"] )? $_POST["Text_FirstName"]: false;
		$Text_LastName = isset($_POST["Text_LastName"] )? $_POST["Text_LastName"]: false;
		$Text_Phone = isset($_POST["Text_Phone"] )? $_POST["Text_Phone"]: false;
		$Text_Email = isset($_POST["Text_Email"] )? $_POST["Text_Email"]: false;
		
		$Text_PhoneType = isset($_POST["Text_PhoneType"] )? $_POST["Text_PhoneType"]: false;
		$Text_Title = isset($_POST["Text_Title"] )? $_POST["Text_Title"]: false;		
		$Checkbox_CPrimary = isset($_POST["Checkbox_CPrimary"] )? $_POST["Checkbox_CPrimary"]: false;
		$Checkbox_CActive = isset($_POST["Checkbox_CActive"] )? $_POST["Checkbox_CActive"]: false;
		
		$Row_No  = 1;
		$ExistPrimaryFlagId = 0;
		$qry = "select * from cxs_site_contacts where SITE_ID = $HeaderId order by ROW_NO ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			//$Row_No = $row['ROW_NO'];
			if ($row['PRIMARY_FLAG']=="Y")
			{
				$ExistPrimaryFlagId  = $row['CONTACT_ID'];
			}			
			$Row_No = $Row_No + 1;
		}
			
		unset($insArr);
		if($Text_Phone!='' || $Text_Email != '' )
		{
			
			$insArr['SITE_ID'] = $HeaderId;
			$insArr['FIRST_NAME'] = $Text_FirstName;
			$insArr['LAST_NAME'] = $Text_LastName;
			$insArr['PHONE'] = $Text_Phone;
			$insArr['Email'] = $Text_Email;
			$insArr['PHONE_TYPE'] = $Text_PhoneType;
			$insArr['Title'] = $Text_Title;			
			if ($Row_No==1)
			{
				$insArr['PRIMARY_FLAG'] = "Y";
			}
			else
			{
				$insArr['PRIMARY_FLAG'] = ($Checkbox_CPrimary==1)?"Y":"N";
			}			
			$insArr['ACTIVE_FLAG'] = ($Checkbox_CActive==1)?"Y":"N";	
			
			
			//$insArr['SOCIAL_URL'] = $Text_Email;	
			//$insArr['SOCIAL_URL_LABEL'] = $Text_Email;	
			//$insArr['LAST_SESSION_ID'] = $Text_Email;	
			
			$insArr['ROW_NO'] = $Row_No; 
			$insArr['LAST_UPDATED_BY']=$LoginUserId;   
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;
			$insArr['SITE_ID']=$SiteId;
			insertdata("cxs_site_contacts",$insArr);		
			
			if ($Checkbox_CPrimary==1 && $ExistPrimaryFlagId > 0 && $Row_No > 1)
			{
				unset($insArr);
				$insArr['PRIMARY_FLAG'] = "N";
				$insArr['LAST_UPDATED_BY']=$LoginUserId;  
				updatedata("cxs_site_contacts",$insArr,"Where cxs_site_contacts.CONTACT_ID = $ExistPrimaryFlagId");	
			}
		}
	}
	
	
	if($HeaderId=="") // in the case when click on pagination buttons
	{
	/*	if (isset($_GET["hid"]))
		{
			$HeaderId = $_GET["hid"];
		}		*/
	}
	$StateList = StateListFun();
?>
<script type="text/javascript" >
	var TABLE_ROWAddr = 0;
	var TABLE_ROWCont = 0;
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Update Contacts";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
	
	function chkfldAddress()
	{
		var s1,s2,s3,s4,s5,s6,s7,s8,s9;
		s1 = s2= s3=s4=s5=s6=s7=s8=s9="";
		s1 = document.getElementById("Text_Address1").value;
		s2 = document.getElementById("Text_Address2").value;
		s3 = document.getElementById("Text_Address3").value;
		if (s1=='' && s2 == '' && s3 == '' && s4 == '' && s5 == '' && s6 == '' && s7 == '' && s8 == '' && s9 == '' )
		{
			alert("Do not keep all fields blank.");
			document.getElementById("Text_Address1").focus();
			return false;
		}
		
		s1 = document.getElementById("lblHeaderId").innerHTML;
		s1 = s1.trim();
		document.getElementById("h_field_headeridAddr").value = s1;
	}
	function chkfldContact()
	{
		if($("#Text_Phone").val()=="" && $("#Text_Email").val()=="")
		{
			alert("Please fill up atleast Phone / Email.");
			$("#Text_Phone").focus();
			return false;
		}
		if ( $("#Text_Email").val() != '' &&  !isEmailValid($("#Text_Email").val())) 
		{
			alert("Please enter valid email address.");
			document.getElementById("Text_Email").focus();
			return false;
		}	
	}
	
	function checkAllAddr()
	{
		var checkboxValue=document.getElementById('selectallAddr').checked;
		var i=1;
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			document.getElementById("inlineCheckboxAddr"+i).checked = checkboxValue;		
		}
		if( $('#cmdUpdateSelectedAddr').text()=="Update Selected")
		{
			$("#cmdCancel").attr('disabled',true);
		}
	}   
	function CheckBoxInlineAddr()
	{
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked == false)
			{
				document.getElementById('selectallAddr').checked = false;
			}
		}
	}
	function EditRecordAddr()
	{
		var flag_updaterecord=""; 
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		
		if (flag_updaterecord=="")
		{
			alert("Please Select Record For Update");
			document.getElementById("inlineCheckboxAddr1").focus();
			return false;
		}
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedAddr").innerHTML;			
			var flag1 = "";
			if (ButtonCaption != "Save")
			{
				
				document.getElementById("cmdUpdateSelectedAddr").innerHTML = "Save";
				
				$('#selectallAddr').hide();
					
				for(i=1;i<=TABLE_ROWAddr;i++)
				{
					if (document.getElementById("inlineCheckboxAddr"+i).checked )
					{
						ShowInputElementsAddr(i,false);
					}
					else
					{
						$('#inlineCheckboxAddr'+i).hide();
					}
				}
				$("#cmdCancel").attr('disabled',false);			
				$("#cmdExport").attr('disabled',true);
			
			}
			else
			{
				document.getElementById('h_field_updateAddr').value = 'Y';
				document.getElementById("h_NumRowsAddr").value = TABLE_ROWAddr;
				var sAddr1,sAddr2,sAddr3,sCity,sState,sCountry,sPostalcode,PrimaryCounter;
				var flag_final="";	
				var s1 = "";
				PrimaryCounter = 0;
				for(i=1;i<=TABLE_ROWAddr;i++)
				{
					if (document.getElementById("Checkbox_APrimary"+i).checked)
					{
						PrimaryCounter = PrimaryCounter+1;
					}
					if (document.getElementById("inlineCheckboxAddr"+i).checked )
					{
						sAddr1 = document.getElementById("Text_Address1_"+i).value;
						sAddr2 = document.getElementById("Text_Address2_"+i).value;
						sAddr3 = document.getElementById("Text_Address3_"+i).value;
						sCity = document.getElementById("Text_City"+i).value;
						sState = document.getElementById("Combo_State"+i).value;
						sCountry = document.getElementById("Text_Country"+i).value;
						sPostalcode = document.getElementById("Text_PostalCode"+i).value;
							
						 
						
					/*	sActive = document.getElementById("Checkbox_CActive"+i).checked;
						sAcceptText = document.getElementById("Checkbox_CAcceptText"+i).checked;
					*/	
						sAddr1 = sAddr1.trim();
						sAddr2 = sAddr2.trim();
						sAddr3 = sAddr3.trim();
						
						sCity = sCity.trim();
						sState = sState.trim();
						sCountry = sCountry.trim();
						sPostalcode = sPostalcode.trim();
						
						if (sAddr1 == "" && sAddr2 == "" && sAddr3 == "" && sCity == ""  && sState == "" && sCountry == "" && sPostalcode == "")
						{
							alert("Do not left all fields blanks.");
							document.getElementById("Text_Address1_"+i).focus();
							flag_final = "N";
							break;
						}
					}					
				}
				
				if (PrimaryCounter==0)
				{
					flag_final= "N";
					alert("One address can be primary.");	
					document.getElementById("Checkbox_APrimary1").focus();					
				}
				else if (PrimaryCounter>1)
				{
					flag_final = "N";
					alert("Only one primary at a time.");
					document.getElementById("Checkbox_APrimary1").focus();
				}
				if (flag_final=="" && PrimaryCounter==1)
				{
					Form2.submit();
				}
			}
		}
	}
	
	function ShowInputElementsAddr(i,flag)
	{
		//document.getElementById("Text_Address1_"+i).disabled = flag;
		$("#Text_Address1_"+i).attr("disabled",flag);
		document.getElementById("Text_Address2_"+i).disabled = flag;
		document.getElementById("Text_Address3_"+i).disabled = flag;
		document.getElementById("Text_City"+i).disabled = flag;
		document.getElementById("Combo_State"+i).disabled = flag;
		document.getElementById("Text_Country"+i).disabled = flag;
		document.getElementById("Text_PostalCode"+i).disabled = flag;		
		document.getElementById("Checkbox_APrimary"+i).disabled = flag;
		document.getElementById("Checkbox_AActive"+i).disabled = flag;
	}
	
	function ExportRecordAddr()
	{
		KEY= "ExportRecordAddr";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_AddressId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}						
		qry1 = 'order by ROW_NO';		
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportCreateResourceAddress&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("selectallAddr").focus();
		}
	}
	
	function checkAllCont()
	{
		var checkboxValue=document.getElementById('selectallCont').checked;
		var i=1;
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			document.getElementById("inlineCheckboxCont"+i).checked = checkboxValue;		
		}
		if( $('#cmdUpdateSelectedCont').text()=="Update Selected")
		{
			$("#cmdCancel1").attr('disabled',true);
		}
	} 
	function CheckBoxInlineCont()
	{
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked == false)
			{
				document.getElementById('selectallCont').checked = false;
			}
		}
	}	
	function EditRecordCont()
	{
		var flag_updaterecord=""; 		
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		
		if (flag_updaterecord=="")
		{
			alert("Please Select Record For Update");
			document.getElementById("inlineCheckboxCont1").focus();
			return false;
		}
		
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedCont").innerHTML;
			var flag1 = "";
			if (ButtonCaption != "Save")
			{
				
				document.getElementById("cmdUpdateSelectedCont").innerHTML = "Save";
				$('#selectallCont').hide();
				for(i=1;i<=TABLE_ROWCont;i++)
				{
					if (document.getElementById("inlineCheckboxCont"+i).checked )
					{
						ShowInputElementsCont(i,false);
					}
					else
					{
						$('#inlineCheckboxCont'+i).hide();
					}
				}
				$("#cmdCancel1").attr('disabled',false);			
				$("#cmdExport1").attr('disabled',true);
			}
			else
			{
				document.getElementById('h_field_updateCont').value = 'Y';
				document.getElementById("h_NumRowsCont").value = TABLE_ROWCont;
				var sPhone,sEmail,sPrimary,sActive,sAcceptText;
				var flag_final="";	
				var s1 = "";
				PrimaryCounter = 0;
				for(i=1;i<=TABLE_ROWCont;i++)
				{
					if (document.getElementById("Checkbox_CPrimary"+i).checked)
					{
						PrimaryCounter = PrimaryCounter+1;
					}
					if (document.getElementById("inlineCheckboxCont"+i).checked )
					{
						sPhone = document.getElementById("Text_Phone"+i).value;
						sEmail = document.getElementById("Text_Email"+i).value;
						
						
					/*	sActive = document.getElementById("Checkbox_CActive"+i).checked;
						sAcceptText = document.getElementById("Checkbox_CAcceptText"+i).checked;
					*/	
						sPhone = sPhone.trim();
						sEmail = sEmail.trim();
						
						if (sPhone == "" && sEmail == "" )
						{
							alert("Please fill out at least phone or email.");
							document.getElementById("Text_Phone"+i).focus();
							flag_final = "N";
							break;
						}
						if(sEmail!='')
						{
							if (!isEmailValid(sEmail)) 
							{
								alert("Please enter valid user name.");
								$("#Text_Email"+i).focus();
								return false;
							}
						}
					}					
				}		
				if (PrimaryCounter==0)
				{
					flag_final= "N";
					alert("One contact can be primary.");	
					document.getElementById("Checkbox_CPrimary1").focus();					
				}
				else if (PrimaryCounter>1)
				{
					flag_final = "N";
					alert("Only one primary at a time.");
					document.getElementById("Checkbox_CPrimary1").focus();
				}	
				if (flag_final=="" && PrimaryCounter==1)
				{
					s1 = "<?php echo $HeaderId; ?>";					
					//location.href="create-new-resource.php?hid="+s1;
					Form3.submit();
				}
			}
		}
	}
	
	function ShowInputElementsCont(i,flag)
	{
		document.getElementById("Text_FirstName"+i).disabled = flag;
		document.getElementById("Text_LastName"+i).disabled = flag;		
		document.getElementById("Text_Phone"+i).disabled = flag;
		document.getElementById("Text_Email"+i).disabled = flag;
		document.getElementById("Text_PhoneType"+i).disabled = flag;
		document.getElementById("Text_Title"+i).disabled = flag;
		document.getElementById("Checkbox_CPrimary"+i).disabled = flag;
		document.getElementById("Checkbox_CActive"+i).disabled = flag;				
	}
	
	function ExportRecordCont()
	{	
		KEY= "ExportRecordCont";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_resourceContactId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		
		//qry1 = '<?php echo $SQueryOrderBy; ?>';					
		qry1 = 'order by ROW_NO';					
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportCreateResourceContact&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("selectallCont").focus();
		}
	}
	function SelectValue(ElementId,Value)
	{
		$("#"+ElementId).val(Value);
	}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">



<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.alert-success { color: #e61d16; }
	.col-sm-3.ss {
    width: auto;
}
	.option_color { color: #000; 	}
</style>
<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">

<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>

<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<script src="../js/jsfunctions.js"></script>

</head>

<body>
<?php include("header.php"); ?>
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
			<li> <a href="#"> Billing & Payment </a></li>
			<li> <a href="#"> Update Contacts  </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='rbam.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
		  <a type="button" id="cmdViewSLA" name="cmdViewSLA" class="btn btn-primary btn-style2" <?php if($VIEW_SLA_permission=='Y'){ ?>href="test.pdf"<?php }else{ ?>disabled="disabled"<?php } ?> target="_blank">View SLA</a>
        </div>
      </div>
      <!-- inner work-->
	<!-- modals start -->
	<form id = "AddressForm" name = "AddressForm" method="post" action="" onsubmit = "return chkfldAddress()">
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalAddAddress" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Add New Address </h4>
					</div>
					<div class="modal-body"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-3 form-group">
								  <label> Address 1 </label> <label id = "lblHeaderId" style = "display:none" > <?php echo $HeaderId;?> </label>
								  <input type="text" id = "Text_Address1" name = "Text_Address1" class="form-control"  placeholder="" maxlength="50">
								</div>
								<div class="col-sm-3 form-group">
								  <label> Address 2 </label>
								  <input type="text" id = "Text_Address2" name = "Text_Address2" class="form-control" placeholder="" maxlength="100">
								</div>
								<div class="col-sm-3 form-group cus-form-ico">
								  <label> Address 3 </label>
								  <input type="text" id = "Text_Address3" name = "Text_Address3" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-3 form-group cus-form-ico">
								  <label> City </label>
								  <input type="text" id = "Text_City" name = "Text_City" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-3 form-group cus-form-ico">
								  <label> State </label>								  
								  <select id = "Combo_State" name = "Combo_State" class = "form-control">
										<?php echo $StateList; ?>
								  <select>
								</div>
								
								<div class="col-sm-3 form-group cus-form-ico">
								  <label> Country </label>
								  <input type="text" id = "Text_Country" name = "Text_Country" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-3 form-group cus-form-ico">
								  <label> Postal Code </label>
								  <input type="text" id = "Text_PostalCode" name = "Text_PostalCode" class="form-control" placeholder="" maxlength="40">
								</div>
								
							<!--	<div class="col-sm-3 form-group cus-form-ico ">
									<div class="checkbox"> &nbsp;&nbsp;&nbsp;
									</div>
									<div class="checkbox">
										<label><input type="checkbox" id = "Checkbox_APrimary" name = "Checkbox_APrimary"  value="1" >  Primary </label> 		
										<label>&nbsp;</label>			
										<label><input type="checkbox" id = "Checkbox_AActive" name = "Checkbox_AActive"  value="1" >  Active </label> 	
									</div>
								</div> -->	
								<div class="col-sm-3 form-group cus-form-ico ss">
									<label> Primary  </label>
									<input type="checkbox" class="form-control"  id = "Checkbox_APrimary" name = "Checkbox_APrimary" value="1">
								</div>
								<div class="col-sm-3 form-group cus-form-ico ss">
									<label> Active   </label>
									<input type="checkbox" class="form-control" id = "Checkbox_AActive" name = "Checkbox_AActive"  value="1">
								</div>		
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<button type="submit" id = "cmdAddAddressPopup"  name = "cmdAddAddressPopup" class="btn btn-primary btn-style"> Add Address </button>
						<input type="hidden" id="h_field_headeridAddr" name="h_field_headeridAddr" value="">
					</div>
				</div>
			</div>
		</div>
	</form>
	<!-- modals end -->
	
	
	<!-- modals start -->
	<form id = "ContactForm" name = "ContactForm" method="post" action="" onsubmit = "return chkfldContact()" >
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalAddContact" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Add New Contact </h4>
					</div>
					<div class="modal-body"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								
								<div class="col-sm-3 form-group">
									<label> First Name  </label>
									<input type="text" id = "Text_FirstName" name = "Text_FirstName" class="form-control" placeholder="" maxlength="15">
								</div>
								<div class="col-sm-3 form-group">
									<label>  Last Name  </label>
									<input type="text" id = "Text_LastName" name = "Text_LastName" class="form-control" placeholder="" maxlength="50">
								</div>
								<div class="col-sm-3 form-group ">
									<label>  Phone   </label>
									<input type="text" id = "Text_Phone" name = "Text_Phone" class="form-control" placeholder="" maxlength="50">
								</div>
								<div class="col-sm-3 form-group cus-form-ico">
									<label> Email   </label>
									<input type="text" id = "Text_Email" name = "Text_Email"  class="form-control" placeholder="" maxlength="200">
								</div>
								<div class="col-sm-3 form-group cus-form-ico">
									<label> Phone Type   </label>
									<input type="text" id = "Text_PhoneType" name = "Text_PhonePhone" class="form-control" placeholder="" maxlength="40">
								</div>
								<div class="col-sm-3 form-group cus-form-ico">
									<label> Title   </label>
									<input type="text" id = "Text_Title" name = "Text_Title" class="form-control" placeholder="" maxlength="15">
								</div>
								<!--<div class="col-sm-3 form-group cus-form-ico">
									<label> Primary   </label>
									<input type="text" id = "Text_Primary" name = "Text_Primary" class="form-control" placeholder="" maxlength="1">
								</div>
								<div class="col-sm-3 form-group cus-form-ico">
									<label> Active  </label>
									<input type="text" class="form-control" placeholder="" maxlength="1">
								</div>							-->
								
								<div class="col-sm-3 form-group cus-form-ico ss">
									<label> Primary  </label>
									<input type="checkbox" class="form-control" id = "Checkbox_CPrimary" name = "Checkbox_CPrimary" value = "1">
									
								</div>
								<div class="col-sm-3 form-group cus-form-ico ss">
									<label> Active   </label>
									<input type="checkbox" class="form-control" id = "Checkbox_CActive" name = "Checkbox_CActive" value = "1">
								</div>
								
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<input type="hidden" id="h_field_headeridCont" name="h_field_headeridCont" value="">
						<button type="submit" id = "cmdAddContactPopup"  name = "cmdAddContactPopup" class="btn btn-primary btn-style"> Add Contact </button>
					</div>
				</div>
			</div>
		</div>
	</form>
	<!-- modals end -->
	
		<div class="cont-box">
			<div class="pge-hd">
				<h2 class="sec-title"  > 
					<label id="Label_Title">Update Contacts</label>  
					<label class = "fright" style = "font-size: 12px; margin-right : 40px;"> <input type="checkbox" id="Check_InUse" name="Check_InUse" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled> In Use </label> 
				</h2>
			</div>
			<div class="data-bx">
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>                                        
								<th> Site Code
									<a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
								</th>
								<th> Site Name 
									<a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
								</th>
								<th> Creation Date
									<a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
								</th>
								<th> Number of users
									<a href="#" class="sort-bx"> <i class="fa fa-sort"></i></a>
								</th>                                        
								<th> Channel (Buy oy Try) </th>
								<th> Last Update Date </th>
								<th> Last Updated BY </th>

							</tr>
						</thead>
						<tbody>
							<?php								
								$qry = "Select * from cxs_sites where SITE_ID = $SiteId";
						//echo	$qry = "Select cxs_sites.*,cxs_users.RESOURCE_ID from cxs_sites inner join cxs_users on cxs_users.USER_ID = cxs_sites.USER_ID left join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID where cxs_sites.SITE_ID = $SiteId";
								$result = mysql_query($qry);
								while($row = mysql_fetch_array($result))
								{	?>
									<tr>
										<td><?php echo $row['SITE_CODE']; ?> </td>
										<td><?php echo $row['SITE_NAME']; ?> </td>
										<td><?php echo date('m/d/Y',strtotime($row['CREATION_DATE'])); ?> </td>
										<td><?php echo $row['SITE_NAME']; ?> </td>
										<td><?php echo "Try"; ?> </td>
										<td><?php echo date('m/d/Y h:m',strtotime($row['UPDATED_DATE'])); ?> </td>
										<td><?php echo "";//$row['LAST_UPDATED_BY']; ?> </td>												
									</tr>		
						<?php	}
							?>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="pge-hd">
				<h2 class="sec-title"> Addresses </h2>
			</div>
			
			<div class="row">
				<h4 class="text-center" id="addr_msg_section"><?php echo $addr_msg; ?></h4>
			</div>
			
			<div class="fleft two">
				<button type="button" class="btn-style btn" <?php if($UpdateSiteContacts_permission=='Y'){ ?> id="cmdUpdateSelectedAddr" name="cmdUpdateSelectedAddr" onclick='EditRecordAddr();'<?php } else { ?> disabled = disabled <?php } ?>> Update selected </button>
				<button type="button" class="btn-style btn" id="cmdExport" name="cmdExport" onclick='ExportRecordAddr();' > Export </button>
				<button type="button" class="btn-style btn" id="cmdCancel" name="cmdCancel" disabled="disabled"> Cancel </button>
			</div>
			
			<div class="fright cr-user">				
				<button type="button" id = "cmdAddAddress" name = "cmdAddAddress" class="btn btn-primary btn-style" data-toggle="modal" data-target="#ModalAddAddress"  <?php  echo ($HeaderId!='')?"":"disabled"; ?>>  Create New </button> 
			</div>
		
			<form class="form" id="Form2" name="Form2" action="" method="POST" >
				<div class="detail-form2 "> 
										
					<div class="data-bx">					
						<div class="table-responsive">						
							<table id = "tableAddressList" name = "tableAddressList" class="table table-bordered mar-cont ">
							  <thead>
								<tr>
									<th width="3%" class="check-bx "><input type="checkbox" id="selectallAddr" onchange="checkAllAddr()"></th>
									<th width="15%"> Address 1 </i></a> </th>
									<th width="15%">Address 2 </i></a></th>
									<th width="10%">Address 3 </i></a></th>
									<th width="10%">City </i></a></th>                      
									<th width="15%">State </i></a></th>
									<th width="10%">Country </i></a></th>
									<th width="9%">Postal Code </i></a></th>
									<th width="5%">Primary </i></a></th>
									<th width="3%">Active </i></a></th>
									<th width="5%"> </th>
								</tr>
							  </thead>
							  <tbody>
								<?php 
									if($HeaderId != '')
									{
									$i=1;
									$qry2 = "select cxs_site_address.*,cxs_users.USER_NAME as CreatedBy from cxs_site_address inner join cxs_users on cxs_users.USER_ID = cxs_site_address.CREATED_BY where cxs_site_address.SITE_ID = $HeaderId order by cxs_site_address.ROW_NO";
									$selectQueryForAddrPages  = $qry2;
									$qry2 = $qry2." limit $start_fromAddr , $record_per_pageAddr";
									$result2 = mysql_query($qry2);
									while ($row2 = mysql_fetch_array($result2))									
									{ 
										$DisplayAddressId  = $row2['ADDRESS_ID']; 
										$Display_Address1 = $row2['ADDRESS1'];
										$Display_Address2 = $row2['ADDRESS2'];
										$Display_Address3 = $row2['ADDRESS3'];										
										$Display_City = $row2['CITY'];
										$Display_State = $row2['STATE'];
										$Display_Country = $row2['COUNTRY'];										
										$Display_PostalCode = $row2['POSTAL_CODE'];
										$Display_PrimaryAddr = $row2['PRIMARY_FLAG'];
										$Display_ActiveAddr = $row2['ACTIVE_FLAG'];
										
										$Display_CreatedByNameAddr	= $row2['CreatedBy'];	
										$Display_CreationDateAddr = date('m/d/Y h:i:sa', strtotime($row2['CREATION_DATE']));
										
										$UpdatedByAddr = $row2['LAST_UPDATED_BY'];
										$Display_UpdatedByNameAddr = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedByAddr");							
										$Display_LastUpdateAddr = date('m/d/Y h:i:sa', strtotime($row2['LAST_UPDATE_DATE']));
									?>
									<tr>
										<td class="check-bx ">
											<input type="checkbox" id="<?php echo "inlineCheckboxAddr$i"; ?>" name="<?php echo "inlineCheckboxAddr$i"; ?>" value="1" onchange="CheckBoxInlineAddr()" >
											<input type="hidden" id = <?php echo "h_AddressId".$i; ?> name = <?php echo "h_AddressId".$i; ?> value = "<?php echo $DisplayAddressId; ?>">
										</td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address1_".$i ?>" name = "<?php echo "Text_Address1_".$i ?>" value = "<?php echo $Display_Address1; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address2_".$i ?>" name = "<?php echo "Text_Address2_".$i ?>" value = "<?php echo $Display_Address2; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address3_".$i ?>" name = "<?php echo "Text_Address3_".$i ?>" value = "<?php echo $Display_Address3; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_City".$i ?>" name = "<?php echo "Text_City".$i ?>" value = "<?php echo $Display_City; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>                    
										<td>
										<div class="form-group">
										  <!--<input type="text" id = "<?php echo "Text_State".$i ?>" name = "<?php echo "Text_State".$i ?>" value = "<?php echo $Display_State; ?>" class="form-control" placeholder="" maxlength="25" disabled>-->
										  <select id = "<?php echo "Combo_State".$i ?>" name = "<?php echo "Combo_State".$i ?>" class = "form-control option_color" disabled>
												<?php echo $StateList; ?>
										  <select>
										</div>
										<script>
											SelectValue("<?php echo "Combo_State".$i ?>","<?php echo $Display_State; ?>");
										</script>
										</td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Country".$i ?>" name = "<?php echo "Text_Country".$i ?>" value = "<?php echo $Display_Country; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_PostalCode".$i ?>" name = "<?php echo "Text_PostalCode".$i ?>" value = "<?php echo $Display_PostalCode; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_APrimary".$i ?>" name = "<?php echo "Checkbox_APrimary".$i ?>" value="1" <?php echo ($Display_PrimaryAddr=="Y")?"checked":"";  ?> maxlength="2" disabled></td>
										<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_AActive".$i ?>" name = "<?php echo "Checkbox_AActive".$i ?>"  value="1" <?php echo ($Display_ActiveAddr=="Y")?"checked":"";  ?> maxlength="2" disabled></td>
										<td>
											<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
											Created By: <?php echo $Display_CreatedByNameAddr; ?> <br> Updated By: <?php echo $Display_UpdatedByNameAddr; ?> 
											<br> Creation Date: <?php echo $Display_CreationDateAddr; ?> <br> Last Update Date: <?php echo $Display_LastUpdateAddr; ?>"> <i class=" fa fa-eye"></i> </button>
										</td>
									</tr>     
								<?php 
									$i=$i+1;
									}
									}
								?>	
							  </tbody>
							</table>
						</div>
					</div>					
					<!-- pagination start-->
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php
										if($HeaderId!='')
										{
											//echo $selectQueryForAddrPages;
											$RunDepQuery=mysql_query($selectQueryForAddrPages);
											$num_recordsAddr = mysql_num_rows($RunDepQuery);
											$total_pagesAddr= ceil($num_recordsAddr/$record_per_pageAddr);
											if (($pageAddr-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo ($pageAddr-1); ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pagesAddr;$i++){ ?>
											<li class="<?php echo ($pageAddr==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($pageAddr==$i){echo 'background-color: #337ab7';} ?>" href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo $i;?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($pageAddr+1)>$total_pagesAddr){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo ($pageAddr+1); ?>">&raquo;</a></li>
													  <?php }
										}
													  ?>

								  </ul>
								</div>
							</div>
							<!-- pagination end -->
				</div>	
				<input type="hidden" id="h_field_updateAddr" name="h_field_updateAddr" value="">
				<input type="hidden" id="h_NumRowsAddr" name="h_NumRowsAddr" value="0"/>	
				<input type="hidden" id="h_field_headeridAddr" name="h_field_headeridAddr" value="<?php echo $HeaderId; ?>">	
			</form>	
				
			
			
			<form id = "Form3" name = "Form3" action="" method="POST">
				<div class="detail-form2 upp-form  ">
					<div class="fleft two">						
						<button type="button" class="btn-style btn" <?php if($UpdateSiteContacts_permission=='Y'){ ?> id="cmdUpdateSelectedCont" name="cmdUpdateSelectedCont" onclick= 'EditRecordCont();'<?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>
						<button type="button" class="btn-style btn" id="cmdExport1" name="cmdExport1" onclick= 'ExportRecordCont()'> Export </button>
						<button type="button" class="btn-style btn" id="cmdCancel1" name="cmdCancel1" disabled="disabled"> Cancel </button>
					</div>	
					<div class="fright" >
						<!--  <label  style = "padding-top:28px;"> &nbsp; </label>-->
						<button type="button"   id = "cmdAddContact" name = "cmdAddContact" class="btn btn-style btn-primary" data-toggle="modal" data-target="#ModalAddContact" <?php  echo ($HeaderId!='')?"":"disabled"; ?> >  Create New </button>  						  
					</div>
					
					<div class="data-bx">					
						<div class="table-responsive">							
							<table id = "tableContactList" name = "tableContactList"  class="table table-bordered mar-cont">
							  <thead>
								<tr>
									<th width="5%" class="check-bx "><input type="checkbox" id="selectallCont" onchange="checkAllCont()"></th>									
									<th width="20%">First Name</th>
									<th width="20%">Last Name</th>
									<th width="10%">Phone</th>
									<th width="15%">Email</th>
									<th width="10%">Phone Type</th>
									<th width="10%">Title</th>
									<th width="5%">Primary</th>
									<th width="5%">Active</th>
									<th width="5%"></th>
								</tr>
							  </thead>
							  <tbody>
								
								<?php 
									if($HeaderId != '')
									{ 
									$i=1;
									$qry2 = "select cxs_site_contacts.*,cxs_users.USER_NAME as CreatedBy  from cxs_site_contacts inner join cxs_users on cxs_users.USER_ID = cxs_site_contacts.CREATED_BY where cxs_site_contacts.SITE_ID = $HeaderId order by ROW_NO";
									$selectQueryForContPages  = $qry2;
									$qry2 = $qry2." limit $start_fromCont , $record_per_pageCont";
									$result2 = mysql_query($qry2);
									while ($row2 = mysql_fetch_array($result2))									
									{ 
										$DisplayContactId  = $row2['CONTACT_ID']; 										
										$Display_PrimaryCont = $row2['PRIMARY_FLAG'];
										$Display_ActiveCont = $row2['ACTIVE_FLAG'];
										$Display_AcceptTextCont = $row2['ACCEPTS_TEXTS_FLAG'];
										
										
										$Display_CreatedByNameCont	= $row2['CreatedBy'];	
										$Display_CreationDateCont = date('m/d/Y h:i:sa', strtotime($row2['CREATION_DATE']));										
										$UpdatedByCont		= $row2['LAST_UPDATED_BY'];
										$Display_UpdatedByNameCont = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedByCont");							
										$Display_LastUpdateCont = date('m/d/Y h:i:sa', strtotime($row2['LAST_UPDATE_DATE']));
									?>
								<tr>
									<td class="check-bx ">
										<input type="checkbox" id="<?php echo "inlineCheckboxCont$i"; ?>" name="<?php echo "inlineCheckboxCont$i"; ?>" value="1" onchange = "CheckBoxInlineCont()">
										<input type="hidden" id = <?php echo "h_ContactId".$i; ?> name = <?php echo "h_ContactId".$i; ?> value = "<?php echo $DisplayContactId; ?>">
									</td>
									<td>
										<div class="form-group">
											<input type="text" id = "<?php echo "Text_FirstName".$i ?>" name = "<?php echo "Text_FirstName".$i ?>" value = "<?php echo $row2['FIRST_NAME']; ?>" class="form-control" maxlength="25" disabled>
										</div>
									</td>
									
									<td>
										<div class="form-group">
											<input type="text" id = "<?php echo "Text_LastName".$i ?>" name = "<?php echo "Text_LastName".$i ?>" value = "<?php echo $row2['LAST_NAME']; ?>" class="form-control"  maxlength="25" disabled>
										</div>
									</td>
									
									<td>
										<div class="form-group">
											<input type="text" id = "<?php echo "Text_Phone".$i ?>" name = "<?php echo "Text_Phone".$i ?>" value = "<?php echo $row2['PHONE']; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div>
									</td>
									<td>
										<div class="form-group">
										  <input type="text" id = "<?php echo "Text_Email".$i ?>" name = "<?php echo "Text_Email".$i ?>" value = "<?php echo $row2['EMAIL']; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div>
									</td>
									<td>
										<div class="form-group">
										  <input type="text" id = "<?php echo "Text_PhoneType".$i ?>" name = "<?php echo "Text_PhoneType".$i ?>" value = "<?php echo $row2['PHONE_TYPE']; ?>" class="form-control" maxlength="25" disabled>
										</div>
									</td>
									<td>
										<div class="form-group">
										  <input type="text" id = "<?php echo "Text_Title".$i ?>" name = "<?php echo "Text_Title".$i ?>" value = "<?php echo $row2['TITLE']; ?>" class="form-control" maxlength="25" disabled>
										</div>
									</td>
									<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_CPrimary".$i ?>" name = "<?php echo "Checkbox_CPrimary".$i ?>" value="1" <?php echo ($Display_PrimaryCont=="Y")?"checked":"";?> maxlength="2" disabled></td>
									<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_CActive".$i ?>" name = "<?php echo "Checkbox_CActive".$i ?>" value="1" <?php echo ($Display_ActiveCont=="Y")?"checked":"";?> maxlength="2" disabled></td>									
									
									<td>
										<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
										Created By: <?php echo $Display_CreatedByNameCont; ?> <br> Updated By: <?php echo $Display_UpdatedByNameCont; ?> 
										<br> Creation Date: <?php echo $Display_CreationDateCont; ?> <br> Last Update Date: <?php echo $Display_LastUpdateCont; ?>"> <i class=" fa fa-eye"></i> </button>
									</td>
								</tr>
								<?php 
										$i=$i+1;
									}	
								}	
								?>
							  </tbody>
							</table>
						</div>
					</div>
				
					<!-- pagination start-->
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php
										if($HeaderId!='')
										{
											//echo $selectQueryForContPages;
											$RunDepQuery=mysql_query($selectQueryForContPages);
											$num_recordsCont = mysql_num_rows($RunDepQuery);
											$total_pagesCont= ceil($num_recordsCont/$record_per_pageCont); 
											if (($pageCont-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo ($pageCont-1); ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pagesCont;$i++){ ?>
											<li class="<?php echo ($pageCont==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($pageCont==$i){echo 'background-color: #337ab7';} ?>" href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo $i;?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($pageCont+1)>$total_pagesCont){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo ($pageCont+1); ?>">&raquo;</a></li>
											<?php } 
										}	
										?>

								  </ul>

								</div>
							</div>
							<!-- pagination end -->
					
				</div>
				<input type="hidden" id="h_field_updateCont" name="h_field_updateCont" value="">
				<input type="hidden" id="h_NumRowsCont" name="h_NumRowsCont" value="0"/>	
				<!--<input type="hidden" id="h_field_headeridCont" name="h_field_headeridCont" value="<?php echo $HeaderId; ?>">-->
			</form>
			
			
		  </div>		
    </div>
  </div>
</section>


<script type="text/javascript">
	
	$(document).ready(function() 
	{													
		$(function() 
		{
			myFunction();				
		});											
	});


function myFunction()
{
	TABLE_ROWAddr = document.getElementById("tableAddressList").rows.length;				
	TABLE_ROWAddr=TABLE_ROWAddr-1;//remove header row from count
	
	TABLE_ROWCont = document.getElementById("tableContactList").rows.length;				
	TABLE_ROWCont=TABLE_ROWCont-1;//remove header row from count 	
}
	
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;											
					window.open('downloaddata.php?r=holiday-calendars', '_blank');
				}
				else if(KEY == "ExportRecordCont")
				{
					var str = http_request.responseText;
					window.open('downloaddata.php?r=new-resource-contacts', '_blank');										
				}				
				else if(KEY == "ExportRecordAddr")
				{
					var str = http_request.responseText;											
					window.open('downloaddata.php?r=new-resource-address', '_blank');
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}
	
	$("#cmdCancel").click(function()
	{
		var i=1;
		
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			$('#inlineCheckboxAddr'+i).show();
			
			if (document.getElementById("inlineCheckboxAddr"+i).checked )
			{
				$("#inlineCheckboxAddr"+i).prop('checked' , false);
				ShowInputElementsAddr(i,true);
			}
		}
		
		$('#cmdUpdateSelectedAddr').text('Update Selected');
		$("#cmdExport").attr('disabled',false);
		$("#cmdCancel").attr('disabled',true);
		$('#selectallAddr').prop('checked',false);
		$('#selectallAddr').show();		
	});	
	
	$("#cmdCancel1").click(function()
	{
		var i=1;
		
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			$('#inlineCheckboxCont'+i).show();
			
			if (document.getElementById("inlineCheckboxCont"+i).checked )
			{
				$("#inlineCheckboxCont"+i).prop('checked' , false);
				ShowInputElementsCont(i,true);
			}
		}
		
		$('#cmdUpdateSelectedCont').text('Update Selected');
		$("#cmdExport1").attr('disabled',false);
		$("#cmdCancel1").attr('disabled',true);
		$('#selectallCont').prop('checked',false);
		$('#selectallCont').show();		
	});	
	
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 

</body>
</html>