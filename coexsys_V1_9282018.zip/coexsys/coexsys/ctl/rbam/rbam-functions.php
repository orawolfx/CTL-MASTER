<?php
//include("../conn.php");
$RecordsPerPage = 25;
$ModuleName = "Access Management";



function getSettingVal($field_name)
{
	$SiteId = $_SESSION['user-siteid'];
	$sql_ss = "select $field_name from cxs_site_settings where SITE_ID='$SiteId'";
	$res_ss = mysql_query($sql_ss);
	$row_ss = mysql_fetch_array($res_ss);	   
	return $row_ss[0];
}

function getRoleAccessStatusByUser($field_name,$user_id)
{
	$sql_ss = "select $field_name from cxs_users,cxs_am_roles where cxs_users.ROLE_ID = cxs_am_roles.ROLE_ID and USER_ID='".$user_id."'";
	$res_ss = mysql_query($sql_ss);
	$row_ss = mysql_fetch_array($res_ss);
	   
	return $row_ss[0];
}

function getTimeAccountingModuleStatusByUser($field_name,$module_name,$user_id)
{
	   $sql_chk="select cxs_resources.RESOURCE_GROUP_ID as RESOURCE_GROUP_ID from cxs_users,cxs_resources where cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID and USER_ID='".$user_id."'";
	   $res_chk=mysql_query($sql_chk);
	   $row_chk=mysql_fetch_array($res_chk);
	   
	   if($row_chk['RESOURCE_GROUP_ID']=='0')
	   {
			 $sql="select $field_name from cxs_ta_modules where USER_ID='".$user_id."' and MODULE_NAME='".$module_name."'";
			 $res = mysql_query($sql);
			 if(mysql_num_rows($res)>0)
			 {
			 	 $row = mysql_fetch_array($res);
			 	 return $row[0];
			 }
			 else
			 {
			 	 return 'N';
			 }	 
	   }
	   else
	   {
			$sql="select $field_name from cxs_ta_modules where RESOURCE_GROUP_ID='".$row_chk['RESOURCE_GROUP_ID']."' and MODULE_NAME='".$module_name."'";
			$res = mysql_query($sql);
			if(mysql_num_rows($res)>0)
			{
			 	 $row = mysql_fetch_array($res);
			 	 return $row[0];
			}
			else
			{
				return 'N';
			}	
	   }	   
	   
}
?>