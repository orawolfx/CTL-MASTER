<?php ob_start ();
 
include("../conn.php");
include("rbam-functions.php");
check_login();

?>
<?php
	if ($_SESSION['current-user-type'] == "RBAM-Admin")
	{
		$CREATE_PRIV_ua_PERMISSION = "Y";
		$UPDATE_PRIV_ua_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('CREATE_NEW_USER',$_SESSION['user_id']);	
		$UPDATE_PRIV_ua_PERMISSION = getRoleAccessStatusByUser('UPDATE_ONLY',$_SESSION['user_id']);
	}							
	if($CREATE_PRIV_ua_PERMISSION!='Y' &&  $UPDATE_PRIV_ua_PERMISSION!='Y')
	{
		header('location:rbam.php');
	}
	$HeaderId = "";
	if (isset($_GET["hid"]))
	{
		$HeaderId  = $_GET["hid"];	
	}	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "users-administration-create.php";
	$SiteId = $_SESSION['user-siteid'];	
	
	if (isset($_POST['cmdCreateUser'] ))
	{
		$Text_UserName  = isset($_POST['h_username'] )? $_POST['h_username']: false;
		$Text_Password  = isset($_POST['Text_Password'] )? $_POST['Text_Password']: false;

		$Pass = GetPassword($_POST['Text_Password']);		
		$Text_ResourceId  = isset($_POST['Text_ResourceId'] )? $_POST['Text_ResourceId']: false;
		$DTPicker_StartDate = isset($_POST['DTPicker_StartDate'] )? $_POST['DTPicker_StartDate']: false;
		$DTPicker_EndDate= isset($_POST['DTPicker_EndDate'] )? $_POST['DTPicker_EndDate']: false;
	//	$Combo_PasswordSecurityRules = isset($_POST['Combo_PasswordSecurityRules'] )? $_POST['Combo_PasswordSecurityRules']: false;
		$Combo_ApplicationRoles = isset($_POST['Combo_ApplicationRoles'] )? $_POST['Combo_ApplicationRoles']: false;
		$DTPicker_RoleStartDate = isset($_POST['DTPicker_RoleStartDate'] )? $_POST['DTPicker_RoleStartDate']: false;
		$DTPicker_RoleEndDate = isset($_POST['DTPicker_RoleEndDate'] )? $_POST['DTPicker_RoleEndDate']: false;
		$insArr = array();

			
		$insArr['RESOURCE_ID']=$Text_ResourceId;		
		
		$date1="";
		if(isset($DTPicker_StartDate))
		{
			$date1 = date("Y/m/d", strtotime($DTPicker_StartDate));			
		}
		$insArr['START_DATE']=$date1;

		$date2="";
		if ($DTPicker_EndDate!='')
		{
			$date2 = date("Y/m/d", strtotime($DTPicker_EndDate));			
		}
		$insArr['END_DATE']=$date2;
//		$insArr['PWD_RULE_CODE']=$Combo_PasswordSecurityRules;
		
		$insArr['LAST_UPDATED_BY']=$LoginUserId;	
		$insArr['SITE_ID']=$SiteId;		
		$insArr['ROLE_ID']=$Combo_ApplicationRoles;				
		$date1="";
		if($DTPicker_RoleStartDate!='')
		{
			$date1 = date("Y/m/d", strtotime($DTPicker_RoleStartDate));	
		}		
		$date2="";
		if($DTPicker_RoleEndDate!='' && $Combo_ApplicationRoles!='')
		{
			$date2 = date("Y/m/d", strtotime($DTPicker_RoleEndDate));
		}
		
		$insArr['ROLE_START_DATE']=$date1;
		$insArr['ROLE_END_DATE']=$date2;
		
		$Query1 = "";
		if($HeaderId!='')
		{
			$Query1 = " and USER_ID <> $HeaderId";
		}
		$qry = "SELECT * FROM cxs_users WHERE USER_NAME ='$Text_UserName' $Query1";
		$result = mysql_query($qry);
		$noofrecords = mysql_num_rows($result);
		if($noofrecords==0)	
		{
			if($HeaderId=='')
			{
				$insArr['USER_NAME']=strtoupper($Text_UserName);
				$insArr['ENC_KEY']=$Pass;	
				$insArr['CREATION_DATE']='now()' ;
				$insArr['CREATED_BY']=$LoginUserId;
				insertdata("cxs_users",$insArr);
				$LastInsertedUserId = mysql_insert_id();
			}
			else
			{
				$qry1 = "Select RESOURCE_ID from cxs_users where USER_ID = $HeaderId and SITE_ID = $SiteId ";
				$result1 = mysql_query($qry1);
				while($row = mysql_fetch_array($result1))
				{
					$Prev_ResourceId = $row['RESOURCE_ID'];
				}
				if($Text_ResourceId!=$Prev_ResourceId)
				{	
					mysql_query("Update cxs_resources set IN_USE_FLAG = 'N' where RESOURCE_ID = $Prev_ResourceId and IN_USE_FLAG = 'Y' and SITE_ID = $SiteId ");				
				}	
				updatedata("cxs_users",$insArr,"Where USER_ID = $HeaderId");
				$LastInsertedUserId = $HeaderId;
			}
			mysql_query("Update cxs_resources set IN_USE_FLAG = 'Y' where RESOURCE_ID = $Text_ResourceId and IN_USE_FLAG <> 'Y' and SITE_ID = $SiteId ");
			
			
			if($_FILES["PHOTO"]["name"] != "")
			{
				 if ($_FILES["PHOTO"]["error"] > 0)
				 {
						$msg = "Return Code: " . $_FILES["PHOTO"]["error"] . "<br />";
				 }
				 else
				 {
					if (!file_exists('../img/uploads/user_images/'.$LastInsertedUserId)) 
					{
					  mkdir('../img/uploads/user_images/'.$LastInsertedUserId, 0777, true);
					}
					$photo_name = $_FILES["PHOTO"]["name"];
					$ds = move_uploaded_file($_FILES["PHOTO"]["tmp_name"], "img/uploads/user_images/".$LastInsertedUserId."/".$photo_name) or die('error');				    
					$updArr['PHOTO'] = $photo_name;				    
					updatedata("cxs_users",$updArr," Where USER_ID = $LastInsertedUserId");
				 }
			}
			
			/**************** Code for sending email *****************/		
			$from_name='Coexsys Time Accounting'; //Website Name
			$from_email='admin@testrbam.com'; //Admin Email
			//$from_email = 'info@synchronwebservices.com';
			$to=$Text_UserName;			
			$subject = "Welcome to ".$from_name;
			$cc="";
			include "email/newUser.php"; //email design with content included			
			$headers  = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: $from_name < $from_email >\r\n";		
			mail($to, $subject, $message, $headers);				
			/*********************************************************/
			
			/*
			if($Combo_ApplicationRoles!='' && $DTPicker_RoleStartDate!='')
			{
			
				//if(($DTPicker_RoleStartDate!='') )
				//{
					unset ($insArr);
					$insArr['CREATION_DATE']='now()' ;
					$insArr['CREATED_BY']=$LoginUserId;
					$insArr['LAST_UPDATED_BY']=$LoginUserId;
					$insArr['APPLICATION_ROLE_ID']=$Combo_ApplicationRoles;

					
					$date1 = date("Y/m/d", strtotime($DTPicker_RoleStartDate));	
					$insArr['ROLE_START_DATE']=$date1;
					
					$date2="";
					$date2 = date("Y/m/d", strtotime($DTPicker_RoleEndDate));	
					if ($date2<>"")
					{				
						$date2 = date("Y/m/d", strtotime($DTPicker_RoleEndDate));	
						$insArr['ROLE_END_DATE']=$date2;
					}
					$insArr['USER_ID']=$LastInsertedUserId;
					insertdata("cxs_application_assignments",$insArr);
				//}
			}*/
			header("Location:users-administration.php");
		}
		else
		{
			$msg = "This Username Is Taken, Please Enter A Different Username.";
		}
	}
	
	if (isset($_GET["hid"]))
	{
		
		$qry = "SELECT cxs_users.*,concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) AS ResourceName from cxs_users left join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID where USER_ID = $HeaderId";		
		$result = mysql_query($qry);
		//$TotalRecords = mysql_num_rows($result);
		while($row=mysql_fetch_array($result))
		{
			$Display_UserName=$row['USER_NAME'];
			$Display_Password=GetPassword($row['ENC_KEY']);			
			$Display_StartDate="";
			$Display_EndDate="";
			
			$Display_RoleStartDate="";
			$Display_RoleEndDate="";
			
			if((!is_null($row['START_DATE'])) && (($row['START_DATE'])!='0000-00-00') )
			{
				$Display_StartDate = date('m/d/Y', strtotime($row['START_DATE']));	
			}
			
			if((!is_null($row['END_DATE'])) && (($row['END_DATE'])!='0000-00-00') )
			{
				$Display_EndDate = date('m/d/Y', strtotime($row['END_DATE']));	
			}
			
			if((!is_null($row['ROLE_START_DATE'])) && (($row['ROLE_START_DATE'])!='0000-00-00') )
			{
				$Display_RoleStartDate = date('m/d/Y', strtotime($row['ROLE_START_DATE']));	
			}
			
			if((!is_null($row['ROLE_END_DATE'])) && (($row['ROLE_END_DATE'])!='0000-00-00') )
			{
				$Display_RoleEndDate = date('m/d/Y', strtotime($row['ROLE_END_DATE']));	
			}
			$Display_ResourceId = $row['RESOURCE_ID'];
			$Display_ResourceName = $row['ResourceName'];
			$Display_ApplicationRoleId = $row['ROLE_ID'];
		}
		
		
	}
	
	/***** Password rules *****/
	$password_rules = array();
	if(getSettingVal('ALLOW_NUMERIC')=='Y')
	{
	   array_push($password_rules,"At least one numeric value.");
	}
	if(getSettingVal('ALLOW_UPPERCASE')=='Y')
	{
	   array_push($password_rules,"At least one upper case character.");
	}
	if(getSettingVal('ALLOW_LOWERCASE')=='Y')
	{
	   array_push($password_rules,"At least one lower case character.");
	}
	if(getSettingVal('ALLOW_SPECIALS')=='Y')
	{
	   array_push($password_rules,"At least one special character.");
	}
	array_push($password_rules,"No Spaces Allowed.");
	$miniCharacters = "";
	$miniCharacters = getSettingVal('MINIMUM_ALLOWED');
	if($miniCharacters!='')
	{
		array_push($password_rules,"At least $miniCharacters character/s.");
	}
	if(getSettingVal('ENABLE_COMMON')=='Y')
	{
	   array_push($password_rules,"Must not use commonly used words.");
	}
	array_push($password_rules,"Must not use any UniCode or Asian Characters.");	
?>

<script type="text/javascript" >
/* $(".readonly").keydown(function(e)
 {
        e.preventDefault();
	});
*/
var GridCurrentRow;
GridCurrentRow = 0;
var IsGridDateValid;
IsGridDateValid = "";
function DataSort(str1,str2)
{
	var str3;
	document.getElementById('h_field_name').value = str1;
	document.getElementById('h_field_order').value = str2;
	AdministrationList.submit();
}
function SearchData()
{
	document.getElementById('h_field_name').value = '';
	document.getElementById('h_field_order').value = '';
	AdministrationList.submit();
}
function test()
{
	//alert("hi");
	//$('.case').attr('checked', this.checked);
	//$('.case').attr('checked', this.checked);
	document.getElementByName("case").checked = true;

}
function UserNameValidation(e)
{
	   keyEntry = (e.keyCode) ? e.keyCode : e.which;
	   //if (((keyEntry >= '65') && (keyEntry <= '90')) || ((keyEntry >= '97') && (keyEntry <= '122')) || (keyEntry == '46') || keyEntry == '8' || keyEntry == '9' || keyEntry == '32' || keyEntry == '37'|| keyEntry == '38')
	   if (keyEntry == '32' ) //do not allow space
		   return false;
	   else
		   return true;
}
function ResetPasswordDaysValidation(e)
{
	var charCode = (e.which) ? e.which : e.keyCode
	if (charCode > 31  && !(charCode== 46 || charCode== 35 || charCode== 36|| charCode== 37 || charCode== 39 || charCode== 45) && (charCode < 48 || charCode > 57))
		return false;
	return true;
}
function chkfld(CurrentForm)
{
	var s1 ;
	var s2 ;
	var s3;
	var ReEnterPsw;
	if (CurrentForm =='CreateUser')
	{
		s1 = document.getElementById("Text_Password").value;
	//	s2 = document.getElementById("Combo_PasswordSecurityRules").value;
		s3 = document.getElementById("Text_UserName").value;			
		
		if (!isEmail(s3)) {
			alert("Please enter valid Email Address");
			document.getElementById("Text_UserName").focus();
			return false;
		}
		var ss1,ss2;
		ss1 = document.getElementById("Combo_ApplicationRoles").value;
		ss2 = document.getElementById("DTPicker_RoleStartDate").value;
		if (ss1!=''&& ss2=='')
		{
			alert("Please Enter Application Role Start Date");
			document.getElementById("DTPicker_RoleStartDate").focus();
			return false;
		}
		else if (ss2!=''&& ss1=='')
		{
			alert("Please Enter Application Role");
			document.getElementById("Combo_ApplicationRoles").focus();
			return false;
		}
	}
	else if (CurrentForm =='ResetPsw')
	{
		s1 = document.getElementById("Text_NewPassword").value;
		s2 = document.getElementById("CurrentUserPswRule").innerHTML;
		ReEnterPsw = document.getElementById("Text_ReEnterPassword").value;
		if (s1!=ReEnterPsw)
		{
			alert("Password Not Match");
			return false;
		}

		document.getElementById("h_userid").value = document.getElementById("CurrentUserId").innerHTML;

	}
	var CheckPsw;
	if (s1.length<8)
	{
		alert("Passward must be atleast 8 characters long.");
		document.getElementById("Text_Password").focus();
		return false;
	}

	if (s2 == "Simple")
	{
		s3 = hasWhiteSpace(s1);
		if (s3==true)
		{
			alert("Space not allow in password.");
			document.getElementById("Text_Password").focus();
			return false;
		}

	}
	if (s2 == "Moderate")
	{
		CheckPsw = CheckPassword(s1);
		if (CheckPsw == false)
		{
			alert("Password Criteria Not Match");
			document.getElementById("Text_Password").focus();
			return false;
		}
	}
	if (s2 == "Complex")
	{
		CheckPsw = CheckPassword(s1);
		if (CheckPsw == false)
		{
			alert("Password Criteria Not Match");
			document.getElementById("Text_Password").focus();
			return false;
		}
		CheckPsw = CheckConsecutiveNumbers(s1);
		if (CheckPsw == false)
		{
			alert("Do Not Use Consecutive Numbers ");
			document.getElementById("Text_Password").focus();
			return false;
		}
	}	
	
	if($("#h_username").val()=="")
	{
		$("#h_username").val($("#Text_UserName").val());
	}
	return true;
}

	function hasWhiteSpace(s)
	{
		return /\s/g.test(s);
	}

	function CheckPassword(inputtxt)   //To check a password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character
	{
	//	var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
		var decimal=  /^(?=.*\d)(?=.*[A-Z])(?=.*[^A-Z0-9])(?!.*\s).{8,240}$/;
		if(inputtxt.match(decimal))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function CheckConsecutiveNumbers(s)
	{
    // Check for sequential numerical characters
		for(var i in s)
		{
			if (+s[+i+1] == +s[i]+1 && +s[+i+2] == +s[i]+2)
			{
				return false;
			}
		}
    // Check for sequential alphabetical characters
    /*for(var i in s)
        if (String.fromCharCode(s.charCodeAt(i)+1) == s[+i+1] &&
            String.fromCharCode(s.charCodeAt(i)+2) == s[+i+2]) return false;*/
    return true;
	}

	function DuplicateUserName(name)
	{
		if (name!='')
		{
			KEY = "UserName";
			var str = document.getElementById('Text_UserName').value;
			var HeaderId = $("#h_HeaderId").val();
			
			makeRequest("ajax.php","REQUEST=UserCheck&UserName=" + str+"&HeaderId="+HeaderId);
		}
	}
	
	function chk_validdate()
	{
	   
		var StartDate,EndDate;
		var RoleStartDate,RoleEndDate;
		
		
		StartDate = document.getElementById("DTPicker_StartDate").value;
		EndDate = document.getElementById("DTPicker_EndDate").value;

		RoleStartDate = document.getElementById("DTPicker_RoleStartDate").value;
		RoleEndDate = document.getElementById("DTPicker_RoleEndDate").value;
		
		if (StartDate!='' && EndDate!='')// for pop up form
		{
			StartDate = new Date($('#DTPicker_StartDate').val());
			EndDate = new Date($('#DTPicker_EndDate').val());

			if (StartDate > EndDate)
			{
				alert("Start Date Must Be Greater Than End Date");
				document.getElementById("DTPicker_StartDate").focus();
				document.getElementById("cmdCreateUser").disabled = true;
			}
			else
			{
				document.getElementById("cmdCreateUser").disabled = false;
			}
		}
		if (EndDate=='')
		{
			document.getElementById("cmdCreateUser").disabled = false;
		}

		if (RoleStartDate!='' && RoleEndDate!='')// for pop up form
		{
			RoleStartDate = new Date($('#DTPicker_RoleStartDate').val());
			RoleEndDate = new Date($('#DTPicker_RoleEndDate').val());

			if (RoleStartDate > RoleEndDate)
			{
				alert("Start Date Must Be Greater Than End Date");
				document.getElementById("DTPicker_RoleStartDate").focus();
				document.getElementById("cmdCreateUser").disabled = true;
			}
			else
			{
				document.getElementById("cmdCreateUser").disabled = false;
			}
		}		
		
	}

	
	
	function TableRowFunction(UserId)
	{
		if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		{	
			KEY= "SingleRecord";
			$("#ModalUserDetail :input").prop('disabled', true);	
			
			//$("DTPicker_StartDate").removeClass("form_datetime");
			$("#ModalUserDetail").find('.modal-title').text('User Administration');	
			$("#cmdCreateUser").hide();
			
			$("#crtFrmPswRules").hide();
			$("#new_psw_err_tooltip").empty();
			
			$('#ModalUserDetail').modal();		
			//var str = UserId;	
			var TableName = "cxs_users";
			var FieldName = "USER_ID";
			var FieldValue = UserId;
			
			//makeRequest("ajax.php","REQUEST=SingleUserRecord&UserId=" + str);						
			makeRequest("ajax-DisplayRecord-rbam.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		}
	}
	
	function ClearField()
	{
		$("#ModalUserDetail :input").prop('disabled', false);
		$("#ModalUserDetail").find('.modal-title').text('Create User');	
		$("#cmdCreateUser").show();
		$("#crtFrmPswRules").show();
		$("#new_psw_err_tooltip").empty();
		
		document.getElementById("Text_UserName").value = "";
		document.getElementById("Text_UserName").disabled = false;
		
		document.getElementById("Text_Password").value = "";
		document.getElementById("Text_Password").disabled = false;
		
		document.getElementById("Combo_ResourceName").value = "";
		document.getElementById("Combo_ResourceName").disabled = false;
		
		document.getElementById("DTPicker_StartDate").value = "";
		document.getElementById("DTPicker_StartDate").disabled = false;
		
		document.getElementById("DTPicker_EndDate").value = "";
		document.getElementById("DTPicker_EndDate").disabled = false;
		
	//	document.getElementById("Combo_PasswordSecurityRules").value = "";
	//	document.getElementById("Combo_PasswordSecurityRules").disabled = false;
		
		document.getElementById("Combo_ApplicationRoles").value = "";
		document.getElementById("Combo_ApplicationRoles").disabled = false;
		
		document.getElementById("DTPicker_RoleStartDate").value = "";
		document.getElementById("DTPicker_RoleStartDate").disabled = false;
		
		document.getElementById("DTPicker_RoleEndDate").value = "";
		document.getElementById("DTPicker_RoleEndDate").disabled = false;
		
		//document.getElementById("cmdCreateUser").disabled = false;
	}
	function EditResourceForm(currentRow)
	{
		var ButtonCaption = document.getElementById("cmdUpdateSelected").innerHTML;
		var cellBgColor = document.getElementById(currentRow+"_3").style.backgroundColor;
		if (ButtonCaption == "Save" && cellBgColor == "white")
		{	
			$('#EditModalResourceName').modal();
			ResetResourceDiv();
			document.getElementById("span_userid").innerHTML = currentRow;
		}
	}
	function SearchResourceName()
	{
		KEY= "SearchResourceNameData";			
		var str = document.getElementById("Text_ResourceName").value;		
		makeRequest("ajax.php","REQUEST=SearchResourceNameData&ResourceName=" + str);
	}
	function SelectedResourceName(s1,s2)
	{
		document.getElementById("Text_ResourceName").value = s1;		
		document.getElementById("Text_ResourceId").value = s2;		
		document.getElementById("ListResourceResult").style.display = 'none';				
	}
	function ResetResourceDiv()
	{
		document.getElementById("ListResourceResult").style.display = 'block';
		document.getElementById("ListResourceResult").innerHTML = "";
		document.getElementById("Text_ResourceName").value = "";
		document.getElementById("Text_ResourceId").value = "";
	}
	function EditResourceName()
	{
		var s1 = document.getElementById("Text_ResourceName").value;		
		var s2 = document.getElementById("Text_ResourceId").value;	
		if (s2=="")
		{
			alert("Please Select Resouce Name From List");
			document.getElementById("Text_ResourceName").focus();			
		}
		else
		{
			var CurrentRow = document.getElementById("span_userid").innerHTML;		
			GridCurrentRow = CurrentRow;
			
			document.getElementById("span"+GridCurrentRow+"_3").innerHTML = s1;
			document.getElementById(GridCurrentRow+"_4").innerHTML = s2;					
			document.getElementById("h_resourceId"+GridCurrentRow).value = s2;					
			$("#EditModalResourceName .close").click()			
		}
	/*	KEY= "FindEditResourceId";			
		var str = document.getElementById("Text_ResourceName").value;		
		makeRequest("ajax.php","REQUEST=FindEditResourceId&ResourceName=" + str);*/
	}
	function CheckDate(currentRow)
	{
		var date1 = document.getElementById("Date_Start"+currentRow).value;
		var date2 = document.getElementById("Date_End"+currentRow).value;
		var IsActive = document.getElementById("Combo_ActiveUser"+currentRow).value;
		if (IsActive=="Inactive" && date2=='')
		{
			alert("Please Select End Date");
			document.getElementById("Date_End"+currentRow).focus();
		}		
		if (date1!='' && date2!='') //
		{
			date1 = new Date($('#Date_Start'+currentRow).val());
			date2 = new Date($('#Date_End'+currentRow).val());						
			if (date1 > date2)
			{
				alert("Start Date Must Be Greater Than End Date");
				document.getElementById("Date_End"+currentRow).focus();				
			}			
		}		
	}
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "User Administration";		
		var s2 = "users-administration.php";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function RefreshData()
	{
		//$('#SearchUsers').modal();
		AdministrationList.submit();
	}
	function showmodal()
	{
		$('#SearchSupervisor').modal();		
	}
	function SearchSupervisor()
	{
		KEY = "SearchSupervisor";				
		var str1 = document.getElementById("Text_SearchFirstName").value;
		var str2 = document.getElementById("Text_SearchMiddleName").value;
		var str3 = document.getElementById("Text_SearchLastName").value;	
		var str4 = '<?php echo $Display_ResourceId; ?>';
		var str5 = "users-administration";
		makeRequest("ajax2.php","REQUEST=SearchSupervisor&FirstName="+str1+"&MiddleName="+str2+"&LastName="+str3+"&ResourceId="+str4+"&form="+str5);
	}
	
	function SelectedSupervisor(s3)
	{	
		var TableName = "cxs_resources";
		var FieldName = "RESOURCE_ID";
		var FieldValue = s3;	
		$.ajax({
				url:"ajax2.php",
				method:"POST",
				data:{REQUEST:"FetchRecords",TableName:TableName,FieldName:FieldName,FieldValue:FieldValue },
				success:function(response)
				{			
					var JSONObject = JSON.parse(response);
					$('#Text_Resource').val(JSONObject[TableName]["FIRST_NAME"]+' '+JSONObject[TableName]["LAST_NAME"]);
					$('#Text_ResourceId').val(JSONObject[TableName]["RESOURCE_ID"]);
					$("#SearchSupervisor .close").click();
				}
			});
	}
function clearViewRoleData()
{
//	document.getElementById("Check_CreateUser").checked = false;
	/*document.getElementById("Check_ViewOnly").checked = false;
	document.getElementById("Check_UpdateOnly").checked = false;
	document.getElementById("Check_ViewSubscribers").checked = false;
	document.getElementById("Check_SubmitCustomization").checked = false;
	//document.getElementById("Check_AllowChat").checked = false;
	document.getElementById("Check_ViewSLA").checked = false;
	document.getElementById("Check_ExistUserAdmin").checked = false;
	//document.getElementById("Check_RemoveAccess").checked = false;
	document.getElementById("Check_UsageHistory").checked = false;
	
	document.getElementById("Check_CreateUser").disabled = true;
	document.getElementById("Check_ViewOnly").disabled = true;
	document.getElementById("Check_UpdateOnly").disabled = true;
	document.getElementById("Check_ViewSubscribers").disabled = true;
	document.getElementById("Check_SubmitCustomization").disabled = true;
	//document.getElementById("Check_AllowChat").disabled = true;
	document.getElementById("Check_ViewSLA").disabled = true;
	document.getElementById("Check_ExistUserAdmin").disabled = true;
	//document.getElementById("Check_RemoveAccess").disabled = true;
	document.getElementById("Check_UsageHistory").disabled = true;
		
		//Heading2
		document.getElementById("Check_BusinessMessage").checked = false;
		document.getElementById("Check_SetAudit").checked = false;		
		//document.getElementById("Check_AllowTimekeeping").checked = false;		
		//document.getElementById("Check_TimezoneProjects").checked = false;		
		//document.getElementById("Check_ProjectAccounting").checked = false;		
		document.getElementById("Check_AllowNegativeTimeEntry").checked = false;		
		document.getElementById("Check_AdvanceForOvertime").checked = false;		
		document.getElementById("Check_SubmittedTime").checked = false;		
		document.getElementById("Check_PrimaryApprover").checked = false;		
		document.getElementById("Text_RecentTimecards").checked = false;		
		document.getElementById("Check_RetroAdjustments").checked = false;		
		document.getElementById("Text_MaxDailyLimit").checked = false;		
		document.getElementById("Check_FlexibleTimeEntry").checked = false;		
		//document.getElementById("Check_EnforceTimeEntry").checked = false;		
		//document.getElementById("Check_EmployeeAliases").checked = false;		
		document.getElementById("Check_CopyTimesheetEmployees").checked = false;		
		document.getElementById("Text_RecentTimecards").value = "";
		document.getElementById("Text_MaxDailyLimit").value = "";
		document.getElementById("Text_AllowRetroUpdates").value = "";
		
		document.getElementById("Check_BusinessMessage").disabled = true;
		document.getElementById("Check_SetAudit").disabled = true;		
		//document.getElementById("Check_AllowTimekeeping").disabled = true;		
		//document.getElementById("Check_TimezoneProjects").disabled = true;		
		//document.getElementById("Check_ProjectAccounting").disabled = true;		
		document.getElementById("Check_AllowNegativeTimeEntry").disabled = true;		
		document.getElementById("Check_AdvanceForOvertime").disabled = true;		
		document.getElementById("Check_SubmittedTime").disabled = true;		
		document.getElementById("Check_PrimaryApprover").disabled = true;		
		document.getElementById("Text_RecentTimecards").disabled = true;		
		document.getElementById("Check_RetroAdjustments").disabled = true;		
		document.getElementById("Text_MaxDailyLimit").disabled = true;		
		document.getElementById("Check_FlexibleTimeEntry").disabled = true;		
		//document.getElementById("Check_EnforceTimeEntry").disabled = true;		
		//document.getElementById("Check_EmployeeAliases").disabled = true;		
		document.getElementById("Check_CopyTimesheetEmployees").disabled = true;		
		document.getElementById("Text_RecentTimecards").disabled = true;
		document.getElementById("Text_MaxDailyLimit").disabled = true;
		document.getElementById("Text_AllowRetroUpdates").disabled = true;
		
		
		//Heading3		
		document.getElementById("Check_CreateTimeSheet").checked = false;		
		document.getElementById("Check_ApproveTimeSheet").checked = false;		
		document.getElementById("Check_CreateTimeSheetTeam").checked = false;		
		document.getElementById("Check_ApproveTimeSheetTeam").checked = false;		
		document.getElementById("Check_CreateSupervisorTimeSheet").checked = false;	
		
		document.getElementById("Check_CreateTimeSheet").disabled = true;	
		document.getElementById("Check_ApproveTimeSheet").disabled = true;	
		document.getElementById("Check_CreateTimeSheetTeam").disabled = true;	
			
		//Heading4
		var rows = [1,2,6,7,9,10,13,14,15,16,17,18,19,20,21];
		
		var j =0;//= 13;
		j = $("#Heading4_Table tbody tr").length;		
		//for(i=1;i<=j;i++)
		for (i = 0; i < rows.length; i++)		
		{
			document.getElementById("Check_Create"+rows[i]).checked = false;
			document.getElementById("Check_Update"+rows[i]).checked = false;
			document.getElementById("Check_View"+rows[i]).checked = false;
			document.getElementById("Check_Audit"+rows[i]).checked = false;
			
			document.getElementById("Check_Create"+rows[i]).disabled = true;	
			document.getElementById("Check_Update"+rows[i]).disabled = true;	
			document.getElementById("Check_View"+rows[i]).disabled = true;	
			document.getElementById("Check_Audit"+rows[i]).disabled = true;	
		}
		
		//Heading6
		
		document.getElementById("Check_AllowPreApproval").checked = false;	
		document.getElementById("Check_ApproveDirectReport").checked = false;
		document.getElementById("Check_UpadteApprovedTimesheet").checked = false;
		//document.getElementById("Check_FlyApprovalRequest").checked = false;
		//document.getElementById("Check_ProjectBasedApproval").checked = false;
		
		document.getElementById("Text_TempApproverName").value = "";
		
		document.getElementById("Check_AllowPreApproval").disabled = true;
		document.getElementById("Check_ApproveDirectReport").disabled = true;
		document.getElementById("Check_UpadteApprovedTimesheet").disabled = true;
		//document.getElementById("Check_FlyApprovalRequest").disabled = true;
		//document.getElementById("Check_ProjectBasedApproval").disabled = true;
		
		j=0;
		j = $("#Heading6_Table1 tbody tr").length;
		for(i=1;i<=j;i++)
		{	
			document.getElementById("Combo_ApproverName"+i).disabled = true;
			document.getElementById("Combo_ApproverType"+i).disabled = true;
		}	
		
		document.getElementById("Text_TempApproverName").disabled = true;
		j=0;
		j = $("#Heading6_Table2 tbody tr").length;
	for(i=1;i<=j;i++)
	{	
		document.getElementById("Combo_PeriodId"+i).disabled = true;
		//document.getElementById("Combo_AliasName"+i).disabled = true;
		document.getElementById("Check_ActiveFlag"+i).disabled = true;			
	}*/
}
</script>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">	
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title> Coexsys Time Accounting </title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- font-awasome-->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- custom-css -->
    <link href="../css/style.css" rel="stylesheet">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	
	<script src="../datepicker/jquery.js"></script>
	<!--<script src="js1/jquery.js"></script>-->
	<link href="../datepicker/datepicker.css" rel="stylesheet">
	<script src="../datepicker/bootstrap-datepicker.js"></script>
	<script src="../js/jsfunctions.js"></script>
	<script type="text/javascript" ><?php //include 'find.php'; ?></script>
<style type="text/css">
.requirefieldcls{ background-color: #fff99c;	}
.AttachOnMouseOverText{ color: black;	}
.myclass{ padding-top : 3px; padding-bottom : 3px; }
.datepicker { font-size: 9px; }
.not-valid-tip{ color: #ff0000; }
.bootstrap-datetimepicker-widget td.day { width: 200px;line-height: 10px;font-size: 10px; }
#new_psw_err_tooltip,#reset_psw_err_tooltip { position: absolute; z-index: 999; background: #ededed; }
#new_psw_err_tooltip span,#reset_psw_err_tooltip span{ display: block; padding: 12px 12px 0 12px; }
#new_psw_err_tooltip span:last-child,#reset_psw_err_tooltip span:last-child{ padding-bottom: 26px; }
#new_psw_err_tooltip br,#reset_psw_err_tooltip br{ height: 10px; }
</style>

</head>
<body>
    <!-- modals start -->
    <!--<form method="post" action="" onsubmit = "return chkfld(document.getElementById('Text_Password').value , document.getElementById('Combo_PasswordSecurityRules').value),''">-->
	
	<!--Password Reset modals start -->
	
    <!--Password Reset modals end -->
	<!--EDIT modals start -->
	
	<!--View Role modals start -->
    
    <!--View Role modals end -->
	<!--New View Role modals START - PR-->
	
	<!--New View Role modals END - PR-->

	<?php include("header.php"); ?>
	<section class="md-bg">
		<div class="container-fluid">
			<div class="row">
				<div class="brd-crmb">
					<ul>
					  <li> <a href="#"> Users And Roles </a></li>
					  <li> <a href="users-administration.php"> User Administration </a></li>
					  <li id="Label_Title1"> <a href="#"> Create User </a></li>
					</ul>
				</div>
				<div class="dash-strip">
					<div class="fleft cr-user">
						<a href="rbam.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button></a>
					</div>
					<div class="fright">										
					<?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						} 
					?>
					<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>					
					</div>
				</div> 
				<div class="cont-box">
					<div class="pge-hd">
					  <h2 class="sec-title"> <label id="Label_Title"> Create User </label> </h2>
					</div>
					<?php
						//$msg = "";
						$s_Query = str_replace("\\","",$s_Query);
						$selectQuery = "select count(*) as expr1 from (SELECT  concat( cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as RESOURCE_NAME,cxs_users.* FROM cxs_users Left JOIN cxs_resources ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE 1=1 $s_Query  ) as a";
						$RunUserQuery=mysql_query($selectQuery);
						while($row = mysql_fetch_array($RunUserQuery))
						{
							$TotalSearchRecords = $row['expr1']; 
						}
						if ($TotalSearchRecords==0)
						{
							$msg = "No Record Found";
						}
					?> 
					
					<form id = "form1" method="post" action="" onsubmit = "return chkfld('CreateUser')" enctype="multipart/form-data">				
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-4 form-group">
									<label> Email Address  (Your Email Address is your User Name) </label>
									<input type="text"  id="Text_UserName" name = "Text_UserName" required class="form-control requirefieldcls" onkeypress = 'return UserNameValidation(event);' oninput="this.value=this.value.toUpperCase()" onblur = "DuplicateUserName(this.value)" value = "<?php echo $Display_UserName; ?>" autofocus > 
									<input type = "hidden" id = "h_username" name = "h_username" value = "<?php echo $Display_UserName; ?>" >
									<!--onkeyup="this.value=this.value.toUpperCase()" oninput='UserNameValidation(this.value);' -->
									<span id = "span_msg" style = "color : 'red'"> <?php echo $msg; ?> </span>
								</div>
								<div class="col-sm-4 form-group">
									<label> Password </label>
									<input type="password" id="Text_Password" name="Text_Password" required class="form-control requirefieldcls" maxlength="240" value = "<?php echo $Display_Password; ?>">
									 <span id="new_psw_err_tooltip" style="color: #ff0000"></span>
								</div>								
								
								<div class="col-sm-4 form-group">
									<label> Resource Name </label>
									<input  type='text' id = 'Text_Resource' class='form-control  requirefieldcls' required   onclick='showmodal();' onkeydown="return false" onkeyup='showmodal();' value = '<?php echo $Display_ResourceName; ?>' >
									<input type='hidden' id = 'Text_ResourceId' name = 'Text_ResourceId' value = '<?php echo $Display_ResourceId; ?>' > 
								</div>
								<div class ="clear-both"></div>
								<div class="col-sm-4 form-group cus-form-ico">
									<label> Start Date </label>
									<input type="text" id="DTPicker_StartDate" name="DTPicker_StartDate" class="form-control requirefieldcls " required value = "<?php echo $Display_StartDate; ?>" onchange = chk_validdate();>
									<span class="inp-icons"><i class="fa fa-calendar"></i></span>
								</div>

								<div class="col-sm-4 form-group cus-form-ico">
									<label> End Date </label>
									<input type="text" id="DTPicker_EndDate" name="DTPicker_EndDate" class="form-control" maxlength="25" onchange = chk_validdate(); value = "<?php echo $Display_EndDate; ?>">
									<span class="inp-icons"><i class="fa fa-calendar"></i></span>
								</div>										
								<div class="col-sm-12">
									<div class="row">
										<div class="bdr-btn">
											<h2 class="f-hd"> Application Roles</h2>
											<span></span>
										</div>
										<div class="col-sm-4 form-group">
										<?php
											$qry = "select * from cxs_am_roles where SITE_ID = $SiteId order by ROLE_NAME";
											$result = mysql_query($qry);
											echo '<select id = "Combo_ApplicationRoles" name = "Combo_ApplicationRoles" class="form-control "  >';
											echo "<option value=''>- Assign Application Role -</option>";
											while($row=mysql_fetch_array($result))
											{
										?>
											<option value='<?php echo$row['ROLE_ID'];?>'<?php echo ($row['ROLE_ID']==$Display_ApplicationRoleId)?' selected':'';?>><?php echo $row['ROLE_NAME'];?></option>
										<?php
											}
										?>
											</select>
										</div>
										<div class="col-sm-4 form-group cus-form-ico">
											<input type="text" id="DTPicker_RoleStartDate" name="DTPicker_RoleStartDate" class="form-control" onchange = chk_validdate() placeholder="Start Date" value = "<?php echo $Display_RoleStartDate; ?>">
											<span class="inp-icons"><i class="fa fa-calendar"></i></span>
										</div>
										<div class="col-sm-4 form-group cus-form-ico">
											<input type="text" id="DTPicker_RoleEndDate" name="DTPicker_RoleEndDate" class="form-control" onchange = chk_validdate() placeholder="End Date" value = "<?php echo $Display_RoleEndDate; ?>">
											<span class="inp-icons"><i class="fa fa-calendar"></i></span>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<div class="col-sm-8" style="text-align: left;">
							<div id="crtFrmPswRules">
								New Password must have:
								<ol>
								<?php foreach($password_rules as $rl){ ?>
								<li><?php echo $rl; ?></li>
								<?php } ?>
								</ol>
							  </div>
						</div>
						<div class="col-sm-4">							
							<button type="submit" id="cmdCreateUser" name="cmdCreateUser" class="btn btn-primary btn-style" <?php if($CREATE_PRIV_ua_PERMISSION!="Y"){?>disabled="disabled"<?php } ?>>Create User</button>							
						</div>
					</div>	
					<input type = "hidden" id = "h_HeaderId" value = "<?php echo $HeaderId; ?>">
				</form>	
				</div>
				
				
			<!-- modals start -->
				<form  method="post" action="" >
					<div class="modal fade custom-modal" id = "SearchSupervisor" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style = "display:none">
						<div class="modal-dialog modal-lg cus-modal-lg" role="document">
						  <div class="modal-content">
							<div class="modal-header">
							  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							  <h4 class="modal-title " id="myModalSearchLabel"> Find Resource </h4>
							</div>
							<div class="modal-body">
							<!-- field start-->
							  <div class="col-sm-12">
								<div class="cus-form-cont">
								  <input type='hidden' id = 'sCurrentRow' > 
								  <div class="col-sm-3 form-group" style = "width : 24%">
									<label> First Name </label>
									<input type="text" id ="Text_SearchFirstName" name ="Text_SearchFirstName" value = "" class="form-control" placeholder="">
								  </div>
								  <div class="col-sm-3 form-group" style = "width : 24%">
									<label> Middle Name </label>
									<input type="text" id ="Text_SearchMiddleName" name ="Text_SearchMiddleName" value = "" class="form-control" oninput="this.value=this.value.toUpperCase()" placeholder="">
								  </div>
								  <div class="col-sm-3 form-group" style = "width : 24%">
									<label> Last Name </label>
									<input type="text" id ="Text_SearchLastName" name ="Text_SearchLastName" value = "" class="form-control" placeholder="">
								  </div>
								  <div class="col-sm-3 form-group " style = "width : 28%">									
									<label> &nbsp;</label>
									<button type="button" id = "cmdFindSupervisors" name = "cmdFindSupervisors" class="btn btn-primary btn-style2 w100" onclick="SearchSupervisor()" > <i class="fa fa-search" aria-hidden="true"></i> Find Resource </button>
								  </div>
								</div>
								<div class="data-bx">
								  <div class="table-responsive" id = "divFindSupervisor">
									
								  </div>
								</div>
							  </div>
							<!-- end -->
							</div>
							<div class="clear-both"></div>
							<div class="modal-footer cr-user">
								<!--<button type="button" id = "cmdFindUsers" name = "cmdFindUsers"  class="btn btn-primary btn-style" onclick = "()"><i class="fa fa-search" aria-hidden="true"></i> Find Users </button>  -->
							</div>
						  </div>
						</div>
					</div>
				</form>
			<!-- modals end -->		
				
				
				
			</div>
		</div>
	</section>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript">

$(document).ready(function() 
{													
   $('.record_chk').change(function() {
		if(!$(this).is(":checked")) {
				HideDatePicker($(this).val());
				for(i=5;i<=7;i++)
				{
					  document.getElementById($(this).val()+"_"+i).style.borderColor  = "";
					  document.getElementById($(this).val()+"_"+i).style.backgroundColor = "";
				}
		}
		
		if ($('.record_chk:checked').length == 0){
			document.getElementById("cmdUpdateSelected").innerHTML = "Update selected";
			$("#cmdCancel").attr('disabled',true);
			$("#cmdExport").attr('disabled',false);
			//flag_checked="N";
			flag_updaterecord = "N";
		}
   });
   if($("#h_HeaderId").val()!="")
   {
	   $("#Text_UserName").attr("disabled",true);
	   $("#Text_Password").attr("disabled",true);
   }
});	
var datePickerOptions = {
    format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
	}
$(document).on('focus',".form_datetime", function()
	{
		$(this).datepicker(datePickerOptions);
	});
	
$('#Text_Password').blur(function() {
	
	   checkPasswordError($(this).val(),$("#new_psw_err_tooltip"),$("#cmdCreateUser"));
});
/*$('#Text_NewPassword').keyup(function() {
	   
	   checkPasswordError($(this).val(),$("#reset_psw_err_tooltip"),$("#cmdResetPassword"));
});
$('#Text_ReEnterPassword').keyup(function() {
	   form_element_correct($('#Text_ReEnterPassword'));
});*/
$('#Text_Password,#Text_NewPassword,#Text_ReEnterPassword').keypress(function(e) {
	 
	   if ((e.which >= 33 && e.which<=45) || (e.which >= 47 && e.which<=126) || e.which==8 || e.which==0) {
			 return true;
	   }
	   else{
			 return false;
	   }
	   
	   /*if(e.which === 32 || e.which === 46) //not accepts space and dot
	   {
			 return false;
	   }*/
});

	
$('.form_datetime').datepicker(
	{
		format:'mm/dd/yyyy',		
		autoclose : true
	});
/*if ($('#DTPicker_StartDate').val()=='')
{*/
	$('#DTPicker_StartDate').datepicker({
	//format:'DD,  MM d, yyyy',
	   format: 'mm/dd/yyyy',	  
	   autoclose : true
});
//}

$('#DTPicker_EndDate').datepicker({
	   //format:'DD,  MM d, yyyy',
	   format: 'mm/dd/yyyy',
	   defaultDate: '',
	   autoclose : true
});
$('#DTPicker_RoleStartDate').datepicker(
{
	   //format:'DD,  MM d, yyyy',
	   format: 'mm/dd/yyyy',
	   defaultDate: '',
	   autoclose : true
});
$('#DTPicker_RoleEndDate').datepicker(
{
	format: 'mm/dd/yyyy',
	//format:'DD,  MM d, yyyy',
	defaultDate: '',
	autoclose : true
});

	
	

function fun1(userid,rules)
{
	document.getElementById("CurrentUserId").innerHTML =userid;
	document.getElementById("CurrentUserPswRule").innerHTML =rules;
	$("#rsPsw_userId").val(userid);
}
	/*	$('#datepicker').datepicker(
		{
			//format: 'mm/dd/yyyy',
			format:'DD,  MM d, yyyy',
			defaultDate: '',
			autoclose : true
		});
		*/

function makeRequest(url,data)
{
		var http_request = false;
		if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
}

function alertContents(http_request)
{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{
				if (KEY == "message")
				{
					//document.getElementById("message").innerHTML = http_request.responseText;
					if (document.getElementById("message").innerHTML == "")
					{
						document.getElementById("h_IsDuplicateEntry").value = "";
					}
					else
					{
						document.getElementById("h_IsDuplicateEntry").value = "y";
						document.getElementById("txtLeadName").focus();
						document.getElementById("message").style.display="block";
						return false;
					}
				}
				else if (KEY == "SubjectData")
				{
						document.getElementById("SubjectData").innerHTML = http_request.responseText;
				}

				else if(KEY == 'UserName')
				{
					var s1 = http_request.responseText;
					s1 = s1.trim();					
					if(s1.length > 1)
					{
						$("#span_msg").text(s1);
						document.getElementById("Text_UserName").focus();
					}
					/*else
					{
						$("#span_msg").text("");
					}*/
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText); 					
					//alert(JSON.stringify(JSONObject));					
					$('#Text_UserName').val(JSONObject['cxs_users']["USER_NAME"]);
					$('#Text_Password').val(JSONObject['cxs_users']["ENC_KEY"]);					
					$('#Combo_ResourceName').val(JSONObject['cxs_users']["RESOURCE_ID"]);
					//$('#DTPicker_StartDate').val(JSONObject['cxs_users']["START_DATE"]);
					
					$('#DTPicker_StartDate').val(MyDateFormat(JSONObject['cxs_users']["START_DATE"]));
					$('#DTPicker_EndDate').val(MyDateFormat(JSONObject['cxs_users']["END_DATE"]));
					//$('#Text_EndDate').val(MyDateFormat(JSONObject['cxs_resources']["END_DATE_ACTIVE"]));
					
					
					$('#Combo_ApplicationRoles').val(JSONObject['cxs_users']["ROLE_ID"]);
					$('#DTPicker_RoleStartDate').val(MyDateFormat(JSONObject['cxs_users']["ROLE_START_DATE"]));
					$('#DTPicker_RoleEndDate').val(MyDateFormat(JSONObject['cxs_users']["ROLE_END_DATE"]));
					
					//$('#Text_CalendarName').val(JSONObject['cxs_holidays']["CALENDAR_NAME"]);					
					//$('#Text_PeriodYear').val(JSONObject['cxs_holidays']["PERIOD_YEAR"]);
					
				}
				else if (KEY == "SearchResourceNameData")
				{
					var str = http_request.responseText;					
					document.getElementById("ListResourceResult").innerHTML = str;
					
					if (document.getElementById("Text_ResourceName").value ==""	)
					{
						ResetResourceDiv();
					}
				}
				else if (KEY == "FindEditResourceId")
				{
					var userid = http_request.responseText;	
					userid = userid.trim();
					alert(userid);
					var s1 = document.getElementById("Text_ResourceName").value;	
					document.getElementById("span"+GridCurrentRow+"_3").innerHTML = s1;
					document.getElementById(GridCurrentRow+"_4").innerHTML = userid;					
					document.getElementById("h_resourceId"+GridCurrentRow).value = userid;					
					$("#EditModalResourceName .close").click()					
				}
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;	
					window.open('downloaddata.php?r=user-administration', '_blank');					
					//window.location.href = "downloaddata.php?r=user-administration","target='_blank'";					
				}
				else if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if (KEY == "SearchSupervisor")
				{
					$("#divFindSupervisor").html(http_request.responseText);
					//$("#divTable").DataTable({"searching": false});
				}
			}
			else
			{
				//document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}
function resetPasswordFormValidation()
{
	   var valid_frm = 'Y';
	   
	   var minPswLength = <?php echo getSettingVal('MINIMUM_ALLOWED'); ?>;
	   
	   var oneCapLtr = new RegExp('(?=.*[A-Z])');
	   var oneLowrLtr = new RegExp('(?=.*[a-z])');
	   var oneDigit = new RegExp('(?=.*\d)');
	   var oneSplChar = /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/;
	   
	   var new_Password = $("#Text_NewPassword");
	   var reentered_Password = $("#Text_ReEnterPassword");
	   
	   if ($.trim(new_Password.val())!='') {
			 comparePswdWithCommonWords($.trim(new_Password.val()),$("#reset_psw_used_common_word"));
	   }	   
	   
	   if ($.trim(new_Password.val())=='') {
			 form_element_correct(new_Password);
			 form_element_empty_err(new_Password);
			 valid_frm = 'N';
	   }
	   else if ($.trim(new_Password.val()).length<minPswLength) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The New Password should contain atleast '+minPswLength+' characters.</span>');
			 valid_frm = 'N';
	   }
	   <?php if(getSettingVal('ALLOW_SPECIALS')=='Y'){ ?>
	   else if (!oneSplChar.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one special character: \':;/?.>,<`~@#$%^&*()_+=-][{}\|"</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_UPPERCASE')=='Y'){ ?>
	   else if (!oneCapLtr.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one uppercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_LOWERCASE')=='Y'){ ?>
	   else if (!oneLowrLtr.test($.trim(new_Password.val()))) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one lowercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_NUMERIC')=='Y'){ ?>
	   else if ($.trim(new_Password.val()).search(/\d/) == -1) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">The new password must have at least one Numeric Value.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ENABLE_COMMON')=='Y'){ ?>
	   else if ($("#reset_psw_used_common_word").val() >= 1) {
			 form_element_correct(new_Password);
			 new_Password.addClass('error_ele');
			 new_Password.after('<span role="alert" class="not-valid-tip">You have entered a password that is a very commonly or known word, consecutive alphabets or with consecutive numbers. This is not allowed. Please try different combination that is not common.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   else
	   {
			 form_element_correct(new_Password);
	   }
			 
	   if ($.trim(reentered_Password.val())==''){
			 form_element_correct(reentered_Password);
			 form_element_empty_err(reentered_Password);
			 valid_frm = 'N';
	   }
	   else
	   {
			 form_element_correct(reentered_Password);
	   }
	   
	   if ($.trim(new_Password.val())!='' && $.trim(reentered_Password.val())!='' && ($.trim(new_Password.val())!=$.trim(reentered_Password.val()))){
			 form_element_correct(reentered_Password);
			 reentered_Password.addClass('error_ele');
			 reentered_Password.after('<span role="alert" class="not-valid-tip">Password not matched.</span>');
			 valid_frm = 'N';
	   }
	   else if ($.trim(new_Password.val())!='' && $.trim(reentered_Password.val())!='') {
			
			 form_element_correct(reentered_Password);
	   }
	   
	   if (valid_frm == 'Y') {
			 return true;
	   }
	   else
	   {
			 return false;
	   }
}
function checkPasswordError(password,ele_error_tooltip,btn_submit_ele)
{
	   ele_error_tooltip.empty();
	   
	   var valid_frm = 'Y';
	   
	   var minPswLength = <?php echo getSettingVal('MINIMUM_ALLOWED'); ?>;
	   
	   var oneCapLtr = new RegExp('(?=.*[A-Z])');
	   var oneLowrLtr = new RegExp('(?=.*[a-z])');
	   var oneDigit = new RegExp('(?=.*\d)');
	   var oneSplChar = /[!@#$%^&*()_=\[\]{};':"\\|,.<>\/?+-]/;
	   
	   
	   <?php if(getSettingVal('ALLOW_NUMERIC')=='Y'){ ?>
	   if (password.search(/\d/) == -1) {
			// ele_error_tooltip.append('<span>* The new password must have at least one Numeric Value.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_UPPERCASE')=='Y'){ ?>
	   if (!oneCapLtr.test(password)) {
			// ele_error_tooltip.append('<span>* The new password must have at least one uppercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_LOWERCASE')=='Y'){ ?>
	   if (!oneLowrLtr.test(password)) {
			// ele_error_tooltip.append('<span>* The new password must have at least one lowercase character.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   <?php if(getSettingVal('ALLOW_SPECIALS')=='Y'){ ?>
	   if (!oneSplChar.test(password)) {
			// ele_error_tooltip.append('<span>* The new password must have at least one special character: \':;/?.>,<`~@#$%^&*()_+=-][{}\|</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   if (password.length<minPswLength) {
			 			 
			// ele_error_tooltip.append('<span>* The New Password should contain atleast '+minPswLength+' characters.</span>');
			 valid_frm = 'N';
	   }
	   if (password.length>240) {
			 			 
			// ele_error_tooltip.append('<span>* The New Password should contain maximum 240 characters.</span>');
			 valid_frm = 'N';
	   }
	   <?php if(getSettingVal('ENABLE_COMMON')=='Y'){ ?>
	   comparePswdWithCommonWords(password,$("#reset_psw_used_common_word"));
	   if ($("#reset_psw_used_common_word").val() >= 1) {
			// ele_error_tooltip.append('<span>* You have entered a password that is a very commonly or known word, consecutive alphabets or with consecutive numbers. This is not allowed. Please try different combination that is not common.</span>');
			 valid_frm = 'N';
	   }
	   <?php } ?>
	   
	   if (valid_frm=='Y') {
			 btn_submit_ele.attr('disabled',false);
	   }
	   else
	   {
			 btn_submit_ele.attr('disabled',true);
	   }
	   	   
}
function comparePswdWithCommonWords(pwd,ele_psw_used_cmn_wrd){
	   
	   var form_data = new FormData();
	   form_data.append("psword", pwd);
	   
	   jQuery.ajax({
			url: "../ajax-functions/comparePswdWithCommonWords.php", // point to server-side PHP script 
			dataType: 'text', // what to expect back from the PHP script
			cache: false,
			contentType: false,
			processData: false,
			async: false,
			data: form_data,
			type: 'POST',
			success: function (response) {
				ele_psw_used_cmn_wrd.val(response);
			},
			error: function (response) {
				//$('#fileMsg').html(response); // display error response from the PHP script
			}
	   });
}
function form_element_empty_err(element)
{
    element.addClass('error_ele');
    element.after('<span role="alert" class="not-valid-tip">The field is required.</span>');
}
function form_element_valid_err(element)
{
    element.addClass('error_ele');
    element.after('<span role="alert" class="not-valid-tip">The field is not valid.</span>');
}
function form_element_correct(element)
{
    element.removeClass('error_ele');
    element.next('span.not-valid-tip').remove();
    //element.nextAll().remove();
}
function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}
	</script>
	
	<?php
		if (isset($_GET["hid"]))
		{
			echo "<script>";							
			echo "$('#Label_Title').text('Update User');";
			echo "$('#Label_Title1').text('Update User');";
			echo "$('#cmdCreateUser').text('Update User');";
			echo "</script>";
		}
		?>	
		
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>