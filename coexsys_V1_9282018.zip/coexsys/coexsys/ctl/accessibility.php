<?php 
ob_start ();
include("conn.php");
check_login1();
?>

<?php
if(isset($_POST['cmdAccessibility']) && $_POST['cmdAccessibility']=='cmdAccessibility' )
{
	if($_POST['Combo_Accessibility']=="RBAM")
	{
		header("location:rbam/rbam.php");
	}
	else if($_POST['Combo_Accessibility']=="TE")
	{
		header("Location:te/te.php");
		
	}
}
?>   

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Accessibility Form</title>  
	<link rel="stylesheet" href="css/bootstrap1.min.css">
	<link rel="stylesheet"href="css/login_style.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
</head>

<body>

    <div class="wrapper">
    <form class="form-signin" method='post' action=''> 
      <div class='row' > <img style='margin-right:-20px;' class='pull-right' src="img/main_logo.png" /> </div>         
		<div id = "div_accessibility" >
			<h4>Accessibility</h4>
			<select id = "Combo_Accessibility" name = "Combo_Accessibility" class="form-control ">
				<option value="RBAM">Access Management</option>
				<option value="TE">Time & Labor</option>
			</select>
		</div>
		<div class="clear-both" style = "padding-top:15px;"></div>
		<button class="btn btn-lg btn-primary btn-block" name='cmdAccessibility' value='cmdAccessibility' type="submit">Select</button> 
    </form>
  </div>
 
  
<script src="js/bootstrap.min.js"></script>
</body>

</html>

