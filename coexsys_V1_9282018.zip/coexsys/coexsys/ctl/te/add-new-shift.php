<?php ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_WorkShift_PERMISSION = "Y";
		$UPDATE_PRIV_WorkShift_PERMISSION = "Y";		
	}
	else
	{
		$CREATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','WorkShift',$_SESSION['user_id']);
		$UPDATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','WorkShift',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_WorkShift_PERMISSION=='N' && $UPDATE_PRIV_WorkShift_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id']; 
	$PageName = "add-new-shift.php";		
	$SiteId = $_SESSION['user-siteid'];
	
	$insArr = array();
	
	//echo strtoupper(jddayofweek(6,1));
	if (isset($_GET["hid"]))
	{
		$s_caption = "Update";
		$HeaderId  = $_GET["hid"];	
	}
	
	if($HeaderId =='')
	{
		$HeaderId = isset($_POST['h_headerid']) ? $_POST['h_headerid']:false;	
	}	
	if (isset($_POST['cmdSaveRecord'] ))
	{
		$Text_ShiftName = isset($_POST["Text_ShiftName"] )? $_POST["Text_ShiftName"]: false;
		$Text_Description = isset($_POST["Text_Description"] )? $_POST["Text_Description"]: false;		
		$Combo_TimeZone = isset($_POST["Combo_TimeZone"] )? $_POST["Combo_TimeZone"]: false;		
		$Combo_PartTime = isset($_POST["Combo_PartTime"] )? $_POST["Combo_PartTime"]: false;		
		$Combo_WorkShiftType = isset($_POST["Combo_WorkShiftType"] )? $_POST["Combo_WorkShiftType"]: false;		
		$Check_Active = isset($_POST['Check_Active'] )? $_POST['Check_Active']: false;
	//	$Check_AllowOvertime = isset($_POST['Check_AllowOvertime'] )? $_POST['Check_AllowOvertime']: false;
		$Check_InUse = isset($_POST['Check_InUse'] )? $_POST['Check_InUse']: false;		
		if($HeaderId=='')
		{
			$HeaderId = isset($_POST['h_headerid']) ? $_POST['h_headerid']:false;
		}
		$insArr['NAME'] = $Text_ShiftName;
		$insArr['DESCRIPTION'] = $Text_Description;
		$insArr['TIMEZONE'] = $Combo_TimeZone;
		$insArr['WORKSHIFT_TYPE'] = $Combo_WorkShiftType;		
		$insArr['PART_TIME'] = $Combo_PartTime;		
		$insArr['ACTIVE_FLAG'] 	= ($Check_Active==1)?"Y":"N";
	//	$insArr['OVERTIME_ALLOWED'] = ($Check_AllowOvertime==1)?"Y":"N";
	//	$insArr['IN_USE_FLAG'] 	= ($Check_InUse==1)?"Y":"N";		
		$insArr['LAST_UPDATED_BY']=$LoginUserId;
		$insArr['SITE_ID']=$SiteId;
		if($HeaderId!='')
		{
			updatedata("cxs_workshifts",$insArr,"Where cxs_workshifts.WORKSHIFT_ID = $HeaderId");		
		}	
		else
		{
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;			
			insertdata("cxs_workshifts",$insArr);	
			$HeaderId= mysql_insert_id();		
		}
		
		if($HeaderId!= '')
		{
			if($Combo_WorkShiftType!='Flexible Shift')
			{
				mysql_query("Delete from cxs_flex_schedule where WORKSHIFT_ID = $HeaderId");
			}
			else			
			{
				mysql_query("Delete from cxs_workshifts_detail where WORKSHIFT_ID = $HeaderId");
			}	
		//	$qry = "DELETE FROM cxs_workshifts_detail where WORKSHIFT_ID = $HeaderId";
			//mysql_query($qry);		
			$Text_ShiftHours = isset($_POST["Text_ShiftHours"] )? $_POST["Text_ShiftHours"]: false;								
			for ($i = 1; $i <= 7; $i++) 
			{	
				$Combo_BeginWorkDay = isset($_POST["Combo_BeginWorkDay$i"] )? $_POST["Combo_BeginWorkDay$i"]: false;						
				unset($insArr);						
				$insArr['WORKSHIFT_ID']=$HeaderId;
				$insArr['BEGIN_WORKDAY']=$Combo_BeginWorkDay;
				$insArr['SHIFT_HOURS']= $Text_ShiftHours[$i-1];
				/*$insArr['BEGIN_TIME']=$StartTime;							
				$insArr['END_TIME']=$EndTime;									*/
				$insArr['ROW_NO']=$i;
				$insArr['LAST_UPDATED_BY']=$LoginUserId;
				$qry = "Select * from cxs_workshifts_detail where WORKSHIFT_ID = $HeaderId and ROW_NO = $i";
				$result = mysql_query($qry);
				$noofRecords = mysql_num_rows($result);
				if($noofRecords==1)
				{
					updatedata("cxs_workshifts_detail",$insArr,"where WORKSHIFT_ID = $HeaderId and ROW_NO = $i");				
				}
				else
				{
					$insArr['CREATION_DATE']='now()' ;
					$insArr['CREATED_BY']=$LoginUserId;	
					if($Text_ShiftHours[$i-1]!='')	
					{
						insertdata("cxs_workshifts_detail",$insArr);				
					}
				}
			}
		}		 
		header("Location:workshifts.php");
	}
	if($HeaderId!='')
	{
		 $qry = "select * from cxs_workshifts left join cxs_flex_schedule on cxs_flex_schedule.WORKSHIFT_ID = cxs_workshifts.WORKSHIFT_ID where cxs_workshifts.WORKSHIFT_ID = $HeaderId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			 $Display_WorkshiftName = $row['NAME'];
			 $Display_Desc = $row['DESCRIPTION'];
			 $Display_TimeZone = $row['TIMEZONE'];
			 $Display_PartTime = $row['PART_TIME'];
			 $Display_WorkshiftType = $row['WORKSHIFT_TYPE'];
			 $Display_Active = $row['ACTIVE_FLAG'];
			 $Display_InUse = $row['IN_USE_FLAG'];			
			 $Display_StartDate = "";
			 $Display_EndDate = "";
				
			 if((!is_null($row['SCHEDULE_START_DATE'])) && (($row['SCHEDULE_START_DATE'])!='0000-00-00') )
			 {
				 $Display_StartDate = date('m/d/Y', strtotime($row['SCHEDULE_START_DATE']));
			 }
			 
			 if((!is_null($row['SCHEDULE_END_DATE'])) && (($row['SCHEDULE_END_DATE'])!='0000-00-00') )
			 {
				 $Display_EndDate = date('m/d/Y', strtotime($row['SCHEDULE_END_DATE']));
			 }
			 for($i=1;$i<=31;$i++)
			 {
				$key =  'DAYS_IN_MONTH'.$i;
				 ${'span'.$i} = "";	
				 if($row[$key]=="X")
				 {
					 ${'span'.$i}="Y";					
				 }
			 }
			 $j=2;
			 $SpanWeek1="";
			 for($i=0;$i<7;$i++)
			 {
				 $key =  strtoupper(jddayofweek($i,1)); 
				 ${'SpanWeek'.$j}="";
				  if($row[$key]=="X")
				  {
					  if ($i==6)
					  {
						  $SpanWeek1="Y";
					  }
					  else
					  {
						  ${'SpanWeek'.$j}="Y";
					  }
				  }
				  $j=$j+1;  
			 }
		}			
		$qry = "select * from cxs_workshifts_detail where WORKSHIFT_ID = $HeaderId order by ROW_NO";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$RowNo = $row['ROW_NO'];			
			${'Display_BeginWorkDay'.$RowNo} = $row['BEGIN_WORKDAY'];
			if( $row['SHIFT_HOURS']!='')
			{	
				${'Display_ShiftHours'.$RowNo} = number_format($row['SHIFT_HOURS'],2);
			}
			//${'Display_StartTime'.$RowNo} = $row['BEGIN_TIME'];			
			//${'Display_EndTime'.$RowNo} = $row['END_TIME'];			
		}
	}	
?>
<script type="text/javascript" >
	var TABLE_ROWAddr = 0;
	var TABLE_ROWCont = 0;
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create New Shift";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
	
	function checkValue()
	{
		var s1 = document.getElementById("Combo_WorkShiftType").value;
		if (s1 == "Flexible Shift")
		{
			document.getElementById("cmdDefineSchedule").disabled = false;						
			ClearDefineScheduleFields();
		}	
		else
		{
			document.getElementById("cmdDefineSchedule").disabled = true;
		}
		
		/*if (s1 == "Part Time Shift")
		{
			document.getElementById("Combo_PartTime").disabled = false;
		}
		else
		{
			document.getElementById("Combo_PartTime").disabled = true;
			document.getElementById("Combo_PartTime").value = "";
		}		*/
		CheckDetailStatus();
		if (s1!='')
		{
			WorkshiftTypeValue(s1);
		}
		else
		{
			for(var i=0;i<=6;i++)
			{
				$('#Text_ShiftHours'+i).val('');
			}
		}
	}
	
	function toggle(td)
	{
		td.className=(td.className=='out')?'over':'out';
	}

	function ChangeBackColor(current)
	{
		var id = "td"+current;		
		var spanValue = "";
		spanValue = document.getElementById("span"+current).innerHTML; 
		spanValue = spanValue.trim();
		if (spanValue=="")
		{
			document.getElementById(id).style.backgroundColor='#1d5db7';
			document.getElementById(id).style.color='#fff'; 				
			document.getElementById("span"+current).innerHTML = "Y";
		}
		else
		{
			document.getElementById(id).style.backgroundColor='#ffffff'; 
			document.getElementById(id).style.color="#000";
			document.getElementById("span"+current).innerHTML = "";
		}		
	}
	
	function ChangeBackColorForWeek(current)
	{
		var id = "td-week-"+current;		
		var spanValue = "";
		spanValue = document.getElementById("span-week-"+current).innerHTML; 
		spanValue = spanValue.trim();
		if (spanValue=="")
		{
			document.getElementById(id).style.backgroundColor='#1d5db7'; 
			document.getElementById(id).style.color='#fff'; 			
			document.getElementById("span-week-"+current).innerHTML = "Y";
		}
		else
		{
			document.getElementById(id).style.backgroundColor='#ffff';
			document.getElementById(id).style.color="#000";
			document.getElementById("span-week-"+current).innerHTML = "";
		}		
	}
	
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="../js/jsfunctions.js"></script>
<!--
<link href="../css/loader-style" rel="stylesheet">
<script src="../js/loader-function.js"></script>
-->

<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.option_color 
	{
		color: #000;
		font-size: 12px;
	}
	.form-control
	{
	//	padding-left:4px;padding-right:4px;
	}
	.myTableFormat
	{
		text-align: center;
		font-size: 16px;
		font-weight: normal;
		color: #333;
		background: #fff;
		padding: 15px 0;		
	}
	
.myTDFormat
{
	color: #333;
	padding: 15px 10px;
	margin : 10px;10px;
	font-weight: 600;
	font-size: 13px;
	height:50px;	
	cursor: pointer;
}
@media (min-width: 992px) 
{
	.ShiftTableWidth
	{
		width: 50%;
	}
	
}
#fade {
				display: none;
				position:absolute;
				top: 0%;
				left: 0%;
				width: 100%;
				height: 100%;
				background-color: #ababab;
				z-index: 1001;
				-moz-opacity: 0.8;
				opacity: .70;
				filter: alpha(opacity=80);
			}

			#modal 
			{
				display: none;
				position: absolute;
				top: 45%;
				left: 45%;
				width: 64px;
				height: 64px;
				padding:10px 10px 5px;
				border: 3px solid #ababab;
				box-shadow:1px 1px 10px #ababab;
				border-radius:20px;
				background-color: white;
				z-index: 1002;
				text-align:right;
				overflow: auto;
			}

</style>

</head>

<body>
<?php include("header.php"); ?>



<form method="post" action="" >
	<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalFlexibleShift" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel"> Add New Flexible Shift </h4>
				</div>
				<div class="modal-body"> 
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active in" id="genrnal">
							<div class="tab-info-bx">
							  <!-- pop up start -->
								<button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="left" data-content="Dummy content" data-original-title="" title=""> <i class=" fa fa-eye"></i> </button> </div>
							<!-- pop up end -->
						  
								<div class="tabbable" id = "tabs">
									<ul class="nav nav-tabs nested-tab-cus">
										<li id = "tab1" class="active"><a href="#sub11"> By Start/ End Date </a></li>
										<li id = "tab2" ><a href="#sub12"> By Days in a Month Basis </a> </li>
										<li id = "tab3"><a href="#sub13"> Days in a Week Basis </a> </li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane fade active in" id="sub11">
											<div class="col-sm-12">
												<div class="row">&nbsp;&nbsp;</div>
												<div class="row">
													<div class="col-sm-6">
														<div class="form-group cus-form-ico">
															<label class="col-sm-4 control-label text-right">Start Date</label>
															<div class="col-sm-8">																  
															  <input type="text" id = "Text_StartDate" name = "Text_StartDate" class="form-control requirefieldcls form_datetime" required placeholder="" maxlength="10" value = "<?php echo $Display_StartDate; ?>" >
															  <span class="inp-icons"><i class="fa fa-calendar"></i></span> 
															</div>
														</div>
													</div>
													<div class="col-sm-6">
														<div class="form-group cus-form-ico">
															<label  class="col-sm-4 control-label text-right">End Date</label>
															<div class="col-sm-8">
																<input type="text" id = "Text_EndDate" name = "Text_EndDate" class="form-control requirefieldcls form_datetime" required placeholder="" maxlength="10" value = "<?php echo $Display_EndDate; ?>" >
																<span class="inp-icons"><i class="fa fa-calendar"></i></span> 
															</div>
														</div>
													</div>															
												</div>                    
											</div>
										</div>

										<div class="tab-pane fade" id="sub12">
											<div class="col-sm-12">
												<div class="row">
													<div class="col-sm-12">

														<div class="in-tbe-hd">Dates of Every Month </div>
														<div class="date-bx tble-pd-none date-bx-hover">
														<div class="table-responsive">
															<table class="table table-bordered" id = "Table-DaysInMonthBasis" >
															  <tbody>
																<?php 																 
																	$k=1;
																	for($i=1;$i<=5;$i++)
																	{?>
																		<tr >
																			<?php 
																				for($j=1;$j<=7;$j++)
																				{?>	
																					<td id = "<?php echo "td$k"; ?>" class = "myTDFormat" style = "vertical-align: middle;" onclick = "ChangeBackColor(<?php echo$k; ?>);" >
																					<span id = "<?php echo"span$k" ?>" style = "display:none"> <?php echo ${'span'.$k}; ?> </span>																					
																						<?php echo $k ; $k=$k+1;
																							  if($k==31){break;}
																						?> 
																					</td>																						
																		<?php   } 
																				if($k==31)
																				{
																					echo "<td colspan = 5 id = 'td$k' class = 'myTDFormat' style = 'vertical-align: middle;' onclick = 'ChangeBackColor($k);' >
																						<span id = 'span$k' style = 'display:none'> ${'span'.$k}  </span>
																						Last Day 
																						</td>";
																				}	
																		?>	
																		</tr>	
																<?php	}
																?>
															  </tbody>
															</table>
														</div>
														</div>
													</div>
												</div>
											</div>
										</div>										
										<div class="tab-pane fade" id="sub13">
											<div class="col-sm-12">
												<div class="in-tbe-hd">Days in a Week </div>
												<div class="date-bx tble-pd-none date-bx-hover">
													<div class="table-responsive">
														<table class="table table-bordered" id = "Table-DaysInWeek">
														  <tr>
															<td id = "td-week-1" class = "myTDFormat" style = "vertical-align: middle;" onclick = "ChangeBackColorForWeek(1);" > <span id = "<?php echo"span-week-1" ?>" style = "display:none"> <?php echo $SpanWeek1; ?> </span> Sunday </td>
															<td id = "td-week-2" class = "myTDFormat" style = "vertical-align: middle;"onclick = "ChangeBackColorForWeek(2);" > <span id = "<?php echo"span-week-2" ?>" style = "display:none"> <?php echo $SpanWeek2; ?> </span> Monday </td>
															<td id = "td-week-3" class = "myTDFormat" style = "vertical-align: middle;" onclick = "ChangeBackColorForWeek(3);" > <span id = "<?php echo"span-week-3" ?>" style = "display:none"> <?php echo $SpanWeek3; ?> </span>Tuesday </td>
															<td id = "td-week-4" class = "myTDFormat" style = "vertical-align: middle;" onclick = "ChangeBackColorForWeek(4);" > <span id = "<?php echo"span-week-4" ?>" style = "display:none"> <?php echo $SpanWeek4; ?> </span>  Wednesday </td>
															<td id = "td-week-5" class = "myTDFormat" style = "vertical-align: middle;"onclick = "ChangeBackColorForWeek(5);" > <span id = "<?php echo"span-week-5" ?>" style = "display:none"> <?php echo $SpanWeek5; ?> </span>  Thursday </td>
															<td id = "td-week-6" class = "myTDFormat" style = "vertical-align: middle;" onclick = "ChangeBackColorForWeek(6);" > <span id = "<?php echo"span-week-6" ?>" style = "display:none"> <?php echo $SpanWeek6; ?> </span>  Friday </td>
															<td id = "td-week-7" class = "myTDFormat" style = "vertical-align: middle;"  onclick = "ChangeBackColorForWeek(7);" > <span id = "<?php echo"span-week-7" ?>" style = "display:none"> <?php echo $SpanWeek7; ?> </span>   Saturday  </td>
														  </tr>
														</table>
													</div>
												</div>
											</div>
										</div>
										<div class="clear-both "></div>
										<div class="text-right mar-tp20 pd-r-15 cr-user">
											<button type="button" class="btn btn-primary btn-style" id = "cmdSaveFlexibleShift" name = "cmdSaveFlexibleShift"  onclick = "CheckFlexibleShiftValue()" > Save </button>
										</div>
									</div>
								</div>
						</div>	
					</div>            
				</div>	
			</div>					
		</div>
	</div>	
</form>
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="workshifts.php"> Workshifts </a></li>
          <li> <a href="#"> <?php echo $s_caption; ?> Shift  </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
			<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>			
        </div>
      </div>
      <!-- inner work-->
	
	
				
		<div class="cont-box">
			<div class="pge-hd">
			  <h2 class="sec-title"  > <label><?php echo $s_caption; ?> Shift</label> 
			  <label class = "fright" style = "font-size: 12px; margin-right : 40px;"> <input type="checkbox" id="Check_AddInUse" name="Check_AddInUse" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled> In Use </label>
			   </h2>
			</div>
			<div  style = "  text-align:center;  width:100%;">
				<div id="fade">
				</div>
				<div id="modal" >
					<img id="loader" src="../img/loading.gif" style="top:15px;left:15px;" />
				</div>	
			</div>
			<form class="form" id="Form1" name="Form1" action="" method="POST" onsubmit = "return chkfld_form1()">
				<div class="shfi-block">	
					<div class = "row">
						<div class="col-sm-12">
							<div class="cus-form-cont">		
								<div class="col-sm-4 form-group">
								  <label> Shift Name </label>
								  <input type="text" id = "Text_ShiftName" name = "Text_ShiftName" class="form-control requirefieldcls" required  maxlength="50" onchange = "CheckDetailStatus()" onblur="CheckDuplicate(this.id)" value = "<?php echo $Display_WorkshiftName; ?>">
								  <span id = "Span_ShiftName">&nbsp;</span>
								</div>
								
								<div class="col-sm-4 form-group">
								  <label> Description </label>
								  <input type="text" id = "Text_Description" name = "Text_Description" class="form-control requirefieldcls" required  maxlength="50" onchange = "CheckDetailStatus()" value = "<?php echo $Display_Desc; ?>" >
								</div>
								  
								
								<div class="col-sm-4 form-group">
									<label> Time Zone </label>
									<select id = "Combo_TimeZone" name = "Combo_TimeZone" class="form-control requirefieldcls" required maxlength="20" onchange="checkValue()" >		
										<option value=""> - Time Zone -  </option>
										<option value="HAST" <?php echo ($Display_TimeZone=="HAST")?"selected":""; ?> > HAST	Hawaii-Aleutian Standard Time</option>
										<option value="AKDT" <?php echo ($Display_TimeZone=="AKDT")?"selected":""; ?>> AKDT	Alaska Daylight Time	</option>
										<option value="PDT" <?php echo ($Display_TimeZone=="PDT")?"selected":""; ?>> PDT	Pacific Daylight Time	 </option>
										<option value="MDT" <?php echo ($Display_TimeZone=="MDT")?"selected":""; ?>> MDT	Mountain Daylight Time	</option>
										<option value="CDT" <?php echo ($Display_TimeZone=="CDT")?"selected":""; ?>> CDT	Central Daylight Time	 </option>
										<option value="EDT" <?php echo ($Display_TimeZone=="EDT")?"selected":""; ?> >EDT	Eastern Daylight Time </option>
									</select>
								</div>	
								<div class="clear-both"></div>
								<div class="col-sm-4 form-group">
									 <label> Work Shift Type </label>
									<select id = "Combo_WorkShiftType" name = "Combo_WorkShiftType" class="form-control requirefieldcls" required maxlength="20" onchange="checkValue()" >		
										<option value=""> - Workshift Type -  </option>
										<option value="9/8/80 Shift"  <?php echo ($Display_WorkshiftType=="9/8/80 Shift")?"selected":""; ?> > 9/8/80 Shift </option>
										<option value="4/10/40 Shift"  <?php echo ($Display_WorkshiftType=="4/10/40 Shift")?"selected":""; ?> > 4/10/40 Shift </option>
										<option value="Regular 40Hours Shift"  <?php echo ($Display_WorkshiftType=="Regular 40Hours Shift")?"selected":""; ?>> Regular 40Hours Shift </option>
										<option value="Flexible Shift"  <?php echo ($Display_WorkshiftType=="Flexible Shift")?"selected":""; ?>> Flexible Shift </option>
										<option value="Hourly Shift"  <?php echo ($Display_WorkshiftType=="Hourly Shift")?"selected":""; ?>> Hourly Shift </option>
										<option value="Six Days Shift"  <?php echo ($Display_WorkshiftType=="Six Days Shift")?"selected":""; ?>> Six Days Shift </option>
										<!--<option value="Part Time Shift"  <?php echo ($Display_WorkshiftType=="Part Time Shift")?"selected":""; ?>> Part Time Shift </option>-->
									</select>
								</div>
								<!--
								<div class="col-sm-4 form-group">
									 <label> Part Time </label>
									<select id = "Combo_PartTime" name = "Combo_PartTime" class="form-control" maxlength="20" disabled onchange ="checkPartTimeValue()">		
										<option value=""> - Part Time -  </option>
										<option value="1/2 Time Base = 4.0 Hrs."  <?php echo ($Display_PartTime=="1/2 Time Base = 4.0 Hrs.")?"selected":""; ?>> 1/2 Time Base = 4.0 Hrs.  </option>
										<option value="3/8 Time Base = 3.0 Hrs." <?php echo ($Display_PartTime=="3/8 Time Base = 3.0 Hrs.")?"selected":""; ?>> 3/8 Time Base = 3.0 Hrs. </option>
										<option value="3/4 Time Base = 6.0 Hrs." <?php echo ($Display_PartTime=="3/4 Time Base = 6.0 Hrs.")?"selected":""; ?>> 3/4 Time Base = 6.0 Hrs. </option>
										<option value="2/5 Time Base = 3.2 Hrs." <?php echo ($Display_PartTime=="2/5 Time Base = 3.2 Hrs.")?"selected":""; ?>> 2/5 Time Base = 3.2 Hrs. </option>
										<option value="4/5 Time Base = 6.4 Hrs." <?php echo ($Display_PartTime=="4/5 Time Base = 6.4 Hrs.")?"selected":""; ?>> 4/5 Time Base = 6.4 Hrs. </option>
										<option value="3/5 Time Base = 4.8 Hrs." <?php echo ($Display_PartTime=="3/5 Time Base = 4.8 Hrs.")?"selected":""; ?>> 3/5 Time Base = 4.8 Hrs. </option>
										<option value="1/8 Time Base = 1.0 Hrs." <?php echo ($Display_PartTime=="1/8 Time Base = 1.0 Hrs.")?"selected":""; ?>>1/8 Time Base = 1.0 Hrs. </option>
										
										<option value="5/8 Time Base = 5.0 Hrs." <?php echo ($Display_PartTime=="5/8 Time Base = 5.0 Hrs.")?"selected":""; ?>> 5/8 Time Base = 5.0 Hrs. </option>
										<option value="1/10 Time Base = 0.8 Hrs." <?php echo ($Display_PartTime=="1/10 Time Base = 0.8 Hrs.")?"selected":""; ?>> 1/10 Time Base = 0.8 Hrs. </option>
										<option value="7/10 Time Base = 5.6 Hrs." <?php echo ($Display_PartTime=="7/10 Time Base = 5.6 Hrs.")?"selected":""; ?>> 7/10 Time Base = 5.6 Hrs. </option>
										<option value="1/5 Time Base = 1.6 Hrs." <?php echo ($Display_PartTime=="1/5 Time Base = 1.6 Hrs.")?"selected":""; ?>>1/5 Time Base = 1.6 Hrs. </option>
										
										<option value="7/8 Time Base = 7.0 Hrs." <?php echo ($Display_PartTime=="7/8 Time Base = 7.0 Hrs.")?"selected":""; ?>> 7/8 Time Base = 7.0 Hrs. </option>
										<option value="1/4 Time Base = 2.0 Hrs." <?php echo ($Display_PartTime=="1/4 Time Base = 2.0 Hrs.")?"selected":""; ?>> 1/4 Time Base = 2.0 Hrs. </option>
										<option value="9/10 Time Base = 7.2 Hrs." <?php echo ($Display_PartTime=="9/10 Time Base = 7.2 Hrs.")?"selected":""; ?>> 9/10 Time Base = 7.2 Hrs. </option>
										<option value="3/10 Time Base = 2.4 Hrs." <?php echo ($Display_PartTime=="3/10 Time Base = 2.4 Hrs.")?"selected":""; ?>>3/10 Time Base = 2.4 Hrs. </option>
										<option value="19/20 Time Base = 7.6 Hrs." <?php echo ($Display_PartTime=="19/20 Time Base = 7.6 Hrs.")?"selected":""; ?>>19/20 Time Base = 7.6 Hrs. </option>
									</select>
								</div>  	-->
								<div class="col-sm-4 form-group cr-user">
									<label style = "height : 16px;width : 480px;">&nbsp;</label>
									<button type="button" class="btn btn-primary btn-style" id = "cmdDefineSchedule"  name = "cmdDefineSchedule"  disabled onclick = "ShowDefineScheduleModal()"> Define Schedule</button>									
								</div>
								<div class="col-sm-8 form-group">
									<div class="checkbox">																				  
										<label style = "padding-right:5px;"> <input type="checkbox" id="Check_Active" name="Check_Active" <?php if($Display_Active == "Y"){ ?> checked="checked" <?php } ?>  value="1" > Active</label>
										<!--<label style = "padding-right:5px;"> <input type="checkbox" id="Check_AllowOvertime" name="Check_AllowOvertime" <?php if($Display_AllowOvertime == "Y"){ ?> checked="checked" <?php } ?>  value="1"> Allow Overtime </label>-->										
									</div>
								</div>									
								<div class="col-sm-4 form-group"> &nbsp;&nbsp; </div>								
							</div>
						</div>
					</div>
					<div class="data-bx ">						
							<div class="table-responsive " id = "div_detail" disabled>							
								<table class="table table-bordered mar-cont ShiftTableWidth " align="center"  >
									<thead>
										<tr>
											<th width = "10%" >Work Day</th>
											<th width = "10%">Shift Hours</th>																					
										</tr>
									</thead>
									<?php
										$days = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
										//$defaultStartTime = "8:00 AM";
										//$defaultEndTime = "4:00 PM";
									?>
									<tbody>
										<?php 
											$j=1;	
											//echo "value ".${'Display_ShiftHours'.$j}; 
											for ($i = 0; $i < 7; $i++) 
											{	
												$selectedDay = $days[$i];
										?>		
												<tr>
													<!-- Start Shift -->
													<td>
														<div class="form-group">
														  <select id = "<?php echo "Combo_BeginWorkDay$j"?>" name = "<?php echo "Combo_BeginWorkDay$j"?>" class="form-control option_color" disabled>
																<?php
																	if (${'Display_BeginWorkDay'.$j}== '')
																	{
																		$selectedValue = $selectedDay;	
																	}
																	else
																	{
																		$selectedValue = ${'Display_BeginWorkDay'.$j};
																	}
																	foreach($days as $arr)
																	{	
																		if ($selectedValue==$arr)
																		{
																			$IsSelected = "selected";
																		}
																		else
																		{
																			$IsSelected = "";
																		} ?>
																		<option  class = "option_color" value="<?php  echo $arr; ?>" <?php echo $IsSelected; ?> > <?php echo $arr; ?> </option>																			
															<?php	}	
																?>
														  </select>
														</div>
													</td>													
													<td> 
														<div class="form-group">
															<input type="text" class="form-control" id = "<?php echo "Text_ShiftHours$i"?>" name = '<?php echo 'Text_ShiftHours[]'; ?>'  value = "<?php echo (${'Display_ShiftHours'.($i+1)})?${'Display_ShiftHours'.($i+1)}:''; ?>" onkeypress="return onlyNos(event,this);" onblur = "DecimalDigit(this);" >
														</div>											
													</td>																								
												</tr>
									<?php 
										$j= $j+1;
									}?>
									</tbody>
								</table>
							</div>
							
					</div>
				</div>				
				<input type="hidden" id="h_headerid" name="h_headerid" value=""/>
				<input type="hidden" id="h_duplicate" name="h_duplicate" value=""/>
				<input type="hidden" id="h_IsFlexibleEntered" value=""/>
				<input type="hidden" id="h_IsEditAllowed" <?php if(($CREATE_PRIV_WorkShift_PERMISSION=='Y' || $UPDATE_PRIV_WorkShift_PERMISSION == 'Y') && $Display_InUse!='Y'){ ?> value = "Y" <?php } else {?> value = "N" <?php } ?> >
				<div class="fright cr-user mar-top-20pxs">
					<button <?php if($CREATE_PRIV_WorkShift_PERMISSION=='Y' || $UPDATE_PRIV_WorkShift_PERMISSION=='Y' ){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style"> Save Record </button>					
				</div>
			</form>			
		</div>
    </div>
  </div>
</section>
<footer> </footer>

<script type="text/javascript">
		function openModal()
		{
			document.getElementById('modal').style.display = 'block';
			document.getElementById('fade').style.display = 'block';
		}

		function closeModal()
		{
			document.getElementById('modal').style.display = 'none';
			document.getElementById('fade').style.display = 'none';
		}
		$("#ModalFlexibleShift").on("hidden.bs.modal", function () 
		{
			// put your default event here
			closeModal();
		});
		$(document).ready(function() 
		{
			
			$("#div_detail :input").attr("disabled", true);				
			for(var i=0;i<=6;i++)
			{
				$('#Text_ShiftHours'+i).bind("cut copy paste",function(e) 
				{
					e.preventDefault();
				});
			}
			CheckDetailStatus();	
			SetExistingValueColor();
			if ($("#h_IsEditAllowed").val()=="N")
			{
				$("#Form1 :input").prop("disabled",true);
			}
		});
		function SetExistingValueColor()
		{
			var spanValue = "";
			for(i=1;i<=31;i++)
			{
				spanValue = document.getElementById("span"+i).innerHTML;
				spanValue = spanValue.trim();
				id =  "td"+i;									
				if(spanValue=="Y")	
				{
					document.getElementById(id).style.backgroundColor='#1d5db7';
					document.getElementById(id).style.color='#fff';
				}
			}
			
			for(i=1;i<=7;i++)
			{
				spanValue = document.getElementById("span-week-"+i).innerHTML;
				spanValue = spanValue.trim();
				id =  "td-week-"+i;									
				if(spanValue=="Y")	
				{
					document.getElementById(id).style.backgroundColor='#1d5db7';
					document.getElementById(id).style.color='#fff';
				}
			}
			
		}
		/*$("#tab1").on("click", function () 
		{
			//alert("tab no 2 is clicked....");
		});*/
		function ShowDefineScheduleModal()
		{
			var HeaderId = document.getElementById("h_headerid").value;			
			if (HeaderId == '')
			{
				openModal();
				KEY = "AddFlexibleShiftHeader"
				var v1 = $('#Text_ShiftName').val();
				var v2 = $('#Text_Description').val();
				var v3 = $('#Combo_TimeZone').val();
				makeRequest("ajax-insert-record.php","REQUEST=CreateShift&ShiftName=" + v1 + "&desc="+v2+"&timezone="+v3 ); 
			}		
			$('#ModalFlexibleShift').modal();
		}
		function CheckFlexibleShiftValue()
		{
			var v1 = $('#Text_StartDate').val();
			var v2 = $('#Text_EndDate').val();
			var v3 = "",v4="",i;			
			if (v1!='' || v2!='')
			{
				if(v1=='')
				{
					$('a[href="#sub11"]').click();	
					alert("Please enter both start and end date");									
					document.getElementById("Text_StartDate").focus();
					return false;	
				}
				else if(v2=='')
				{
					$('a[href="#sub11"]').click();
					alert("Please enter both start and end date");					
					document.getElementById("Text_EndDate").focus();
					return false;
				}	
			}
			
			var s1 = "";
			for(i=1;i<=31;i++)
			{
				s1 = document.getElementById("span"+i).innerHTML.trim();				
				if (s1!='')
				{
					v3 = v3 + i + "|";
				}				
			}
			s1 = "";
			var weekday=new Array(7);
			weekday[0]="SUNDAY"; 
			weekday[1]="MONDAY"; 
			weekday[2]="TUESDAY"; 
			weekday[3]="WEDNESDAY"; 
			weekday[4]="THURSDAY"; 
			weekday[5]="FRIDAY"; 
			weekday[6]="SATURDAY"; 
			
			for(i=1;i<=7;i++)
			{
				s1 = document.getElementById("span-week-"+i).innerHTML.trim();
				if (s1!='')
				{
					v4 = v4 + weekday[i-1] + "|";
				}				
			}
			var tab1="";
			if (v1!='' && v2!='')
			{
				tab1=v1 + "|" + v2;
			}
			
			if ((tab1!= '' && v3!='') || (tab1!= '' && v4!='') || (v3!= '' && v4!='') )			
			{
				alert("You have choose days from multiple tabs. Please select days from any single tab.");
				return false;
			}
			else
			{
				$('#h_IsFlexibleEntered').val('Y');
				var ScheduleType = "";
				var TabValues = "";
				var HeaderId =document.getElementById("h_headerid").value; 				
				if(tab1!='')
				{
					ScheduleType = "DATE_RANGE";
					TabValues = tab1;
				}
				else if(v3!='')
				{
					ScheduleType = "DAYS_IN_MONTH";
					TabValues = v3;
				}
				else if (v4!='')
				{
					ScheduleType = "DAYS_IN_WEEK";
					TabValues = v4;
				}
				
				if (ScheduleType=='')
				{
					alert("Please Select / Enter Value For Flexible Shift");
					return false;
				}
				openModal();
				KEY = "AddFlexibleShift";		
				makeRequest("ajax-insert-record.php","REQUEST=Add-Record&TableName=cxs_flex_schedule&ScheduleType=" + ScheduleType+"&TabValues=" + TabValues+"&HeaderId="+HeaderId);				
				$('#ModalFlexibleShift').modal('hide');
				
			}
		}
		
		function ClearDefineScheduleFields()
		{
			$('#Text_StartDate').val('');
			$('#Text_EndDate').val('');
			for(i=1;i<=31;i++)
			{ 
				document.getElementById("td"+i).style.backgroundColor='#ffffff'; 
				document.getElementById("td"+i).style.color="#000";
				document.getElementById("span"+i).innerHTML = "";
			}
			
			for(i=1;i<=7;i++)
			{
				document.getElementById("td-week-"+i).style.backgroundColor='#ffffff'; 
				document.getElementById("td-week-"+i).style.color="#000";
				document.getElementById("span-week-"+i).innerHTML = "";
			}
			
		}
		function DetailDisableValue(jFlag)
		{
			//$("#div_detail :input").attr("disabled", jFlag);			
			$("#div_detail").attr("disabled", jFlag);			
			$('#Combo_WorkShiftType').attr("disabled",jFlag);
			if(jFlag == true)
			{
				//$('#Combo_WorkShiftType').val('');			
				$('#cmdDefineSchedule').attr("disabled",jFlag);
			}
			var s1 = $('#Combo_WorkShiftType').val();		
			if(s1=='Part Time Shift')
			{
				$('#Combo_PartTime').attr("disabled",jFlag);
			}
			else if(s1=='Flexible Shift')
			{
				$('#cmdDefineSchedule').attr("disabled",jFlag);
			}
		}
		
		function CheckDetailStatus()
		{
			var s1 = document.getElementById("Text_ShiftName").value;
			var s2 = document.getElementById("Text_Description").value;
			var s3 = document.getElementById("Combo_TimeZone").value;
			var s4 = "<?php echo $HeaderId; ?>";
			if (s4!='')
			{
				document.getElementById("h_headerid").value = s4;
			}
			if (s1!='' && s2!='' && s3!= '')
			{
				DetailDisableValue(false);
			}
			else
			{
				DetailDisableValue(true);
			}			
			/*if(s4=='')
			{
				if($('#Combo_WorkShiftType').val()!='')
				{
					WorkshiftTypeValue($('#Combo_WorkShiftType').val())
				}
			}*/
		}
		function WorkshiftTypeValue(sType)
		{
			for(i=0;i<=6;i++)
			{
				$('#Text_ShiftHours'+i).attr("disabled",false);
			}
			
			if (sType == '9/8/80 Shift')
			{
				for(i=0;i<=6;i++)
				{
					$('#Text_ShiftHours'+i).attr("disabled",true);	
					
					if(i<=3)
					{
						$('#Text_ShiftHours'+i).val('9.00');
					}
					else if(i==4)
					{
						$('#Text_ShiftHours'+i).val('8.00');	
					}
					else if (i>4)
					{
						$('#Text_ShiftHours'+i).val('');
					}
				}
				
//				$('#Text_ShiftHours6').attr("disabled",true);
			}
			else if (sType == '4/10/40 Shift')
			{
				for(i=0;i<=3;i++)
				{
					$('#Text_ShiftHours'+i).val('10.00');					
				}
				$('#Text_ShiftHours'+i).val('');
				for(i=5;i<=6;i++)
				{
					$('#Text_ShiftHours'+i).val('');
					$('#Text_ShiftHours'+i).attr("disabled",true);
				}
			}
			else if (sType == 'Flexible Shift' || sType == 'Part Time Shift')
			{
				for(i=0;i<=6;i++)
				{
					$('#Text_ShiftHours'+i).val('');
					$('#Text_ShiftHours'+i).attr("disabled",true);
				}
			}
			
			
		}
		function chkfld_form1()
		{	
			var s1 = $('#Combo_WorkShiftType').val();
			var flag_TotalDaysEntry=0;
			var TotalDaysValue=0;
			var CurrentValue='';
			if(s1=='4/10/40 Shift')
			{
				CurrentValue='';
				for(var i=0;i<=6;i++)
				{
					CurrentValue = $('#Text_ShiftHours'+i).val();
					if (CurrentValue!='')
					{
						if (parseInt(CurrentValue)!='10')
						{
							//alert("Shift Hours Must 40 Hours.");
							alert("Shift Hours Must 10 Hours Per Day.");
							return false;
						}
						else
						{
							TotalDaysValue = TotalDaysValue+parseFloat(CurrentValue);
						}
					}
				}
				if (TotalDaysValue!=40)
				{
					alert("Shift Total Hours Must Match 40 Hours.");
					$('#Text_ShiftHours0').focus();
					return false;
				}
			}
			else if(s1=='Regular 40Hours Shift')
			{
				CurrentValue='';
				for(var i=0;i<=6;i++)
				{
					CurrentValue = $('#Text_ShiftHours'+i).val();
					if (CurrentValue!='')
					{
						flag_TotalDaysEntry++;
						TotalDaysValue=TotalDaysValue+ parseFloat($('#Text_ShiftHours'+i).val());
					}
				}
				if (TotalDaysValue != 40)
				{
					alert("Shift Total Hours Must Match 40 Hours.");
					return false;
				}
				else if(flag_TotalDaysEntry!=5)
				{
					alert("Regular 40Hours Shift Required 5 days.");
					return false;
				}
			}
			else if (s1=='Flexible Shift')
			{
				if($('#h_IsFlexibleEntered').val()!='Y')
				{
					alert("Please Define Schedule For Flexible Shift Type");
					ShowDefineScheduleModal();
					return false;
				}
			}
			else if (s1=='Hourly Shift')
			{
				CurrentValue='';
				for(var i=0;i<=6;i++)
				{
					CurrentValue = $('#Text_ShiftHours'+i).val();
					if (CurrentValue>24)
					{
						$('#Text_ShiftHours'+i).focus();
						return false;
					}
				}
			}
			else if(s1=='Six Days Shift')
			{
				CurrentValue='';
				for(var i=0;i<=6;i++)
				{
					CurrentValue = $('#Text_ShiftHours'+i).val();
					if (CurrentValue!='')
					{
						flag_TotalDaysEntry++;
						TotalDaysValue=TotalDaysValue+ parseFloat($('#Text_ShiftHours'+i).val());
					}
				}
				if (TotalDaysValue != 48)
				{
					alert("Shift Total Hours Must Match 48 Hours.");
					return false;
				}
				else if(flag_TotalDaysEntry!=6)
				{
					alert("Six Days Shift Required 6 days.");
					return false;
				}
			}
			else if(s1=='Part Time Shift')
			{
				if($('#Combo_PartTime').val()=='')
				{
					alert("Please Select Part Time");
					$('#Combo_PartTime').focus();
					return false;
				}
			}
			
			for(var i=0;i<=6;i++)
			{
				$('#Text_ShiftHours'+i).attr("disabled",false);	
			}
			
		}
		
		function CheckDuplicate(name)
		{	
			if (name!='')
			{
				KEY = "CheckDuplicate";				
				var s1="";
				var str="";
				var TableName = "cxs_workshifts";
				var FieldName = "NAME";
				var FieldValue = "";
				var FieldId = "";
				var SelectedId = "";								
				FieldValue = document.getElementById('Text_ShiftName').value;					
				makeRequest("ajax-checkduplicate.php","REQUEST=CheckDuplicate&TableName=" + TableName+"&FieldName="+FieldName+"&FieldValue="+FieldValue+"&FieldId="+FieldId+"&SelectedId="+SelectedId);
			}
		}
		$('.form_datetime').datepicker(
		{
			//format:'DD,  MM d, yyyy',
			format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
		});	
		/*$('.form_time').timepicker({
			//format : 'H:i:s',
			template: false,
			showInputs: false,			
			minuteStep: 1			
		});*/
		
		function makeRequest(url,data)
			{
				var http_request = false;
				if (window.XMLHttpRequest) { // Mozilla, Safari, ...
					http_request = new XMLHttpRequest();
					if (http_request.overrideMimeType) {
						http_request.overrideMimeType('text/xml');
						// See note below about this line
					}
				} else if (window.ActiveXObject) { // IE
					try {
						http_request = new ActiveXObject("Msxml2.XMLHTTP");
					} catch (e) {
						try {
							http_request = new ActiveXObject("Microsoft.XMLHTTP");
						} catch (e) {}
					}
				}

				if (!http_request) {
					alert('Giving up :( Cannot create an XMLHTTP instance');
					return false;
				}
				http_request.onreadystatechange = function() { alertContents(http_request); };
				http_request.open('POST', url, true);
				http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				http_request.send(data);
		}

		function alertContents(http_request)
		{
			if (http_request.readyState == 4)
			{
				if (http_request.status == 200)
				{ 
					if(KEY == "CheckFavoriteData")
					{
						var s1 = http_request.responseText;	
						s1=s1.trim();				
						str = s1;
						var n;
						n = str.lastIndexOf("No");					
						if (n>=0)//(s1=="No")
						{
							document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
							s1 = str.substring(0,n);											
						}
						else
						{
							document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
						}					
						document.getElementById("favorite_list").innerHTML = s1;
					}
					else if(KEY == "AddFlexibleShiftHeader")
					{
						document.getElementById("h_headerid").value = http_request.responseText.trim();
						closeModal();
					}	
					else if(KEY == "AddFlexibleShift")
					{
						//alert(http_request.responseText);
						closeModal();
					}
					else if (KEY == 'CheckDuplicate')
					{
						var s1 = http_request.responseText;
						s1 = s1.trim();
						if(s1.length > 1)
						{
							document.getElementById("Span_ShiftName").innerHTML = s1;
							document.getElementById("h_duplicate").value = "Y";	
							document.getElementById("Text_ShiftName").focus();					
						}
						else
						{
							document.getElementById("Span_ShiftName").innerHTML = "&nbsp;";
						}
					}		
				}
				else
				{
					document.getElementById(KEY).innerHTML = "";
					alert('There was a problem with the request.');
				}
			}
		}	
		
		function DecimalDigit(ele)
		{	
			var val = $(ele).val();
			if(val.indexOf(',') > -1) 
			{
				val = val.replace(',', '.');
			}
			var num = parseFloat(val);
			var num = num.toFixed(2);
			if(isNaN(num)) 
			{
				num = '';
			}
			$(ele).val(num);		
			
			
			var WorkshifType = $('#Combo_WorkShiftType').val();	
			if (WorkshifType=='Hourly Shift')
			{
				CheckValidation(ele.id);
			}
			else
			{
				CheckValidation(ele.id);
			}
		}
		function CheckValidation(id)
		{
			var val = document.getElementById(id).value; //$(id).val();
			if (val>24)	
			{
				alert("Shift Hours Maximum 24 Hours Allowed.");					
				
				$('#'+id).val("");
				$('#'+id).focus();
				document.getElementById(id).focus();	
				//ele.select();
				//document.getElementById("Text_ShiftHours"+currentRow).focus();
			}
		}
		function checkPartTimeValue()
		{
			var SelectedValue = $('#Combo_PartTime').val();
			var ShiftHours='';
			if (SelectedValue=="1/2 Time Base = 4.0 Hrs.")
			{
				ShiftHours="4.00";
			}
			else if (SelectedValue=="3/8 Time Base = 3.0 Hrs.")
			{
				ShiftHours="3.00";
			}	
			else if(SelectedValue=="3/4 Time Base = 6.0 Hrs.") 
			{
				ShiftHours="6.00";
			}
			else if(SelectedValue=="2/5 Time Base = 3.2 Hrs.")
			{
				ShiftHours="3.20";
			}
			else if (SelectedValue=="4/5 Time Base = 6.4 Hrs.")
			{
				ShiftHours="6.40";
			}
			else if (SelectedValue=="3/5 Time Base = 4.8 Hrs.") 
			{
				ShiftHours="4.80";
			}
			else if(SelectedValue=="1/8 Time Base = 1.0 Hrs.") 
			{
				ShiftHours="1.00";
			}							
			else if (SelectedValue=="5/8 Time Base = 5.0 Hrs.") 
			{
				ShiftHours="5.00";
			}				
			else if (SelectedValue=="1/10 Time Base = 0.8 Hrs." ) 
			{
				ShiftHours="0.80";
			}
			else if (SelectedValue=="7/10 Time Base = 5.6 Hrs.")
			{
				ShiftHours="5.60";
			}	
			else if (SelectedValue=="1/5 Time Base = 1.6 Hrs.")
			{
				ShiftHours="1.60";
			}
			else if (SelectedValue=="7/8 Time Base = 7.0 Hrs.")
			{
				ShiftHours="7.00";
			}
			else if (SelectedValue=="1/4 Time Base = 2.0 Hrs.")
			{
				ShiftHours="2.00";
			}
			else if (SelectedValue=="9/10 Time Base = 7.2 Hrs.")
			{
				ShiftHours="7.20";
			}	
			else if (SelectedValue=="3/10 Time Base = 2.4 Hrs.")
			{
				ShiftHours="2.40";
			}
			else if (SelectedValue=="19/20 Time Base = 7.6 Hrs.")
			{
				ShiftHours="7.60";
			}	
			for(i=0;i<=6;i++)
			{
				$('#Text_ShiftHours'+i).val(ShiftHours);
			}
		}
		
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>