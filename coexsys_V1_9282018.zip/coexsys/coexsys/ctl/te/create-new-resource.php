<?php ob_start ();	 
	include("te-functions.php");
	check_login();
?>
<?php 
	$s_caption = "";
	$s_caption = "Create";
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_Resources_PERMISSION = "Y";
		$UPDATE_PRIV_Resources_PERMISSION = "Y";	
	}
	else
	{
		$CREATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','Resources',$_SESSION['user_id']);
		$UPDATE_PRIV_Resources_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','Resources',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_Resources_PERMISSION=='N' && $UPDATE_PRIV_Resources_PERMISSION=='N' )
	{
		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id']; 
	$IsAllowPreApproval = getvalue("cxs_am_ta_rules","ALLOW_PREAPPROVAL","where USER_ID = $LoginUserId");
	$PageName = "create-new-resource.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$record_per_pageAddr = 5;
	$record_per_pageCont = 5;
	if (isset($_GET["pageAddr"]))
	{
		$pageAddr  = $_GET["pageAddr"];		
	}
	else
	{
		$pageAddr=1; 
	}
	
	if (isset($_GET["pageCont"]))
	{
		$pageCont  = $_GET["pageCont"];
	}
	else
	{
		$pageCont=1;
	}
	
	$start_fromAddr = ($pageAddr-1) *  $record_per_pageAddr;
	$start_fromCont = ($pageCont-1) *  $record_per_pageCont;
	
	$insArr = array();
	
	$AddressListRows= 5;
	$ContactListRows = 5;
	$HeaderId = "";
	$Records = 0;
	$qry = "SELECT count(*) as expr1 from cxs_resources where SITE_ID = $SiteId";		
	$result = mysql_query($qry);	
	while($row=mysql_fetch_array($result))
	{
		$Records = $row['expr1'];		
	}
	$IsAllowSupervisor = "";
	if ($Records>1)// ($Records>=1)
	{
		$IsAllowSupervisor = "Y";
	}	
	
	
	if (isset($_GET["hid"]))
	{
		$HeaderId  = $_GET["hid"];
		$s_caption = "Update";
		DisplayRecord($HeaderId);	
	}
	$IsOverrideInUse = "";
	if($HeaderId!='')
	{
		$qry = "select cxs_am_roles.OVERRIDE_INUSE from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID Inner join cxs_am_roles on cxs_am_roles.ROLE_ID = cxs_users.ROLE_ID  where cxs_resources.RESOURCE_ID = $HeaderId and cxs_resources.SITE_ID = $SiteId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$IsOverrideInUse = $row['OVERRIDE_INUSE'];
		}
	}
	
	$IsUpdateCont = isset( $_POST['h_field_updateCont'] )? $_POST['h_field_updateCont']: "";	
	$TotalRowsCont = isset($_REQUEST['h_NumRowsCont'])?$_REQUEST['h_NumRowsCont']:0;
	
	$IsUpdateAddr = isset( $_POST['h_field_updateAddr'] )? $_POST['h_field_updateAddr']: "";	
	$TotalRowsAddr = isset($_REQUEST['h_NumRowsAddr'])?$_REQUEST['h_NumRowsAddr']:0;
	
	function DisplayRecord($HeaderId1)
	{
		global $Display_FirstName ,$Display_MiddleName,$Display_LastName,$Display_ResourceType,$Display_ContractorType;
		global $Display_StartDate,$Display_EndDate,$Display_TimeManagementPolicy,$Display_PreApprovalRules,$Display_Supervisor,			
			   $Display_ResourceGroup,$Display_AvailbiltyType,$Display_SupervisorId,$Display_InUse   ;
		$qry = "SELECT * from cxs_resources where RESOURCE_ID = $HeaderId1";		
		$result = mysql_query($qry);
		//$TotalRecords = mysql_num_rows($result);
		while($row=mysql_fetch_array($result))
		{
			$Display_FirstName = $row['FIRST_NAME'];
			$Display_MiddleName = $row['MIDDLE_NAME'];
			$Display_LastName = $row['LAST_NAME'];				
			$Display_ResourceType = $row['RESOURCE_TYPE'];	
			$Display_ContractorType = $row['CONTRACTOR_TYPE_FLAG'];	
							
			if((!is_null($row['START_DATE_ACTIVE'])) && (($row['START_DATE_ACTIVE'])!='0000-00-00') )
			{
				$Display_StartDate = date('m/d/Y', strtotime($row['START_DATE_ACTIVE']));	
			}
			
			if((!is_null($row['END_DATE_ACTIVE'])) && (($row['END_DATE_ACTIVE'])!='0000-00-00') )
			{
				$Display_EndDate = date('m/d/Y', strtotime($row['END_DATE_ACTIVE']));	
			}
			
			$Display_TimeManagementPolicy = $row['TIMEMANAGEMENTPOLICY_ID'];	
			$Display_PreApprovalRules = $row['PREAPPROVALRULES_ID'];	
			$Display_SupervisorId = "";
			$Display_Supervisor =  $row['SUPREVISOR_ID'];	
			
			if($Display_Supervisor!='')
			{
				//echo "<script> document.getElementById('h_field_supervisorid').value = '$Display_Supervisor'; </script>";
				$Display_SupervisorId = $Display_Supervisor;
				$qry1 = "select FIRST_NAME,LAST_NAME from cxs_resources where RESOURCE_ID =  $Display_Supervisor";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					 $Display_Supervisor = $row1['FIRST_NAME']. ' '.$row1['LAST_NAME'];
				}
				
			}
			if ($Display_Supervisor=="0")
			{
				$Display_Supervisor = "";
			}
			$Display_Supervisor;
		//	$Display_JobClassification = $row['JOB_CLASSIFICATION'];	
			$Display_ResourceGroup = $row['RESOURCE_GROUP_ID'];	
			$Display_AvailbiltyType = $row['AVAILABILTY_TYPE'];
			$Display_InUse= $row['IN_USE_FLAG'];
		}
	}
	
	if (isset($_POST['cmdSaveRecord'] ))
	{
		$Text_FirstName = isset($_POST["Text_FirstName"] )? $_POST["Text_FirstName"]: false;
		$Text_MiddleName = isset($_POST["Text_MiddleName"] )? $_POST["Text_MiddleName"]: false;
		$Text_LastName = isset($_POST["Text_LastName"] )? $_POST["Text_LastName"]: false;
	//	$Check_PreApprove = isset($_POST["Check_PreApprove"] )? $_POST["Check_PreApprove"]: false;
		
		$Combo_ResourceType = isset($_POST["Combo_ResourceType"] )? $_POST["Combo_ResourceType"]: false;
		$Combo_ContractorType = isset($_POST["Combo_ContractorType"] )? $_POST["Combo_ContractorType"]: false;
		//$Text_PartyName = isset($_POST["Text_PartyName"] )? $_POST["Text_PartyName"]: false;
		//$Text_ContractName = isset($_POST["Text_ContractName"] )? $_POST["Text_ContractName"]: false;
		//$Combo_Department = isset($_POST["Combo_Department"] )? $_POST["Combo_Department"]: false;
		$Text_StartDate = isset($_POST["Text_StartDate"] )? $_POST["Text_StartDate"]: false;
		$Text_EndDate = isset($_POST["Text_EndDate"] )? $_POST["Text_EndDate"]: false;
		$Combo_TimeManagementPolicy = isset($_POST["Combo_TimeManagementPolicy"] )? $_POST["Combo_TimeManagementPolicy"]: false;
		$Combo_PreApprovalRules = isset($_POST["Combo_PreApprovalRules"] )? $_POST["Combo_PreApprovalRules"]: false;
		$Text_Supervisor = isset($_POST["h_field_supervisorid"] )? $_POST["h_field_supervisorid"]: false;
		//$Combo_JobClassification = isset($_POST["Combo_JobClassification"] )? $_POST["Combo_JobClassification"]: false;
		
		/*$Text_Address1_ = isset($_POST["Combo_ResourceType"] )? $_POST["Combo_ResourceType"]: false;
		$Combo_ContractorType = isset($_POST["Combo_ContractorType"] )? $_POST["Combo_ContractorType"]: false;
		*/
		if($Text_StartDate!='')
		{
			$Text_StartDate = date("Y/m/d", strtotime($Text_StartDate));	
		}
		if($Text_EndDate!='')
		{
			$Text_EndDate = date("Y/m/d", strtotime($Text_EndDate));	
		}
		$Combo_ResourceGroup = isset($_POST["Combo_ResourceGroup"] )? $_POST["Combo_ResourceGroup"]: false;
		$Combo_AvailbiltyType = isset($_POST["Combo_AvailbiltyType"] )? $_POST["Combo_AvailbiltyType"]: false;		
		$h_OverrideInuse = isset($_POST["h_OverrideInuse"] )? $_POST["h_OverrideInuse"]: false;
		
		
		if($h_OverrideInuse=="Y" && $Text_FirstName=='' && $Text_LastName=='')
		{
			$insArr['SUPREVISOR_ID'] = $Text_Supervisor;
			$insArr['LAST_UPDATED_BY']=$LoginUserId;
		}
		else
		{	
			$insArr['FIRST_NAME'] = $Text_FirstName;
			$insArr['MIDDLE_NAME'] = $Text_MiddleName;
			$insArr['LAST_NAME'] = $Text_LastName;
		//	$insArr['PREAPPROVAL_FLAG'] = ($Check_PreApprove==1)?"Y":"N";
			$insArr['RESOURCE_TYPE'] = $Combo_ResourceType;
			$insArr['CONTRACTOR_TYPE_FLAG'] = $Combo_ContractorType;
		//	$insArr['PARTY_ID'] = $Text_PartyName;
		//	$insArr['CONTRACT_ID'] = $Text_ContractName;
		//	$insArr['DEPARTMENT_ID'] = $Combo_Department;
			
			$insArr['START_DATE_ACTIVE'] = $Text_StartDate; 
			$insArr['END_DATE_ACTIVE'] = $Text_EndDate;
			$insArr['TIMEMANAGEMENTPOLICY_ID'] = $Combo_TimeManagementPolicy;
			
			$insArr['PREAPPROVALRULES_ID'] = $Combo_PreApprovalRules;
			$insArr['SUPREVISOR_ID'] = $Text_Supervisor;
	//		$insArr['JOB_CLASSIFICATION'] = $Combo_JobClassification;
			
			$insArr['LAST_UPDATED_BY']=$LoginUserId;
			$insArr['RESOURCE_GROUP_ID'] = $Combo_ResourceGroup;		
			$insArr['AVAILABILTY_TYPE'] = $Combo_AvailbiltyType;	
			$insArr['SITE_ID'] = $SiteId;	
		}
		
		if($HeaderId!='')
		{
			updatedata("cxs_resources",$insArr,"Where cxs_resources.RESOURCE_ID = $HeaderId");		
		}	
		else
		{
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;			
			insertdata("cxs_resources",$insArr);	
			$HeaderId= mysql_insert_id();						
			//echo "<script>";
			//echo "document.getElementById('h_field_headerid').value = $HeaderId";			
			//echo "</script>";			
			header("Location:create-new-resource.php?hid=$HeaderId");
		}
		
		if($Combo_PreApprovalRules != '')
		{
			mysql_query("update cxs_preapp_rules set IN_USE_FLAG = 'Y' where PREAPP_RULE_ID = $Combo_PreApprovalRules and IN_USE_FLAG <> 'Y'");				
		}
	}	
	
	if($IsUpdateAddr =='Y' ) // save multiple contacts 
	{	
		if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridAddr"] )? $_POST["h_field_headeridAddr"]: false;
		}	
		
		for($i=1;$i<=$TotalRowsAddr;$i++)
		{
			$Check_RecordAddr = isset( $_POST['inlineCheckboxAddr'.$i] )? $_POST['inlineCheckboxAddr'.$i]: false;
			if($Check_RecordAddr==1)
			{
				unset($insArr);
				$Post_ResourceAddressId = isset( $_POST['h_resourceAddressId'.$i] )? $_POST['h_resourceAddressId'.$i]: false;				
				$Text_Address1 = isset($_POST["Text_Address1_$i"] )? $_POST["Text_Address1_$i"]: false;
				$Text_Address2 = isset($_POST["Text_Address2_$i"] )? $_POST["Text_Address2_$i"]: false;
				$Text_Address3 = isset($_POST["Text_Address3_$i"] )? $_POST["Text_Address3_$i"]: false;
				$Text_City = isset($_POST["Text_City$i"] )? $_POST["Text_City$i"]: false;
				$Text_State = isset($_POST["Text_State$i"] )? $_POST["Text_State$i"]: false;
				$Text_Country = isset($_POST["Text_Country$i"] )? $_POST["Text_Country$i"]: false;
				$Text_PostalCode = isset($_POST["Text_PostalCode$i"] )? $_POST["Text_PostalCode$i"]: false;
				$Checkbox_APrimary = isset($_POST["Checkbox_APrimary$i"] )? $_POST["Checkbox_APrimary$i"]: false;
				$Checkbox_AActive = isset($_POST["Checkbox_AActive$i"] )? $_POST["Checkbox_AActive$i"]: false;
				
				$insArr['ADDRESS1'] = $Text_Address1;
				$insArr['ADDRESS2'] = $Text_Address2;
				$insArr['ADDRESS3'] = $Text_Address3;
				$insArr['CITY'] = $Text_City;
				$insArr['STATE'] = $Text_State;
				$insArr['COUNTRY'] = $Text_Country;
				$insArr['POSTAL_CODE'] = $Text_PostalCode;
				$insArr['PRIMARY_FLAG'] = ($Checkbox_APrimary==1)?"Y":"N";
				$insArr['ACTIVE_FLAG'] = ($Checkbox_AActive==1)?"Y":"N";	
				$insArr['LAST_UPDATED_BY']=$LoginUserId;   				
				updatedata("cxs_resource_address",$insArr,"Where cxs_resource_address.ADDRESS_RESOURCE_ID = $Post_ResourceAddressId");		
			}
		}
	}
	
	
	if (isset($_POST['cmdAddAddressPopup'] ))
	{
		if ($HeaderId == "")
		{	
			$HeaderId = isset($_POST["h_field_headeridAddr"] )? $_POST["h_field_headeridAddr"]: false;
		}	
		$Text_Address1 = isset($_POST["Text_Address1"] )? $_POST["Text_Address1"]: false;
		$Text_Address2 = isset($_POST["Text_Address2"] )? $_POST["Text_Address2"]: false;
		$Text_Address3 = isset($_POST["Text_Address3"] )? $_POST["Text_Address3"]: false;
		$Text_City = isset($_POST["Text_City"] )? $_POST["Text_City"]: false;
		$Text_State = isset($_POST["Text_State"] )? $_POST["Text_State"]: false;
		$Text_Country = isset($_POST["Text_Country"] )? $_POST["Text_Country"]: false;
		$Text_PostalCode = isset($_POST["Text_PostalCode"] )? $_POST["Text_PostalCode"]: false;
		$Checkbox_APrimary = isset($_POST["Checkbox_APrimary"] )? $_POST["Checkbox_APrimary"]: false;
		$Checkbox_AActive = isset($_POST["Checkbox_AActive"] )? $_POST["Checkbox_AActive"]: false;
		$Row_No  = 1;
		$ExistPrimaryFlagIdAddr = 0;
		$qry = "select * from cxs_resource_address where RESOURCE_ID = $HeaderId order by ROW_NO ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			//$Row_No = $row['ROW_NO'];
			if ($row['PRIMARY_FLAG']=="Y")
			{
				$ExistPrimaryFlagIdAddr  = $row['ADDRESS_RESOURCE_ID'];
			}	
			$Row_No = $Row_No + 1;
		}
			
		unset($insArr);
		if($Text_Address1!='' || $Text_Address2 != '' || $Text_Address3 != '' || $Text_City!='' || $Text_State != '' || $Text_Country != '' || $Text_PostalCode!='' || $Checkbox_APrimary != '' || $Checkbox_AActive != ''  )
		{
			$insArr['RESOURCE_ID'] = $HeaderId;
			$insArr['ADDRESS1'] = $Text_Address1;
			$insArr['ADDRESS2'] = $Text_Address2;
			$insArr['ADDRESS3'] = $Text_Address3;
			$insArr['CITY'] = $Text_City;
			$insArr['STATE'] = $Text_State;
			$insArr['COUNTRY'] = $Text_Country;
			$insArr['POSTAL_CODE'] = $Text_PostalCode;
			if ($Row_No==1)
			{
				$insArr['PRIMARY_FLAG'] = "Y";
			}
			else
			{
				$insArr['PRIMARY_FLAG'] = ($Checkbox_APrimary==1)?"Y":"N";
			}
			$insArr['ACTIVE_FLAG'] = ($Checkbox_AActive==1)?"Y":"N";					
			$insArr['ROW_NO'] = $Row_No; 
			$insArr['LAST_UPDATED_BY']=$LoginUserId;   
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;
			$insArr['SITE_ID']=$SiteId;
			insertdata("cxs_resource_address",$insArr);	
			
			if ($Checkbox_APrimary==1 && $ExistPrimaryFlagIdAddr > 0 && $Row_No > 1)
			{
				unset($insArr);
				$insArr['PRIMARY_FLAG'] = "N";
				$insArr['LAST_UPDATED_BY']=$LoginUserId;  
				updatedata("cxs_resource_address",$insArr,"Where cxs_resource_address.ADDRESS_RESOURCE_ID = $ExistPrimaryFlagIdAddr");	
			}
		}
		//}
	}
	
	if($IsUpdateCont =='Y' ) // save multiple contacts 
	{	
		if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridCont"] )? $_POST["h_field_headeridCont"]: false;
		}	
		
		for($i=1;$i<=$TotalRowsCont;$i++)
		{
			$Check_Record = isset( $_POST['inlineCheckboxCont'.$i] )? $_POST['inlineCheckboxCont'.$i]: false;
			if($Check_Record==1)
			{
				unset($insArr);
				$Post_ResourceContactId = isset( $_POST['h_resourceContactId'.$i] )? $_POST['h_resourceContactId'.$i]: false;				
				$Text_Phone = isset($_POST["Text_Phone$i"] )? $_POST["Text_Phone$i"]: false;
				$Text_Email = isset($_POST["Text_Email$i"] )? $_POST["Text_Email$i"]: false;			
				$Checkbox_CPrimary = isset($_POST["Checkbox_CPrimary$i"] )? $_POST["Checkbox_CPrimary$i"]: false;
				$Checkbox_CActive = isset($_POST["Checkbox_CActive$i"] )? $_POST["Checkbox_CActive$i"]: false;
				$Checkbox_CAcceptText = isset($_POST["Checkbox_CAcceptText$i"] )? $_POST["Checkbox_CAcceptText$i"]: false;	
				
				$insArr['PHONE_NUMBER'] = $Text_Phone;
				$insArr['EMAIL_ADDRESS'] = $Text_Email;			
				$insArr['PRIMARY_FLAG'] = ($Checkbox_CPrimary==1)?"Y":"N";
				$insArr['ACTIVE_FLAG'] = ($Checkbox_CActive==1)?"Y":"N";	
				$insArr['ACCEPTS_TEXTS_FLAG'] = ($Checkbox_CAcceptText==1)?"Y":"N";	
				
				//$insArr['SOCIAL_URL'] = $Text_Email;	
				//$insArr['SOCIAL_URL_LABEL'] = $Text_Email;	
				//$insArr['LAST_SESSION_ID'] = $Text_Email;	
				
				$insArr['LAST_UPDATED_BY']=$LoginUserId;   
				$insArr['SITE_ID']=$SiteId;
				
				updatedata("cxs_resource_contact",$insArr,"Where cxs_resource_contact.CONTACT_RESOURCE_ID = $Post_ResourceContactId");		
			}
		}
	}
	
	if (isset($_POST['cmdAddContactPopup'] ))
	{
		
		if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridCont"] )? $_POST["h_field_headeridCont"]: false;
		}	
		$Text_Phone = isset($_POST["Text_Phone"] )? $_POST["Text_Phone"]: false;
		$Text_Email = isset($_POST["Text_Email"] )? $_POST["Text_Email"]: false;		
		$Checkbox_CPrimary = isset($_POST["Checkbox_CPrimary"] )? $_POST["Checkbox_CPrimary"]: false;
		$Checkbox_CActive = isset($_POST["Checkbox_CActive"] )? $_POST["Checkbox_CActive"]: false;
		$Checkbox_CAcceptText = isset($_POST["Checkbox_CAcceptText"] )? $_POST["Checkbox_CAcceptText"]: false;
		$Row_No  = 1;
		$ExistPrimaryFlagId = 0;
		$qry = "select * from cxs_resource_contact where RESOURCE_ID = $HeaderId order by ROW_NO ";
		$result = mysql_query($qry);			
		while($row = mysql_fetch_array($result))
		{
			//$Row_No = $row['ROW_NO'];
			if ($row['PRIMARY_FLAG']=="Y")
			{
				$ExistPrimaryFlagId  = $row['CONTACT_RESOURCE_ID'];
			}			
			$Row_No = $Row_No + 1;
		}
			
		unset($insArr);
		if($Text_Phone!='' || $Text_Email != '' )
		{
			
			$insArr['RESOURCE_ID'] = $HeaderId;
			$insArr['PHONE_NUMBER'] = $Text_Phone;
			$insArr['EMAIL_ADDRESS'] = $Text_Email;			
			if ($Row_No==1)
			{
				$insArr['PRIMARY_FLAG'] = "Y";
			}
			else
			{
				$insArr['PRIMARY_FLAG'] = ($Checkbox_CPrimary==1)?"Y":"N";
			}			
			$insArr['ACTIVE_FLAG'] = ($Checkbox_CActive==1)?"Y":"N";	
			$insArr['ACCEPTS_TEXTS_FLAG'] = ($Checkbox_CAcceptText==1)?"Y":"N";	
			
			//$insArr['SOCIAL_URL'] = $Text_Email;	
			//$insArr['SOCIAL_URL_LABEL'] = $Text_Email;	
			//$insArr['LAST_SESSION_ID'] = $Text_Email;	
			
			$insArr['ROW_NO'] = $Row_No; 
			$insArr['LAST_UPDATED_BY']=$LoginUserId;   
			$insArr['CREATION_DATE']='now()' ;
			$insArr['CREATED_BY']=$LoginUserId;
			$insArr['SITE_ID']=$Site_Id;
			insertdata("cxs_resource_contact",$insArr);		
			
			if ($Checkbox_CPrimary==1 && $ExistPrimaryFlagId > 0 && $Row_No > 1)
			{
				unset($insArr);
				$insArr['PRIMARY_FLAG'] = "N";
				$insArr['LAST_UPDATED_BY']=$LoginUserId;  
				updatedata("cxs_resource_contact",$insArr,"Where cxs_resource_contact.CONTACT_RESOURCE_ID = $ExistPrimaryFlagId");	
			}
		}
	}
	
	/*if($IsUpdateCont =='Y' ) // save multiple contacts 
	{	
		if ($HeaderId == "")
		{
			$HeaderId = isset($_POST["h_field_headeridCont"] )? $_POST["h_field_headeridCont"]: false;
		}	
		
		for($i=1;$i<=$TotalRowsCont;$i++)
		{
			$Check_Record = isset( $_POST['inlineCheckboxCont'.$i] )? $_POST['inlineCheckboxCont'.$i]: false;
			if($Check_Record==1)
			{
				unset($insArr);
				$Post_ResourceContactId = isset( $_POST['h_resourceContactId'.$i] )? $_POST['h_resourceContactId'.$i]: false;				
				$Text_Phone = isset($_POST["Text_Phone$i"] )? $_POST["Text_Phone$i"]: false;
				$Text_Email = isset($_POST["Text_Email$i"] )? $_POST["Text_Email$i"]: false;			
				$Checkbox_CPrimary = isset($_POST["Checkbox_CPrimary$i"] )? $_POST["Checkbox_CPrimary$i"]: false;
				$Checkbox_CActive = isset($_POST["Checkbox_CActive$i"] )? $_POST["Checkbox_CActive$i"]: false;
				$Checkbox_CAcceptText = isset($_POST["Checkbox_CAcceptText$i"] )? $_POST["Checkbox_CAcceptText$i"]: false;	
				
				$insArr['PHONE_NUMBER'] = $Text_Phone;
				$insArr['EMAIL_ADDRESS'] = $Text_Email;			
				$insArr['PRIMARY_FLAG'] = ($Checkbox_CPrimary==1)?"Y":"N";
				$insArr['ACTIVE_FLAG'] = ($Checkbox_CActive==1)?"Y":"N";	
				$insArr['ACCEPTS_TEXTS_FLAG'] = ($Checkbox_CAcceptText==1)?"Y":"N";	
				
				//$insArr['SOCIAL_URL'] = $Text_Email;	
				//$insArr['SOCIAL_URL_LABEL'] = $Text_Email;	
				//$insArr['LAST_SESSION_ID'] = $Text_Email;	
				
				$insArr['LAST_UPDATED_BY']=$LoginUserId;   
				
				updatedata("cxs_resource_contact",$insArr,"Where cxs_resource_contact.CONTACT_RESOURCE_ID = $Post_ResourceContactId");		
			}
		}
	}*/
	
	
	if($HeaderId=="") // in the case when click on pagination buttons
	{
		if (isset($_GET["hid"]))
		{
			$HeaderId = $_GET["hid"];
		}		
	}
	
	
	if($HeaderId!='')
	{
		DisplayRecord($HeaderId);
	}	
	$StateList = StateListFun();
?>
<script type="text/javascript" >
	var TABLE_ROWAddr = 0;
	var TABLE_ROWCont = 0;
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Create New Resource";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}	
	function SearchSupervisor()
	{
		KEY = "SearchSupervisor";		
		
		var str1 = document.getElementById("Text_SearchFirstName").value;
		var str2 = document.getElementById("Text_SearchMiddleName").value;
		var str3 = document.getElementById("Text_SearchLastName").value;
		var str4 = "<?php echo $HeaderId; ?>";
		//alert(str4);		
		makeRequest("ajax.php","REQUEST=SearchSupervisor&FirstName="+str1+"&MiddleName="+str2+"&LastName="+str3+"&ResourceId="+str4);
	}	
	//function SelectedSupervisor(s1,s2,s3)
	function SelectedSupervisor(s3)
	{
		//document.getElementById("Text_Supervisor").value = s1 + " " +s2;	
		document.getElementById("h_field_supervisorid").value =s3;		
		var TableName = "cxs_resources";
		var FieldName = "RESOURCE_ID";
		var FieldValue = s3;	
		$.ajax({
				url:"ajax2_te.php",
				method:"POST",
				data:{TableName:TableName,FieldName:FieldName,FieldValue:FieldValue },
				success:function(response)
				{
					var JSONObject = JSON.parse(response); 										
					$('#Text_Supervisor').val(JSONObject[TableName]["FIRST_NAME"]+' '+JSONObject[TableName]["LAST_NAME"]);					
					document.getElementById("Text_SearchMiddleName").value = "";		
					document.getElementById("Text_SearchFirstName").value = "";		
					document.getElementById("Text_SearchLastName").value = "";
					document.getElementById("ListSupervisor").innerHTML = "";	
					$("#SearchSupervisor .close").click();		
				}
			});
	}	
	function chkfldAddress()
	{
		var s1,s2,s3,s4,s5,s6,s7,s8,s9;
		s1 = s2= s3=s4=s5=s6=s7=s8=s9="";
		s1 = document.getElementById("Text_Address1").value;
		s2 = document.getElementById("Text_Address2").value;
		s3 = document.getElementById("Text_Address3").value;
		if (s1=='' && s2 == '' && s3 == '' && s4 == '' && s5 == '' && s6 == '' && s7 == '' && s8 == '' && s9 == '' )
		{
			alert("Do not keep all fields blank.");
			document.getElementById("Text_Address1").focus();
			return false;
		}
		
		s1 = document.getElementById("lblHeaderId").innerHTML;
		s1 = s1.trim();
		document.getElementById("h_field_headeridAddr").value = s1;
	}
	function chkfldContact()
	{
		s1 = document.getElementById("lblHeaderIdContact").innerHTML;
		s1 = s1.trim();		
		document.getElementById("h_field_headeridCont").value = s1;
		
		var s1,s2;
		s1 = s2= "";
		s1 = document.getElementById("Text_Phone").value;
		s2 = document.getElementById("Text_Email").value;		
		if (s1=='' && s2 == '' )
		{
			alert("Please fill out at least phone or email.");
			document.getElementById("Text_Phone").focus();
			return false;
		}
		if(s2!='')
		{
			if (!isEmailValid(s2)) 
			{
				alert("Please enter valid email address.");
				$("#Text_Email").focus();
				return false;
			}
		}
	}
	
	function checkAllAddr()
	{
		var checkboxValue=document.getElementById('selectallAddr').checked;
		var i=1;
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			document.getElementById("inlineCheckboxAddr"+i).checked = checkboxValue;		
		}
	}   
	function CheckBoxInlineAddr()
	{
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked == false)
			{
				document.getElementById('selectallAddr').checked = false;
			}
		}
	}
	function EditRecordAddr()
	{
		var flag_updaterecord=""; 
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		
		if (flag_updaterecord=="")
		{
			alert("Please Select Record For Update");
			document.getElementById("inlineCheckboxAddr1").focus();
			return false;
		}
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedAddr").innerHTML;
			var flag1 = "";
			if (ButtonCaption != "Save")
			{
				
				document.getElementById("cmdUpdateSelectedAddr").innerHTML = "Save";
				
				$('#selectallAddr').hide();
					
				for(i=1;i<=TABLE_ROWAddr;i++)
				{
					if (document.getElementById("inlineCheckboxAddr"+i).checked )
					{
						ShowInputElementsAddr(i);
					}
					else
					{
						$('#inlineCheckboxAddr'+i).hide();
					}
				}
			}
			else
			{
				document.getElementById('h_field_updateAddr').value = 'Y';
				document.getElementById("h_NumRowsAddr").value = TABLE_ROWAddr;
				var sAddr1,sAddr2,sAddr3,sCity,sState,sCountry,sPostalcode,PrimaryCounter;
				var flag_final="";	
				var s1 = "";
				PrimaryCounter = 0;
				for(i=1;i<=TABLE_ROWAddr;i++)
				{
					if (document.getElementById("Checkbox_APrimary"+i).checked)
					{
						PrimaryCounter = PrimaryCounter+1;
					}
					if (document.getElementById("inlineCheckboxAddr"+i).checked )
					{
						sAddr1 = document.getElementById("Text_Address1_"+i).value;
						sAddr2 = document.getElementById("Text_Address2_"+i).value;
						sAddr3 = document.getElementById("Text_Address3_"+i).value;
						sCity = document.getElementById("Text_City"+i).value;
						sState = document.getElementById("Text_State"+i).value;
						sCountry = document.getElementById("Text_Country"+i).value;
						sPostalcode = document.getElementById("Text_PostalCode"+i).value;
						
					/*	sActive = document.getElementById("Checkbox_CActive"+i).checked;
						sAcceptText = document.getElementById("Checkbox_CAcceptText"+i).checked;
					*/	
						sAddr1 = sAddr1.trim();
						sAddr2 = sAddr2.trim();
						sAddr3 = sAddr3.trim();
						
						sCity = sCity.trim();
						sState = sState.trim();
						sCountry = sCountry.trim();
						sPostalcode = sPostalcode.trim();
						
						if (sAddr1 == "" && sAddr2 == "" && sAddr3 == "" && sCity == ""  && sState == "" && sCountry == "" && sPostalcode == "")
						{
							alert("Do not left all fields blanks.");
							document.getElementById("Text_Address1_"+i).focus();
							flag_final = "N";
							break;
						}
					}					
				}
				if (PrimaryCounter==0)
				{
					flag_final= "N";
					alert("One address can be primary.");	
					document.getElementById("Checkbox_APrimary1").focus();					
				}
				else if (PrimaryCounter>1)
				{
					flag_final = "N";
					alert("Only one primary at a time.");
					document.getElementById("Checkbox_APrimary1").focus();
				}
				if (flag_final=="" && PrimaryCounter==1)
				{
					Form2.submit();
				}
			}
		}
	}
	
	function ShowInputElementsAddr(i)
	{
		document.getElementById("Text_Address1_"+i).disabled = false;
		document.getElementById("Text_Address2_"+i).disabled = false;
		document.getElementById("Text_Address3_"+i).disabled = false;
		document.getElementById("Text_City"+i).disabled = false;
		document.getElementById("Text_State"+i).disabled = false;
		document.getElementById("Text_Country"+i).disabled = false;
		document.getElementById("Text_PostalCode"+i).disabled = false;		
		document.getElementById("Checkbox_APrimary"+i).disabled = false;
		document.getElementById("Checkbox_AActive"+i).disabled = false;
	}
	function ExportRecordAddr()
	{
		KEY= "ExportRecordAddr";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROWAddr;i++)
		{
			if (document.getElementById("inlineCheckboxAddr"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_resourceAddressId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		//qry1 = '<?php echo $SQueryOrderBy; ?>';					
		qry1 = 'order by ROW_NO';		
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportCreateResourceAddress&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("selectallAddr").focus();
		}
	}
	function chkfld_form1() 
	{
		//KEY = "IsAllowSupervisor";
		var s = "";
		if($('#Combo_PreApprovalRules').val()=="")
		{
			s = "<?php echo $IsAllowPreApproval; ?>";
			if (s=="Y")
			{
				//var msg = "You are Pre Approved for Pre Approval Time Entry, However, the your profile does not comply all rules for Pre Approval Entry. Please contact your Administrator.";
				//$('#msg_section').append("<div class='alert alert-success'>"+msg+"</div>");
				//<div class='alert alert-success'> Site Settings inserted successfully.</div>
				alert("Please Select Pre approval");
				document.getElementById("Combo_PreApprovalRules").focus();
				return false;
			}
		}
		/*else
		{
			$("#msg_section").empty();
		}*/
		s = "";
		if (document.getElementById("Text_Supervisor").value == "")
		{
			var s = "<?php echo $IsAllowSupervisor; ?>";
			if (s=="Y")
			{
				alert("Please Select Supervisor");
				document.getElementById("Text_Supervisor").focus();
				return false;
			}
		}
	}
	
	function checkAllCont()
	{
		var checkboxValue=document.getElementById('selectallCont').checked;
		var i=1;
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			document.getElementById("inlineCheckboxCont"+i).checked = checkboxValue;		
		}
	} 
	function CheckBoxInlineCont()
	{
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked == false)
			{
				document.getElementById('selectallCont').checked = false;
			}
		}
	}	
	function EditRecordCont()
	{
		var flag_updaterecord=""; 
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked == true)
			{
				flag_updaterecord = "Y";
				break;
			}
		}
		
		if (flag_updaterecord=="")
		{
			alert("Please Select Record For Update");
			document.getElementById("inlineCheckboxCont1").focus();
			return false;
		}
		
		if (flag_updaterecord == "Y")
		{
			var ButtonCaption = document.getElementById("cmdUpdateSelectedCont").innerHTML;
			var flag1 = "";
			if (ButtonCaption != "Save")
			{
				
				document.getElementById("cmdUpdateSelectedCont").innerHTML = "Save";
				$('#selectallCont').hide();
				for(i=1;i<=TABLE_ROWCont;i++)
				{
					if (document.getElementById("inlineCheckboxCont"+i).checked )
					{
						ShowInputElementsCont(i);
					}
					else
					{
						$('#inlineCheckboxCont'+i).hide();
					}
				}
			}
			else
			{
				document.getElementById('h_field_updateCont').value = 'Y';
				document.getElementById("h_NumRowsCont").value = TABLE_ROWCont;
				var sPhone,sEmail,sPrimary,sActive,sAcceptText;
				var flag_final="";	
				var s1 = "";
				PrimaryCounter = 0;
				for(i=1;i<=TABLE_ROWCont;i++)
				{
					if (document.getElementById("Checkbox_CPrimary"+i).checked)
					{
						PrimaryCounter = PrimaryCounter+1;
					}
					if (document.getElementById("inlineCheckboxCont"+i).checked )
					{
						sPhone = document.getElementById("Text_Phone"+i).value;
						sEmail = document.getElementById("Text_Email"+i).value;
						
						
					/*	sActive = document.getElementById("Checkbox_CActive"+i).checked;
						sAcceptText = document.getElementById("Checkbox_CAcceptText"+i).checked;
					*/	
						sPhone = sPhone.trim();
						sEmail = sEmail.trim();
						
						if (sPhone == "" && sEmail == "" )
						{
							alert("Do not left both fields blanks.");
							document.getElementById("Text_Phone"+i).focus();
							flag_final = "N";
							break;
						}
						
						if(sEmail!='')
						{
							if (!isEmailValid(sEmail)) 
							{
								alert("Please enter valid user name.");
								$("#Text_Email"+i).focus();
								return false;
							}
						}
					}					
				}		
				if (PrimaryCounter==0)
				{
					flag_final= "N";
					alert("One contact can be primary.");	
					document.getElementById("Checkbox_CPrimary1").focus();					
				}
				else if (PrimaryCounter>1)
				{
					flag_final = "N";
					alert("Only one primary at a time.");
					document.getElementById("Checkbox_CPrimary1").focus();
				}	
				if (flag_final=="" && PrimaryCounter==1)
				{
					s1 = "<?php echo $HeaderId; ?>";					
					//location.href="create-new-resource.php?hid="+s1;
					Form3.submit();
				}
			}
		}
	}
	
	function ShowInputElementsCont(i)
	{
		document.getElementById("Text_Phone"+i).disabled = false;
		document.getElementById("Text_Email"+i).disabled = false;
		document.getElementById("Checkbox_CPrimary"+i).disabled = false;
		document.getElementById("Checkbox_CActive"+i).disabled = false;		
		document.getElementById("Checkbox_CAcceptText"+i).disabled = false;
	}
	
	function chkfldAll()
	{
		if (document.getElementById("Text_FirstName").value == "" )
		{
			alert("Do not leave blank.");
			document.getElementById("Text_FirstName").focus();
			return false;
		}
		if (document.getElementById("Text_LastName").value == "" )
		{
			alert("Do not leave blank.");
			document.getElementById("Text_LastName").focus();
			return false;
		}
		if (document.getElementById("Combo_ResourceType").value == "" )
		{
			alert("Do not leave blank.");
			document.getElementById("Combo_ResourceType").focus();
			return false;
		}
		if (document.getElementById("Text_StartDate").value == "" )
		{
			alert("Do not leave blank.");
			document.getElementById("Text_StartDate").focus();
			return false;
		}
		if (document.getElementById("Text_Supervisor").value == "" )
		{
			var s = "<?php echo $IsAllowSupervisor; ?>";
			if (s=="Y")
			{
				alert("Please Select Supervisor.");
				document.getElementById("Text_Supervisor").focus();
				return false;
			}
		}
		
		location.href="resource-management.php";
		
	}
	function ExportRecordCont()
	{	
		KEY= "ExportRecordCont";
		var qry="";
		var qry1="";
		var s1="";
		
		var flag_checked="";
		for(i=1;i<=TABLE_ROWCont;i++)
		{
			if (document.getElementById("inlineCheckboxCont"+i).checked )
			{
				flag_checked="Y";
				s1 = document.getElementById("h_resourceContactId"+i).value;				
				s1 = s1.trim();
				qry += s1+"|";
			}
		}	
		
		//qry1 = '<?php echo $SQueryOrderBy; ?>';					
		qry1 = 'order by ROW_NO';					
		if(flag_checked=="Y")
		{
			makeRequest("ajax.php","REQUEST=ExportCreateResourceContact&qry=" + qry+"&sortby="+qry1);
		}
		else
		{
			alert("Please Select Records For Export");
			document.getElementById("selectallCont").focus();
		}
	}

</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">



<style type="text/css">
	.requirefieldcls
	{
		background-color: #fff99c;
	}
	.alert-success { color: #e61d16; }			
	.option_color { color: #000; font-size: 12px;	}
	
</style>
<link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>


<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<script src="../js/jsfunctions.js"></script>

</head>

<body>
<?php include("header.php"); ?>
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="resource-management.php"> Resource Management </a></li>
          <li id="Label_Title1"> <a href="#"> <?php echo $s_caption; ?> Resource </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user">
          <button type="button" class="btn btn-primary dash" onclick="window.location.href='te.php'"> Dashboard </button>
        </div>
		<div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
		  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
        </div>
      </div>
      <!-- inner work-->
	<!-- modals start -->
	<form id = "AddressForm" name = "AddressForm" method="post" action="" onsubmit = "return chkfldAddress()">
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalAddAddress" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Add New Address </h4>
					</div>
					<div class="modal-body"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-6 form-group">
								  <label> Address 1 </label> <label id = "lblHeaderId" style = "display:none" > <?php echo $HeaderId;?> </label>
								  <input type="text" id = "Text_Address1" name = "Text_Address1" class="form-control"  placeholder="" maxlength="50">
								</div>
								<div class="col-sm-6 form-group">
								  <label> Address 2 </label>
								  <input type="text" id = "Text_Address2" name = "Text_Address2" class="form-control" placeholder="" maxlength="100">
								</div>
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> Address 3 </label>
								  <input type="text" id = "Text_Address3" name = "Text_Address3" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> City </label>
								  <input type="text" id = "Text_City" name = "Text_City" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> State </label>
								  <!--<input type="text" id = "Text_State" name = "Text_State" class="form-control" placeholder="" maxlength="40">-->
								  <select id = "Text_State" name = "Text_State" class = "form-control">
										<?php echo $StateList; ?>
								  <select>
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> Country </label>
								  <input type="text" id = "Text_Country" name = "Text_Country" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
								  <label> Postal Code </label>
								  <input type="text" id = "Text_PostalCode" name = "Text_PostalCode" class="form-control" placeholder="" maxlength="40">
								</div>
								
								<div class="col-sm-6 form-group cus-form-ico">
									<div class="checkbox"> &nbsp;&nbsp;&nbsp;
									</div>
									<div class="checkbox">
										<label><input type="checkbox" id = "Checkbox_APrimary" name = "Checkbox_APrimary"  value="1" >  Primary </label> 		
										<label>&nbsp;</label>			
										<label><input type="checkbox" id = "Checkbox_AActive" name = "Checkbox_AActive"  value="1" >  Active </label> 	
									</div>
									
									
								</div>
								
								
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<button type="submit" id = "cmdAddAddressPopup"  name = "cmdAddAddressPopup" class="btn btn-primary btn-style"> Add Address </button>
						<input type="hidden" id="h_field_headeridAddr" name="h_field_headeridAddr" value="">
					</div>
				</div>
			</div>
		</div>
	</form>
	<!-- modals end -->
	
	
	<!-- modals start -->
	<form id = "ContactForm" name = "ContactForm" method="post" action="" onsubmit = "return chkfldContact()" >
		<div class="modal fade bs-example-modal-lg custom-modal" id = "ModalAddContact" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">		
			<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel"> Add New Contact </h4>
					</div>
					<div class="modal-body"> 
						<!-- field start-->
						<div class="col-sm-12">
							<div class="cus-form-cont">
								<div class="col-sm-6 form-group">
								  <label> Phone </label> <label id = "lblHeaderIdContact" style = "display:none" > <?php echo $HeaderId;?></label>
								  <input type="text" id = "Text_Phone" name = "Text_Phone" class="form-control" placeholder="" maxlength="50">
								</div>
								<div class="col-sm-6 form-group">
								  <label> Email Address </label>
								  <input type="text" id = "Text_Email" name = "Text_Email" class="form-control" placeholder="" maxlength="100">
								</div>								
								<div class="col-sm-6 form-group cus-form-ico">									
									<div class="checkbox">
										<label><input type="checkbox" id = "Checkbox_CPrimary" name = "Checkbox_CPrimary"  value="1" >  Primary </label> 		
										<label>&nbsp;</label>			
										<label><input type="checkbox" id = "Checkbox_CActive" name = "Checkbox_CActive"  value="1" >  Active </label> 	
										<label>&nbsp;</label>			
										<label><input type="checkbox" id = "Checkbox_CAcceptText" name = "Checkbox_CAcceptText"  value="1" >  Accept Text </label> 	
									</div>
								</div>								
							</div>
						</div>
					<!-- end --> 
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<input type="hidden" id="h_field_headeridCont" name="h_field_headeridCont" value="">
						<button type="submit" id = "cmdAddContactPopup"  name = "cmdAddContactPopup" class="btn btn-primary btn-style"> Add Contact </button>
					</div>
				</div>
			</div>
		</div>
	</form>
	<!-- modals end -->
	
	
	<!-- modals start -->
		<form  method="post" action="" >
			<div class="modal fade custom-modal" id = "SearchSupervisor" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style = "display:none">
				<div class="modal-dialog modal-lg cus-modal-lg" role="document">
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  <h4 class="modal-title " id="myModalSearchLabel"> Find Supervisors </h4>
					</div>
					<div class="modal-body">
					<!-- field start-->
					  <div class="col-sm-12">
						<div class="cus-form-cont">
						  
						  <div class="col-sm-3 form-group" style = "width : 24%">
							<label> First Name </label>
							<input type="text" id ="Text_SearchFirstName" name ="Text_SearchFirstName" value = "" class="form-control" placeholder="">
						  </div>
						  <div class="col-sm-3 form-group" style = "width : 24%">
							<label> Middle Name </label>
							<input type="text" id ="Text_SearchMiddleName" name ="Text_SearchMiddleName" value = "" class="form-control" oninput="this.value=this.value.toUpperCase()" placeholder="">
						  </div>
						  <div class="col-sm-3 form-group" style = "width : 24%">
							<label> Last Name </label>
							<input type="text" id ="Text_SearchLastName" name ="Text_SearchLastName" value = "" class="form-control" placeholder="">
						  </div>
						  <div class="col-sm-3 form-group " style = "width : 28%">
							<label style="visibility:hidden"> submit </label>
							<button type="button" id = "cmdFindSupervisors" name = "cmdFindSupervisors" class="btn btn-primary btn-style2 w100" onclick="SearchSupervisor()" > <i class="fa fa-search" aria-hidden="true"></i> Find Supervisors </button>
						  </div>
						</div>
						<div class="data-bx">
						  <div class="table-responsive" id = "divFindSupervisor">
							
						  </div>
						</div>
					  </div>
					<!-- end -->
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">
						<!--<button type="button" id = "cmdFindUsers" name = "cmdFindUsers"  class="btn btn-primary btn-style" onclick = "()"><i class="fa fa-search" aria-hidden="true"></i> Find Users </button>  -->
					</div>
				  </div>
				</div>
			</div>
		</form>
	<!-- modals end -->
	
		<div class="cont-box">
			<div class="pge-hd">
				<h2 class="sec-title"  > 
					<label id="Label_Title"><?php echo $s_caption; ?> Resource</label>  
					<label class = "fright" style = "font-size: 12px; margin-right : 40px;"> <input type="checkbox" id="Check_InUse" name="Check_InUse" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?> disabled> In Use </label> 
				</h2>
			</div>
			<form class="form" id="Form1" name="Form1" action="" method="POST" onsubmit = "return chkfld_form1()">
				<?php $ss_msg = "<div class='alert alert-success'> Site Settings inserted successfully.</div>"; ?>
				<div class="row">
					<h4 class="text-center"  id="msg_section"></h4>
				</div>
				  <!-- upper form -->
				<div class="upp-form row">
					<!-- <div class="app-bx">
					  <div class="checkbox">
						<label>
						  <input type="checkbox" value="" class="mar-tp3">
						  PreApproval Allowed </label>
					  </div>
					</div> -->
					<div class="col-sm-3 form-group">
					  <label> First Name </label>
					  <input type="text" id = "Text_FirstName" name = "Text_FirstName" value = "<?php echo $Display_FirstName; ?>" class="form-control requirefieldcls" required placeholder="" maxlength="40" autofocus>
					</div>
					<div class="col-sm-3 form-group">
					  <label> Middle Name </label>
					  <input type="text" id = "Text_MiddleName" name = "Text_MiddleName" value = "<?php echo $Display_MiddleName; ?>" class="form-control" placeholder="" maxlength="40">
					</div>
					<div class="col-sm-3 form-group">
					  <label> Last Name </label>
					  <input type="text" id = "Text_LastName" name = "Text_LastName" value = "<?php echo $Display_LastName; ?>" class="form-control requirefieldcls" required placeholder="" maxlength="40">
					</div>
					
					<div class="col-sm-3 form-group">
					  <label> Availability Type </label>
					  <select id = "Combo_AvailbiltyType" name = "Combo_AvailbiltyType" class="form-control option_color" maxlength="20">
						<option class = "option_color" value="" > - Select Availability Type - </option>
						<option class = "option_color" value="Full Time"  <?php echo (${'Display_AvailbiltyType'.$j} == "Full Time")? "selected" : ""; ?> > Full Time </option>
						<option class = "option_color" value="Part Time" <?php echo (${'Display_AvailbiltyType'.$j} == "Part Time")? "selected" : ""; ?> > Part Time </option>													
					  </select>
					</div>
					
					<!--<div class="checkbox col-sm-3 form-group pd-tp25">
						<label> <input type="checkbox" id = "Check_PreApprove" name = "Check_PreApprove" value="1" class="mar-tp3" <?php echo ($Display_PreApprove=="Y")?"checked":"";  ; ?>> PreApproval Allowed </label>
					</div>-->

					<div class="clear-both"></div>	
					<div class="col-sm-3 form-group">
					  <label> Resource Group </label>					
					  <select id = "Combo_ResourceGroup" name = "Combo_ResourceGroup" class="form-control "  maxlength="40">
						<option value="">- Resource Group -</option>
						<?php
							$qry = "select * from cxs_resource_groups where SITE_ID = $SiteId order by RESOURCE_GROUP_NAME";
							$result = mysql_query($qry);
							while($row=mysql_fetch_array($result))
							{
								$ResourceGroupName = $row['RESOURCE_GROUP_NAME'];
								$ResourceGroupId = $row['RESOURCE_GROUP_ID'];
								$IsSelected = "";
								if($Display_ResourceGroup==$ResourceGroupId)
								{
									$IsSelected = "selected";
								}
								echo "<option value='$ResourceGroupId' $IsSelected >$ResourceGroupName</option>";
							}
						?>
					  </select>
					</div>	
					<div class="col-sm-3 form-group">
					  <label> Resource Type </label>					
					  <select id = "Combo_ResourceType" name = "Combo_ResourceType" class="form-control requirefieldcls" required maxlength="40">
						<option value="">- Resource Type -</option>
						<option value="Employee" <?php echo ($Display_ResourceType=="Employee")?"selected":""; ?> > Employee</option>
						<option value="Contractor" <?php echo ($Display_ResourceType=="Contractor")?"selected":""; ?>  >Contractor</option>
						<option value="External"  <?php echo ($Display_ResourceType=="External or Out of the organization resource")?"selected":""; ?> >External or Out of the organization resource</option>
					  </select>
					</div>
					
					<div class="col-sm-3 form-group">
					  <label> Contractor Type </label>
					  <select id = "Combo_ContractorType" name = "Combo_ContractorType" class="form-control" maxlength="15">
						<option value="">- Contractor Type -</option>
						<option value="1099" <?php echo ($Display_ContractorType=="1099")?"selected":""; ?>>1099</option>
						<option value="C2C" <?php echo ($Display_ContractorType=="C2C")?"selected":""; ?>>C2C</option>						
					  </select>
					</div>					
					
					<div class="col-sm-3 form-group cus-form-ico">
					  <label> Start Date </label>
					  <input type="text" id = "Text_StartDate" name = "Text_StartDate" class="form-control requirefieldcls" required maxlength="10" value = "<?php echo $Display_StartDate; ?>" >
					  <span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>
					
					<div class="col-sm-3 form-group cus-form-ico">
					  <label> End Date </label>
					  <input type="text" id = "Text_EndDate" name = "Text_EndDate" class="form-control" placeholder="" maxlength="10" value = "<?php echo $Display_EndDate; ?>">
					  <span class="inp-icons"><i class="fa fa-calendar"></i></span> </div>
					
					<div class="col-sm-3 form-group">  
					  <label> Time Management Policy </label>
					  <select id = "Combo_TimeManagementPolicy" name = "Combo_TimeManagementPolicy" class="form-control requirefieldcls" required maxlength="40">
						<option value="">- Time Management Policy -</option>
						<?php
							$qry = "select * from cxs_policy_header where SITE_ID = $SiteId order by NAME";
							$result = mysql_query($qry);
							while($row=mysql_fetch_array($result))
							{
								$TimeManagementName = $row['NAME'];
								$TimeManagementId = $row['POLICY_ID'];
								$selectedValue = "";
								if($Display_TimeManagementPolicy==$TimeManagementId)
								{
									$selectedValue = "selected";
								}
								echo "<option value='$TimeManagementId' $selectedValue>$TimeManagementName</option>";
						}
						
						?>
					  </select>
					</div>
					<div class="col-sm-3 form-group">
					  <label> Pre Approval Rules </label>
					  <select id = "Combo_PreApprovalRules" name = "Combo_PreApprovalRules" class="form-control" maxlength="40">
						<option value="">- Pre Approval Rules -</option>
						<?php
							$qry = "select * from cxs_preapp_rules where SITE_ID = $SiteId order by RULE_NAME";
							$result = mysql_query($qry);
							while($row=mysql_fetch_array($result))
							{
								$PreApprovalName = $row['RULE_NAME'];
								$PreApprovalId = $row['PREAPP_RULE_ID'];
								$selectedValue = "";
								if($Display_PreApprovalRules==$PreApprovalId)
								{
									$selectedValue = "selected";
								}
								echo "<option value='$PreApprovalId' $selectedValue>$PreApprovalName</option>";
						}
						
						?>
					  </select>
					</div>
					
					 <div class="col-sm-3 form-group">
					  <label> Supervisor </label>
					  <input type="text" id = "Text_Supervisor" name = "Text_Supervisor" class="form-control requirefieldcls" placeholder="" <?php    echo ($IsAllowSupervisor=="Y")?"":""; ?>  readonly maxlength="40"   onkeypress ="$('#SearchSupervisor').modal()" onclick="$('#SearchSupervisor').modal()" value = "<?php echo $Display_Supervisor; ?>">
					</div>
					
					<div class="col-sm-3 form-group fright">
						<label  style = "padding-top:28px;"> &nbsp; </label>						
						<button <?php if($CREATE_PRIV_Resources_PERMISSION=='Y'){ ?> type="submit" id = "cmdSaveRecord" name = "cmdSaveRecord"  <?php } else { ?> disabled = disabled <?php } ?> class="btn btn-primary btn-style fright"> Save Record </button>
						<input type="hidden" id="h_IsEditAllowed" <?php if($CREATE_PRIV_Resources_PERMISSION=='Y' && $Display_InUse!='Y'){ ?> value = "Y" <?php } else {?> value = "N" <?php } ?> >
						<input type="hidden" id="h_field_supervisorid" name="h_field_supervisorid" value="">
						<input type="hidden" id="h_field_headerid" name="h_field_headerid" value="">
						<input type="hidden" id="h_OverrideInuse" name="h_OverrideInuse" value="<?php echo $IsOverrideInUse; ?>">
					</div>
				</div>
			</form>
			
			<form class="form" id="Form2" name="Form2" action="" method="POST" >
				<div class="detail-form2 upp-form row "> 
					<!-- table form -->  
					<div class="fleft two">						
						<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_Resources_PERMISSION=='Y'){ ?> id="cmdUpdateSelectedAddr" name="cmdUpdateSelectedAddr" onclick= 'EditRecordAddr();'<?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>						
						<button type="button" class="btn-style btn" onclick= 'ExportRecordAddr()'> Export </button>
					</div>	
					<div class="fleft " >
						<!--  <label  style = "padding-top:28px;"> &nbsp; </label>		
						<button type="button" id = "cmdAddAddress" name = "cmdAddAddress" class="btn btn-primary btn-style" data-toggle="modal" data-target="#ModalAddAddress"  <?php  echo ($HeaderId!='')?"":"disabled"; ?>>  Add New Address </button>
						-->  				 
						<button type="button" id = "cmdAddAddress" name = "cmdAddAddress" class="btn btn-primary btn-style" data-toggle="modal" data-target="#ModalAddAddress"  <?php  echo ($HeaderId!='')?"":"disabled"; ?>>  Add New Address </button>  						  
					</div>					
					<div class="upp-form row data-bx">					
						<div class="table-responsive">						
							<table id = "tableAddressList" name = "tableAddressList" class="table table-bordered mar-cont ">
							  <thead>
								<tr>
									<th width="3%" class="check-bx "><input type="checkbox" id="selectallAddr" onchange="checkAllAddr()"></th>
									<th width="15%"> Address 1 </i></a> </th>
									<th width="15%">Address 2 </i></a></th>
									<th width="10%">Address 3 </i></a></th>
									<th width="10%">City </i></a></th>                      
									<th width="14%">State </i></a></th>
									<th width="10%">Country </i></a></th>
									<th width="8%">Postal Code </i></a></th>
									<th width="5%">Primary </i></a></th>
									<th width="5%">Active </i></a></th>
									<th width="5%"> </th>
								</tr>
							  </thead>
							  <tbody>
								<?php 
									if($HeaderId != '')
									{
									$i=1;
									$qry2 = "select cxs_resource_address.*,cxs_users.USER_NAME as CreatedBy from cxs_resource_address inner join cxs_users on cxs_users.USER_ID = cxs_resource_address.CREATED_BY where cxs_resource_address.RESOURCE_ID = $HeaderId order by cxs_resource_address.ROW_NO";
									$selectQueryForAddrPages  = $qry2;
									$qry2 = $qry2." limit $start_fromAddr , $record_per_pageAddr";
									$result2 = mysql_query($qry2);
									while ($row2 = mysql_fetch_array($result2))									
									{ 
										$DisplayAddressId  = $row2['ADDRESS_RESOURCE_ID']; 
										$Display_Address1 = $row2['ADDRESS1'];
										$Display_Address2 = $row2['ADDRESS2'];
										$Display_Address3 = $row2['ADDRESS3'];										
										$Display_City = $row2['CITY'];
										$Display_State = $row2['STATE'];
										$Display_Country = $row2['COUNTRY'];										
										$Display_PostalCode = $row2['POSTAL_CODE'];
										$Display_PrimaryAddr = $row2['PRIMARY_FLAG'];
										$Display_ActiveAddr = $row2['ACTIVE_FLAG'];
										
										$Display_CreatedByNameAddr	= $row2['CreatedBy'];	
										$Display_CreationDateAddr = date('m/d/Y h:i:sa', strtotime($row2['CREATION_DATE']));
										
										$UpdatedByAddr		= $row2['LAST_UPDATED_BY'];
										$Display_UpdatedByNameAddr = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedByAddr");							
										$Display_LastUpdateAddr = date('m/d/Y h:i:sa', strtotime($row2['LAST_UPDATE_DATE']));
									?>
									<tr>
										<td class="check-bx ">
											<input type="checkbox" id="<?php echo "inlineCheckboxAddr$i"; ?>" name="<?php echo "inlineCheckboxAddr$i"; ?>" value="1" onchange="CheckBoxInlineAddr()" >
											<input type="hidden" id = <?php echo "h_resourceAddressId".$i; ?> name = <?php echo "h_resourceAddressId".$i; ?> value = "<?php echo $DisplayAddressId; ?>">
										</td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address1_".$i ?>" name = "<?php echo "Text_Address1_".$i ?>" value = "<?php echo $Display_Address1; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address2_".$i ?>" name = "<?php echo "Text_Address2_".$i ?>" value = "<?php echo $Display_Address2; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Address3_".$i ?>" name = "<?php echo "Text_Address3_".$i ?>" value = "<?php echo $Display_Address3; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_City".$i ?>" name = "<?php echo "Text_City".$i ?>" value = "<?php echo $Display_City; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>                    
										<td>
										<div class="form-group">
										  <!--<input type="text" id = "<?php echo "Text_State".$i ?>" name = "<?php echo "Text_State".$i ?>" value = "<?php echo $Display_State; ?>" class="form-control" placeholder="" maxlength="25" disabled>-->
											<select id = "<?php echo "Text_State".$i ?>" name = "<?php echo "Text_State".$i ?>" class = "form-control" disabled>
												<?php echo $StateList; ?>
											<select>
										</div></td>
										<script>
											var ElementId = "<?php echo "Text_State".$i ?>";
											var StateValue = "<?php echo $Display_State; ?>";											
											selectValue(ElementId,StateValue);
										</script>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_Country".$i ?>" name = "<?php echo "Text_Country".$i ?>" value = "<?php echo $Display_Country; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td><div class="form-group">
										  <input type="text" id = "<?php echo "Text_PostalCode".$i ?>" name = "<?php echo "Text_PostalCode".$i ?>" value = "<?php echo $Display_PostalCode; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div></td>
										<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_APrimary".$i ?>" name = "<?php echo "Checkbox_APrimary".$i ?>" value="1" <?php echo ($Display_PrimaryAddr=="Y")?"checked":"";  ?> maxlength="2" disabled></td>
										<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_AActive".$i ?>" name = "<?php echo "Checkbox_AActive".$i ?>"  value="1" <?php echo ($Display_ActiveAddr=="Y")?"checked":"";  ?> maxlength="2" disabled></td>
										<td>
											<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
											Created By: <?php echo $Display_CreatedByNameAddr; ?> <br> Updated By: <?php echo $Display_UpdatedByNameAddr; ?> 
											<br> Creation Date: <?php echo $Display_CreationDateAddr; ?> <br> Last Update Date: <?php echo $Display_LastUpdateAddr; ?>"> <i class=" fa fa-eye"></i> </button>
										</td>
									</tr>     
								<?php 
									$i=$i+1;
									}
									}
								?>	
							  </tbody>
							</table>
						</div>
					</div>					
					<!-- pagination start-->
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php
										if($HeaderId!='')
										{
											//echo $selectQueryForAddrPages;
											$RunDepQuery=mysql_query($selectQueryForAddrPages);
											$num_recordsAddr = mysql_num_rows($RunDepQuery);
											$total_pagesAddr= ceil($num_recordsAddr/$record_per_pageAddr);
											if (($pageAddr-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo ($pageAddr-1); ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pagesAddr;$i++){ ?>
											<li class="<?php echo ($pageAddr==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($pageAddr==$i){echo 'background-color: #337ab7';} ?>" href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo $i;?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($pageAddr+1)>$total_pagesAddr){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?hid=<?php echo ($HeaderId); ?>&pageAddr=<?php echo ($pageAddr+1); ?>">&raquo;</a></li>
													  <?php }
										}
													  ?>

								  </ul>
								</div>
							</div>
							<!-- pagination end -->
				</div>	
				<input type="hidden" id="h_field_updateAddr" name="h_field_updateAddr" value="">
				<input type="hidden" id="h_NumRowsAddr" name="h_NumRowsAddr" value="0"/>	
				<input type="hidden" id="h_field_headeridAddr" name="h_field_headeridAddr" value="<?php echo $HeaderId; ?>">	
			</form>	
				
			
			
			<form id = "Form3" name = "Form3" action="" method="POST">
				<div class="detail-form2 upp-form row ">
					<div class="fleft two">						
						<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_Resources_PERMISSION=='Y'){ ?> id="cmdUpdateSelectedCont" name="cmdUpdateSelectedCont" onclick= 'EditRecordCont();'<?php } else { ?> disabled = disabled <?php } ?>> Update Selected </button>
						<button type="button" class="btn-style btn" onclick= 'ExportRecordCont()'> Export </button>
					</div>	
					<div class="fleft" >
						<!--  <label  style = "padding-top:28px;"> &nbsp; </label>-->
						<button type="button"   id = "cmdAddContact" name = "cmdAddContact" class="btn btn-style btn-primary" data-toggle="modal" data-target="#ModalAddContact" <?php  echo ($HeaderId!='')?"":"disabled"; ?> >  Add New Contact </button>  						  
					</div>
					
					<div class="data-bx">					
						<div class="table-responsive">							
							<table id = "tableContactList" name = "tableContactList"  class="table table-bordered mar-cont">
							  <thead>
								<tr>
									<th width="5%" class="check-bx "><input type="checkbox" id="selectallCont" onchange="checkAllCont()"></th>
									<th width="25%"> Phone </i></a></th>
									<th width="30%">Email Address </i></a></th>
									<th width="10%">Primary </i></a></th>
									<th width="10%">Active </i></a></th>
									<th width="10%">Accept Text </i></a></th>
									<th width="5%"> </th>
								</tr>
							  </thead>
							  <tbody>
								
								<?php 
									if($HeaderId != '')
									{ 
									$i=1;
									$qry2 = "select cxs_resource_contact.*,cxs_users.USER_NAME as CreatedBy  from cxs_resource_contact inner join cxs_users on cxs_users.USER_ID = cxs_resource_contact.CREATED_BY where cxs_resource_contact.RESOURCE_ID = $HeaderId order by ROW_NO";
									$selectQueryForContPages  = $qry2;
									$qry2 = $qry2." limit $start_fromCont , $record_per_pageCont";
									$result2 = mysql_query($qry2);
									while ($row2 = mysql_fetch_array($result2))									
									{ 
										$DisplayContactId  = $row2['CONTACT_RESOURCE_ID']; 
										$Display_PhoneNumber = $row2['PHONE_NUMBER'];
										$Display_Email = $row2['EMAIL_ADDRESS'];
										
										$Display_PrimaryCont = $row2['PRIMARY_FLAG'];
										$Display_ActiveCont = $row2['ACTIVE_FLAG'];
										$Display_AcceptTextCont = $row2['ACCEPTS_TEXTS_FLAG'];
										
										
										$Display_CreatedByNameCont	= $row2['CreatedBy'];	
										$Display_CreationDateCont = date('m/d/Y h:i:sa', strtotime($row2['CREATION_DATE']));										
										$UpdatedByCont		= $row2['LAST_UPDATED_BY'];
										$Display_UpdatedByNameCont = getvalue("cxs_users","USER_NAME", "where USER_ID = $UpdatedByCont");							
										$Display_LastUpdateCont = date('m/d/Y h:i:sa', strtotime($row2['LAST_UPDATE_DATE']));
									?>
								<tr>
									<td class="check-bx ">
										<input type="checkbox" id="<?php echo "inlineCheckboxCont$i"; ?>" name="<?php echo "inlineCheckboxCont$i"; ?>" value="1" onchange = "CheckBoxInlineCont()">
										<input type="hidden" id = <?php echo "h_resourceContactId".$i; ?> name = <?php echo "h_resourceContactId".$i; ?> value = "<?php echo $DisplayContactId; ?>">
									</td>
									<td>
										<div class="form-group">
											<input type="text" id = "<?php echo "Text_Phone".$i ?>" name = "<?php echo "Text_Phone".$i ?>" value = "<?php echo $Display_PhoneNumber; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div>
									</td>
									<td>
										<div class="form-group">
										  <input type="text" id = "<?php echo "Text_Email".$i ?>" name = "<?php echo "Text_Email".$i ?>" value = "<?php echo $Display_Email; ?>" class="form-control" placeholder="" maxlength="25" disabled>
										</div>
									</td>
									<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_CPrimary".$i ?>" name = "<?php echo "Checkbox_CPrimary".$i ?>" value="1" <?php echo ($Display_PrimaryCont=="Y")?"checked":"";?> maxlength="2" disabled></td>
									<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_CActive".$i ?>" name = "<?php echo "Checkbox_CActive".$i ?>" value="1" <?php echo ($Display_ActiveCont=="Y")?"checked":"";?> maxlength="2" disabled></td>
									<td class="check-bx"><input type="checkbox" id = "<?php echo "Checkbox_CAcceptText".$i ?>" name = "<?php echo "Checkbox_CAcceptText".$i ?>" value="1" <?php echo ($Display_AcceptTextCont=="Y")?"checked":"";?> maxlength="2" disabled></td>
									
									<td>
										<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
										Created By: <?php echo $Display_CreatedByNameCont; ?> <br> Updated By: <?php echo $Display_UpdatedByNameCont; ?> 
										<br> Creation Date: <?php echo $Display_CreationDateCont; ?> <br> Last Update Date: <?php echo $Display_LastUpdateCont; ?>"> <i class=" fa fa-eye"></i> </button>
									</td>
								</tr>
								<?php 
										$i=$i+1;
									}	
								}	
								?>
							  </tbody>
							</table>
						</div>
					</div>
				
					<!-- pagination start-->
							<div class="pagination-bx">
								<div class="bs-example">
								  <ul class="pagination">
									<?php
										if($HeaderId!='')
										{
											//echo $selectQueryForContPages;
											$RunDepQuery=mysql_query($selectQueryForContPages);
											$num_recordsCont = mysql_num_rows($RunDepQuery);
											$total_pagesCont= ceil($num_recordsCont/$record_per_pageCont); 
											if (($pageCont-1)==0){ ?>
												<li class="disabled">
													<!--<a rel="0" href="#"> «</a>-->
													<a rel="0" href="#">&laquo;</a>
												</li>
									  <?php  } else{  ?>
										<li class="">
										<a rel="0" href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo ($pageCont-1); ?>">&laquo;</a>
										</li>
										<?php }
									   for($i=1;$i<=$total_pagesCont;$i++){ ?>
											<li class="<?php echo ($pageCont==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($pageCont==$i){echo 'background-color: #337ab7';} ?>" href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo $i;?>"><?php echo $i; ?></a></li>
											<?php }
											 if (($pageCont+1)>$total_pagesCont){   ?>
											<li class="disabled"><a href="#">&raquo;</a></li>
												<?php  }else{    ?>
										   <li class=""><a href="?hid=<?php echo ($HeaderId); ?>&pageCont=<?php echo ($pageCont+1); ?>">&raquo;</a></li>
											<?php } 
										}	
										?>

								  </ul>

								</div>
							</div>
							<!-- pagination end -->
					
				</div>
				<input type="hidden" id="h_field_updateCont" name="h_field_updateCont" value="">
				<input type="hidden" id="h_NumRowsCont" name="h_NumRowsCont" value="0"/>	
				<input type="hidden" id="h_field_headeridCont" name="h_field_headeridCont" value="<?php echo $HeaderId; ?>">
			</form>
			
			<div class="fright mar-top20 row cr-user upp-form ">
				<button type="button" class="btn btn-primary btn-style fright"  <?php if($CREATE_PRIV_Resources_PERMISSION=='Y'){ ?> name = "cmdCreateResources" id = "cmdCreateResources" onclick = "chkfldAll();" <?php  echo ($HeaderId!='')?"":"disabled"; ?> <?php } else {?> disabled = "disabled" <?php } ?> > <?php echo $s_caption; ?> Resource </button>
			</div>
			
			
		  </div>			
    </div>
  </div>
</section>

<script type="text/javascript">
	$('#Combo_ResourceType').change(function()
	{
		if ($('#Combo_ResourceType').val() == 'Employee')
		{
			$('#Combo_ContractorType').val('');			
			$('#Combo_ContractorType').attr('disabled','disabled');
		}
		else
		{
			$('#Combo_ContractorType').attr('disabled',false);
		}
	}	
	);
	$(document).ready(function() 
	{													
		$(function() 
		{
			myFunction();	
			if ($("#h_IsEditAllowed").val()=="N")
			{
				$("#Form1 :input").prop("disabled",true);
				$("#Form2 :input").prop("disabled",true);
				$("#Form3 :input").prop("disabled",true);
				$("#cmdCreateResources").prop("disabled",true);
				if($("#h_OverrideInuse").val()=="Y")
				{
					$("#Text_Supervisor").prop("disabled",false);
					$("#h_OverrideInuse").prop("disabled",false);
					$("#h_field_supervisorid").prop("disabled",false);
					$("#cmdSaveRecord").prop("disabled",false);
					$("#cmdCreateResources").prop("disabled",false);					
				}
			}
		});											
	});

$('#Combo_ResourceGroup').on('click change',
	function()
	{
		KEY = "SetPreapprovalRule";
		var ResourceGroupId = $('#Combo_ResourceGroup').val();
		makeRequest("ajax-validations.php","REQUEST=PreApprovalByResourceGroup&ResourceGroupId="+ResourceGroupId);
	}
);
function myFunction()
{
	TABLE_ROWAddr = document.getElementById("tableAddressList").rows.length;				
	TABLE_ROWAddr=TABLE_ROWAddr-1;//remove header row from count
	
	TABLE_ROWCont = document.getElementById("tableContactList").rows.length;				
	TABLE_ROWCont=TABLE_ROWCont-1;//remove header row from count 
	var a = "<?php echo $Display_SupervisorId; ?>"	
	document.getElementById('h_field_supervisorid').value = a;
}
	$('#Text_StartDate').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});
	$('#Text_EndDate').datepicker(
	{
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}

	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}
				else if (KEY == "SearchSupervisor")
				{
					//var s1 = http_request.responseText;
				//	s1 = s1.trim();
				//	alert(s1+"result:");
				//	document.getElementById("ListSupervisor").innerHTML = http_request.responseText;						
					$("#divFindSupervisor").html(http_request.responseText);
					$("#divTable").DataTable({"searching": false});
				}
				else if(KEY == "ExportRecord")
				{
					var str = http_request.responseText;											
					window.open('downloaddata.php?r=holiday-calendars', '_blank');
				}
				else if(KEY == "ExportRecordCont")
				{
					var str = http_request.responseText;
					window.open('downloaddata.php?r=new-resource-contacts', '_blank');										
				}
				else if(KEY == "SetPreapprovalRule")
				{
					var JSONObject = JSON.parse(http_request.responseText.trim());
					$('#Combo_PreApprovalRules').val();
					if(JSONObject["PREAPPROVAL_RULE_ID"]!=''  )
					{
						$('#Combo_PreApprovalRules').val(JSONObject["PREAPPROVAL_RULE_ID"]);
					}	
					if(JSONObject["TIME_POLICY_ID"]!=''  )
					{
						$('#Combo_TimeManagementPolicy').val(JSONObject["TIME_POLICY_ID"]);
					}	
				}
				else if(KEY == "ExportRecordAddr")
				{
					var str = http_request.responseText;											
					window.open('downloaddata.php?r=new-resource-address', '_blank');
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}
		
	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 

</body>
</html>