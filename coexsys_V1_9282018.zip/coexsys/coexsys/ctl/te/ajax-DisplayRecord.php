<?php
include('../conn.php');
?>
<?php
	if($_REQUEST['REQUEST'] == "SingleUserRecord")
	{
		$TableName = $_REQUEST['TableName'];
		$FieldName = $_REQUEST['FieldName'];
		$FieldValue = $_REQUEST['FieldValue'];		
		$Query = "select * from $TableName where $FieldName = $FieldValue";
		//echo json_encode($Query);
		$result = mysql_query ($Query);
		while($row = mysql_fetch_array($result))
		{
			$data[$TableName] = $row;			
			if ($TableName=="cxs_aliases" )
			{
				$Segment1 = "";
				$WBSId = $row['WBS_ID'];
				$qry1 = "select * from cxs_wbs where WBS_ID = $WBSId";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$Segment1 =  $row1['SEGMENT1'];	
					$Segment2 =  $row1['SEGMENT2'];
					$Segment3 =  $row1['SEGMENT3'];
					$Segment4 =  $row1['SEGMENT4'];
					$Segment5 =  $row1['SEGMENT5'];	
					$Segment6 =  $row1['SEGMENT6'];	
					$Segment7 =  $row1['SEGMENT7'];
					$Segment8 =  $row1['SEGMENT8'];
					$Segment9 =  $row1['SEGMENT9'];
					$Segment10 =  $row1['SEGMENT10'];	
					$Segment11 =  $row1['SEGMENT11'];	
					$Segment12 =  $row1['SEGMENT12'];
					$Segment13 =  $row1['SEGMENT13'];
					$Segment14 =  $row1['SEGMENT14'];
					$Segment15 =  $row1['SEGMENT15'];	
				}
				if ($Segment1!="")
				{
					$WBSValue = $Segment1;
					$WBSValue .= ($Segment2!='')?".$Segment2":"";
					$WBSValue .= ($Segment3!='')?".$Segment3":"";
					$WBSValue .= ($Segment4!='')?".$Segment4":"";
					$WBSValue .= ($Segment5!='')?".$Segment5":"";
					$WBSValue .= ($Segment6!='')?".$Segment6":"";
					$WBSValue .= ($Segment7!='')?".$Segment7":"";
					$WBSValue .= ($Segment8!='')?".$Segment8":"";
					$WBSValue .= ($Segment9!='')?".$Segment9":"";
					$WBSValue .= ($Segment10!='')?".$Segment10":"";
					$WBSValue .= ($Segment11!='')?".$Segment11":"";
					$WBSValue .= ($Segment12!='')?".$Segment12":"";
					$WBSValue .= ($Segment13!='')?".$Segment13":"";
					$WBSValue .= ($Segment14!='')?".$Segment14":"";
					$WBSValue .= ($Segment15!='')?".$Segment15":"";
					$data[$TableName]['WBSValue']=$WBSValue;
					
				}
			}
			else if($TableName=="cxs_resources")
			{	
				$SupervisorId = $data[$TableName]['SUPREVISOR_ID'];
				$i=0;
				$qry1 = "select FIRST_NAME,LAST_NAME from $TableName where SUPREVISOR_ID = $SupervisorId";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data['SupervisorName'] = $row1['FIRST_NAME'];					
				}
				$qry1 = "select cxs_resource_address.* from $TableName inner join cxs_resource_address on cxs_resource_address.RESOURCE_ID = $TableName.$FieldName
						 where $TableName.$FieldName = $FieldValue  order by ROW_NO";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;
					$i=$i+1;
				}
				$data['ADetailRows'] = $i;	

				$i=0;				
				$Query = "select PHONE_NUMBER,EMAIL_ADDRESS,PRIMARY_FLAG as CPRIMARY_FLAG,ACTIVE_FLAG as CACTIVE_FLAG,ACCEPTS_TEXTS_FLAG as CACCEPTS_TEXTS_FLAG  from cxs_resource_contact where $FieldName = $FieldValue order by ROW_NO";
				$result2 = mysql_query ($Query);
				while($row2 = mysql_fetch_array($result2))
				{
					$data[] = $row2;	
					$i = $i+1;
				}
				$data['CDetailRows'] = $i;
			}
			
			else if($TableName=="cxs_calendars") // for accounting-periods.php page
			{	
				$i=0;	
				$qry1 = "select cxs_periods.* from cxs_periods inner join $TableName on $TableName.$FieldName = cxs_periods.CALENDAR_ID
						 where $TableName.$FieldName = $FieldValue  ";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;
					$i=$i+1;	
				}	
				$data['DetailRows'] = $i;	
			}
			else if($TableName=="cxs_holidays") // for holiday-calendar.php page
			{	
				$i=0;	
				$qry1 = "select DATE_FORMAT(HOLIDAY_START_DATE, '%W,%M %d, %Y') as START_DATE,DATE_FORMAT(HOLIDAY_END_DATE, '%W,%M %d, %Y') as END_DATE,cxs_holiday_calendar.* from cxs_holiday_calendar inner join $TableName on $TableName.$FieldName = cxs_holiday_calendar.HOLIDAY_CALENDAR_ID
						 where $TableName.$FieldName = $FieldValue  ";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;
					
					$i=$i+1;	
				}	
				$data['DetailRows'] = $i;	
			}
			
			else if($TableName=="cxs_workshifts") // for workshift.php page
			{	
				$i=0;		
				$qry1 = "select * from cxs_workshifts_detail inner join $TableName on $TableName.$FieldName = cxs_workshifts_detail.WORKSHIFT_ID
						 where $TableName.$FieldName = $FieldValue order by ROW_NO ";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;					
					$i=$i+1;
				}	
				$data['WDetailRows'] = $i;	
			}
			else if($TableName=="cxs_policy_header")
			{	
				$i=0;				
				$qry1 = "select cxs_policy_general.*,cxs_aliases.ALIAS_NAME as AliasNameG, cxs_aliases.ALIAS_TYPE as AliasTypeG, cxs_aliases.ALIAS_CLASS as AliasClassG, cxs_aliases.DESCRIPTION as AliasDescriptionG , 'a' as WBSGeneral,
						cxs_users.USER_NAME as CreatedByName,(select USER_NAME from cxs_users where cxs_users.USER_ID = cxs_policy_general.LAST_UPDATED_BY) as UpdatedByName,cxs_wbs.SEGMENT1,cxs_wbs.SEGMENT2,cxs_wbs.SEGMENT3,cxs_wbs.SEGMENT4
						,cxs_wbs.SEGMENT5 from cxs_policy_general
						inner join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_policy_general.ALIAS_ID inner join cxs_users on cxs_users.USER_ID = cxs_policy_general.CREATED_BY left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID
						where cxs_policy_general.POLICY_ID = $FieldValue  order by ROW_NO";
						 
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;
					$i=$i+1;
				}
				$data['GeneralRows'] = $i;	
				
				$i=0;				
				$qry1 = "select cxs_aliases.ALIAS_NAME as AliasNameTimeOff,cxs_users.USER_NAME as CreatedByNameTimeOff,(select USER_NAME from cxs_users where cxs_users.USER_ID = cxs_policy_time_off.LAST_UPDATED_BY) as UpdatedByNameTimeOff,
						cxs_policy_time_off.CREATION_DATE as CreateDateTimeOff,cxs_workshifts.NAME as WorkshiftNameTimeOff,cxs_policy_time_off.MAXIMUM_HOURS_ALLOWED  as HoursTimeOff,
						cxs_policy_time_off.LAST_UPDATE_DATE as UpdateDateTimeOff from cxs_policy_time_off
						inner join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_policy_time_off.ALIAS_ID inner join cxs_users on cxs_users.USER_ID = cxs_policy_time_off.CREATED_BY 
						inner join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_time_off.WORKSHIFT_ID 
						where cxs_policy_time_off.POLICY_ID = $FieldValue  order by ROW_NO";
						 
				$result2 = mysql_query($qry1);
				while($row2 = mysql_fetch_array($result2))
				{
					$data[] = $row2;
					$i=$i+1;
				}
				$data['TimeOffRows'] = $i;				
				/*$i=0;				
				$qry1 = "select cxs_policy_time_earned.EXCESS_HOURS_ALLOWED,cxs_policy_time_earned.HOLIDAY_EARN_CREDIT,cxs_policy_time_earned.SHIFT_DIFFERENTIAL,cxs_policy_time_earned.OVERTIME_ALLOWED,
						cxs_policy_time_earned.EARN_TYPE,cxs_users.USER_NAME as CreatedByNameTimeEarn,(select USER_NAME from cxs_users where cxs_users.USER_ID = cxs_policy_time_earned.LAST_UPDATED_BY) as UpdatedByNameTimeEarn,
						cxs_policy_time_earned.CREATION_DATE as CreateDateTimeEarn,cxs_workshifts.NAME as WorkshiftNameTimeEarn,cxs_periods.PERIOD_NAME as PeriodNameTimeEarn,
						cxs_policy_time_earned.LAST_UPDATE_DATE as UpdateDateTimeEarn from cxs_policy_time_earned
						inner join cxs_users on cxs_users.USER_ID = cxs_policy_time_earned.CREATED_BY inner join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_time_earned.WORKSHIFT_ID 
						inner join cxs_periods on cxs_periods.PERIOD_ID = cxs_policy_time_earned.PERIOD_ID
						where cxs_policy_time_earned.POLICY_ID = $FieldValue  order by ROW_NO";
						 
				$result2 = mysql_query($qry1);
				while($row2 = mysql_fetch_array($result2))
				{
					$data[] = $row2;
					$i=$i+1;
				}
				$data['TimeEarnRows'] = $i;
				
				$i=0;				
				$qry1 = "select cxs_hours_deduction.ALLOW_PAID_BREAK,cxs_hours_deduction.BREAK_HOURS,cxs_users.USER_NAME as CreatedByNameHDeduct,(select USER_NAME from cxs_users where cxs_users.USER_ID = cxs_hours_deduction.LAST_UPDATED_BY) as UpdatedByNameHDeduct,
						cxs_hours_deduction.CREATION_DATE as CreateDateHDeduct,cxs_workshifts.NAME as WorkshiftNameHDeduct,cxs_hours_deduction.LAST_UPDATE_DATE as UpdateDateHDeduct from cxs_hours_deduction
						inner join cxs_users on cxs_users.USER_ID = cxs_hours_deduction.CREATED_BY inner join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_hours_deduction.WORKSHIFT_ID 						
						where cxs_hours_deduction.POLICY_ID = $FieldValue  order by ROW_NO";
						 
				$result2 = mysql_query($qry1);
				while($row2 = mysql_fetch_array($result2))
				{
					$data[] = $row2;
					$i=$i+1;
				}
				$data['HDeductRows'] = $i;*/
			}
			else if($TableName=="cxs_preapp_rules") // for pre-approval-rules.php page
			{	
				$i=0;		
				$qry1 = "select cxs_preapp_alias.*,cxs_preapp_alias.CREATION_DATE as CreateDate,cxs_users.USER_NAME as CreatedByName,(select USER_NAME from cxs_users where cxs_users.USER_ID = cxs_preapp_alias.LAST_UPDATED_BY) as UpdatedByName,cxs_aliases.ALIAS_NAME  from cxs_preapp_alias inner join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_preapp_alias.ALIAS_ID inner join cxs_users on cxs_users.USER_ID = cxs_preapp_alias.CREATED_BY 
						  where cxs_preapp_alias.PREAPP_RULE_ID = $FieldValue order by ROW_NO "; //query is working
				/*$qry1 = "select cxs_aliases.ALIAS_NAME  from cxs_preapp_alias inner join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_preapp_alias.ALIAS_ID  
						  where cxs_preapp_alias.PREAPP_RULE_ID = $FieldValue order by ROW_NO ";	*/	  
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$data[] = $row1;					
					$i=$i+1;
				}	
				$data['AliasRows'] = $i;	
			}
		}		
		echo json_encode($data);
		
	}
?>