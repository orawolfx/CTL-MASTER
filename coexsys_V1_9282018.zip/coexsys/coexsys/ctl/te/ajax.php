<?php
//include('../conn.php');
include('te-functions.php');
?>

<?php
	if($_REQUEST['REQUEST'] == "FavoritesList")
	{
		$LoginUserId = $_SESSION['user_id'];
		$FeatureName = $_REQUEST['FeatureName'];
		$PageName = $_REQUEST['PageName'];		
		$list = "";
		$IsExistData="";
		$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' and MODULE_NAME = '$ModuleName'";
		$result=mysql_query	($qry);
		$TotalRecords = mysql_fetch_array($result);
		if($TotalRecords>0)
		{
			$qry1 ="Delete from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' ";
			mysql_query($qry1);			
			$IsExistData = "No";
		}
		else
		{
			$insArr = array();
			$insArr['USER_ID']=$LoginUserId;
			$insArr['FEATURE_NAME']=$FeatureName;
			$insArr['PAGE_NAME']=$PageName;	
			$insArr['MODULE_NAME']=$ModuleName;								
			insertdata("cxs_users_favorites",$insArr);				
		}
		
		$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId order by FEATURE_NAME";
		$result=mysql_query	($qry);
		
		while($row = mysql_fetch_array($result))
		{
			$PAGE_NAME = $row['PAGE_NAME'];
			$FEATURE_NAME = $row['FEATURE_NAME'];
			$list .= "<li><a href='$PAGE_NAME'> $FEATURE_NAME </a></li>";   	
		}
		echo $list.$IsExistData;
	}
?>

<?php
if($_REQUEST['REQUEST'] == "SearchSupervisor")
{
	$FirstName = $_REQUEST['FirstName'];
	$MiddleName = $_REQUEST['MiddleName'];
	$LastName = $_REQUEST['LastName'];
	$ResourceId  = $_REQUEST['ResourceId'];
	$SiteId = $_SESSION['user-siteid'];
	
	$s_query = " where SITE_ID=$SiteId ";	
	if($FirstName!='')
	{
		$s_query .= "and cxs_resources.FIRST_NAME like'%$FirstName%' ";
	}
	if($MiddleName!='')
	{
		$s_query .= " and cxs_resources.MIDDLE_NAME like'%$MiddleName%' ";
	}
	if($LastName!='')
	{
		$s_query .= "and cxs_resources.LAST_NAME like'%$LastName%' ";
	}	
	if($ResourceId!='')
	{
		$s_query .= "and cxs_resources.RESOURCE_ID <> $ResourceId ";
	}	
	$sql = "SELECT * FROM cxs_resources $s_query";
?>
	<table class="table table-bordered " width="100%" id = "divTable">
		  <thead>
			<tr>								  
			  <th><span> First Name </span></th>
			  <th><span> Middle Name </span></th>
			  <th><span> Last Name </span></th>
			</tr>
		  </thead>
		  <tbody id='ListSupervisor'>
<?php	$result = mysql_query($sql);	
	while($row=mysql_fetch_array($result))
	{
		$SearchResourceId 	  =  $row['RESOURCE_ID'];		
		$SearchFirstName  =  $row['FIRST_NAME'];	
		$SearchMiddleName	  =  $row['MIDDLE_NAME'];				
		$SearchLastName   =  $row['LAST_NAME'];	
	?>
			<!--<tr style="cursor:pointer"  onClick="SelectedSupervisor('<?php echo $SearchFirstName; ?>','<?php echo $SearchLastName; ?>',<?php echo $SearchResourceId; ?>);">-->
			<tr style="cursor:pointer"  onClick="SelectedSupervisor(<?php echo $SearchResourceId; ?>);">
			<td><?php echo $SearchFirstName; ?></td> 
			<td><?php echo $SearchMiddleName; ?> </td> 
			<td> <?php echo $SearchLastName; ?>  </td></tr>
<?php	
	}?>	
		  </tbody>
	</table>
<?php }
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportResources")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."RESOURCE_ID=$s1 or ";
			$s = substr($s, $pos+1);		
		}while(strlen($s)>0);	
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		$Export_data = "First Name,Last Name,Resource Type,Start Date Active,End Date Active ,Supervisor  \r\n";
		
		$ExportQuery = "select * FROM cxs_resources  where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$FirstName 		= $row['FIRST_NAME'];
			$LastName 		= $row['LAST_NAME'];
			$ResourceType 	= $row['RESOURCE_TYPE'];
			
			$Supervisor 	= $row['SUPREVISOR_ID'];	
			
			if((!is_null($row['START_DATE_ACTIVE'])) && (($row['START_DATE_ACTIVE'])!='0000-00-00') )
			{
				$StartDate = date('m/d/Y', strtotime($row['START_DATE_ACTIVE']));	
			}
			if((!is_null($row['END_DATE_ACTIVE'])) && (($row['END_DATE_ACTIVE'])!='0000-00-00') )
			{
				$EndDate = date('m/d/Y', strtotime($row['END_DATE_ACTIVE']));	
			}
			
			if($Supervisor!=0)
			{
				 $qry1 = "select FIRST_NAME,LAST_NAME from cxs_resources where RESOURCE_ID = $Supervisor";
				$result1 = mysql_query($qry1);
				while($row1 = mysql_fetch_array($result1))
				{
					$Supervisor = $row1['FIRST_NAME']." ".$row1['LAST_NAME'];
				}
			}
			else
			{
				$Supervisor = "";
			}
						
			$Export_data .= "$FirstName, $LastName,$ResourceType,$StartDate,$EndDate,$Supervisor \r\n";
		}	
		$_SESSION['Resources_Export'] = $Export_data;		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportCreateResourceAddress")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."ADDRESS_RESOURCE_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
		//}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		$Export_data = "Address 1,Address 2,Address 3,City,State,Country,Postal Code,Primary,Active  \r\n";
		
		$ExportQuery = "select * FROM cxs_resource_address inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_resource_address.RESOURCE_ID where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$Address1 		= $row['ADDRESS1'];
			$Address2 		= $row['ADDRESS2'];
			$Address3 	= $row['ADDRESS3'];
			$City		= $row['City'];
			$State 	= $row['State'];
			$Country 	= $row['Country'];
			$Postalcode		= $row['POSTAL_CODE'];
			$Primary 	= $row['PRIMARY_FLAG'];
			$Active 	= $row['ACTIVE_FLAG'];				
			$ResourceName	= $row['FIRST_NAME']." ".$row['LAST_NAME'];			
			$Export_data .= "$Address1, $Address2,$Address3,$City,$State,$Country,$Postalcode,$Primary,$Active \r\n";
		}	
		$_SESSION['NewResourceAddress_Export'] = $ResourceName."\r\n".$Export_data;		
		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportCreateResourceContact")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."CONTACT_RESOURCE_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
		//}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		//$Export_data = "Address 1,Address 2,Address 3,City,State,Country,Postal Code,Primary,Active  \r\n";
		$Export_data = "Phone,Email Address,Primary,Active,Accept Text\r\n";				
		$ExportQuery = "select * FROM cxs_resource_contact inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_resource_contact.RESOURCE_ID where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$PhoneNo 		= $row['PHONE_NUMBER'];
			$Email 		= $row['EMAIL_ADDRESS'];
			$Primary 	= $row['PRIMARY_FLAG'];
			$Active		= $row['ACTIVE_FLAG'];
			$AcceptTag 	= $row['ACCEPTS_TEXTS_FLAG'];	
			$ResourceName	= $row['FIRST_NAME']." ".$row['LAST_NAME'];
			$Export_data .= "$PhoneNo, $Email , $Primary,$Active,$AcceptTag \r\n";
		}	
		$_SESSION['NewResourceContacts_Export'] = $ResourceName."\r\n".$Export_data;		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportHolidayCalendar")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."HOLIDAY_CALENDAR_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
		//}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		$Export_data = "Holiday Name,Description,Start Date,End Date,Enforce,Recess Allowed,Enabled  \r\n";
		
		$ExportQuery = "select * FROM cxs_holiday_calendar  where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$HolidayName 		= $row['HOLIDAY_TAG_NAME'];
			$Description 		= $row['DESCRIPTION'];
			$Enforce 	= $row['ENFORCE_FLAG'];			
			$RecessAllowed 	= $row['RECESS_ALLOWED'];	
			$Enabled = $row['ENABLED_FLAG'];
			
			if((!is_null($row['HOLIDAY_START_DATE'])) && (($row['HOLIDAY_START_DATE'])!='0000-00-00') )
			{
				$StartDate = date('m/d/Y', strtotime($row['HOLIDAY_START_DATE']));	
			}
			if((!is_null($row['HOLIDAY_END_DATE'])) && (($row['HOLIDAY_END_DATE'])!='0000-00-00') )
			{
				$EndDate = date('m/d/Y', strtotime($row['HOLIDAY_END_DATE']));	
			}	
			$Export_data .= "$HolidayName, $Description,$StartDate,$EndDate,$Enforce,$RecessAllowed,$Enabled \r\n";
		}	
		$_SESSION['HolidayCalendar_Export'] = $Export_data;		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportAccountingPeriod")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."CALENDAR_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
		//}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		$Export_data = "Calendar Name,Description,Period Year,Period Type  \r\n";
		
		$ExportQuery = "select * FROM cxs_calendars  where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$CalendarName	= $row['NAME'];
			$Description	= $row['DESCR'];
			$PeriodYear 	= $row['PERIOD_YEAR'];
			$PeriodType 	= $row['PERIOD_TYPE'];			
			$Export_data .= "$CalendarName,$Description,$PeriodYear,$PeriodType \r\n";
		}	
		$_SESSION['AccountingPeriod_Export'] = $Export_data;		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportWorkShift")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."WORKSHIFT_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
		//}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		//$Export_data = "Shift Code,Shift Name,Description,Work Days,Daily Work Hours,Allow Overtime,Effective Start Date,Effective End Date  \r\n";
		$Export_data = "Shift Name,Description,Workshift Type,Active Flag,In Use Flag \r\n";		
		$ExportQuery = "select * FROM cxs_workshifts  where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			//echo$ShiftCode 		= $row['SHIFT_CODE'];
			$ShiftName 		= $row['SHIFT_NAME'];
			$Description	= $row['DESCRIPTION'];	
			$WorkshiftType 	= $row['WORKSHIFT_TYPE'];	
			$ActiveFlag = $row['ACTIVE_FLAG'];
			$InUseFlag = $row['IN_USE_FLAG'];								
			
			//$Export_data .= "$ShiftCode,$ShiftName,$Description,$WorkDays,$DailyWorkHours,$AllowOverTime,$StartDate,$EndDate \r\n";
			$Export_data .= "$ShiftName,$Description,$WorkshiftType,$ActiveFlag,$InUseFlag \r\n";
		}	
		$_SESSION['WorkShift_Export'] = $Export_data;		
	}
?>

<?php
	if($_REQUEST['REQUEST'] == "ExportResourceGroup")
	{
		$sId = $_REQUEST['qry'];	
		$Sortby = $_REQUEST['sortby'];	
		$s = $sId;
		do
		{
			$pos = strpos($s,"|");
			$s1 = trim(substr($s, 0, $pos));  //id
			$s2 = $s2."RESOURCE_GROUP_ID=$s1 or ";
			$s = substr($s, $pos+1);
		}while(strlen($s)>0);	
	//	}while($s.length>0);			
		$s2=substr( $s2, 0, -3 );
		
		$Export_data = "";
		$Export_data = "Name,Description,Active Flag  \r\n";
		
		$ExportQuery = "select * FROM cxs_resource_groups  where $s2 $Sortby ";		
		$ResultExport = mysql_query($ExportQuery);		
		while($row = mysql_fetch_array($ResultExport))
		{
			$ResourceGroupName 		= $row['RESOURCE_GROUP_NAME'];
			$Description 		= $row['DESCRIPTION'];
			$ActiveFlag 	=''; //$row['STATUS'];	
			$Export_data .= "$ResourceGroupName,$Description,$ActiveFlag \r\n";
		}	
		$_SESSION['ResourceGroup_Export'] = $Export_data;		
	}
?>