<?php ob_start ();
	 
	include("te-functions.php");
	check_login();
?>
<?php
	if ($_SESSION['current-user-type'] == "TE-Admin")
	{
		$CREATE_PRIV_WorkShift_PERMISSION = "Y";
		$UPDATE_PRIV_WorkShift_PERMISSION = "Y";
		$VIEW_PRIV_WorkShift_PERMISSION = "Y";
		$ENABLE_AUDIT_WorkShift_PERMISSION = "Y";
	}
	else
	{
		$CREATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('CREATE_PRIV','WorkShift',$_SESSION['user_id']);
		$UPDATE_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('UPDATE_PRIV','WorkShift',$_SESSION['user_id']);
		$VIEW_PRIV_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('VIEW_PRIV','WorkShift',$_SESSION['user_id']);
		$ENABLE_AUDIT_WorkShift_PERMISSION = getTimeAccountingModuleStatusByUserId('ENABLE_AUDIT','WorkShift',$_SESSION['user_id']);
	}
	if($CREATE_PRIV_WorkShift_PERMISSION=='N' && $UPDATE_PRIV_WorkShift_PERMISSION=='N' && $VIEW_PRIV_WorkShift_PERMISSION=='N' && $ENABLE_AUDIT_WorkShift_PERMISSION=='N')
	{
		header('location:te.php');
	}
	
	$LoginUserId = $_SESSION['user_id'];
	$PageName = "workshifts.php";
	$SiteId = $_SESSION['user-siteid'];
	
	$sort =  isset( $_GET['sort'] )? $_GET['sort']:'desc';
	$OrderBY = "";
	$FieldName = "";
	
	$OrderBY = "asc";
	$FieldName = "NAME";
	$Sorts = "";
	$Sorts = isset( $_POST['h_field_order'] )? $_POST['h_field_order']: $sort;
	$FileName = isset( $_POST['h_field_name'] )? $_POST['h_field_name']: $FieldName;
	$s_Query = isset( $_POST['h_query'] )? $_POST['h_query']: "";	
	$s_Query = str_replace("\\","",$s_Query);
	if ($Sorts == 'asc')
	{
		$OrderBY = " desc";
		$FieldName = $FileName;
	}
	if ($Sorts == 'desc')
	{
		 $OrderBY = " asc";
		 $FieldName = $FileName;
	}

	$SQueryOrderBy = " order by $FieldName $OrderBY";
	
	$record_per_page=$RecordsPerPage;
	if (isset($_GET["page"]))
	{
		$page  = $_GET["page"];
	}
	else
	{
		$page=1;
	}
	$start_from = ($page-1) *  $record_per_page;
	$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
	$IsUpdate = isset( $_POST['h_field_update'] )? $_POST['h_field_update']: "";
	$insArr = array();
	
	if($IsUpdate =='Y' && $TotalRows >0) //when data post with the caption save
	{
		
	//	$TotalRows=1;
		$insArr = array();
		for($i=1;$i<=$TotalRows;$i++)
		{
			
			$Check_Record = isset( $_POST['CheckboxInline'.$i] )? $_POST['CheckboxInline'.$i]: false;
			if($Check_Record==1)			
			{
				$Text_ShiftCode = isset($_POST["Text_ShiftCode$i"] )? $_POST["Text_ShiftCode$i"]: false;
				$Text_ShiftName = isset($_POST["Text_ShiftName$i"] )? $_POST["Text_ShiftName$i"]: false;
				$Text_Description = isset($_POST["Text_Description$i"] )? $_POST["Text_Description$i"]: false;
				$Text_WorkDays = isset($_POST["Text_WorkDays$i"] )? $_POST["Text_WorkDays$i"]: false;
				$Text_DailyWorkHours = isset($_POST["Text_DailyWorkHours$i"] )? $_POST["Text_DailyWorkHours$i"]: false;
				$Text_AllowOverTime = isset($_POST["Text_AllowOverTime$i"] )? $_POST["Text_AllowOverTime$i"]: false;				
				$Text_StartDate = isset($_POST["Text_StartDate$i"] )? $_POST["Text_StartDate$i"]: false;
				$Text_EndDate = isset($_POST["Text_EndDate$i"] )? $_POST["Text_EndDate$i"]: false;
				
				if($Text_StartDate!='')
				{
					$Text_StartDate = date("Y/m/d", strtotime($Text_StartDate));	
				}
				if($Text_EndDate!='')
				{
					$Text_EndDate = date("Y/m/d", strtotime($Text_EndDate));	
				}
				
				unset($inArr);
				$Post_WorkshiftId = isset( $_POST['h_WorkShiftId'.$i] )? $_POST['h_WorkShiftId'.$i]: false;
				
				$insArr['SHIFT_CODE'] 			= $Text_ShiftCode;
				$insArr['SHIFT_NAME'] 			= $Text_ShiftName;
			//	$insArr['STATUS'] 				= $Text_Description;
			//	$insArr['STATUS'] 				= $Text_WorkDays;
				$insArr['DAILY_WORK_HOURS'] 	= $Text_DailyWorkHours;
				$insArr['ALLOW_OVERTIME_FLAG'] 	= $Text_AllowOverTime;				
				$insArr['EFFECTIVE_START_DATE'] 	= $Text_StartDate;
				$insArr['EFFECTIVE_END_DATE'] 		= $Text_EndDate;
				$insArr['LAST_UPDATED_BY'] 		= $LoginUserId;			
			//	$insArr['ROW_NO'] 		= $i;
				
				
				updatedata("cxs_workshifts",$insArr,"where WORKSHIFT_ID = $Post_WorkshiftId");	
				
			}
		}
	}	
?>
<script type="text/javascript" >
	var TABLE_ROW;
	
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Work Shifts";		
		var s2 = "<?php echo $PageName; ?>";				
		makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
	}
	function DataSort(str1,str2)
	{
		var str3;
		document.getElementById('h_field_name').value = str1;
		document.getElementById('h_field_order').value = str2;
		//alert(document.getElementById('h_field_name').value);
		//alert(str2);
		WorkshiftList.submit();
	}
	function checkAll()
	{	
		var checkboxValue=document.getElementById('Checkbox_SelectAll').checked;
		var i=1;
		for(i=1;i<=TABLE_ROW;i++)
		{
			document.getElementById("CheckboxInline"+i).checked = checkboxValue;		
		}
	}   
	
	function checkInline()
	{
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == false)
			{
				document.getElementById('Checkbox_SelectAll').checked = false;
			}
		}
	}
	
	function EditRecord()
	{
		var counter=0;
		var selectedRow = 0;		
		for(i=1;i<=TABLE_ROW;i++)
		{
			if (document.getElementById("CheckboxInline"+i).checked == true)
			{
				counter = counter +1;
				selectedRow = i;
			}
			
		}		
		if (counter >1)
		{
			alert("Only One Record Can Edit At A Time");
			return false;
		}
		else if (counter == 1)
		{
			var s = document.getElementById("h_WorkShiftId"+selectedRow).value;
			location.href="add-new-shift.php?hid="+s;
		}
		else
		{
			alert("Please Select Any Record For Update");
			document.getElementById("Checkbox_Inline1").focus();
		}

		
	}
	
	function ShowInputElements(CurrentRow)
	{
		//document.getElementById(CurrentRow+"_5").value = "Save";
		document.getElementById("span"+CurrentRow+"_2").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_3").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_4").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_5").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_6").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_7").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_8").style.display = 'none';
		document.getElementById("span"+CurrentRow+"_9").style.display = 'none';
		
		document.getElementById("Text_ShiftCode"+CurrentRow).style.display = 'block';//2
		document.getElementById("Text_ShiftName"+CurrentRow).style.display = 'block';//3	
		document.getElementById("Text_Description"+CurrentRow).style.display = 'block';//4
		document.getElementById("Text_WorkDays"+CurrentRow).style.display = 'block';//5
		document.getElementById("Text_DailyWorkHours"+CurrentRow).style.display = 'block';//6
		document.getElementById("Text_AllowOverTime"+CurrentRow).style.display = 'block';//7
		document.getElementById("Text_StartDate"+CurrentRow).style.display = 'block';//8
		document.getElementById("Text_EndDate"+CurrentRow).style.display = 'block';//9
	}
	function CheckDate(currentRow)
	{
		var date1 = document.getElementById("Text_StartDate"+currentRow).value;
		var date2 = document.getElementById("Text_EndDate"+currentRow).value;
		
		if (date1!='' && date2!='') //
		{
			date1 = new Date($('#Text_StartDate'+currentRow).val());
			date2 = new Date($('#Text_EndDate'+currentRow).val());			
			
			if (date1 > date2)
			{
				alert("Start Date Must Be Greater Than End Date");
				document.getElementById("Text_EndDate"+currentRow).focus();
				return "N";
			}			
			return "Y";
		}
		
	}
	
	function ShowReadOnly(Id)
	{
		//if (document.getElementById("cmdUpdateSelected").innerHTML!="Save")
		//{	
			KEY= "SingleRecord";			
			//ReadonlyInputElements(true);
			$('#ModalDisplayPopup').modal();		
			var FieldValue = Id;
			var FieldName = "WORKSHIFT_ID";
			var TableName = "cxs_workshifts";
			makeRequest("ajax-DisplayRecord.php","REQUEST=SingleUserRecord&TableName="+TableName+"&FieldName="+FieldName+"&FieldValue=" + FieldValue);			
		//}
	}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">

<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>

<style type="text/css">
	.table-responsive 
	{
		overflow-x: inherit;
	}
	@media (min-width: 992px) 
	{
		.modal-lg
		{
			width: 1100px;
		}
	}
</style>
</head>

<body>
<?php include("header.php"); ?>
<!--Search modals start -->
	<form id="Find-Workshift-Form" >
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "FindPopup" role="dialog" aria-labelledby="myLargeModalLabel">
	  <div class="modal-dialog modal-lg cus-modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title " id="myModalLabel">Find Workshift </h4>
		  </div>
		  <div class="modal-body"> 
			<!-- field start-->
			<div class="col-sm-12">
			  <div class="cus-form-cont">
				
				<div class="col-sm-6 form-group">
					<label> Workshift Name </label>
					<input type="text" id = "Text_FindWorkshiftName" name = "Text_FindWorkshiftName" class="form-control" maxlength="100">
				</div>
				
				
			  </div>
			  
			</div>
			<!-- end --> 
		  </div>
		  <div class="clear-both"></div>
		  <div class="modal-footer cr-user">
			<button type="button" id="cmdFindPopup" name="cmdFindPopup" class="btn btn-primary btn-style" onclick="FindData()">Find</button>
		  </div>
		</div>
	  </div>
	</div>
	</form>
	<!-- Search Modal  -->
	
	<!--Display modals start -->
	<div class="modal fade bs-example-modal-lg custom-modal" tabindex="-1" id = "ModalDisplayPopup" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg cus-modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title " id="myModalLabel">Workshift</h4>
				</div>
				<div class="modal-body"> 
					<!-- field start-->
					<div class="col-sm-12">
						<div class="cus-form-cont">
							<div class="col-sm-4 form-group">
							  <label> Shift Name </label>
							  <input type="text" id = "Text_ShiftName" name = "Text_ShiftName" class="form-control requirefieldcls" required  disabled maxlength="50">
							</div>
							
							<div class="col-sm-4 form-group">
							  <label> Description </label>
							  <input type="text" id = "Text_Description" name = "Text_Description" class="form-control requirefieldcls" required  disabled maxlength="50">
							</div>
							  
							
							<div class="col-sm-4 form-group">
								<label> Time Zone </label>
								<select id = "Combo_TimeZone" name = "Combo_TimeZone" class="form-control requirefieldcls" required disabled >		
									<option value=""> - Time Zone -  </option>
									<option value="HAST"> HAST	Hawaii-Aleutian Standard Time</option>
									<option value="AKDT"> AKDT	Alaska Daylight Time	</option>
									<option value="PDT"> PDT	Pacific Daylight Time	 </option>
									<option value="MDT"> MDT	Mountain Daylight Time	</option>
									<option value="CDT"> CDT	Central Daylight Time	 </option>
									<option value="EDT">EDT	Eastern Daylight Time </option>
								</select>
							</div>			
							
							<div class="col-sm-4 form-group">
								 <label> Part Time </label>
								<select id = "Combo_PartTime" name = "Combo_PartTime" class="form-control" maxlength="20" disabled>		
									<option value=""> - Part Time -  </option>
									<option value="1/2 Time Base = 4.0 Hrs."> 1/2 Time Base = 4.0 Hrs.  </option>
									<option value="3/8 Time Base = 3.0 Hrs."> 3/8 Time Base = 3.0 Hrs. </option>
									<option value="3/4 Time Base = 6.0 Hrs."> 3/4 Time Base = 6.0 Hrs. </option>
									<option value="2/5 Time Base = 3.2 Hrs."> 2/5 Time Base = 3.2 Hrs. </option>
									<option value="4/5 Time Base = 6.4 Hrs."> 4/5 Time Base = 6.4 Hrs. </option>
									<option value="3/5 Time Base = 4.8 Hrs."> 3/5 Time Base = 4.8 Hrs. </option>
									<option value="1/8 Time Base = 1.0 Hrs.">1/8 Time Base = 1.0 Hrs. </option>
									
									<option value="5/8 Time Base = 5.0 Hrs."> 5/8 Time Base = 5.0 Hrs. </option>
									<option value="1/10 Time Base = 0.8 Hrs."> 1/10 Time Base = 0.8 Hrs. </option>
									<option value="7/10 Time Base = 5.6 Hrs."> 7/10 Time Base = 5.6 Hrs. </option>
									<option value="1/5 Time Base = 1.6 Hrs.">1/5 Time Base = 1.6 Hrs. </option>
									
									<option value="7/8 Time Base = 7.0 Hrs."> 7/8 Time Base = 7.0 Hrs. </option>
									<option value="1/4 Time Base = 2.0 Hrs."> 1/4 Time Base = 2.0 Hrs. </option>
									<option value="9/10 Time Base = 7.2 Hrs."> 9/10 Time Base = 7.2 Hrs. </option>
									<option value="3/10 Time Base = 2.4 Hrs.">3/10 Time Base = 2.4 Hrs. </option>
									<option value="19/20 Time Base = 7.6 Hrs.">19/20 Time Base = 7.6 Hrs. </option>
								</select>
							</div>  
							
							<div class="col-sm-4 form-group">
								 <label> Work Shift Type </label>
								<select id = "Combo_WorkShiftType" name = "Combo_WorkShiftType" class="form-control" maxlength="20" disabled>		
									<option value=""> - Workshift Type -  </option>
									<option value="9/8/80 Shift"> 9/8/80 Shift </option>
									<option value="4/10/40 Shift"> 4/10/40 Shift </option>
									<option value="Regular 40Hours Shift"> Regular 40Hours Shift </option>
									<option value="Flexible Shift"> Flexible Shift </option>
									<option value="Hourly Shift"> Hourly Shift </option>
									<option value="Six Days Shift"> Six Days Shift </option>
									<option value="Part Time Shift"> Part Time Shift </option>
								</select>
							</div> 
							
							<div class="col-sm-4 form-group">
								<br>
								<div class="checkbox">																				  
									<label style = "padding-right:5px;"> <input type="checkbox" id="Check_Active" name="Check_Active" <?php if($Display_Active == "Y"){ ?> checked="checked" <?php } ?>  value="1" disabled> Active</label>																		
									<label style = "padding-right:5px;"> <input type="checkbox" id="Check_InUse" name="Check_InUse" <?php if($Display_Check_InUser == "Y"){ ?> checked="checked" <?php } ?>  value="1" disabled> In Use </label>									
								</div>
							</div>											
						</div>
						
						<div class="data-bx">
							<div class="table-responsive">
								<div class="col-sm-6 col-md-offset-3">
								<table class="table table-bordered mar-cont table-cus2"  id = "TableDetails" >
								  <thead>
										<tr>
											<th width = "10%" >Work Day</th>
											<th width = "10%">Shift Hours</th>																					
										</tr>
									</thead>
								  <tbody>
									
								  </tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
					<!-- end --> 
					
				</div>
			  
				<div class="clear-both"></div>
				<div class="modal-footer cr-user">
				
				</div>
			</div>			
		</div>
	</div>
	<!-- Display Modal  -->
	
<section class="md-bg">
  <div class="container-fluid">
    <div class="row"> 
      <!-- brd crum-->
      <div class="brd-crmb">
        <ul>
          <li> <a href="#"> Set Up </a></li>
          <li> <a href="#"> Workshifts </a></li>
        </ul>
      </div>
      <!-- Dash board -->
      <div class="dash-strip">
        <div class="fleft cr-user"> <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> </div>
        <div class="fright">
			 <?php
				$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
				$result=mysql_query	($qry);
				$TotalRecords = mysql_num_rows($result);
				if($TotalRecords == 0)
				{
					$s_Style = "";
				}
				else
				{
					$s_Style = "background-color: #000;";
				}
			?>          
			<button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
			<button type="button" id = "cmdFind" name = "cmdFind"  class="btn btn-primary btn-style2" data-toggle="modal" data-target="#FindPopup"> <i class="fa fa-search" aria-hidden="true"></i> Find </button>
			<button type="button" id = "cmdRefresh" name = "cmdRefresh"class="btn btn-primary btn-style2" onclick="RefreshData()" ><i class="fa fa-refresh" aria-hidden="true"></i>Refresh</button>
        </div>
      </div>
      <!-- inner work-->
      <div class="cont-box">
        <div class="pge-hd">
          <h2 class="sec-title"> <label id="Label_Title"> Workshifts </label> </h2>
        </div>
        <div>
		<?php		  
			$selectQuery = "SELECT  NAME,DESCRIPTION,WORKSHIFT_TYPE,cxs_workshifts.ACTIVE_FLAG,cxs_workshifts.IN_USE_FLAG, cxs_workshifts.*,cxs_users.USER_NAME as CreatedBy FROM cxs_workshifts  inner join cxs_users on cxs_users.USER_ID = cxs_workshifts.CREATED_BY  WHERE cxs_workshifts.SITE_ID = $SiteId $s_Query  $SQueryOrderBy";
			$selectQueryForPages  = $selectQuery;
			$selectQuery = $selectQuery." limit $start_from , $record_per_page";
			
			$ExportQry = $selectQuery;
			
			$RunUserQuery=mysql_query($selectQuery);
			$StdNumRows = mysql_num_rows($RunUserQuery);
			$msg = "";
			if($StdNumRows == 0 )
			{
				$msg = "No Record Found";
			}	
		 ?>		
		  <div class = "text-center" style="color:red" ><h4><?php echo $msg; ?></h4></div>
		  <br>
          <div class="fleft two">     
			<button type="button" class="btn-style btn" <?php if($UPDATE_PRIV_WorkShift_PERMISSION=='Y'){ ?>id="cmdUpdateSelected" name="cmdUpdateSelected" onclick='EditRecord();'<?php }else{ ?>disabled="disabled"<?php } ?>> Update selected </button>			
			<button type="button" class="btn-style btn" onclick= 'ExportRecord()'> Export </button>
          </div>
          <div class="fright cr-user">
			<a <?php $sDisabled = ""; if($CREATE_PRIV_WorkShift_PERMISSION=='Y'){ ?> href="add-new-shift.php" <?php } else $sDisabled ="disabled=disabled"; ?>> 
						<button type="button" class="btn btn-primary btn-style" <?php echo $sDisabled; ?>> Create Shift</button></a>												
          </div>
		<form name = "WorkshiftList" id = "WorkshiftList" method="post" >
          <div class="data-bx">
            <div class="table-responsive">              
			  <table id='Table1' class="table table-bordered mar-cont">
                <thead>
                  <tr>                    
					<th width="5%" class="check-bx "><input type="checkbox" id="Checkbox_SelectAll" onchange="checkAll()"></th>
					<th width="8%">
						<?php if($Sorts == 'desc' && $FileName == 'NAME') { ?>
							  <span style="">
								Shift Name
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('NAME','asc');"></i>
							  </span>
						<?php } else { ?>
							  <span style="">
								Shift Name
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('NAME','desc');"></i>
							  </span>
						<?php } ?>
					</th>	

					<th width="10%">
						<?php if($Sorts == 'desc' && $FileName == 'DESCRIPTION') { ?>
							  <span style="">
								Description
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','asc');"></i>
							  </span>
						<?php } else { ?>
							  <span style="">
								Description
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('DESCRIPTION','desc');"></i>
							  </span>
						<?php } ?>
					</th>	

					<th width="10%">
						<?php if($Sorts == 'desc' && $FileName == 'WORKSHIFT_TYPE') { ?>
							  <span style="">
								Work Shift Type
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('WORKSHIFT_TYPE','asc');"></i>
							  </span>
						<?php } else { ?>
							  <span style="">
								Work Shift Type
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('WORKSHIFT_TYPE','desc');"></i>
							  </span>
						<?php } ?>
					</th>	

					<th width="10%">
						<?php if($Sorts == 'desc' && $FileName == 'ACTIVE_FLAG') { ?>
							  <span style="">
								Active
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','asc');"></i>
							  </span>
						<?php } else { ?>
							  <span style="">
								Active
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('ACTIVE_FLAG','desc');"></i>
							  </span>
						<?php } ?>
					</th>	
					<th width="10%">
						<?php if($Sorts == 'desc' && $FileName == 'IN_USE_FLAG') { ?>
							  <span style="">
								In Use
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('IN_USE_FLAG','asc');"></i>
							  </span>
						<?php } else { ?>
							  <span style="">
								In Use
								<i style="cursor:pointer;" class="fa fa-sort pull-right" onclick="DataSort('IN_USE_FLAG','desc');"></i>
							  </span>
						<?php } ?>
					</th>
					
                    <th width="5%"> </th>
                  </tr>
                </thead>
                <tbody>
				<?php
					
					$i= 1;
					while($rows=mysql_fetch_array($RunUserQuery))
					{
						$Display_WorkShiftId = $rows['WORKSHIFT_ID'];						
						$Display_ShiftName	=  $rows['NAME']; //$rows['SHIFT_NAME'];	
						$Display_Description = $rows['DESCRIPTION'];
						$Display_WorkShiftType	= $rows['WORKSHIFT_TYPE'];	
						$Display_Active	= $rows['ACTIVE_FLAG'];
						$Display_InUse	= $rows['IN_USE_FLAG'];
						//$Display_AllowSplitShift	= $rows['SPLIT_SHIFT_ALLOWED'];
										
						$Display_CreatedByName	= $rows['CreatedBy'];	
						$Display_CreationDate = date('m/d/Y h:i:sa', strtotime($rows['CREATION_DATE']));
						$UpdatedBy		= $rows['LAST_UPDATED_BY'];	
						$Display_UpdatedByName = getvalue("cxs_users","USER_NAME"," where USER_ID = $UpdatedBy");
						$Display_LastUpdate = date('m/d/Y h:i:sa', strtotime($rows['LAST_UPDATED']));
					?>
					<tr  <?php if($VIEW_PRIV_WorkShift_PERMISSION=='Y') {?> ondblclick="ShowReadOnly('<?php echo $Display_WorkShiftId; ?>')" <?php } ?>>						
						<td class="check-bx "><input type="checkbox" id="<?php echo "CheckboxInline$i"; ?>" name="<?php echo "CheckboxInline$i"; ?>" value="1" onchange="checkInline()">
							<input type="hidden" id = <?php echo "h_WorkShiftId".$i; ?> name = <?php echo "h_WorkShiftId".$i; ?> value = "<?php echo $Display_WorkShiftId; ?>">
						</td>
						
						<td> 
							<span id = "<?php echo "span".$i."_2"; ?>"> <?php echo $Display_ShiftName; ?> </span>
							<input type = "text" class="form-control" id="<?php echo "Text_ShiftName".$i; ?>" name="<?php echo "Text_ShiftName".$i; ?>" value ="<?php echo $Display_ShiftName; ?>" style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">
						</td>
						
						<td> 
							<span id = "<?php echo "span".$i."_3"; ?>"> <?php echo $Display_Description; ?> </span>
							<input type = "text" class="form-control" id="<?php echo "Text_Description".$i; ?>" name="<?php echo "Text_Description".$i; ?>" value ="<?php echo $Display_Description; ?>" style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">
						</td>
						
						<td> 
							<span id = "<?php echo "span".$i."_4"; ?>"> <?php echo $Display_WorkShiftType; ?> </span>
							<input type = "text" class="form-control" id="<?php echo "Text_WorkDays".$i; ?>" name="<?php echo "Text_WorkDays".$i; ?>" value ="<?php echo $Display_WorkShiftType; ?>" style = "height : 24px;font-size:9pt; padding-top: 0px;padding-bottom: 0px; display:none">
						</td>						
						
						
						<td class="check-bx ">
							<input type="checkbox" id="<?php echo "Check_DisplayActive$i"; ?>" name="<?php echo "Check_DisplayActive$i"; ?>" value="1" <?php echo($Display_Active == "Y")?"checked":""; ?>  disabled>		
						</td>
						
						
						<td class="check-bx ">
							<input type="checkbox" id="<?php echo "Check_DisplayInUse$i"; ?>" name="<?php echo "Check_DisplayInUse$i"; ?>" value="1" <?php echo($Display_InUse == "Y")?"checked":""; ?>  disabled>		
						</td>
						<!--
						<td class="check-bx ">
							<input type="checkbox" id="<?php echo "Check_DisplayAllowSplitShift$i"; ?>" name="<?php echo "Check_DisplayAllowSplitShift$i"; ?>" value="1" <?php echo($Display_AllowSplitShift == "Y")?"checked":""; ?>  disabled>		
						</td>						 -->
						
					<!--	<td> 
							<span id = "<?php echo "span".$i."_7"; ?>"> <?php echo $Display_StartDate; ?> </span>
							<input type="text" id="<?php echo "Text_StartDate".$i; ?>" name="<?php echo "Text_StartDate".$i; ?>" class="form-control small" value = "<?php echo $Display_StartDate; ?>"  style = "height : 24px;font-size:9pt;   display:none" >
						</td>	
						
						<td> 
							<span id = "<?php echo "span".$i."_8"; ?>"> <?php echo $Display_EndDate; ?> </span>
							<input type="text" id="<?php echo "Text_EndDate".$i; ?>" name="<?php echo "Text_EndDate".$i; ?>" class="form-control small" value = "<?php echo $Display_EndDate; ?>"  style = "height : 24px;font-size:9pt;   display:none" >
						</td>	-->
						<td>
							<?php if($VIEW_PRIV_WorkShift_PERMISSION=='Y') {?> 
							<button type="button" class="btn btn-default" data-trigger="focus" data-container="body" data-toggle="popover" data-html="true" data-placement="left" data-content="
							Created By: <?php echo $Display_CreatedByName; ?> <br> Updated By: <?php echo $Display_UpdatedByName; ?> 
							<br> Creation Date: <?php echo $Display_CreationDate; ?> <br> Last Update Date: <?php echo $Display_LastUpdate; ?>"> <i class=" fa fa-eye"></i> </button>
							<?php } else {?> <button type="button" class="btn btn-default"><i class=" fa fa-eye"></i></button> <?php } ?>
						</td>						
					</tr>
                  <?php   
						$i=$i+1;
						}
					?>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- pagination start-->
			
		<div class="pagination-bx">
			<div class="bs-example">
			  <ul class="pagination">
				<?php
					//$selectQueryForPages=$selectQueryForPages;
					$RunDepQuery=mysql_query($selectQueryForPages);
					$num_records = mysql_num_rows($RunDepQuery);
					$total_pages= ceil($num_records/$record_per_page);
					if (($page-1)==0){ ?>
						<li class="disabled">
							<!--<a rel="0" href="#"> «</a>-->
							<a rel="0" href="#">&laquo;</a>
						</li>
			  <?php  } else{  ?>
					<li class="">
					<a rel="0" href="?page=<?php echo ($page-1); ?>&sort=<?php echo $Sorts; ?>">&laquo;</a>
					</li>
					<?php }
				   for($i=1;$i<=$total_pages;$i++){ ?>
						<li class="<?php echo ($page==$i)?'active':''; ?>"><a class="<?php echo ($page==$i)?'current':''; ?>" style = "<?php if($page==$i){echo 'background-color: #337ab7';} ?>" href="?page=<?php echo $i;?>&sort=<?php echo $Sorts; ?>"><?php echo $i; ?></a></li>
						<?php }
						 if (($page+1)>$total_pages){   ?>
						<li class="disabled"><a href="#">&raquo;</a></li>
							<?php  }else{    ?>
					   <li class=""><a href="?page=<?php echo ($page+1); ?>&sort=<?php echo $Sorts; ?>">&raquo;</a></li>
								  <?php } ?>

			  </ul>

			</div>
		</div>
		<!-- pagination end -->
		<input type="hidden" id="h_field_name" name="h_field_name" value="<?php echo $FieldName; ?>">
		<input type="hidden" id="h_field_order" name="h_field_order" value="<?php echo $Sorts; ?>">	
		<input type="hidden" id="h_field_update" name="h_field_update" value="">
		<input type="hidden" id="h_NumRows" name="h_NumRows" value="0"/>
		<input type="hidden" id="h_query" name="h_query" value=""/>
	</form>
        </div>
      </div>
    </div>
  </div>
</section>
<footer> </footer>
<script type="text/javascript">
	TABLE_ROW = document.getElementById("Table1").rows.length;				
	TABLE_ROW=TABLE_ROW-1;//remove header row from count	
	
	$('#Text_StartDate').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});
	
	$('#Text_EndDate').datepicker(
	{
		//format:'DD,  MM d, yyyy',
		format:'mm/dd/yyyy',
		defaultDate: '',
		autoclose : true
	});
	
	for(i=1;i<TABLE_ROW;i++)
	{
		$('#Text_StartDate'+i).datepicker(
		{
			//format:'DD,  MM d, yyyy',
			format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
		});
		$('#Text_EndDate'+i).datepicker(
		{
			//format:'DD,  MM d, yyyy',
			format:'mm/dd/yyyy',
			defaultDate: '',
			autoclose : true
		});
	}
	
	function convertTime24to12(time24)
	{
		var tmpArr = time24.split(':'), time12;
		if(+tmpArr[0] == 12) {
		time12 = tmpArr[0] + ':' + tmpArr[1] + ' pm';
		} else {
		if(+tmpArr[0] == 00) {
		time12 = '12:' + tmpArr[1] + ' am';
		} else {
		if(+tmpArr[0] > 12) {
		time12 = (+tmpArr[0]-12) + ':' + tmpArr[1] + ' pm';
		} else {
		time12 = (+tmpArr[0]) + ':' + tmpArr[1] + ' am';
		}
		}
		}
		return time12;
	}
	
	function makeRequest(url,data)
		{
			var http_request = false;
			if (window.XMLHttpRequest) { // Mozilla, Safari, ...
				http_request = new XMLHttpRequest();
				if (http_request.overrideMimeType) {
					http_request.overrideMimeType('text/xml');
					// See note below about this line
				}
			} else if (window.ActiveXObject) { // IE
				try {
					http_request = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try {
						http_request = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
				}
			}

			if (!http_request) {
				alert('Giving up :( Cannot create an XMLHTTP instance');
				return false;
			}
			http_request.onreadystatechange = function() { alertContents(http_request); };
			http_request.open('POST', url, true);
			http_request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			http_request.send(data);
	}
	function FindData()
	{	
		KEY = "FindData";
		var formdata = $( "#Find-Workshift-Form" ).serialize();		
		makeRequest("ajax-finddata.php","REQUEST=FindDataWorkshift&"+formdata);			
	}
	function RefreshData()
	{
		WorkshiftList.submit();
	}	
	function alertContents(http_request)
	{
		if (http_request.readyState == 4)
		{
			if (http_request.status == 200)
			{ 
				if(KEY == "CheckFavoriteData")
				{
					var s1 = http_request.responseText;	
					s1=s1.trim();				
					str = s1;
					var n;
					n = str.lastIndexOf("No");					
					if (n>=0)//(s1=="No")
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
						s1 = str.substring(0,n);											
					}
					else
					{
						document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
					}					
					document.getElementById("favorite_list").innerHTML = s1;
				}				
				else if (KEY == "FindData")
				{
					var s1 = http_request.responseText;					
					document.getElementById("h_query").value=s1;						
					s1 = s1.trim();					
					WorkshiftList.submit();
				}
				else if (KEY == "SingleRecord")
				{
					var JSONObject = JSON.parse(http_request.responseText);
					document.getElementById("Text_ShiftName").value = JSONObject['cxs_workshifts']["NAME"];
					document.getElementById("Text_Description").value = JSONObject['cxs_workshifts']["DESCRIPTION"];
					document.getElementById("Combo_TimeZone").value = JSONObject['cxs_workshifts']["TIMEZONE"];					
					document.getElementById("Combo_PartTime").value = JSONObject['cxs_workshifts']["PART_TIME"];
					document.getElementById("Combo_WorkShiftType").value = JSONObject['cxs_workshifts']["WORKSHIFT_TYPE"];
					
					document.getElementById("Check_Active").checked=false;
					document.getElementById("Check_InUse").checked=false;
					//document.getElementById("Check_AllowSplitShift").checked=false;
					
					if(JSONObject['cxs_workshifts']["ACTIVE_FLAG"]=="Y")
					{
						document.getElementById("Check_Active").checked=true;
					}
					if(JSONObject['cxs_workshifts']["IN_USE_FLAG"]=="Y")
					{
						document.getElementById("Check_InUse").checked=true;
					}					
					var WorkShiftDetailRows = JSONObject['WDetailRows'];	
					var WeekDays = ["Monday", "Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
					
					$('#TableDetails').find('tbody').remove();
					
					for(i=0;i<WorkShiftDetailRows;i++) 
					{
						pos = parseFloat(JSONObject[i]["ROW_NO"])-1; 
						
						$('#TableDetails').append('<tr><td>'+WeekDays[pos]+'</td><td>'+JSONObject[i]["SHIFT_HOURS"]+'</td></tr>');					
					}	
				}
			}
			else
			{
				document.getElementById(KEY).innerHTML = "";
				alert('There was a problem with the request.');
			}
		}
	}	
	
	function ExportRecord()
	{
		var exportIds=[];
		var exportTableHeadings = [];
		var SelecteId = "";
		var sql = '<?php echo $ExportQry; ?>';	
		var flag_checked = "";
		var TotalRows = $("#Table1 tr").length-1;
		
		for(i=1;i<=TotalRows;i++)
		{
			if ($("#CheckboxInline"+i).prop("checked")==true)
			{
				flag_checked="Y";
				SelecteId = $("#h_WorkShiftId"+i).val();
				exportIds.push(SelecteId);
			}
		}
		if(flag_checked=="Y")		
		{
			$('#Table1 thead>tr').each(function () 
			{  
				$('th', this).each(function () 
				{  
					if($(this).text().trim()!='')
					{
						exportTableHeadings.push($(this).text().trim());
					}
				});
			});  
		
			$.ajax({
					url:"../ajax-export.php",				
					data:{ExportHeadings:exportTableHeadings,ExportQry:sql,
						  ExportQryFieldName:'WORKSHIFT_ID', ExportIdList:exportIds,
						  ExportFileName:'_workshifts.xls', ExportSheetTitle:"Workshifts"
						  },
					type:"POST",
					success:function(response)
					{
						window.location.href = '../export-records.php';										
					}
				});	
		}
		else
		{
			alert("Please Select Records For Export");
			$("#Checkbox_SelectAll").focus();
		}
	}
	

	</script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../js/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script> 
<script src="../js/custom.js" type="text/javascript"></script>
</body>
</html>