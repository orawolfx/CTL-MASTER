<?php
//include('../conn.php');
include("te-functions.php"); 
?>
<?php 
	if($_POST['REQUEST']=='CheckRowStatus')
	{
		$FinalArray = array();
		$FirstDate = $_POST['StartDate'];
		$FirstDate = strtotime($FirstDate);
		$FirstDate = date("Y-m-d",$FirstDate);
		//$FinalArray['first date']=$FirstDate;
		$LoginUserId = $_SESSION['user_id']; 
		$SiteId = $_SESSION['user-siteid'];	
		$CurrentWeek = GetCurrentWeekDates($FirstDate); 
	//	$IsAllowPreApproval = getvalue("cxs_am_ta_rules","ALLOW_PREAPPROVAL","where USER_ID = $LoginUserId");	
		$startDate = $CurrentWeek[0]; 
		$endDate = $CurrentWeek[6];
		$CurrentWeekHolidayList=array();	
		
		$qry = "select * from cxs_holiday_calendar where ((HOLIDAY_START_DATE >= '$startDate' and HOLIDAY_START_DATE <= '$endDate') or (HOLIDAY_END_DATE >= '$startDate' and HOLIDAY_END_DATE <= '$endDate')) and ENABLED_FLAG = 'Y' and cxs_holiday_calendar.SITE_ID =$SiteId order by HOLIDAY_START_DATE";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$HolidayName = $row['HOLIDAY_TAG_NAME'];
			$HolidayStartDate = $row['HOLIDAY_START_DATE'];
			$HolidayEndDate = $row['HOLIDAY_END_DATE'];
			$RecessAllowed = $row['RECESS_ALLOWED'];
			$EnforceFlag = $row['ENFORCE_FLAG'];			
			for($i=0;$i<=6;$i++)
			{
				$WeekDate = strtotime($CurrentWeek[$i]);
				if($WeekDate >= strtotime($HolidayStartDate) && $WeekDate <= strtotime($HolidayEndDate))
				{
					if($RecessAllowed=="Y")
					{
						$WeekDay = date('l',strtotime($CurrentWeek[$i]));						
						if($WeekDay=='Saturday')
						{
							$UpdateDate = strtotime('-1 day', strtotime($CurrentWeek[$i]));
						}
						else if($WeekDay=='Sunday')
						{
							$UpdateDate = strtotime('+1 day', strtotime($CurrentWeek[$i]));
						}
						$CurrentWeekHolidayList['Dates'][]=date('Y-m-d',$UpdateDate);	
						
					}
					else
					{
						$CurrentWeekHolidayList['Dates'][]=$CurrentWeek[$i];					
					}
					//$CurrentWeekHolidayList['HolidayName'][$i]=$HolidayName;
					//$CurrentWeekHolidayList['Enforce'][$i]=$EnforceFlag;
					$CurrentWeekHolidayList['HolidayName'][]=$HolidayName;
					$CurrentWeekHolidayList['Enforce'][]=$EnforceFlag;
				}
			} 
		}	
		//$HolidayFlag = "";	
		$qry = "select cxs_policy_header.ACTIVE_FLAG,cxs_policy_general.HOLIDAY_EARN_CREDIT,cxs_policy_general.OVERTIME_ALLOWED,cxs_preapp_rules.WEEKEND_HOURS_FLAG,cxs_policy_general.WORKSHIFT_ID,
				'Manual' as EARN_TYPE,cxs_policy_header.POLICY_ID
				from cxs_resources inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID inner join cxs_policy_header on cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID
				INNER JOIN cxs_policy_general ON cxs_policy_general.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID				
				left join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID
				where cxs_users.USER_ID = $LoginUserId limit 0,1";			
		$result = mysql_query ($qry);
		$WorkshiftId = "";
		while($row=mysql_fetch_array($result))
		{	
			$IsTimePolicyActive = $row['ACTIVE_FLAG'];
			$HolidayEarnCredit = $row['HOLIDAY_EARN_CREDIT'];
			$WorkshiftId = $row['WORKSHIFT_ID'];
			$EarnType = $row['EARN_TYPE'];
			$PolicyId = $row['POLICY_ID'];
			//$HolidayFlag = $row['HOLIDAY_FLAG'];//
			$WeekendFlag = $row['WEEKEND_HOURS_FLAG'];
			$OvertimeAllowed = $row['OVERTIME_ALLOWED'];
		}	
		
		$EvenFriday = array();		
		$day1 = date('Y-m-d',strtotime('second fri of '.date('F Y')));
		$EvenFriday[] = $day1;
		$day1 = date('Y-m-d',strtotime('fourth fri of '.date('F Y')));
		$EvenFriday[] = $day1;
		
		$IsExist= "";	
		$ShiftHours = array();
		if($WorkshiftId!='')
		{
			$qry = "select * from cxs_workshifts inner join cxs_workshifts_detail on cxs_workshifts_detail.WORKSHIFT_ID = cxs_workshifts.WORKSHIFT_ID where cxs_workshifts.WORKSHIFT_ID= $WorkshiftId order by ROW_NO";
			$result = mysql_query($qry);
			$RowNo=1;
			while($row=mysql_fetch_array($result))
			{
				$IsExist= "";	
				if($row['ROW_NO']==$RowNo)
				{
					/*if ($row['WORKSHIFT_TYPE']== '9/8/80 Shift' && $row['ROW_NO'] == 5 )//if and its friday
					{
						foreach($EvenFriday as $key)
						{
							if($key ==$CurrentWeek[5])
							{
								$IsExist = "Y";
							}
						}
						if($IsExist=="Y")	 { $ShiftHours[] = "-";	}
						else {$ShiftHours[] = $row['SHIFT_HOURS'];}
					}
					else
					{	*/ //do not delete the comment
						$ShiftHours[] = $row['SHIFT_HOURS'];
					//}
				}
				else
				{
					$ShiftHours[] = "-";
				}
				$RowNo++;
				//$ShiftHours[] = $row['SHIFT_HOURS'];
			}
			while($RowNo <= 7)
			{
				$ShiftHours[] = "-";
				$RowNo++;
			}
		}
		
		$AutoPopulateAlias = array();
		$qry = "select cxs_aliases.ALIAS_ID,cxs_aliases.ALIAS_NAME from cxs_aliases left join cxs_policy_general on cxs_policy_general.ALIAS_ID = cxs_aliases.ALIAS_ID left join cxs_policy_time_off on cxs_policy_time_off.ALIAS_ID = cxs_aliases.ALIAS_ID where (cxs_policy_general.POLICY_ID = $PolicyId or cxs_policy_time_off.POLICY_ID = $PolicyId) and cxs_aliases.AUTOPOPULATE = 'Y' AND cxs_aliases.ACTIVE_FLAG = 'Y'";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$AutoPopulateAlias['Id'][] = $row['ALIAS_ID'];
			$AutoPopulateAlias['AliasName'][] = $row['ALIAS_NAME'];
		}
		
		$DisableWeekDays=array();
		$ProjectTask=array();
		$ProjectTaskIsDisable = array();
		$ProjectTaskStatus=array();
		$position=0;$counter=0;
		$HolDate = "";
		
		foreach($CurrentWeek as $key)
		{
			$key = strtotime($key);		
			$IsHoliday="";	
				
			if (sizeof($CurrentWeekHolidayList)>0) 
			{
				foreach($CurrentWeekHolidayList['Dates'] as $key1)
				{
					$HolDate=$key1;			
					$HolDate = strtotime($HolDate);
					if($key==$HolDate)
					{
						$IsHoliday = "Y";
						break;
					}
				}
			}
			//echo $IsHoliday."-";
			/*if($IsHoliday=='Y')
			{
				if($CurrentWeekHolidayList['Enforce'][$position]=='Y')			
				{
					$s1 = "HOL-".$CurrentWeekHolidayList['HolidayName'][$position];
					if($HolidayEarnCredit == 'Y')
					{
						$ProjectTask[]=$s1;
						$ProjectTaskIsDisable[]="false";
					}
					else if($HolidayEarnCredit == 'N' )
					{
						$ProjectTask[]=$s1;
						$ProjectTaskIsDisable[]="true";
					}
				}
				else
				{
					$ProjectTask[]="-";
					if($HolidayEarnCredit == 'Y')
					{
						$ProjectTaskIsDisable[]="false";
					}
					else if($HolidayEarnCredit == 'N' )
					{
						
						$ProjectTaskIsDisable[]="true";
					}
				}
				$DisableWeekDays[] = "Holiday";
				$position++;
			}*/
			if($IsHoliday=='Y')
			{
				$s1 = "HOL-".$CurrentWeekHolidayList['HolidayName'][$position];
				$ProjectTask[]=$s1;
				
				$DisableWeekDays[] = "Holiday";				
				$HolidaysHourIsDisable[$counter]="true"; // in two situation it should be editable
				if($EarnType=="Manual")
				{
					if($HolidayEarnCredit == 'Y')
					{
						$HolidaysHourIsDisable[$counter]="false";
						$ProjectTaskStatus[]="Holiday";
					}
					else
					{
						if($CurrentWeekHolidayList['Enforce'][$position]!='Y')
						{
							$HolidaysHourIsDisable[$counter]="false";
							$ProjectTaskStatus[]="Holiday";
						}
						else
						{
							$ProjectTaskStatus[]="Working";
						}
					}
				}	 
				$position++;
			}
			else
			{
				$ProjectTask[]="-";
				$DisableWeekDays[] = "No Holiday";
				$ProjectTaskStatus[]="Working";
				$HolidaysHourIsDisable[$counter]="false";
			}
			$counter++;
		}
		
		$FinalArray['WeekDays'] = $DisableWeekDays;
		$FinalArray['ProjectTask'] = $ProjectTask;
		$FinalArray['HolidaysHourIsDisable'] = $HolidaysHourIsDisable;
		$FinalArray['ProjectTaskStatus'] = $ProjectTaskStatus;
		$CurrentWeek1=array();
		
		foreach($CurrentWeek as $key)
		{
			$key = strtotime($key);
			$CurrentWeek1[]= date('D, M d, Y', $key); 
		}
		$FinalArray['CurrentWeek']=$CurrentWeek1; 
		$FinalArray['ShiftHours'] = $ShiftHours;
		$FinalArray['EarnType']=$EarnType;
		$FinalArray['AutoPopulateAlias']=$AutoPopulateAlias;
		//$FinalArray['CurrentWeekHolidayList'] = $CurrentWeekHolidayList;
		echo json_encode($FinalArray);
	}
	
	else if($_POST['REQUEST']=='MoveDates')	
	{
		function total_mondays($month,$year)
		{
			$mondays=0;
			$total_days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
			for($i=1;$i<=$total_days;$i++)
			if(date('N',strtotime($year.'-'.$month.'-'.$i))==1) // 1 for monday
			$mondays++;
			return $mondays;
		}
		$FinalArray=array();
		$StartDate = $_POST['StartDate'];
		$EndDate = $_POST['EndDate'];
		$PayPeriodId = $_POST['PayPeriodId'];
		$Event = $_POST['Event'];
		$IsWeekEndAllowed = $_POST['IsWeekEndAllowed'];
		$SiteId = $_SESSION['user-siteid'];	 
		$qry = "select cxs_calendars.PERIOD_TYPE,cxs_periods.FROM_PERIOD_DATE,cxs_periods.TO_PERIOD_DATE,cxs_calendars.CALENDAR_ID from cxs_periods inner join cxs_calendars on cxs_calendars.PERIOD_YEAR = cxs_periods.PERIOD_YEAR where cxs_periods.PERIOD_ID = $PayPeriodId and cxs_periods.SITE_ID = $SiteId and cxs_calendars.SITE_ID = $SiteId ";
		//$FinalArray['qry'] = $qry;
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$PeriodType = $row['PERIOD_TYPE'];
			$CalendarId = $row['CALENDAR_ID'];
			
			//$PeriodType = $row['PERIOD_TYPE'];			
			if((!is_null($row['FROM_PERIOD_DATE'])) && (($row['FROM_PERIOD_DATE'])!='0000-00-00') )
			{			
				$FromDate = date('m/d/Y', strtotime($row['FROM_PERIOD_DATE']));
			}
			if((!is_null($row['TO_PERIOD_DATE'])) && (($row['TO_PERIOD_DATE'])!='0000-00-00'))
			{			
				$ToDate = date('Y-m-d', strtotime($row['TO_PERIOD_DATE']));	
			}			
		}		
		$i=0;
		$week=0;
		if (date("N", mktime(0, 0, 0, date(n), 1, date(Y))) <= "6") $week++;
		while ($i <= date(j)) 
		{
			if (date("N", mktime(0, 0, 0, date(n), $i, date(Y))) == "7") $week++;
			$i++;
		}
		
		$CurrentWeekNo = $week;		
		$TotalMondays = total_mondays(date(n),date(Y));
		
		$StartDate = strtotime($StartDate);		
		$StartDate = date('Y-m-d', $StartDate);
		$EndDate = strtotime($EndDate);		
		
		$EndDate1= date('Y-m-d', $EndDate);
		$NewPeriodId ="";
		$NewPeriodId = $PayPeriodId;
		/*if($PeriodType!='Monthly') 
		{
			
			$qry = "SELECT * FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$StartDate'  AND TO_PERIOD_DATE>='$StartDate') and (FROM_PERIOD_DATE<='$EndDate1'  AND TO_PERIOD_DATE>='$EndDate1')";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$NewPeriodId = $row['PERIOD_ID'];
			}
			if($NewPeriodId == "")	
			{
				$qry = "SELECT * FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$EndDate1'  AND TO_PERIOD_DATE>='$EndDate1')";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$NewPeriodId = $row['PERIOD_ID'];
				}
			}
		} 
		else
		{
			$qry = "SELECT * FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$StartDate'  AND TO_PERIOD_DATE>='$StartDate') and (FROM_PERIOD_DATE<='$EndDate1'  AND TO_PERIOD_DATE>='$EndDate1')";			
			$FinalArray['qry1'] = $qry;
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$NewPeriodId = $row['PERIOD_ID'];
			}
			if($NewPeriodId == "")	
			{
				if($Event == "Previous")
				{
					$Condition = "  WHERE (FROM_PERIOD_DATE<='$StartDate'  AND TO_PERIOD_DATE>='$StartDate') ";
				}
				else
				{
					$Condition = "  WHERE (FROM_PERIOD_DATE<='$EndDate1'  AND TO_PERIOD_DATE>='$EndDate1') ";
				}
				$qry = "SELECT * FROM cxs_periods $Condition ";				
				$FinalArray['Event1'] = $Event;
				$FinalArray['Event'] = $StartDate;				
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$NewPeriodId = $row['PERIOD_ID'];
				}
			}
		}*/
		// when else error handling remaining for newperiodid
		$FinalArray['NewPeriodId'] = $NewPeriodId;		
		$weekList = array();
		$weekListHiddenValue = array();
		
		$FinalArray['Todate'] = $ToDate;$FinalArray['EndDate'] = $EndDate;
		if(strtotime($ToDate)>$EndDate && $Event=="Next")
		{
			//if($CurrentWeekNo<=$TotalMondays)
			{
				$currentDate1 =strtotime($StartDate);
				$firstday = strtotime("next Monday",$currentDate1);				
				
				$this_week_sd = date("Y-m-d",$firstday);				
				$this_week_sd = strtotime($this_week_sd);
								
				for($i=0;$i<=6;$i++)
				{
					$currentDay = strtotime(date("Y-m-d",$this_week_sd)." +".$i." days");
					$weekList[]= date('D, M d, Y', $currentDay);//date("Y-m-d",$currentDay);
					$weekListHiddenValue[]=date("Y-m-d",$currentDay);
				}
				$FinalArray['weekList'] = $weekList;
				$FinalArray['weekListHiddenValue'] = $weekListHiddenValue;
			}
		}
		else if(strtotime($FromDate)<strtotime($StartDate) && $Event=="Previous")
		{
			//$FinalArray['CurrentWeekNo'] = $CurrentWeekNo;
		//	$FinalArray['TotalMondays'] = $TotalMondays;
			//if($CurrentWeekNo<=$TotalMondays )
			{
				$currentDate1 =strtotime($StartDate);
				//$lastday = strtotime($firstday.' -7 days'); 
				
				$firstday = strtotime("last Monday",$currentDate1);				
				$this_week_sd = date("Y-m-d",$firstday);				
				
				$qry = "SELECT PERIOD_ID,FROM_PERIOD_DATE FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$this_week_sd'  AND TO_PERIOD_DATE>='$this_week_sd' and SITE_ID = $SiteId )";
				$this_week_sd = strtotime($this_week_sd);				
				
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$TempPeriodId = $row['PERIOD_ID'];
				}
				if($TempPeriodId!=$PayPeriodId && $IsWeekEndAllowed == "N" )
				{
					$TempDate1 = date("Y-m-d",$currentDate1);
					$qry = "SELECT FROM_PERIOD_DATE FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$TempDate1'  AND TO_PERIOD_DATE>='$TempDate1' and SITE_ID = $SiteId)";										
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result))
					{
						$TempFromDate = $row['FROM_PERIOD_DATE'];
					}					
					$TempFromDate = date('Y-m-d',strtotime($TempFromDate));
					
					$FinalArray['TempFromDate Day'] = date('l',strtotime($TempFromDate));
					if(date('l',strtotime($TempFromDate))=="Saturday" || date('l',strtotime($TempFromDate))=="Sunday")
					{		
						$this_week_sd= strtotime($StartDate);	
					}
				}
				for($i=0;$i<=6;$i++)
				{
					$currentDay = strtotime(date("Y-m-d",$this_week_sd)." +".$i." days");
					$weekList[]= date('D, M d, Y', $currentDay);//date("Y-m-d",$currentDay);
					$weekListHiddenValue[]=date("Y-m-d",$currentDay);
				}
				$FinalArray['weekList'] = $weekList;
				$FinalArray['weekListHiddenValue'] = $weekListHiddenValue;
			}
		}
		
		$i=0;
		$IsAllowEntry=array();
		if(sizeof($weekListHiddenValue)>0)
		{
			foreach($weekListHiddenValue as $key)
			{
				$date1 = $key;//$weekListHiddenValue[$i];
				$qry = "SELECT PERIOD_ID FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$date1'  AND TO_PERIOD_DATE>='$date1' and SITE_ID = $SiteId)";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					if($row['PERIOD_ID']==$NewPeriodId) { $IsAllowEntry[] = "Y";}
					else { $IsAllowEntry[] = "N"; }
				}				
			}
		}
		$FinalArray['IsAllowEntry'] = $IsAllowEntry;
		echo json_encode($FinalArray);
	}
	else if($_POST['REQUEST']=='CheckEachDateValidation')	
	{
		$FinalArray = array();
		$CurrentDate = $_POST['CurrentDate'];
		$PayPeriodId = $_POST['PayPeriodId'];
		
		$qry = "select cxs_calendars.PERIOD_TYPE,cxs_periods.FROM_PERIOD_DATE,cxs_periods.TO_PERIOD_DATE from cxs_periods inner join cxs_calendars on cxs_calendars.PERIOD_YEAR = cxs_periods.PERIOD_YEAR where cxs_periods.PERIOD_ID = $PayPeriodId";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			//$PeriodType = $row['PERIOD_TYPE'];			
			if((!is_null($row['FROM_PERIOD_DATE'])) && (($row['FROM_PERIOD_DATE'])!='0000-00-00') )
			{			
				$FromDate = strtotime($row['FROM_PERIOD_DATE']);
			}
			if((!is_null($row['TO_PERIOD_DATE'])) && (($row['TO_PERIOD_DATE'])!='0000-00-00'))
			{			
				$ToDate = strtotime($row['TO_PERIOD_DATE']);	
			}			
		}
		$CurrentDate = strtotime($CurrentDate);
		if($CurrentDate>=$FromDate && $CurrentDate <= $ToDate)
		{
			$IsDisable = "false";
		}
		else
		{
			$IsDisable = "true";
		}
		
		
		$FinalArray['IsDisable'] = $IsDisable;
		
		//echo json_encode($FinalArray);
		echo $IsDisable;
	}
	else if($_POST['REQUEST']=='IsAllowNegative')	
	{
		/*$FinalArray = array();		
		$PolicyId = $_POST['PolicyId'];
		$AllowPaidBreak = "";
		$qry = "Select ALLOW_PAID_BREAK from cxs_hours_deduction where POLICY_ID = $PolicyId";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$AllowPaidBreak = $row['ALLOW_PAID_BREAK'];
		}
		if($AllowPaidBreak=='')
		{
			$AllowPaidBreak = "N";
		}
		echo $AllowPaidBreak;
		//$FinalArray['AllowPaidBreak']=$AllowPaidBreak;		
		*/
	}	
	else if ($_POST['REQUEST'] == 'TEHeader-SearchData')
	{
		$PayPeriodId = $_POST['PayPeriodId'];
		$ResourceId = $_POST['ResourceId'];
		$qry = "select * from cxs_te_header where PAY_PERIOD_ID = $PayPeriodId and RESOURCE_ID = $ResourceId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			echo $HeaderId = $row['TE_ID'];
		}
	}
	else if($_POST['REQUEST'] == 'TE-header-data')
	{
		parse_str($_POST['form'],$formArr);	
		$PayPeriodId = $_POST['PayPeriodId'];
		$SupervisorId = $_POST['SupervisorId'];
		$ResourceId = $_POST['ResourceId'];
		$CurrentUserId = $_POST['CurrentUserId'];
		$SiteId = $_SESSION['user-siteid'];
		$qry = "select * from cxs_te_header where PAY_PERIOD_ID = $PayPeriodId and RESOURCE_ID = $ResourceId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			echo $HeaderId = $row['TE_ID'];
		}
		if($HeaderId=='')
		{
			$insArr = array();
			$insArr['TE_NAME'] = $formArr['Text_TEName'];
			$insArr['TE_PREFIX'] = strtoupper($formArr['Text_TEPrefix']);
			$insArr['TE_DESCR'] = $formArr['Text_TEDescription'];
			$insArr['PAY_PERIOD_ID'] = $PayPeriodId;
			$insArr['SUPERVISOR_ID'] = $SupervisorId;
			$insArr['RESOURCE_ID'] = $ResourceId;
			$insArr['STATUS'] = 'Open';
			$insArr['CREATED_BY']=$CurrentUserId;	
			$insArr['CREATION_DATE']='now()';
			$insArr['LAST_UPDATED_BY'] = $CurrentUserId;
			$insArr['SITE_ID'] = $SiteId;
			insertdata('cxs_te_header',$insArr);		
			echo $HeaderId= mysql_insert_id();
		}
	}
	else if($_POST['REQUEST'] == 'TE-Grid-data')
	{
		$LoginUserId = $_SESSION['user_id'];
		$SiteId = $_SESSION['user-siteid'];		
		$RecordSaveDate = isset($_POST['RecordSaveDate'])?$_POST['RecordSaveDate']:'';
		$Event = isset($_POST['Event'])?$_POST['Event']:'';
		$RowNoForUpdate = isset($_POST['RowNoForUpdate'])?$_POST['RowNoForUpdate']:'';
		
		parse_str($_POST['form'],$formArr);		
		$ResourceId = $formArr['ResourceId'];
		//$PayPeriodId = $formArr['PayPeriodId'];
		$WorkshiftId = $formArr['CurrentWorkshiftId'];		
		$HeaderId = $formArr['hCurrentTEId'];	
		$Rows = $formArr['h_rows'];	
		$IsAllowEntry = $formArr['IsAllowEntry'];	
		$CurrentSupervisorId = $formArr['CurrentSupervisorId'];	
		$EntryDays = $formArr['h_currentweek'];
		$IsAllowEntryInTable = $formArr['IsAllowEntry'];
		$TotalHours = 0;
		
		if ($RecordSaveDate!='') // if only single day approval
		{
			$RecordSaveDate = date("Y-m-d",strtotime($RecordSaveDate));
			$EntryDays = array();
			$EntryDays[] = $RecordSaveDate;
		}
		
		$PayPeriodIdList = array();
		$i=1;
		$CurrentCol=1;
		foreach($formArr['h_currentweek'] as $key)
		{	
			$PayPeriodIdList[] = getvalue("cxs_periods","PERIOD_ID","where FROM_PERIOD_DATE <= '$key' and TO_PERIOD_DATE >= '$key' and SITE_ID = $SiteId");			
			if($i==1)
			{
				$FirstDate = $key;
			}
			else if ($i==7)
			{
				$LastDate = $key;
			}
			if($RecordSaveDate!='' && strtotime($key)==strtotime($RecordSaveDate))
			{
				$CurrentCol =$i;
			}
			$i++;
		}
		if($Event=="save")
		{
			$Status = "W";
		}
		else
		{
			$Status = "S"; //Submitted
			
			$PreApprovalType = "";	
			$qry = "select PREAPP_RULE_ID,cxs_preapp_rules.PREAPPROVAL_TYPE,cxs_preapp_rules.QUOTA_HOURS from cxs_resources inner join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID where RESOURCE_ID = $ResourceId";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$PreApprovalRuleId = $row['PREAPP_RULE_ID'];
				$PreApprovalType = $row['PREAPPROVAL_TYPE'];
				$QuotaHours = $row['QUOTA_HOURS'];
			}
			if($PreApprovalType == 'Direct Preapproval' && $QuotaHours > 0)
			{
				if($HeaderId!='')
				{
					$query_1 = " and not (ENTRY_DATE >= '$FirstDate' and ENTRY_DATE <= '$LastDate'  and STATUS_FLAG = 'W' ) and STATUS_FLAG <> 'W'";
					if($RecordSaveDate!='')//means only single date record wants to save + approve
					{
						$query_1 = " and not (ENTRY_DATE = '$RecordSaveDate'  and STATUS_FLAG = 'W' ) and STATUS_FLAG <> 'W'";
					}
					$qry = "select sum(HOURS) as TotalHours from cxs_te_file where cxs_te_file.TE_ID = $HeaderId  $query_1";
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result))
					{
						$TotalHours = $row['TotalHours'];
					}
				}
			}
			else if($PreApprovalType == 'Task Base Preapproval' && $QuotaHours > 0)
			{
				if($HeaderId!='')
				{
					
					$query_1 = " and not (ENTRY_DATE >= '$FirstDate' and ENTRY_DATE <= '$LastDate' and STATUS_FLAG = 'W' ) and STATUS_FLAG <> 'W' ";
					if($RecordSaveDate!='')//means only single date record wants to save + approve
					{
						$query_1 = " and not (ENTRY_DATE = '$RecordSaveDate' and STATUS_FLAG = 'W') and STATUS_FLAG <> 'W'";
					}
					
					$Aliasquery = "";
					$PreApprovalAliasList = array();
					$qry = "select ALIAS_ID from cxs_preapp_alias where PREAPP_RULE_ID = $PreApprovalRuleId";
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result))
					{
						$tempAliasId = $row['ALIAS_ID'];
						$Aliasquery .= " cxs_te_file.ALIAS_ID = $tempAliasId or";
						$PreApprovalAliasList[]=$tempAliasId;
					}
					
					if($Aliasquery!='')
					{
						$Aliasquery=substr( $Aliasquery, 0, -3 );
						$query_1 .= " and ( $Aliasquery )";
					}	
					
					$qry = "select sum(HOURS) as TotalHours from cxs_te_file where cxs_te_file.TE_ID = $HeaderId  $query_1";
					$result = mysql_query($qry);
					while($row = mysql_fetch_array($result))
					{
						$TotalHours = $row['TotalHours'];
					}
				}
			}
		}
		
		$AliasList = "";
		$TotalHours = isset($TotalHours)?$TotalHours:0;
		$i=0;
		foreach($EntryDays as $key1) //rowwise -col
		{	
			foreach($Rows as $key) //rowwise
			{
				unset($insArr);	
				
				$AliasId = isset($formArr['h_Taskid'.$key])? $formArr['h_Taskid'.$key]:0;					
				$Shift = isset($formArr['Combo_Shift'.$key])? $formArr['Combo_Shift'.$key]:'';				
				$SeedAlias = "";
				$WBSId = 0;
				if ($AliasId==""){$AliasId=0;}
				if ($AliasId==0)
				{
					$SeedAlias = isset($formArr['Text_Task'.$key])? $formArr['Text_Task'.$key]:"";
				}
				else
				{
					$WBSId = getvalue("cxs_aliases","WBS_ID","where ALIAS_ID = $AliasId");
				}
				
				$AliasList.=	$formArr['Text_Task'.$key].", "; // for email list
				
				$PayPeriodId = $PayPeriodIdList[$CurrentCol-1];
				$EntryDate = $key1;//$formArr['h_currentweek'][$CurrentCol-1];
				
				$TempQty = isset($formArr["Text_Hours$key"."_$CurrentCol"])?$formArr["Text_Hours$key"."_$CurrentCol"]:0;				
				
				/*if($Event=="save" && $Status=="W" )
				{
					if($SeedAlias!='')
					{
						$Status = "H";
					}		
					else if($SeedAlias=='')
					{
						$Status = "W";
					}		
				}*/
				
				if($Event!="save" && $QuotaHours > 0 && $PreApprovalType == 'Direct Preapproval')
				{
					//echo "Temp qty $TempQty TotalHours $TotalHours <br> Total ($TempQty + $TotalHours)";
					if($QuotaHours >= ($TempQty + $TotalHours))
					{
						$Status = "A";
					}
					else
					{
						$Status = "S";
					}	
					$TotalHours = $TotalHours + $TempQty;	
				}
				else if($Event!="save" && $QuotaHours > 0 && $PreApprovalType == 'Task Base Preapproval')
				{
					$Status = "S";
					//echo "Temp qty $TempQty TotalHours $TotalHours <br> Total ($TempQty + $TotalHours)";
					if($QuotaHours >= ($TempQty + $TotalHours))
					{
						foreach($PreApprovalAliasList as $AliasIdKey)
						{
							if($AliasId == $AliasIdKey)
							{
								$Status = "A";
								break;
							}
						}						
					}
					else
					{
						$Status = "S";
					}	
					$TotalHours = $TotalHours + $TempQty;	
				}
				$IsAllowEntryInTableA = $IsAllowEntryInTable[$CurrentCol-1];
				$insArr['TE_ID'] = $HeaderId;
				$insArr['APPROVAL_ID'] = $CurrentSupervisorId;	
				$insArr['RESOURCE_ID'] = $ResourceId;
				$insArr['ALIAS_ID'] = $AliasId;//$_POST['h_Taskid'.$key];					
				$insArr['WBS_ID'] = $WBSId;
				$insArr['SEED_ALIAS'] = $SeedAlias;			
				$insArr['SHIFT'] = $Shift;	
				$insArr['PERIOD_ID'] = $PayPeriodId;
				$insArr['ENTRY_DATE'] = $EntryDate;
				$insArr['HOURS'] = $TempQty;
				$insArr['STATUS_FLAG'] = $Status;//isset($formArr["Text_Status$key"."_$CurrentCol"])?substr($formArr["Text_Status$key"."_$CurrentCol"],0,1):"";
				$insArr['COMMENT'] = isset($formArr["h_comment$key"."_$CurrentCol"])?$formArr["h_comment$key"."_$CurrentCol"]:"";
				$insArr['ENTRY_TYPE'] = 'A';				
				$insArr['ROW_NO'] = $key;
				$insArr['LAST_UPDATED_BY']	= $LoginUserId;
				$insArr['SITE_ID']	= $SiteId;
				
				$IsEnableAudit = $_SESSION['IsEnableAudit'];
				
				if(($AliasId!=0 || $SeedAlias != "") && $IsAllowEntryInTableA == 'Y' && $TempQty != 0)
				{
					$qry = "select * from cxs_te_file where TE_ID = $HeaderId and RESOURCE_ID = $ResourceId and PERIOD_ID = $PayPeriodId and (ALIAS_ID=$AliasId and SEED_ALIAS ='$SeedAlias') and ENTRY_DATE = '$EntryDate' and ROW_NO = $key";
					$result=mysql_query($qry);
					$noofrecords = mysql_num_rows($result);
					if($noofrecords==1)				
					{
						$OldHours = 0;
						while($row = mysql_fetch_array($result))
						{
							$DetailId = $row['DETAIL_ID'];
							$OldHours = $row['HOURS'];
						}
						updatedata('cxs_te_file',$insArr,"where TE_ID = $HeaderId and RESOURCE_ID = $ResourceId and PERIOD_ID = $PayPeriodId and (ALIAS_ID=$AliasId and SEED_ALIAS ='$SeedAlias') and ENTRY_DATE = '$EntryDate' and ROW_NO = $key and (STATUS_FLAG='W' or STATUS_FLAG='H' or STATUS_FLAG='R')");
						
						
						if(mysql_affected_rows()>0  &&  $IsEnableAudit == "Y" )
						{
							if($i==0)
							{
								InsertPeriodAudit($DetailId,$PreApprovalType,$Status);
								$i++;
							}
							InsertDailyAudit($DetailId,$PreApprovalType,$Status,$OldHours);
						}
					}
					else
					{
						
						if($SeedAlias!='')
						{
							//$Status = "H";
							$insArr['STATUS_FLAG'] = 'H';
						}
						$insArr['CREATION_DATE']='now()';
						$insArr['CREATED_BY']=$LoginUserId;	
						insertdata('cxs_te_file',$insArr);
						$DetailId = mysql_insert_id();
						$OldHours=$insArr['HOURS'];
						if( $IsEnableAudit == "Y" )
						{
							if($i==0)
							{
								InsertPeriodAudit($DetailId,$PreApprovalType,$Status);
								$i++;
							}
							//echo " call InsertDailyAudit function";
							InsertDailyAudit($DetailId,$PreApprovalType,$Status,$OldHours);
						}
					}					
				}		
			}
			$CurrentCol++;
		}
		
		$currentResourceId = $ResourceId;
		$currentPolicyId = $formArr['CurrentTimePolicyId'];
		if($currentPolicyId != '')
		{
			$qry = "Select * from cxs_policy_header where POLICY_ID = $currentPolicyId ";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				if($row['ADDINUSE_FLAG']!='Y') 
				{
					mysql_query("update cxs_policy_header set ADDINUSE_FLAG = 'Y' where POLICY_ID = $currentPolicyId");
				}
			}
		}
		if($CurrentWorkshiftId != '')
		{
			$qry = "Select * from cxs_workshifts where WORKSHIFT_ID = $CurrentWorkshiftId ";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				if($row['IN_USE_FLAG']!='Y')
				{
					mysql_query("update cxs_workshifts set IN_USE_FLAG = 'Y' where WORKSHIFT_ID = $CurrentWorkshiftId");
				}
			}
		}	
		
		if($Preapproval=="")
		{
			$AliasList=substr( $AliasList, 0, -2);
			$qry = "SELECT ResourceEmail,SupervisorId,(SELECT cxs_users.USER_NAME FROM cxs_resources INNER JOIN cxs_users ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_resources.resource_id = a.SupervisorId) AS SupervisorEmail 
					FROM ( SELECT cxs_users.USER_NAME AS ResourceEmail, cxs_resources.SUPREVISOR_ID AS SupervisorId FROM cxs_resources INNER JOIN cxs_users ON cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID WHERE cxs_resources.RESOURCE_ID = $ResourceId ) AS a"; 
			$result = mysql_query($qry)		;
			while($row = mysql_fetch_array($result))
			{
				$ResourceEmail = $row['ResourceEmail'];
				$SupervisorEmail = $row['SupervisorEmail'];
			}
			
			/**************** Code for sending email *****************/		
		$s_html = "";
		$s_html = "	<html>
					<head></head>
					<body>
					<table align='left' width='600' border=0 cellspacing='1' cellpadding='2'>					
						<tr height='25px'>
							<td style='font-family:Verdana;font-size:10pt;'> $AliasList require approval. </td>
						</tr>
					</table>
					</body>
					</html>";
		$from_name='Coexsys Time Accounting'; //Website Name
		$from_email='admin@testrbam.com'; //Admin Email		
		$to=$ResourceEmail." ,".$SupervisorEmail;		
		$subject = "Approval for Submit Task";		
		//include "email/newUser.php"; //email design with content included		
		$message = $s_html;		
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From: $from_name < $from_email >\r\n";		
	    mail($to, $subject, $message, $headers);				
		/*********************************************************/			
		}		 
	}
	if($_POST['REQUEST'] == 'TimeKeeping')	
	{
		$ResourceId = isset($_POST['ResourceId'])?$_POST['ResourceId']:'';		
		$PayPeriodId = isset($_POST['PayPeriod'])?$_POST['PayPeriod']:'';		
		$CurrentPayPeriod = isset($_POST['CurrentPayPeriod'])?$_POST['CurrentPayPeriod']:'';
		$StartDate = isset($_POST['StartDate'])?$_POST['StartDate']:'';
		$EndDate = isset($_POST['EndDate'])?$_POST['EndDate']:'';
		$Event = isset($_POST['Event1'])?$_POST['Event1']:'';  
		$StartDate = strtotime($StartDate);		
		$StartDate = date('Y-m-d', $StartDate);
		$EndDate = strtotime($EndDate);		 
		$EndDate = date('Y-m-d', $EndDate);
		$SiteId = $_SESSION['user-siteid'];
		if($CurrentPayPeriod!='')
		{
			$PayPeriodId = $_SESSION['CurrentPayPeriodId'];
		}
		$ResultArray=array();	
		$ResultArray['PayPeriodId']=$PayPeriodId;
		$ResultArray['row']['msg']="";	
		$SupervisorId ="";
		$SupervisorName = "";
		$IsRecordExist = "";
		if($PayPeriodId!='' )
		{
			$query1 = " and cxs_te_header.PAY_PERIOD_ID = $PayPeriodId ";//and (cxs_te_file.ENTRY_DATE >= '$StartDate' and cxs_te_file.ENTRY_DATE <= '$EndDate')";
		}		
		else if($StartDate!='' && $EndDate != '')
		{
			$query1 = " and (cxs_te_file.ENTRY_DATE >= '$StartDate' and cxs_te_file.ENTRY_DATE <= '$EndDate' and cxs_te_file.SITE_ID = $SiteId )";
		}
		/*check TE-Header has record or not
		left join cxs_te_file on cxs_te_file.TE_ID = cxs_te_header.TE_ID order by cxs_te_file.DETAIL_ID
		*/
		$qry = "SELECT cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME,cxs_resources.RESOURCE_ID,cxs_periods.PERIOD_NAME,cxs_te_header.PAY_PERIOD_ID,cxs_users.USER_ID,cxs_resources.TIMEMANAGEMENTPOLICY_ID,cxs_policy_general.WORKSHIFT_ID,cxs_workshifts.NAME as WorkshifName,cxs_resources.SUPREVISOR_ID,cxs_te_header.TE_ID,
					cxs_te_header.TE_NAME,cxs_te_header.TE_PREFIX,cxs_policy_general.OVERTIME_ALLOWED,cxs_policy_general.CTO_OVERTIME,cxs_te_header.CREATION_DATE,cxs_te_header.LAST_UPDATE_DATE from cxs_te_header 
					INNER JOIN cxs_resources ON cxs_resources.RESOURCE_ID = cxs_te_header.RESOURCE_ID INNER JOIN cxs_periods ON cxs_periods.PERIOD_ID = cxs_te_header.PAY_PERIOD_ID inner join cxs_users on cxs_users.RESOURCE_ID = cxs_resources.RESOURCE_ID left join cxs_policy_header on cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID 
					left join cxs_policy_general on cxs_policy_general.POLICY_ID = cxs_policy_header.POLICY_ID left join cxs_workshifts on cxs_workshifts.WORKSHIFT_ID = cxs_policy_general.WORKSHIFT_ID 
					where cxs_te_header.RESOURCE_ID = $ResourceId and cxs_te_header.SITE_ID = $SiteId $query1  limit 0,1";			
		$ResultArray['qry12345']=$qry;
		$result = mysql_query($qry);		
		while($row = mysql_fetch_array($result))
		{
			$TEId = $row['TE_ID'];
			$SupervisorId =  $row['SUPREVISOR_ID'];
			$ResultArray['row']=$row;
			$IsRecordExist="Y";
		}
		if ($SupervisorId!="" && $IsRecordExist=='Y')
		{
			$qry = "select concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as SupervisorName from cxs_resources where cxs_resources.RESOURCE_ID = $SupervisorId and SITE_ID = $SiteId";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$SupervisorName = $row['SupervisorName'];
			}
		}
		else
		{
			if($PayPeriodId=='' && ($StartDate!='' && $EndDate != ''))
			{
				if($Event == 'Next')
				{
					$condition1 = " where (FROM_PERIOD_DATE <= '$StartDate' and TO_PERIOD_DATE >= '$StartDate' and SITE_ID = $SiteId )";
				}
				else if($Event == 'Previous' || $Event == '')
				{
					$condition1 = " where (FROM_PERIOD_DATE <= '$EndDate' and TO_PERIOD_DATE >= '$EndDate' and SITE_ID = $SiteId)";
				}				
				
				$qry = "select * from cxs_periods $condition1";
				$result = mysql_query($qry) ;
				while($row = mysql_fetch_array($result))
				{
					$PayPeriodId = $row['PERIOD_ID'];
				}
			}
			$qry = "select '' as TE_NAME,'' as TE_ID,cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME,cxs_resources.RESOURCE_ID,cxs_workshifts.NAME as WorkshifName,cxs_resources.SUPREVISOR_ID,cxs_workshifts.WORKSHIFT_ID,cxs_policy_header.POLICY_ID,cxs_resources.TIMEMANAGEMENTPOLICY_ID,cxs_policy_general.OVERTIME_ALLOWED,cxs_policy_general.CTO_OVERTIME from cxs_users
			inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_users.RESOURCE_ID 
			inner JOIN cxs_policy_header ON cxs_policy_header.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID inner JOIN cxs_policy_general ON cxs_policy_general.POLICY_ID = cxs_policy_header.POLICY_ID inner JOIN cxs_workshifts ON cxs_workshifts.WORKSHIFT_ID = cxs_policy_general.WORKSHIFT_ID			 			 
			where cxs_users.RESOURCE_ID = $ResourceId ";			 
			$condition1 = "";			
			if($PayPeriodId!='')
			{
				$condition1 = " limit 0,1 ";
			}			
			$qry = $qry.$condition1;			
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				$IsRecordExist='Y';
				$SupervisorId =  $row['SUPREVISOR_ID'];
				$ResultArray['row']=$row;				
			}
			if($PayPeriodId!='') 
			{	$ResultArray['row']['PAY_PERIOD_ID']=$PayPeriodId;	 }
			
			if ($SupervisorId!="" && $IsRecordExist=='Y')
			{
				$qry = "select concat(cxs_resources.FIRST_NAME,' ',cxs_resources.LAST_NAME) as SupervisorName from cxs_resources where cxs_resources.RESOURCE_ID = $SupervisorId";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$SupervisorName = $row['SupervisorName'];
				}
			}
			else 
			{
				if($Event == '' && $PayPeriodId!='') // when directly payperiod search from timekeeping so no prev - next
				{
					$TempCalendarID = getvalue("cxs_periods","CALENDAR_ID","where PERIOD_ID = $PayPeriodId");
					$qry123 = "select cxs_policy_general.CALENDAR_ID from cxs_policy_general inner join cxs_resources on cxs_policy_general.POLICY_ID = cxs_resources.TIMEMANAGEMENTPOLICY_ID 
							where cxs_resources.RESOURCE_ID =$ResourceId limit 0,1";						
					$result123 = mysql_query($qry123);
					while($row123 = mysql_fetch_array($result123))
					{
						$TempCalendarID1 = $row123['CALENDAR_ID'];
					}
					if($TempCalendarID != $TempCalendarID1)
					{
						$ResultArray['row']['msg']="Not match";
					}
				}
			}
		} 
		$ResultArray['SupervisorName'] = $SupervisorName;
		
		$AliasList = array();
		$AliasHolidayList = array();
		if($TEId!='')
		{
			$condition1 = " and (ENTRY_DATE >= '$StartDate' and ENTRY_DATE <= '$EndDate')";			
			$qry ="select cxs_te_file.ALIAS_ID as AliasId,cxs_te_file.SEED_ALIAS,cxs_aliases.ALIAS_NAME from cxs_te_header inner join cxs_te_file on cxs_te_file.TE_ID = cxs_te_header.TE_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID where cxs_te_header.TE_ID = $TEId $query1 $condition1 group by ROW_No";
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				if($row['AliasId']==0)
				{
					$AliasHolidayList[]=$row['SEED_ALIAS'];					
				}				
				$AliasList[]=$row['AliasId'];
			}		
		}	
		//$ResultArray['DetailValue']['TotalRows'] = $LastRow;
		$ResultArray['AliasList'] = $AliasList;		
		$ResultArray['AliasHolidayList'] = $AliasHolidayList;		
		/*********- CHECK VALIDATIONS ON TIME KEEPING*******/
		$FindUserId = getvalue("cxs_users","USER_ID"," where RESOURCE_ID = $ResourceId");	
		
		
		$msg = UserValidationsForTE($FindUserId,$PayPeriodId);
		$ResultArray['row']['msg'] = $msg;
		/********* - VALIDATIONS CHECKING COMPLETED ********/
		
		echo json_encode($ResultArray);
	}
	else if($_POST['REQUEST']=='SetDatewiseValue')
	{
		$FinalArray = array();
		//$CurrentDate = isset($_POST['CurrentDate'])?$_POST['CurrentDate']:'';		
		$StartDate = isset($_POST['StartDate'])?$_POST['StartDate']:'';
		$HeaderId = isset($_POST['HeaderId'])?$_POST['HeaderId']:'';
		$PayPeriodId = isset($_POST['PayPeriodId'])?$_POST['PayPeriodId']:'';
		$AliasId = isset($_POST['AliasId'])?$_POST['AliasId']:'';
		$RowNo = isset($_POST['RowNo'])?$_POST['RowNo']:'';
		
		if($CurrentDate!='')
		{
			$CurrentDate = strtotime($CurrentDate);		
			$CurrentDate = date('Y-m-d', $CurrentDate);
		}
		if($StartDate!='')
		{
			$StartDate = strtotime($StartDate);		
			$StartDate = date('Y-m-d', $StartDate);
		}  
		
		if($PayPeriodId!='' && $AliasId!= '' && $RowNo != '')
		{
			for($i=1;$i<=7;$i++)
			{
				$qry = "select * from cxs_te_file where TE_ID = $HeaderId and ALIAS_ID = $AliasId and ROW_NO = $RowNo and ENTRY_DATE = '$StartDate' order by ENTRY_DATE";				
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$ResultArray[] = $row;
				}				
				$StartDate = strtotime('+1 day', strtotime($StartDate));
				$StartDate = date('Y-m-d',$StartDate);
			}
			echo json_encode($ResultArray); 
		}  
	}	
	
	else if($_POST['REQUEST']=='ChangePeriod')	
	{
		$FinalArray = array();
		$weekList[] = array();
		$weekListHiddenValue[] = array();
		$IsAllowEntry[] = array();
		$SiteId = $_SESSION['user-siteid'];	
		$PayPeriodId = $_POST['PayPeriodId'];
		$qry = "select * from cxs_periods inner join cxs_calendars on cxs_calendars.CALENDAR_ID = cxs_periods.CALENDAR_ID where cxs_periods.PERIOD_ID = $PayPeriodId and cxs_periods.SITE_ID = $SiteId and cxs_calendars.SITE_ID = $SiteId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$PeriodType = $row['PERIOD_TYPE'];
			$BeginDate = $row['FROM_PERIOD_DATE'];
			$EndDate = $row['TO_PERIOD_DATE'];
		}
		$FinalArray['qry'] = $qry;
		if($PeriodType!='Weekly')
		{
			$BeginDate = date('Y-m-d',strtotime($BeginDate));			
			if(date('l',strtotime($BeginDate))=='Monday')
			{
				$firstday = strtotime($BeginDate);				
			}
			else										
			{
				$First_Day = date('l',strtotime($BeginDate));
				$FinalArray['First_Day'] = $First_Day;
				if($First_Day=='Saturday' || $First_Day=='Sunday')
				{
					$firstday = strtotime("next Monday",strtotime($BeginDate));
				}
				else
				{
					$firstday = strtotime("last Monday",strtotime($BeginDate));
				}	
			}									
			$lastday = strtotime($firstday.' 6 days');
		}
		else
		{
			$firstday = strtotime($BeginDate);
			$lastday = strtotime($EndDate);
		}
		
		for($i=0;$i<=6;$i++)
		{
			$currentDay = strtotime(date("Y-m-d",$firstday)." +".$i." days");
			$currentDay1 = date("Y-m-d",$currentDay);			
			$qry = "SELECT PERIOD_ID FROM cxs_periods WHERE (FROM_PERIOD_DATE<='$currentDay1'  AND TO_PERIOD_DATE>='$currentDay1' and SITE_ID = $SiteId )";			
			$result = mysql_query($qry);
			while($row = mysql_fetch_array($result))
			{
				if($row['PERIOD_ID']==$PayPeriodId) { $IsAllowEntry[] = "Y";}
				else { $IsAllowEntry[] = "N"; }
			}	
			$weekList[]= date('D, M d, Y', $currentDay);//date("Y-m-d",$currentDay);
			$weekListHiddenValue[]=date("Y-m-d",$currentDay);
		}
		$FinalArray['weekList'] = $weekList;
		$FinalArray['weekListHiddenValue'] = $weekListHiddenValue;		
		$FinalArray['IsAllowEntry'] = $IsAllowEntry;	
		
		echo json_encode($FinalArray);
	}
	
	else if($_POST['REQUEST']=='SaveRecordValidation')
	{
		parse_str($_POST['form'],$formArr);
		
		$ResourceId = $formArr['ResourceId'];
		$TEId = $formArr['hCurrentTEId'];
		$i=1;
		foreach($formArr['h_currentweek'] as $key)
		{	
			if($i==1)
			{
				$FirstDate = $key;
			}
			else if ($i==7)
			{
				$LastDate = $key;
			}
			$i++;
		}
		
		$TotalHours = 0;
		
		$qry = "select cxs_preapp_rules.PREAPPROVAL_TYPE,cxs_preapp_rules.QUOTA_HOURS from cxs_resources inner join cxs_preapp_rules on cxs_preapp_rules.PREAPP_RULE_ID = cxs_resources.PREAPPROVALRULES_ID where RESOURCE_ID = $ResourceId";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$PreApprovalType = $row['PREAPPROVAL_TYPE'];
			$QuotaHours = $row['QUOTA_HOURS'];
		}
		$ResultArray['PreApprovalType'] = $PreApprovalType;
		$ResultArray['QuotaHours'] = $QuotaHours;
		
		if($PreApprovalType == 'Direct Preapproval' && $QuotaHours > 0)
		{
			if($TEId != '')
			{
				$qry = "select sum(HOURS) as TotalHours from cxs_te_file where cxs_te_file.TE_ID = $TEId and not (ENTRY_DATE >= '$FirstDate' and ENTRY_DATE <= '$LastDate')";
				$result = mysql_query($qry);
				while($row = mysql_fetch_array($result))
				{
					$TotalHours = $row['TotalHours'];
				}
			}
		}
		else if($PreApprovalType == 'Task Base Preapproval')
		{
		}
		$ResultArray['TotalHours'] = $TotalHours;
		echo json_encode($ResultArray);
	}
	/*else if ($_POST['REQUEST'] == 'AuditDetails')	{				$PayPeriodId = $_POST['PayPeriodId'];		$ResourceId = $_POST['ResourceId'];		$CurrentTEId = $_POST['CurrentTEId'];		$AuditDate = $_POST['AuditDate'];		$AuditDate = strtotime($AuditDate);		$AuditDate = date("Y-m-d",$AuditDate);		$SiteId = $_SESSION['user-siteid'];				$UserName = getvalue("cxs_users","USER_NAME", "where RESOURCE_ID = $ResourceId");		$PeriodName = getvalue("cxs_periods","PERIOD_NAME", "where PERIOD_ID = $PayPeriodId");				$qry = "select cxs_te_file.ALIAS_ID,cxs_aliases.ALIAS_NAME, cxs_te_file.SEED_ALIAS from cxs_te_file left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID 		where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate'  and cxs_te_file.SITE_ID = $SiteId order by  cxs_te_file.ALIAS_ID,ALIAS_NAME,SEED_ALIAS ";				//$data["qry"] = $qry;			$result = mysql_query($qry);		$TotalAlias=0;		$prev_Alisvalue = "";		while($row = mysql_fetch_array($result))		{			if($row['ALIAS_ID']==0)			{				$AliasValue = $row['SEED_ALIAS'];			}			else			{				$AliasValue = $row['ALIAS_NAME'];			}						if($prev_Alisvalue!=$AliasValue)			{				$TotalAlias++;				if($row['ALIAS_ID']==0)				{					$data['AliasCaption'][] = $row['SEED_ALIAS'];					$data['AliasValue'][] = $row['SEED_ALIAS'];				}				else				{					$data['AliasCaption'][] = $row['ALIAS_NAME'];					$data['AliasValue'][] = $row['ALIAS_ID'];				}			}			$prev_Alisvalue = $AliasValue;			//$data['cxs_te_file'] = $row;		}		$data['TotalAlias'] = $TotalAlias;						$qry = "select * from cxs_period_audit where PERIOD_NAME = '$PeriodName' and USER_NAME = '$UserName' and date(SORT_DATE) = '$AuditDate'";				$result = mysql_query($qry);		while($row = mysql_fetch_array($result))		{			$data['cxs_period_audit'] = $row;		}					$data["UserName"] = $UserName;			echo json_encode($data);			}
		else if ($_POST['REQUEST'] == 'AuditAliasChange')	{				$PayPeriodId = $_POST['PayPeriodId'];		$ResourceId = $_POST['ResourceId'];		$CurrentTEId = $_POST['CurrentTEId'];		$AliasId = $_POST['AliasId'];		$AuditDate = $_POST['AuditDate'];		$AuditDate = strtotime($AuditDate);		$AuditDate = date("Y-m-d",$AuditDate);		$SiteId = $_SESSION['user-siteid'];				$qry = "SELECT cxs_te_file.HOURS,cxs_te_file.STATUS_FLAG,SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,SEGMENT15 from cxs_te_file left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID 		left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate'  and cxs_te_file.ALIAS_ID = $AliasId and cxs_te_file.SITE_ID = $SiteId ORDER BY cxs_te_file.DETAIL_ID desc limit 1 ";				//$data["qry"] = $qry;			$result = mysql_query($qry);				while($row = mysql_fetch_array($result))		{				$data['Hours'] = $row['HOURS'];						if($row['STATUS_FLAG']=="H")			{				$data['StatusFlag'] = "Holiday";			}			elseif($row['STATUS_FLAG']=="S")			{				$data['StatusFlag'] = "Submitted";			}			elseif($row['STATUS_FLAG']=="A")			{				$data['StatusFlag'] = "Approved";			}			elseif($row['STATUS_FLAG']=="R")			{				$data['StatusFlag'] = "Rejected";			}				elseif($row['STATUS_FLAG']=="W")			{				$data['StatusFlag'] = "Working";			}			$WBSValue="";						if($row['SEGMENT1']!='')			{				$WBSValue = $row['SEGMENT1'];			}			if($row['SEGMENT2']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT2'];			}			if($row['SEGMENT3']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT3'];			}			if($row['SEGMENT4']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT4'];			}			if($row['SEGMENT5']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT5'];			}			if($row['SEGMENT6']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT6'];			}			if($row['SEGMENT7']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT7'];			}			if($row['SEGMENT8']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT8'];			}			if($row['SEGMENT9']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT9'];			}			if($row['SEGMENT10']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT10'];			}			if($row['SEGMENT11']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT11'];			}			if($row['SEGMENT12']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT12'];			}			if($row['SEGMENT13']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT13'];			}			if($row['SEGMENT14']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT14'];			}			if($row['SEGMENT15']!='')			{				$WBSValue = $WBSValue.".".$row['SEGMENT15'];			}			$data['WBSValue'] = $WBSValue;		}			echo json_encode($data);	}		
	*/
	else if ($_POST['REQUEST'] == 'AuditDetails')	
	{
		$PayPeriodId = $_POST['PayPeriodId'];
		$ResourceId = $_POST['ResourceId'];	
		$CurrentTEId = $_POST['CurrentTEId'];
		$AuditDate = $_POST['AuditDate'];
		$AuditDate = strtotime($AuditDate);
		$AuditDate = date("Y-m-d",$AuditDate);
		$SiteId = $_SESSION['user-siteid'];				
		$UserName = getvalue("cxs_users","USER_NAME", "where RESOURCE_ID = $ResourceId");		
		$PeriodName = getvalue("cxs_periods","PERIOD_NAME", "where PERIOD_ID = $PayPeriodId");
		
		$qry = "select cxs_te_file.ALIAS_ID,cxs_aliases.ALIAS_NAME, cxs_te_file.SEED_ALIAS ,cxs_daily_audit.EMPLOYEE_NUMBER,
				cxs_daily_audit.EMPLOYEE_NAME FROM cxs_daily_audit left join cxs_te_file on cxs_te_file.DETAIL_ID =cxs_daily_audit.EI_DNORM_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID 
				where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate'  and cxs_te_file.SITE_ID = $SiteId order by  cxs_te_file.ALIAS_ID,ALIAS_NAME,SEED_ALIAS ";				
				$result = mysql_query($qry);
				$TotalAlias=0;
				$prev_Alisvalue = "";
				while($row = mysql_fetch_array($result))
				{
					$data['EMPLOYEE_NUMBER'] = $row['EMPLOYEE_NUMBER'];
					$data['EMPLOYEE_NAME'] = $row['EMPLOYEE_NAME'];
					if($row['ALIAS_ID']==0)
					{
						$AliasValue = $row['SEED_ALIAS'];
					}
					else			
					{
						$AliasValue = $row['ALIAS_NAME'];
					}
					if($prev_Alisvalue!=$AliasValue)
					{
						$TotalAlias++;
						if($row['ALIAS_ID']==0)
						{
							$data['AliasCaption'][] = $row['SEED_ALIAS'];
							$data['AliasValue'][] = $row['SEED_ALIAS'];
						}
						else
						{	
							$data['AliasCaption'][] = $row['ALIAS_NAME'];
							$data['AliasValue'][] = $row['ALIAS_ID'];
						}
					}
					$prev_Alisvalue = $AliasValue;
					
					}
					$data['qry'] = $qry;
					$data['TotalAlias'] = $TotalAlias;					
					$data["UserName"] = $UserName;
					echo json_encode($data);			
		
	}
	else if ($_POST['REQUEST'] == 'AuditAliasChange')	
	{
		$PayPeriodId = $_POST['PayPeriodId'];		
		$ResourceId = $_POST['ResourceId'];		
		$CurrentTEId = $_POST['CurrentTEId'];		
		$AliasId = $_POST['AliasId'];		
		$AuditDate = $_POST['AuditDate'];		
		$AuditDate = strtotime($AuditDate);		
		$AuditDate = date("Y-m-d",$AuditDate);		
		$SiteId = $_SESSION['user-siteid'];		
		if (is_numeric($AliasId))
		{
			$sub_qry1 = " and cxs_te_file.ALIAS_ID = '$AliasId' ";
		}
		else
		{
			$sub_qry1 = " and cxs_te_file.SEED_ALIAS = '$AliasId' ";
		}
		/*$qry = "SELECT cxs_te_file.HOURS,cxs_te_file.STATUS_FLAG,SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,SEGMENT15 from cxs_te_file left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID 
		left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate'  and cxs_te_file.ALIAS_ID = '$AliasId' and cxs_te_file.SITE_ID = $SiteId ORDER BY cxs_te_file.DETAIL_ID desc limit 1 ";				
		*/
		//$qry12 = " left join cxs_aliases on cxs_aliases.ALIAS_NAME = cxs_te_file.SEED_ALIAS ";
		
		/*$qry = "SELECT cxs_te_file.HOURS,cxs_te_file.STATUS_FLAG,SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,SEGMENT15 from cxs_te_file left join cxs_aliases on cxs_aliases.ALIAS_NAME = cxs_te_file.SEED_ALIAS left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID 
		left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate' $sub_qry1 and cxs_te_file.SITE_ID = $SiteId ORDER BY cxs_te_file.DETAIL_ID desc limit 1 ";				
		*/
		$qry = "SELECT cxs_te_file.HOURS,cxs_te_file.STATUS_FLAG as TEStatus,cxs_daily_audit.EMPLOYEE_NUMBER,EMPLOYEE_NAME,EXPENDITURE_QTY,cxs_daily_audit.STATUS_FLAG,cxs_daily_audit.LAST_UPDATE,UPDATEDBY_ENAME,UPDATEDBY_EMPNO,";
		$qry .="SEGMENT1,SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,SEGMENT15 ";
		$qry .="from cxs_daily_audit left join cxs_te_file on cxs_te_file.DETAIL_ID =cxs_daily_audit.EI_DNORM_ID left join cxs_aliases on cxs_aliases.ALIAS_ID = cxs_te_file.ALIAS_ID ";
		$qry .="left join cxs_wbs on cxs_wbs.WBS_ID = cxs_aliases.WBS_ID  ";
		$qry .="where  TE_ID = '$CurrentTEId'  and RESOURCE_ID = $ResourceId and PERIOD_ID = '$PayPeriodId' and ENTRY_DATE = '$AuditDate' $sub_qry1 and cxs_te_file.SITE_ID = $SiteId order by cxs_daily_audit.LAST_UPDATE desc ";		
		//$data["qry"] = $qry;
		$TotalRecords=0;
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))		
		{				
			$data['Hours'] = $row['HOURS'];	
			if($row['TEStatus']=="H"){ $data['StatusFlag'] = "Holiday";	}
			elseif($row['TEStatus']=="S"){ $data['StatusFlag'] = "Submitted";}
			elseif($row['TEStatus']=="A"){ $data['StatusFlag'] = "Approved"; }
			elseif($row['TEStatus']=="R"){ $data['StatusFlag'] = "Rejected";}				
			elseif($row['TEStatus']=="W"){ $data['StatusFlag'] = "Working";	}	
			
			$WBSValue="";		
			if($row['SEGMENT1']!='') {	$WBSValue = $row['SEGMENT1'];}
			if($row['SEGMENT2']!='') { $WBSValue = $WBSValue.".".$row['SEGMENT2'];	}
			if($row['SEGMENT3']!='') { $WBSValue = $WBSValue.".".$row['SEGMENT3'];			}
			if($row['SEGMENT4']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT4'];			}
			if($row['SEGMENT5']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT5'];			}
			if($row['SEGMENT6']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT6'];			}
			if($row['SEGMENT7']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT7'];			}
			if($row['SEGMENT8']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT8'];			}
			if($row['SEGMENT9']!='') {	$WBSValue = $WBSValue.".".$row['SEGMENT9'];			}
			if($row['SEGMENT10']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT10'];		}
			if($row['SEGMENT11']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT11'];		}
			if($row['SEGMENT12']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT12'];		}
			if($row['SEGMENT13']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT13'];		}
			if($row['SEGMENT14']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT14'];		}
			if($row['SEGMENT15']!=''){	$WBSValue = $WBSValue.".".$row['SEGMENT15'];		}
			$data['WBSValue'] = $WBSValue;	
			
			$data[] = $row;				

			$TotalRecords++;
	}
			$data['TotalRecords'] = $TotalRecords;	
			//$qry = " SELECT * FROM `cxs_daily_audit` left join cxs_te_file on cxs_te_file.DETAIL_ID = cxs_daily_audit.EI_DNORM_ID WHERE Employee_Number = $ResourceId and EXPENDITURE_DATE = '$AuditDate' and cxs_daily_audit.SITE_ID = $SiteId and cxs_te_file.ALIAS_ID =  ";				
		
			echo json_encode($data);	
	}		
	function InsertPeriodAudit($DetailId,$PreApprovalType,$Status)
	{
		$insArr1 = array();
		$qry = "select cxs_te_file.*,cxs_resources.FIRST_NAME,cxs_resources.MIDDLE_NAME ,cxs_resources.LAST_NAME,cxs_periods.PERIOD_NAME,
		( select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_te_file.LAST_UPDATED_BY ) as UserName,
		( select cxs_users.RESOURCE_ID from cxs_users where cxs_users.USER_ID = cxs_te_file.CREATED_BY ) as CreateBy_EmpNo,
		( select cxs_users.RESOURCE_ID from cxs_users where cxs_users.USER_ID = cxs_te_file.LAST_UPDATED_BY ) as UpdatedBy_EmpNo
		from cxs_te_file Inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_te_file.RESOURCE_ID 
		Inner join cxs_periods on cxs_periods.PERIOD_ID = cxs_te_file.PERIOD_ID where DETAIL_ID = $DetailId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$FullName = $row['FIRST_NAME'].' ';
			if($row['MIDDLE_NAME']!='')
			{
				$FullName .= $row['MIDDLE_NAME'].' ';
			}
			$FullName .= $row['LAST_NAME'];
			if($PreApprovalType!='' && $Status=="A")
			{
				$ExpStatus = "PreApproved";
			}
			else
			{
				if($Status=="W")
				{
					$ExpStatus = "SAVED";
				}
				else if($Status=="S")
				{
					$ExpStatus = "SUBMITTED";
				}
				else if($Status=="A")
				{
					$ExpStatus = "APPROVED";
				}
				else if($Status=="R")
				{
					$ExpStatus = "REJECTED";
				}
			}
			
			$insArr1['SORT_DATE']=$row['CREATION_DATE'];
			$insArr1['EI_NORM_ID']=$row['TE_ID'];			
			$insArr1['EXP_STATUS']=$ExpStatus;			
			$insArr1['UPDATE_DATE']=$row['LAST_UPDATE_DATE'];							
			$insArr1['FULL_NAME']=$FullName;							
			$insArr1['EMPLOYEE_NUMBER']=$row['RESOURCE_ID'];							
			$insArr1['PERIOD_NAME']=$row['PERIOD_NAME'];							
			$insArr1['USER_NAME']=$row['UserName'];
			$insArr1['SITE_ID']=$row['SITE_ID'];			
			insertdata('cxs_period_audit',$insArr1);			
		}
	}
	
	function InsertDailyAudit($DetailId,$PreApprovalType,$Status,$OldHours)
	{
		$insArr1 = array();
		$qry = "select cxs_te_file.*,cxs_resources.FIRST_NAME,cxs_resources.MIDDLE_NAME ,cxs_resources.LAST_NAME,cxs_periods.PERIOD_NAME,
		( select cxs_users.USER_NAME from cxs_users where cxs_users.USER_ID = cxs_te_file.LAST_UPDATED_BY ) as UserName,
		( select cxs_users.RESOURCE_ID from cxs_users where cxs_users.USER_ID = cxs_te_file.CREATED_BY ) as CreateBy_EmpNo,
		( select cxs_users.RESOURCE_ID from cxs_users where cxs_users.USER_ID = cxs_te_file.LAST_UPDATED_BY ) as UpdatedBy_EmpNo
		from cxs_te_file Inner join cxs_resources on cxs_resources.RESOURCE_ID = cxs_te_file.RESOURCE_ID 
		Inner join cxs_periods on cxs_periods.PERIOD_ID = cxs_te_file.PERIOD_ID where DETAIL_ID = $DetailId ";
		$result = mysql_query($qry);
		while($row = mysql_fetch_array($result))
		{
			$FullName = $row['FIRST_NAME'].' ';
			if($row['MIDDLE_NAME']!='')
			{
				$FullName .= $row['MIDDLE_NAME'].' ';
			}
			$FullName .= $row['LAST_NAME'];
			if($PreApprovalType!='' && $Status=="A")
			{
				$ExpStatus = "PreApproved";
			}
			else
			{
				if($Status=="W")
				{
					$ExpStatus = "SAVED";
				}
				else if($Status=="S")
				{
					$ExpStatus = "SUBMITTED";
				}
				else if($Status=="A")
				{
					$ExpStatus = "APPROVED";
				}
				else if($Status=="R")
				{
					$ExpStatus = "REJECTED";
				}
			}	
			$CreatedById = $row['CreateBy_EmpNo'];
			$UpdatedById = $row['UpdatedBy_EmpNo'];
			
			$qry1 = "select FIRST_NAME, LAST_NAME from cxs_resources where RESOURCE_ID = $CreatedById ";
			$result1 = mysql_query($qry1);
			while($row1 = mysql_fetch_array($result1))
			{
				$CreatedByEName = $row1['FIRST_NAME'].' '.$row1['LAST_NAME'];
			}
			
			$qry1 = "select FIRST_NAME, LAST_NAME from cxs_resources where RESOURCE_ID = $UpdatedById ";
			$result1 = mysql_query($qry1);
			while($row1 = mysql_fetch_array($result1))
			{
				$UpdatedByEName = $row1['FIRST_NAME'].' '.$row1['LAST_NAME'];
			}
			
			$insArr1['EMPLOYEE_NUMBER']=$row['RESOURCE_ID'];
			$insArr1['EMPLOYEE_NAME']=$FullName;	
			$insArr1['CREATEDBY_EMPNO']=$row['CreateBy_EmpNo'];
			$insArr1['UPDATEDBY_EMPNO']=$row['UpdatedBy_EmpNo'];			
			$insArr1['CREATEDBY_ENAME']=$CreatedByEName;			
			$insArr1['UPDATEDBY_ENAME']=$UpdatedByEName; 
			
			$insArr1['EI_NORM_ID']=$row['APPROVAL_ID'];							
			$insArr1['EI_DNORM_ID']=$row['DETAIL_ID'];
			$insArr1['CREATION_DATE']=$row['CREATION_DATE'];			
			
			$insArr1['EXPENDITURE_QTY']=$OldHours;//$row['HOURS'];							
			$insArr1['STATUS_FLAG']=$ExpStatus;
			$insArr1['EXPENDITURE_DATE']=$row['ENTRY_DATE'];
			$insArr1['LAST_UPDATE']=$row['LAST_UPDATE_DATE'];
			$insArr1['SITE_ID']=$row['SITE_ID'];
			$insArr1['ROW_NO']=$row['ROW_NO'];			
			insertdata('cxs_daily_audit',$insArr1);
			
		}
	}	
?>