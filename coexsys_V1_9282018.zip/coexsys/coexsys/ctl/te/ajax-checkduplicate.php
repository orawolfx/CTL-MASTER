<?php
include('../conn.php');
?>

<?php
if($_REQUEST['REQUEST'] == "CheckResourceGroup") //resource-group.php
{
	$ResourceGroup = $_REQUEST['resourcegroup'];	
	$ResourceGroupId = $_REQUEST['selectedid'];
	
	if($ResourceGroupId != '')
	{
		 $Query = "SELECT * FROM cxs_resource_groups WHERE RESOURCE_GROUP_NAME ='$ResourceGroup' and RESOURCE_GROUP_ID <> $ResourceGroupId ";		
	}
	else
	{
		$Query = "SELECT * FROM cxs_resource_groups WHERE RESOURCE_GROUP_NAME ='$ResourceGroup' ";		
	}	
	if($Query != '')	
	{
		$Result = mysql_query($Query);
		$result_row = mysql_num_rows($Result);
		if($result_row != 0)
		{
			echo 'Resource Group Already Exists. Enter Different Name.';
		}
		else
		{
			echo '';
		}
	}
}
?>


<?php
/*if($_REQUEST['REQUEST'] == "CheckAccountingPeriod") //accounting-periods.php
{
	$CalendarName = $_REQUEST['CalendarName'];	
	$CalendaIdId = $_REQUEST['selectedid'];
	
	if($PeriodId != '')
	{
		 $Query = "SELECT * FROM cxs_calendars WHERE NAME ='$CalendarName' and CALENDAR_ID <> $CalendaIdId ";		
	}
	else
	{
		 $Query = "SELECT * FROM cxs_calendars WHERE NAME ='$CalendarName' ";		
	}	
	if($Query != '')	
	{
		$Result = mysql_query($Query);
		$result_row = mysql_num_rows($Result);
		if($result_row != 0)
		{
			echo 'Period Name Already Exists. Enter Different Name.';
		}
		else
		{
			echo '';
		}
	}
}*/

?>

<?php
if($_REQUEST['REQUEST'] == "CheckDuplicate") //every page
{
	$TableName = $_REQUEST['TableName'];
	$FieldName = $_REQUEST['FieldName'];	
	$FieldValue = $_REQUEST['FieldValue'];	
	$FieldId = $_REQUEST['FieldId'];
	$SelectedId = $_REQUEST['SelectedId'];
	$SiteId = $_SESSION['user-siteid'];
	
	if($SelectedId != '')
	{
		$Query = "SELECT * FROM $TableName WHERE $FieldName ='$FieldValue' and $FieldId <> $SelectedId and SITE_ID = $SiteId";				
	}
	else
	{
		$Query = "SELECT * FROM $TableName WHERE $FieldName ='$FieldValue' and SITE_ID = $SiteId";				
	}	
	if($Query != '')	
	{
		$Result = mysql_query($Query);
		$result_row = mysql_num_rows($Result);
		if($result_row != 0)
		{
			//echo 'Period Name Already Exists. Enter Different Name.';
			echo 'Do not allow duplicate entry.';
		}
		else
		{
			echo '';
		}
	}
}

	else if($_REQUEST['REQUEST'] == "AccountingPeriodOverlap")
	{
		$Text_CalendarName = $_REQUEST['Text_CalendarName'];
		$Text_PeriodYear = $_REQUEST['Text_PeriodYear'];
		$HeaderId = $_REQUEST['HeaderId'];
		$TotalRows = isset($_REQUEST['h_NumRows'])?$_REQUEST['h_NumRows']:0;
		$SiteId = $_SESSION['user-siteid']; 
		if($HeaderId!='')
		{
			$qry = "select * from cxs_calendars where cxs_calendars.SITE_ID = $SiteId and ( NAME = '$Text_CalendarName' or PERIOD_YEAR = '$Text_PeriodYear') and CALENDAR_ID != $HeaderId";
		}
		else
		{
			$qry = "select * from cxs_calendars where  cxs_calendars.SITE_ID = $SiteId and ( NAME = '$Text_CalendarName' or PERIOD_YEAR = '$Text_PeriodYear')";
		}
		
		$result = mysql_query($qry);
		$noofrows = mysql_num_rows($result);
		if($noofrows>0)
		{
			$msg = "Calendar or Period";
		}
		if ($msg=='')
		{
			$condition1 = substr($Text_PeriodYear,0,4);
			for($i=1;$i<=$TotalRows;$i++)
			{
				$Text_StartDate = isset( $_POST['Text_StartDate'.$i] )? $_POST['Text_StartDate'.$i]: false;
				$Text_EndDate = isset( $_POST['Text_EndDate'.$i] )? $_POST['Text_EndDate'.$i]: false;
				//$h_PeriodId = isset( $_POST['h_PeriodId'.$i] )? $_POST['h_PeriodId'.$i]: false;
				if($Text_StartDate!='' && $Text_EndDate!= '')
				{
					$Text_StartDate = date("Y/m/d", strtotime($Text_StartDate));
					$Text_EndDate = date("Y/m/d", strtotime($Text_EndDate));
					if ($HeaderId!='')
					{
						$qry="select * from cxs_periods where cxs_periods.SITE_ID = $SiteId and PERIOD_YEAR like '%$condition1%'  and ((FROM_PERIOD_DATE >= '$Text_StartDate' and FROM_PERIOD_DATE <= '$Text_EndDate') or (TO_PERIOD_DATE>='$Text_StartDate' and TO_PERIOD_DATE <= '$Text_EndDate')) and CALENDAR_ID != $HeaderId";
					}
					else
					{
						$qry="select * from cxs_periods where cxs_periods.SITE_ID = $SiteId and PERIOD_YEAR like '%$condition1%'  and ((FROM_PERIOD_DATE >= '$Text_StartDate' and FROM_PERIOD_DATE <= '$Text_EndDate') or (TO_PERIOD_DATE>='$Text_StartDate' and TO_PERIOD_DATE <= '$Text_EndDate'))";
					}					
					$result=mysql_query($qry);
					$noofrows=mysql_num_rows($result);
					if($noofrows > 0)
					{
						$msg = "Yes";
						break;
					}		
				}
			}
		}
		if($msg=='')
		{
			$msg = "No";
		}
		echo $msg;
	}
?>