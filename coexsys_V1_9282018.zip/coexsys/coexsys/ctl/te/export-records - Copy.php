<?php
include('../conn.php');
error_reporting(E_ALL);
ini_set("display_errors", "ON");
require_once '../lib/PHPExcel.php';
require_once '../lib/PHPExcel/IOFactory.php';
/*$heading = array('FIRST_NAME' => 'FIRST NAME','LAST_NAME' => 'LAST NAME',		    
					'RESOURCE_TYPE' => 'RESOURCE TYPE','START_DATE_ACTIVE' => 'START DATE ACTIVE',
					'END_DATE_ACTIVE' => 'END DATE ACTIVE','SUPERVISOR' => 'Superviosr',);
	*/
//$xls_filename = 'Data' . date('d-m-Y') . '.xls'; // Define Excel (.xls) file name

	$TableName = $_GET['TableName'];
	//$ExportIdList = $_GET['ExportIdList'];

	$heading = $_SESSION['ExportHeadings'];
	$ExportQryFieldName = $_SESSION['ExportQryFieldName'];
	$ExportIdList = $_SESSION['ExportIdList'];
	$ExportOrderBy = $_SESSION['ExportOrderBy'];

	$columns = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ','BA','BB','BC','BD','BE','BF','BG','BH','BI','BJ','BK','BL','BM','BN','BO','BP','BQ','BR','BS','BT','BU','BV','BW','BX','BY','BZ','CA','CB','CC','CD','CE','CF','CG','CH','CI','CJ','CK','CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU','CV','CW','CX','CY','CZ');
	$objPHPExcel = new PHPExcel();
	$xls_filename = date('m-d-Y');
	$SiteId = $_SESSION['user-siteid'];
	$query_1="";
	
	$rw=1;
	$objPHPExcel->setActiveSheetIndex(0);
	$col=0;
	foreach($heading as $hd)
	{
		$objPHPExcel->getActiveSheet()->getRowDimension($rw)->setRowHeight(20);   
		$objPHPExcel->getActiveSheet()->getColumnDimension($columns[$col])->setWidth(15);
		$objPHPExcel->getActiveSheet()->setCellValue($columns[$col].$rw, $hd);
		$col++;   
	}
	
	
	if($TableName=='cxs_resources')
	{
		$xls_filename .= '_resource-management.xls';
	
		foreach($ExportIdList as $id)
		{
			$query_1 .= $ExportQryFieldName.' = '.$id.' or ';
		}
		$query_1 = "and ( ".substr($query_1,0,-3).") ";
		
		//$sql = "SELECT * FROM $TableName where SITE_ID = $SiteId $query_1 $ExportOrderBy";
		$sql = "select a.FIRST_NAME,a.LAST_NAME,a.RESOURCE_TYPE,a.START_DATE_ACTIVE,a.END_DATE_ACTIVE,concat (cxs_resources.FIRST_NAME,cxs_resources.LAST_NAME) as SupervisorName from (
				SELECT FIRST_NAME,LAST_NAME,RESOURCE_TYPE,START_DATE_ACTIVE,END_DATE_ACTIVE,SUPREVISOR_ID  FROM cxs_resources 
				where cxs_resources.SITE_ID = $SiteId $query_1 $ExportOrderBy
				) as a left join cxs_resources on cxs_resources.RESOURCE_ID = a.SUPREVISOR_ID";		
		$res = mysql_query($sql);
		while($row=mysql_fetch_array($res))
		{   
			$col=0;
			$rw++;			
			$StartDate= "";
			$EndDate= "";
			
			if((!is_null($row['START_DATE_ACTIVE'])) && (($row['START_DATE_ACTIVE'])!='0000-00-00') )
			{			
				$StartDate = date('m/d/Y', strtotime($row['START_DATE_ACTIVE']));
			}
			if((!is_null($row['END_DATE_ACTIVE'])) && (($row['END_DATE_ACTIVE'])!='0000-00-00') )
			{			
				$EndDate = date('m/d/Y', strtotime($row['END_DATE_ACTIVE']));
			}	
			$FirstCol = $heading[0];	
			$objPHPExcel->getActiveSheet()->getRowDimension($rw)->setRowHeight(22);   	
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col].$rw, $row[$col++]);		
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++].$rw, $row['LAST_NAME']);		
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++].$rw, $row['RESOURCE_TYPE']);		
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++].$rw, $StartDate);		
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++].$rw, $EndDate);			
			$objPHPExcel->getActiveSheet()->setCellValue($columns[$col++].$rw, $row['SupervisorName']);
		}
		$objPHPExcel->getActiveSheet()->setTitle('Resource Management');
	}
	
	
unset($_SESSION['ExportIdList']);
unset($_SESSION['ExportOrderBy']);

// Redirect output to a clients web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename='.$xls_filename);  
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
?>