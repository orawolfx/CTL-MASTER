<?php ob_start ();
	 	
	include("te-functions.php");
	check_login(); 
?>
<?php
 	$LoginUserId = $_SESSION['user_id'];
	$SiteId = $_SESSION['user-siteid'];
	$PageName = "te.php";	
?>
<script type="text/javascript" >
	function CheckFavoriteData()
	{	
		KEY = "CheckFavoriteData";			
		var s1 = "Dashboard - Time Entry";		
		var s2 = "<?php echo $PageName; ?>";				
		//makeRequest("ajax.php","REQUEST=FavoritesList&FeatureName=" +s1+"&PageName="+s2);
		$.ajax({
			url:"ajax.php",
			method:"POST",
			data:{REQUEST:"FavoritesList",FeatureName:s1,PageName:s2},
			success:function(response)
			{	
				var s1 = response.trim();					
				var str = s1;
				var n;
				n = str.lastIndexOf("No");					
				if (n>=0)//(s1=="No")
				{
					document.getElementById("cmdFavorites").style.backgroundColor = "#f0ad4e";
					s1 = str.substring(0,n);											
				}
				else
				{
					document.getElementById("cmdFavorites").style.backgroundColor = "#000";						
				}					
				document.getElementById("favorite_list").innerHTML = s1;				
			}
		});
		
		
	}
</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Coexsys Time Accounting</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<!-- font-awasome-->
<link href="../css/font-awesome.min.css" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- custom-css -->
<link href="../css/style.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />

	
	<script src="../js/jquery.min.js"></script> 
	<script src="../js/jquery-ui.js"></script>	
	<script src="../js/bootstrap.min.js"></script>
    <script src="../js/custom.js" type="text/javascript"></script>
	<script src="../js/jsfunctions.js" type="text/javascript"></script>
	<script src="../livesearch/bootstrap-select.min.js"></script>	
	
<!--
<script src="../datepicker/jquery.js"></script>
<link href="../datepicker/datepicker.css" rel="stylesheet">
<script src="../datepicker/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="../livesearch/bootstrap-select.min.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
-->	 
	
</head>
<body>
<?php include("header.php"); 
?>
<section class="md-bg">
	<div class="container-fluid">
		<div class="row">
			<div class="brd-crmb">
				<ul><li> <a href="#"> </a></li></ul>
			</div>
			<div class="dash-strip">
				<div class="fleft cr-user"> <a href="te.php"> <button type="button" class="btn btn-primary dash"> Dashboard </button>  </a> </div>
				<div class="fright">
					 <?php
						$qry = "select * from cxs_users_favorites where USER_ID = $LoginUserId and PAGE_NAME ='$PageName' AND MODULE_NAME = '$ModuleName'";
						$result=mysql_query	($qry);
						$TotalRecords = mysql_num_rows($result);
						if($TotalRecords == 0)
						{
							$s_Style = "";
						}
						else
						{
							$s_Style = "background-color: #000;";
						}
					?>          
				  <button type="button" id = "cmdFavorites" name = "cmdFavorites" onclick = "CheckFavoriteData();" class="btn btn-warning fav-ico" style = "<?php echo $s_Style;?>"> <i class="fa fa-star"></i></button>
				</div>
			</div>
			<div class="cont-box">
				<div class="pge-hd"> </div>
				<?php include("../supervisor-dashboard.php"); //include("../supervisor-dashboard.php"); ?>	
			</div>
		</div>
	</div>
	
	
</section>

</body>
</html>