<?php // RAY_temp_happysunny.php
error_reporting(E_ALL);

// GENERATE THE ISO-8601 DATETIME STRING
//$mydate = date('c', strtotime('-5 days'));


$mydate = date('m/d/Y', strtotime('-5 days'));
// CREATE A NON-STANDARD DATETIME STRING
$todaysdate=date("m/d/Y");
$mydate1=strtotime($mydate);
$todaysdate1=strtotime($todaysdate);

	
if ($todaysdate1>=$mydate1)
{
echo "$todaysdate IS Equal or greater $mydate";
}
else
{
// FALSE STATEMENT
echo "$todaysdate IS less $mydate";
}

/*
if ($todaysdate>=$mydate)
{
echo "$todaysdate IS Equal or greater $mydate";
}
else
{
// FALSE STATEMENT
echo "$todaysdate IS less $mydate";
}*/
