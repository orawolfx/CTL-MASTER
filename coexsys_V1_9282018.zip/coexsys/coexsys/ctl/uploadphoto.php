<style>

</style>
<!--Upload Photo modals start -->
	   
		<div class="modal fade custom-modal" id = "ModalUploadPhoto" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-lg cus-modal-lg" role="document" style="width: 525px;">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title " id="myModalLabel" style = "text-align: left;"> Upload Picure </h4>						
					</div>
					<div class="modal-body">
						<form id="cropimage" method="post" enctype="multipart/form-data" action="../change-profile-img.php">
							<div class="col-sm-12" style = "text-align: left;">
								Upload your image 
								<input type="file" name="photoimg" id="photoimg" />
								<input type="hidden" name="hdn-profile-id" id="hdn-profile-id" value="<?php echo $_SESSION['user_id']; ?>" />
							</div>
							<div class="col-sm-12" id="previewProfileImg" style="display: none;">
								<img id="imgProfilePreview" src="#">
							</div>
							<div class="col-sm-12">
								 <div id='preview-avatar-profile' style="max-width: 250px;"></div>
								 <div id="thumbs" style="padding:5px; width:600p"></div>
							</div>
							<div class="col-sm-12" id="img-upl-msg"></div>
						</form>
					</div>
					<div class="clear-both"></div>
					<div class="modal-footer cr-user">						  
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="button" id="btn-crop" class="btn btn-primary">Save</button>
					</div>
				</div>
			</div>
		</div>
	
    <!--Upload Photo modals end -->
	
<script>
function uploadProfilePhotoModal()
{
	$("#photoimg").val('');
	$("#preview-avatar-profile").html('');
	$("#previewProfileImg").css("display", "none");
	$('#imgProfilePreview').attr('src', '#');
	$('#ModalUploadPhoto').modal();
}
function readURL(input) {
	
	$("#previewProfileImg").css("display", "none");
	$("#preview-avatar-profile").html('');
	$('#imgProfilePreview').attr('src', '#');
	
	var ValidImageTypes = ["image/jpg", "image/jpeg", "image/png"];
	
	if (input.files && input.files[0]) {
	
		if($.inArray(input.files[0]["type"], ValidImageTypes) < 0)
		{
			$("#preview-avatar-profile").html('<span style="color:red">Please upload an image file.</span>');
			$("#btn-crop").attr('disabled','disabled');
		}
		else
		{
			var reader = new FileReader();

			reader.onload = function(e) {
				var image = new Image();
				image.src = e.target.result;
				image.onload = function () {
					var height = this.height;
					var width = this.width;
					//alert(this.type); if (height > 1500 || width > 1500) 
					if (height > 1000 || width > 1000) 					
					{
						$("#preview-avatar-profile").html('<span style="color:red">Height and Width must not exceed 450px.</span>');
						$("#btn-crop").attr('disabled','disabled');
						//return false;
					}
					else
					{
						$("#previewProfileImg").css("display", "block");
						$('#imgProfilePreview').attr('src', e.target.result);
						$("#btn-crop").removeAttr('disabled');
					}
			     };
			}
		
			reader.readAsDataURL(input.files[0]);
		}
	}
}
$("#photoimg").change(function() 
{
  readURL(this);
});
/*$('#photoimg').change( function(){*/
jQuery('#btn-crop').on('click', function(e){
	
	if ($("#photoimg").val()=='') {
		$("#preview-avatar-profile").html('<span style="color:red">Please upload an image.</span>');
	}
	else
	{
		var form_data = new FormData();
		var ins = document.getElementById('photoimg').files.length;
		for (var x = 0; x < ins; x++) {
			form_data.append("photoimg", document.getElementById('photoimg').files[x]);
		}
		var csrf_token = $("input[name=_token]").val();
    
    
		var hdn_profile_id = $('#hdn-profile-id').val();
    
		form_data.append("hdn-profile-id", hdn_profile_id);
    
		jQuery.ajax({
			url: '../change-profile-img.php', // point to server-side PHP script 
			dataType: 'text', // what to expect back from the PHP script
			cache: false,
			contentType: false,
			processData: false,
			async: false,
			data: form_data,
			type: 'POST',
			success: function (response) {
				var res = response.split('|');				
				$('.pro-img-bx').attr('src',res[1]);
				$("#preview-avatar-profile").html('<span style="color:green">Profile image updated successfully.</span>');
			
				setTimeout(function(){
					$('#ModalUploadPhoto').modal('toggle');
				}, 2000);            
			},
			error: function (response) {
			    //$('#fileMsg').html(response); // display error response from the PHP script
				//alert(response);
			}
			//return filePath;
		});
	}
	/*$("#preview-avatar-profile").html('');
	$("#preview-avatar-profile").html('Uploading....');
	$("#img-upl-msg").text('');
	$("#cropimage").ajaxForm(
	{
		target: '#preview-avatar-profile',
		success:    function(data) {
		
			alert(data);
			$("#img-upl-msg").html('Image updated successfully.');
	    }
	}).submit();
	*/
});
</script>
